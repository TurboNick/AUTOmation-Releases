<?php
/**
 * The send API: everything between "send this" and the connector.
 *
 * @package AUTOmation_Comms
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Orchestrates a send: build the context, render the template, find the
 * recipient, check the dry-run gate, hand off to the active connector, record
 * the result.
 *
 * All of that policy lives here rather than in the connectors so it stays
 * identical for every route. A connector only delivers.
 */
class AMAC_Comms {

	/**
	 * Log channel for core's AMAT_Log. One slug for the plugin; the Logs page
	 * filters by it. (Core's own log docblock anticipates this one — it names
	 * "a customer email that was sent" as a thing the log is for.)
	 */
	const CHANNEL = 'comms';

	/**
	 * Option holding the dry-run flag.
	 */
	const DRY_RUN_OPTION = 'amat_comms_dry_run';

	/**
	 * Whether dry-run mode is on.
	 *
	 * DEFAULTS TO ON, deliberately. A mis-sent Wave push creates a draft you can
	 * delete; a mis-sent message reaches a real customer and cannot be recalled.
	 * So the plugin will not deliver anything until someone turns delivery on
	 * explicitly, having seen the previews. The gate is enforced here, in the one
	 * path every send goes through — not in the UI, and not left to each
	 * connector to remember.
	 *
	 * @return bool
	 */
	public static function is_dry_run() {
		return '1' === (string) get_option( self::DRY_RUN_OPTION, '1' );
	}

	/**
	 * Render (and optionally send) a message about a core document.
	 *
	 * @param array{
	 *     entity_type:string,
	 *     entity_id:int,
	 *     channel:string,
	 *     message_type?:string,
	 *     recipient?:string,
	 *     preview_only?:bool
	 * } $args Send arguments.
	 * @return array{status:string,message:string,subject?:string,body?:string,recipient?:string,message_id?:int}
	 *         status is 'success', 'error' or 'preview'.
	 */
	public static function send_document( array $args ) {
		$entity_type  = (string) ( $args['entity_type'] ?? '' );
		$entity_id    = (int) ( $args['entity_id'] ?? 0 );
		$channel      = (string) ( $args['channel'] ?? '' );
		$preview_only = ! empty( $args['preview_only'] );

		if ( ! AMAC_Channels::is_valid( $channel ) ) {
			return self::error( __( 'Unknown message channel.', 'auto-mation' ) );
		}

		$context = self::document_context( $entity_type, $entity_id );
		if ( is_wp_error( $context ) ) {
			return self::error( $context->get_error_message() );
		}

		$customer_id = (int) $context['_customer_id'];
		unset( $context['_customer_id'] );

		// Message type: the caller's, else the first one defined for this entity.
		$message_type = (string) ( $args['message_type'] ?? '' );
		if ( '' === $message_type ) {
			$types        = AMAC_Templates::types_for_entity( $entity_type );
			$message_type = $types ? $types[0] : '';
		}
		if ( ! AMAC_Templates::is_valid_type( $message_type ) ) {
			return self::error( __( 'No message template applies to this record.', 'auto-mation' ) );
		}

		$rendered = AMAC_Templates::render( $message_type, $channel, $context );

		// Recipient: explicit, else the customer's preferred address for this
		// channel (contact methods are stored in the customer's own priority
		// order, so "first usable" is their stated preference).
		$recipient = trim( (string) ( $args['recipient'] ?? '' ) );
		if ( '' === $recipient ) {
			$recipient = AMAC_Channels::address_for( $customer_id, $channel );
		}

		if ( $preview_only ) {
			return array(
				'status'    => 'preview',
				'message'   => '',
				'subject'   => $rendered['subject'],
				'body'      => $rendered['body'],
				'recipient' => $recipient,
			);
		}

		if ( '' === $recipient ) {
			return self::error(
				AMAC_Channels::EMAIL === $channel
					? __( 'This customer has no email contact method.', 'auto-mation' )
					: __( 'This customer has no contact method that accepts texts. (A "Call Only" number is not textable.)', 'auto-mation' )
			);
		}

		$connector = AMAC_Connector_Registry::active( $channel );
		if ( ! $connector ) {
			return self::error( __( 'No delivery connector is selected for this channel. Choose one in Settings → Comms.', 'auto-mation' ) );
		}
		if ( ! $connector->is_configured() ) {
			$hint = $connector->config_hint();
			return self::error(
				sprintf(
					/* translators: 1: connector label, 2: reason it isn't ready. */
					__( '%1$s is not configured: %2$s', 'auto-mation' ),
					$connector->label(),
					'' !== $hint ? $hint : __( 'check its settings', 'auto-mation' )
				)
			);
		}

		$row = array(
			'channel'      => $channel,
			'connector'    => $connector->slug(),
			'message_type' => $message_type,
			'customer_id'  => $customer_id,
			'entity_type'  => $entity_type,
			'entity_id'    => $entity_id,
			'recipient'    => $recipient,
			'subject'      => $rendered['subject'],
			'body'         => $rendered['body'],
			'external_id'  => '',
		);

		// The dry-run gate. The message is fully rendered and recorded — so the
		// trail shows exactly what would have gone out — but never delivered.
		if ( self::is_dry_run() ) {
			$row['status']  = AMAC_Message_Model::STATUS_DRY_RUN;
			$row['sent_at'] = '';
			$message_id     = (int) AMAC_Message_Model::create( $row );

			AMAT_Log::info(
				self::CHANNEL,
				sprintf(
					/* translators: 1: channel label, 2: recipient. */
					__( 'Dry run: %1$s to %2$s was rendered but not sent.', 'auto-mation' ),
					AMAC_Channels::label( $channel ),
					$recipient
				),
				array(
					'entity_type' => $entity_type,
					'entity_id'   => $entity_id,
					'context'     => array( 'message_type' => $message_type ),
				)
			);

			return array(
				'status'     => 'success',
				'message'    => sprintf(
					/* translators: %s: recipient address. */
					__( 'Dry run — nothing was sent. The message for %s was recorded so you can review it. Turn off dry-run mode in Settings → Comms to send for real.', 'auto-mation' ),
					$recipient
				),
				'subject'    => $rendered['subject'],
				'body'       => $rendered['body'],
				'recipient'  => $recipient,
				'message_id' => $message_id,
			);
		}

		$result = $connector->send( $recipient, $rendered, $row );

		$sent            = AMAC_Message_Model::STATUS_SENT === ( $result['status'] ?? '' );
		$row['status']   = $sent ? AMAC_Message_Model::STATUS_SENT : AMAC_Message_Model::STATUS_FAILED;
		$row['error']    = $sent ? '' : (string) ( $result['message'] ?? '' );
		$row['sent_at']  = $sent ? current_time( 'mysql' ) : '';
		$row['external_id'] = (string) ( $result['external_id'] ?? '' );

		$message_id = (int) AMAC_Message_Model::create( $row );

		if ( $sent ) {
			AMAT_Log::info(
				self::CHANNEL,
				sprintf(
					/* translators: 1: channel label, 2: recipient. */
					__( 'Sent %1$s to %2$s.', 'auto-mation' ),
					AMAC_Channels::label( $channel ),
					$recipient
				),
				array(
					'entity_type' => $entity_type,
					'entity_id'   => $entity_id,
					'context'     => array(
						'message_type' => $message_type,
						'connector'    => $connector->slug(),
					),
				)
			);

			return array(
				'status'     => 'success',
				'message'    => sprintf(
					/* translators: 1: channel label, 2: recipient. */
					__( '%1$s sent to %2$s.', 'auto-mation' ),
					AMAC_Channels::label( $channel ),
					$recipient
				),
				'recipient'  => $recipient,
				'message_id' => $message_id,
			);
		}

		AMAT_Log::error(
			self::CHANNEL,
			sprintf(
				/* translators: 1: channel label, 2: recipient, 3: reason. */
				__( 'Failed to send %1$s to %2$s: %3$s', 'auto-mation' ),
				AMAC_Channels::label( $channel ),
				$recipient,
				$row['error']
			),
			array(
				'entity_type' => $entity_type,
				'entity_id'   => $entity_id,
				'context'     => array(
					'message_type' => $message_type,
					'connector'    => $connector->slug(),
				),
			)
		);

		return array(
			'status'     => 'error',
			'message'    => $row['error'],
			'recipient'  => $recipient,
			'message_id' => $message_id,
		);
	}

	/**
	 * Build the token context for an estimate or invoice.
	 *
	 * Returns the context plus a `_customer_id` key the caller strips off (the
	 * customer id is needed for routing but is not a template token).
	 *
	 * @param string $entity_type 'estimate' or 'invoice'.
	 * @param int    $entity_id   Document row id.
	 * @return array<string,string>|WP_Error
	 */
	public static function document_context( $entity_type, $entity_id ) {
		$entity_id = (int) $entity_id;

		if ( 'estimate' === $entity_type ) {
			$doc = AMAT_Estimate_Model::find( $entity_id );
			if ( ! $doc ) {
				return new WP_Error( 'amac_not_found', __( 'Estimate not found.', 'auto-mation' ) );
			}
			$item_class = 'AMAT_Estimate_Item_Model';
			$items      = AMAT_Estimate_Item_Model::for_parent( $entity_id );
			$total      = AMAT_Estimate_Model::total( $entity_id );
			$number     = AMAT_Estimates_Page::label( $doc );
			$doc_type   = __( 'Estimate', 'auto-mation' );
			$due        = (string) ( $doc['valid_until'] ?? '' );
		} elseif ( 'invoice' === $entity_type ) {
			$doc = AMAT_Invoice_Model::find( $entity_id );
			if ( ! $doc ) {
				return new WP_Error( 'amac_not_found', __( 'Invoice not found.', 'auto-mation' ) );
			}
			$item_class = 'AMAT_Invoice_Item_Model';
			$items      = AMAT_Invoice_Item_Model::for_parent( $entity_id );
			$total      = AMAT_Invoice_Model::total( $entity_id );
			$number     = AMAT_Invoices_Page::label( $doc );
			$doc_type   = __( 'Invoice', 'auto-mation' );
			$due        = (string) ( $doc['due_date'] ?? '' );
		} else {
			return new WP_Error( 'amac_bad_entity', __( 'Messages can only be sent about an estimate or an invoice.', 'auto-mation' ) );
		}

		$customer_id = (int) ( $doc['customer_id'] ?? 0 );
		$customer    = $customer_id ? AMAT_Customer_Model::find( $customer_id ) : null;

		if ( ! $customer ) {
			return new WP_Error( 'amac_no_customer', __( 'This document has no customer to send to.', 'auto-mation' ) );
		}

		return array(
			'customer_name' => AMAT_Customer_Model::display_name( $customer ),
			'business_name' => (string) get_option( 'amat_business_name', '' ),
			'doc_type'      => $doc_type,
			'doc_number'    => $number,
			'doc_total'     => AMAT_Money::format_amount( $total ),
			'doc_date'      => self::format_date( (string) ( $doc['issue_date'] ?? '' ) ),
			'doc_due'       => self::format_date( $due ),
			'vehicle'       => self::vehicle_label( $doc ),
			'line_items'    => self::line_items_block( $items, $item_class ),
			'notes'         => trim( (string) ( $doc['notes'] ?? '' ) ),
			'_customer_id'  => (string) $customer_id,
		);
	}

	/**
	 * The vehicle a document is about.
	 *
	 * Prefers the parent job's vehicle, falling back to the document's own —
	 * the same precedence the Wave companion uses when building its memo header,
	 * because the job is the owner and the document inherits from it.
	 *
	 * @param array<string,mixed> $doc Estimate or invoice row.
	 * @return string
	 */
	private static function vehicle_label( array $doc ) {
		$vehicle_id = 0;

		$job_id = (int) ( $doc['job_id'] ?? 0 );
		if ( $job_id ) {
			$job = AMAT_Job_Model::find( $job_id );
			if ( $job ) {
				$vehicle_id = (int) ( $job['vehicle_id'] ?? 0 );
			}
		}

		if ( ! $vehicle_id ) {
			$vehicle_id = (int) ( $doc['vehicle_id'] ?? 0 );
		}

		if ( ! $vehicle_id ) {
			return '';
		}

		$vehicle = AMAT_Vehicle_Model::find( $vehicle_id );
		return $vehicle ? AMAT_Vehicle_Model::label( $vehicle ) : '';
	}

	/**
	 * Render line items as a plain-text block.
	 *
	 * Plain text, not a table: this has to survive in an email client and in a
	 * text message, and neither is a good place for HTML column alignment.
	 *
	 * @param array<int,array<string,mixed>> $items      Line item rows.
	 * @param string                         $item_class The matching line-item model.
	 * @return string
	 */
	private static function line_items_block( array $items, $item_class ) {
		$lines = array();

		foreach ( $items as $item ) {
			$description = trim( (string) ( $item['description'] ?? '' ) );
			if ( '' === $description ) {
				continue;
			}

			$qty    = AMAT_Money::quantity( $item['quantity'] ?? null );
			$amount = AMAT_Money::format_amount( call_user_func( array( $item_class, 'line_amount' ), $item ) );

			$lines[] = ( '' !== $qty && '1' !== $qty )
				? sprintf( '- %1$s x%2$s — %3$s', $description, $qty, $amount )
				: sprintf( '- %1$s — %2$s', $description, $amount );
		}

		return implode( "\n", $lines );
	}

	/**
	 * Format a stored date for a customer-facing message, or '' when unset.
	 *
	 * @param string $date Stored Y-m-d date.
	 * @return string
	 */
	private static function format_date( $date ) {
		$date = trim( (string) $date );
		if ( '' === $date || '0000-00-00' === $date ) {
			return '';
		}

		$ts = strtotime( $date );
		return $ts ? wp_date( (string) get_option( 'date_format', 'F j, Y' ), $ts ) : $date;
	}

	/**
	 * Build an error result.
	 *
	 * @param string $message Reason.
	 * @return array{status:string,message:string}
	 */
	private static function error( $message ) {
		return array(
			'status'  => 'error',
			'message' => (string) $message,
		);
	}
}
