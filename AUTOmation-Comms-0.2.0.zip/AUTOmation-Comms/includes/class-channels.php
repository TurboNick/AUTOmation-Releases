<?php
/**
 * Channel vocabulary, and working out how to reach a customer on each one.
 *
 * @package AUTOmation_Comms
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The delivery channels this plugin knows about, plus contact-method routing.
 *
 * A channel is *what kind of message* (email, text). A connector is *who
 * delivers it* (wp_mail, SMTP, an SMS provider). Several connectors exist per
 * channel; exactly one is active at a time.
 *
 * ## Why the SMS-capability rule lives here
 *
 * Core's AMAT_Contact_Method_Types is a validation/formatting registry, not a
 * capability registry: it offers phone_types() but nothing that answers "may I
 * text this number?". Those are not the same question — `call_only` is a phone
 * type that explicitly means *do not text me*. Core's href() looks like an
 * answer and is not: it returns `tel:` for `call_text`, which is the right
 * default tap target but the wrong SMS-capability verdict, so it must not be
 * reused for routing.
 *
 * Until core grows an is_sms_type() (worth proposing — the type vocabulary is
 * core's to own), the mapping is made here, once:
 *
 *   text_call  -> textable (texting is their stated preference)
 *   call_text  -> textable (they take texts, they just prefer a call)
 *   call_only  -> NOT textable, ever
 *   email      -> emailable
 *
 * Getting this wrong sends a text to someone who asked not to receive one, so
 * the exclusion is expressed as an allowlist, not as "any phone type".
 */
class AMAC_Channels {

	/**
	 * Email channel slug.
	 */
	const EMAIL = 'email';

	/**
	 * SMS/text channel slug.
	 */
	const SMS = 'sms';

	/**
	 * Contact-method types that accept a text message.
	 *
	 * @return array<int,string>
	 */
	public static function sms_types() {
		return array( 'text_call', 'call_text' );
	}

	/**
	 * All known channels as slug => label.
	 *
	 * @return array<string,string>
	 */
	public static function all() {
		return array(
			self::EMAIL => __( 'Email', 'auto-mation' ),
			self::SMS   => __( 'Text message', 'auto-mation' ),
		);
	}

	/**
	 * Human label for a channel slug.
	 *
	 * @param string $channel Channel slug.
	 * @return string
	 */
	public static function label( $channel ) {
		$all = self::all();
		return $all[ $channel ] ?? $channel;
	}

	/**
	 * Whether a channel slug is one we support.
	 *
	 * @param string $channel Channel slug.
	 * @return bool
	 */
	public static function is_valid( $channel ) {
		return array_key_exists( $channel, self::all() );
	}

	/**
	 * The best address to reach a customer on for a channel.
	 *
	 * "Best" is the customer's own stated priority: contact methods are ordered
	 * by sort_order (lower = preferred), which replaced the old single
	 * preferred_contact_method field, so the first usable one wins.
	 *
	 * @param int    $customer_id Customer row id.
	 * @param string $channel     Channel slug.
	 * @return string Address (email, or bare 10-digit phone), or '' if unreachable.
	 */
	public static function address_for( $customer_id, $channel ) {
		$all = self::addresses_for( $customer_id, $channel );
		return $all ? $all[0] : '';
	}

	/**
	 * Every address a customer can be reached on for a channel, in priority order.
	 *
	 * @param int    $customer_id Customer row id.
	 * @param string $channel     Channel slug.
	 * @return array<int,string>
	 */
	public static function addresses_for( $customer_id, $channel ) {
		$found = array();

		if ( ! class_exists( 'AMAT_Contact_Method_Model' ) ) {
			return $found;
		}

		$methods = AMAT_Contact_Method_Model::for_customer( (int) $customer_id );

		foreach ( $methods as $method ) {
			$type  = (string) ( $method['type'] ?? '' );
			$value = trim( (string) ( $method['value'] ?? '' ) );

			if ( '' === $value ) {
				continue;
			}

			$usable = self::EMAIL === $channel
				? ( 'email' === $type )
				: in_array( $type, self::sms_types(), true );

			if ( $usable && ! in_array( $value, $found, true ) ) {
				$found[] = $value;
			}
		}

		return $found;
	}

	/**
	 * Whether a customer can be reached at all on a channel.
	 *
	 * @param int    $customer_id Customer row id.
	 * @param string $channel     Channel slug.
	 * @return bool
	 */
	public static function can_reach( $customer_id, $channel ) {
		return '' !== self::address_for( $customer_id, $channel );
	}
}
