<?php
/**
 * Message templates: one per message type, per channel.
 *
 * @package AUTOmation_Comms
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Editable message bodies, keyed by (message type × channel).
 *
 * A template belongs to a CHANNEL, not to a connector. Email and SMS get
 * genuinely separate templates — an email carries a subject line and can hold a
 * full line-item table; a text has no subject and needs to be one short line, so
 * writing one message for both would produce a bad version of each. But wp_mail
 * and SMTP are two routes for the *same* email, so they share the email
 * template: switching delivery route must never mean rewriting content.
 *
 * Bodies are stored in options and fall back to the defaults below when unset,
 * so the plugin works before anything is customized and a "reset" is just
 * deleting the option.
 */
class AMAC_Templates {

	/**
	 * Option key prefix: amat_comms_tpl_{type}_{channel}_{part}.
	 */
	const OPTION_PREFIX = 'amat_comms_tpl_';

	/**
	 * The message types this plugin can send.
	 *
	 * `entity` ties a type to the core record it describes, which is what lets
	 * the send button on an estimate know which templates apply to it.
	 *
	 * @return array<string,array{label:string,entity:string}>
	 */
	public static function types() {
		return array(
			'estimate_ready' => array(
				'label'  => __( 'Estimate ready', 'auto-mation' ),
				'entity' => 'estimate',
			),
			'invoice_ready'  => array(
				'label'  => __( 'Invoice', 'auto-mation' ),
				'entity' => 'invoice',
			),
		);
	}

	/**
	 * Whether a message type exists.
	 *
	 * @param string $type Message type slug.
	 * @return bool
	 */
	public static function is_valid_type( $type ) {
		return array_key_exists( $type, self::types() );
	}

	/**
	 * Human label for a message type.
	 *
	 * @param string $type Message type slug.
	 * @return string
	 */
	public static function type_label( $type ) {
		$types = self::types();
		return $types[ $type ]['label'] ?? $type;
	}

	/**
	 * The message types that apply to a core entity.
	 *
	 * @param string $entity Entity slug, e.g. 'estimate'.
	 * @return array<int,string> Message type slugs.
	 */
	public static function types_for_entity( $entity ) {
		$out = array();
		foreach ( self::types() as $slug => $def ) {
			if ( $def['entity'] === $entity ) {
				$out[] = $slug;
			}
		}
		return $out;
	}

	/**
	 * The placeholder tokens a template may use, with a description each.
	 *
	 * Shown as a cheat-sheet next to the editor. {line_items} is deliberately
	 * listed as email-oriented — it expands to a multi-line block, which is
	 * right in an email and wrong in a text.
	 *
	 * @return array<string,string>
	 */
	public static function tokens() {
		return array(
			'{customer_name}' => __( 'The customer\'s display name', 'auto-mation' ),
			'{business_name}' => __( 'Your business name (Settings → My Business)', 'auto-mation' ),
			'{doc_type}'      => __( 'Estimate or Invoice', 'auto-mation' ),
			'{doc_number}'    => __( 'Document number, e.g. "Estimate #12"', 'auto-mation' ),
			'{doc_total}'     => __( 'Document total, e.g. "$487.50"', 'auto-mation' ),
			'{doc_date}'      => __( 'Issue date', 'auto-mation' ),
			'{doc_due}'       => __( 'Valid-until (estimate) or due date (invoice)', 'auto-mation' ),
			'{vehicle}'       => __( 'Year Make Model of the vehicle, when known', 'auto-mation' ),
			'{line_items}'    => __( 'Multi-line list of line items — for email, not text', 'auto-mation' ),
			'{notes}'         => __( 'The document\'s notes', 'auto-mation' ),
		);
	}

	/**
	 * Built-in default templates, keyed type => channel => part => text.
	 *
	 * The email defaults render the document inline. That is deliberate: a link
	 * would need either the customer portal (not built yet) or the Wave
	 * companion's viewUrl — and depending on Wave would defeat the point of
	 * keeping Comms a separate, provider-independent plugin. Inline works today
	 * with no dependencies; a link can be added when the portal exists.
	 *
	 * @return array<string,array<string,array<string,string>>>
	 */
	public static function defaults() {
		return array(
			'estimate_ready' => array(
				AMAC_Channels::EMAIL => array(
					'subject' => __( 'Your estimate from {business_name}', 'auto-mation' ),
					'body'    => __(
						"Hi {customer_name},

Here is your estimate for the {vehicle}.

{line_items}

Total: {doc_total}
Valid until: {doc_due}

{notes}

Just reply to this email or give us a call to go ahead, and we'll get you booked in.

Thanks,
{business_name}",
						'auto-mation'
					),
				),
				AMAC_Channels::SMS   => array(
					'subject' => '',
					'body'    => __( 'Hi {customer_name}, your estimate from {business_name} for the {vehicle} is ready: {doc_total}. Reply or call us to go ahead.', 'auto-mation' ),
				),
			),
			'invoice_ready'  => array(
				AMAC_Channels::EMAIL => array(
					'subject' => __( 'Your invoice from {business_name}', 'auto-mation' ),
					'body'    => __(
						"Hi {customer_name},

Thanks for your business. Here is your invoice for the {vehicle}.

{line_items}

Total: {doc_total}
Due: {doc_due}

{notes}

Thanks,
{business_name}",
						'auto-mation'
					),
				),
				AMAC_Channels::SMS   => array(
					'subject' => '',
					'body'    => __( 'Hi {customer_name}, your invoice from {business_name} for the {vehicle} is {doc_total}, due {doc_due}. Thanks!', 'auto-mation' ),
				),
			),
		);
	}

	/**
	 * Option key for one template part.
	 *
	 * @param string $type    Message type slug.
	 * @param string $channel Channel slug.
	 * @param string $part    'subject' or 'body'.
	 * @return string
	 */
	public static function option_key( $type, $channel, $part ) {
		return self::OPTION_PREFIX . $type . '_' . $channel . '_' . $part;
	}

	/**
	 * The stored template part, falling back to the built-in default.
	 *
	 * @param string $type    Message type slug.
	 * @param string $channel Channel slug.
	 * @param string $part    'subject' or 'body'.
	 * @return string
	 */
	public static function get( $type, $channel, $part ) {
		$stored = get_option( self::option_key( $type, $channel, $part ), null );
		if ( null !== $stored && '' !== $stored ) {
			return (string) $stored;
		}
		return self::default_for( $type, $channel, $part );
	}

	/**
	 * The built-in default for a template part.
	 *
	 * @param string $type    Message type slug.
	 * @param string $channel Channel slug.
	 * @param string $part    'subject' or 'body'.
	 * @return string
	 */
	public static function default_for( $type, $channel, $part ) {
		$defaults = self::defaults();
		return (string) ( $defaults[ $type ][ $channel ][ $part ] ?? '' );
	}

	/**
	 * Store a template part. Saving a value identical to the default (or blank)
	 * deletes the option instead, so "reset to default" needs no separate
	 * mechanism and the option table doesn't fill with redundant copies.
	 *
	 * @param string $type    Message type slug.
	 * @param string $channel Channel slug.
	 * @param string $part    'subject' or 'body'.
	 * @param string $value   New text.
	 * @return void
	 */
	public static function save( $type, $channel, $part, $value ) {
		$key   = self::option_key( $type, $channel, $part );
		$value = trim( (string) $value );

		if ( '' === $value || $value === trim( self::default_for( $type, $channel, $part ) ) ) {
			delete_option( $key );
			return;
		}

		update_option( $key, $value, false );
	}

	/**
	 * Substitute tokens into a template.
	 *
	 * Unknown tokens are left as-is rather than blanked, so a typo is visible in
	 * the preview instead of silently producing a gap in a customer's message.
	 *
	 * @param string               $text    Template text.
	 * @param array<string,string> $context Token => replacement (without braces).
	 * @return string
	 */
	public static function substitute( $text, array $context ) {
		$find    = array();
		$replace = array();

		foreach ( $context as $token => $value ) {
			$find[]    = '{' . $token . '}';
			$replace[] = (string) $value;
		}

		$out = str_replace( $find, $replace, (string) $text );

		// Collapse the runs of blank lines left behind when an optional block
		// (notes, line items) resolved to nothing.
		$out = preg_replace( "/\n{3,}/", "\n\n", $out );

		return trim( (string) $out );
	}

	/**
	 * Render a full message for a type + channel from a token context.
	 *
	 * @param string               $type    Message type slug.
	 * @param string               $channel Channel slug.
	 * @param array<string,string> $context Token => replacement (without braces).
	 * @return array{subject:string,body:string}
	 */
	public static function render( $type, $channel, array $context ) {
		return array(
			'subject' => self::substitute( self::get( $type, $channel, 'subject' ), $context ),
			'body'    => self::substitute( self::get( $type, $channel, 'body' ), $context ),
		);
	}
}
