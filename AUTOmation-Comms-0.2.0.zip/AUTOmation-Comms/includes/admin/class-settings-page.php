<?php
/**
 * The Comms settings page.
 *
 * @package AUTOmation_Comms
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Settings → ↳ Comms: pick a connector per channel, control the dry-run gate,
 * set the From identity, and edit the message templates.
 */
class AMAC_Settings_Page {

	/**
	 * admin_post action for the delivery/sending settings form.
	 */
	const SAVE_DELIVERY = 'amac_save_delivery';

	/**
	 * admin_post action for the templates form.
	 */
	const SAVE_TEMPLATES = 'amac_save_templates';

	/**
	 * Register the form handlers.
	 *
	 * @return void
	 */
	public function register() {
		add_action( 'admin_post_' . self::SAVE_DELIVERY, array( $this, 'handle_save_delivery' ) );
		add_action( 'admin_post_' . self::SAVE_TEMPLATES, array( $this, 'handle_save_templates' ) );
	}

	/* --------------------------------------------------------------------- */
	/* Handlers                                                              */
	/* --------------------------------------------------------------------- */

	/**
	 * Save the connector choices, dry-run flag and From identity.
	 *
	 * @return void
	 */
	public function handle_save_delivery() {
		$this->guard( self::SAVE_DELIVERY );

		foreach ( array_keys( AMAC_Channels::all() ) as $channel ) {
			$field = 'amac_connector_' . $channel;
			$slug  = isset( $_POST[ $field ] ) ? sanitize_key( wp_unslash( $_POST[ $field ] ) ) : '';

			// Only accept a slug that is actually registered for this channel,
			// so a tampered POST can't point a channel at someone else's route.
			$connector = '' !== $slug ? AMAC_Connector_Registry::get( $slug ) : null;
			AMAC_Connector_Registry::set_active(
				$channel,
				( $connector && $connector->channel() === $channel ) ? $slug : ''
			);
		}

		// Absent checkbox = unchecked = dry run OFF. Storing '1'/'0' explicitly
		// rather than deleting, so "never configured" (default ON) stays
		// distinguishable from "deliberately turned off".
		$dry_run = ! empty( $_POST['amac_dry_run'] ) ? '1' : '0';
		update_option( AMAC_Comms::DRY_RUN_OPTION, $dry_run, false );

		$from_name = isset( $_POST['amac_from_name'] )
			? sanitize_text_field( wp_unslash( $_POST['amac_from_name'] ) )
			: '';
		update_option( AMAC_Connector_Wp_Mail::FROM_NAME_OPTION, $from_name, false );

		$from_email = isset( $_POST['amac_from_email'] )
			? sanitize_email( wp_unslash( $_POST['amac_from_email'] ) )
			: '';
		update_option( AMAC_Connector_Wp_Mail::FROM_EMAIL_OPTION, $from_email, false );

		$this->notice( 'success', __( 'Delivery settings saved.', 'auto-mation' ) );
		$this->redirect_back();
	}

	/**
	 * Save the message templates.
	 *
	 * @return void
	 */
	public function handle_save_templates() {
		$this->guard( self::SAVE_TEMPLATES );

		foreach ( array_keys( AMAC_Templates::types() ) as $type ) {
			foreach ( array_keys( AMAC_Channels::all() ) as $channel ) {
				foreach ( array( 'subject', 'body' ) as $part ) {
					$field = 'amac_tpl_' . $type . '_' . $channel . '_' . $part;

					if ( ! isset( $_POST[ $field ] ) ) {
						continue;
					}

					// Templates are plain text with {tokens}; sanitize_textarea_field
					// preserves the newlines an email body depends on.
					AMAC_Templates::save(
						$type,
						$channel,
						$part,
						sanitize_textarea_field( wp_unslash( $_POST[ $field ] ) )
					);
				}
			}
		}

		$this->notice( 'success', __( 'Templates saved. Blank fields, or ones matching the built-in wording, are reset to the default.', 'auto-mation' ) );
		$this->redirect_back( 'templates' );
	}

	/* --------------------------------------------------------------------- */
	/* Rendering                                                             */
	/* --------------------------------------------------------------------- */

	/**
	 * Render the settings page.
	 *
	 * @return void
	 */
	public function render() {
		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'auto-mation' ) );
		}

		$this->render_notice();

		echo '<div class="wrap">';
		echo '<h1>' . esc_html__( 'Comms', 'auto-mation' ) . '</h1>';
		echo '<p class="description">'
			. esc_html__( 'Send estimates and invoices to customers by email or text. A channel is the kind of message; a connector is the route that delivers it.', 'auto-mation' )
			. '</p>';

		$this->render_delivery_form();
		$this->render_templates_form();

		echo '</div>';
	}

	/**
	 * The delivery + sending form.
	 *
	 * @return void
	 */
	private function render_delivery_form() {
		$dry_run = AMAC_Comms::is_dry_run();

		echo '<h2>' . esc_html__( 'Delivery', 'auto-mation' ) . '</h2>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( self::SAVE_DELIVERY );
		echo '<input type="hidden" name="action" value="' . esc_attr( self::SAVE_DELIVERY ) . '">';

		echo '<table class="form-table" role="presentation"><tbody>';

		foreach ( AMAC_Channels::all() as $channel => $channel_label ) {
			$available = AMAC_Connector_Registry::all( $channel );
			$active    = AMAC_Connector_Registry::active( $channel );

			echo '<tr>';
			echo '<th scope="row"><label for="amac-connector-' . esc_attr( $channel ) . '">'
				. esc_html( $channel_label ) . '</label></th>';
			echo '<td>';

			if ( ! $available ) {
				echo '<p class="description">'
					. esc_html__( 'No connector is available for this channel yet.', 'auto-mation' )
					. '</p>';
				echo '</td></tr>';
				continue;
			}

			echo '<select name="amac_connector_' . esc_attr( $channel ) . '" id="amac-connector-' . esc_attr( $channel ) . '">';
			echo '<option value="">' . esc_html__( '— Not set —', 'auto-mation' ) . '</option>';
			foreach ( $available as $slug => $connector ) {
				printf(
					'<option value="%1$s"%2$s>%3$s</option>',
					esc_attr( $slug ),
					selected( $active && $active->slug() === $slug, true, false ),
					esc_html( $connector->label() )
				);
			}
			echo '</select>';

			foreach ( $available as $connector ) {
				$description = $connector->description();
				if ( '' === $description ) {
					continue;
				}
				echo '<p class="description"><strong>' . esc_html( $connector->label() ) . ':</strong> '
					. esc_html( $description );
				if ( ! $connector->is_configured() ) {
					echo ' <em>' . esc_html( $connector->config_hint() ) . '</em>';
				}
				echo '</p>';
			}

			echo '</td></tr>';
		}

		echo '<tr>';
		echo '<th scope="row">' . esc_html__( 'Dry-run mode', 'auto-mation' ) . '</th>';
		echo '<td>';
		echo '<label><input type="checkbox" name="amac_dry_run" value="1"' . checked( $dry_run, true, false ) . '> '
			. esc_html__( 'Render and record messages, but do not actually deliver them', 'auto-mation' )
			. '</label>';
		echo '<p class="description">'
			. esc_html__( 'On by default. A message that reaches a customer cannot be recalled, so leave this on until you have reviewed the previews on a real estimate. Every send is still recorded while it is on, so you can see exactly what would have gone out.', 'auto-mation' )
			. '</p>';
		echo '</td></tr>';

		echo '<tr>';
		echo '<th scope="row"><label for="amac-from-name">' . esc_html__( 'From name', 'auto-mation' ) . '</label></th>';
		echo '<td><input type="text" class="regular-text" id="amac-from-name" name="amac_from_name" value="'
			. esc_attr( (string) get_option( AMAC_Connector_Wp_Mail::FROM_NAME_OPTION, '' ) ) . '">';
		echo '<p class="description">'
			. esc_html__( 'Shown as the sender on emails. Blank uses your business name from Settings → My Business.', 'auto-mation' )
			. '</p></td></tr>';

		echo '<tr>';
		echo '<th scope="row"><label for="amac-from-email">' . esc_html__( 'From address', 'auto-mation' ) . '</label></th>';
		echo '<td><input type="email" class="regular-text" id="amac-from-email" name="amac_from_email" value="'
			. esc_attr( (string) get_option( AMAC_Connector_Wp_Mail::FROM_EMAIL_OPTION, '' ) ) . '">';
		echo '<p class="description">'
			. esc_html__( 'Blank uses the WordPress default. Use an address at your own domain — mail claiming to be from a domain the server is not authorised to send for is what spam filters catch.', 'auto-mation' )
			. '</p></td></tr>';

		echo '</tbody></table>';
		submit_button( __( 'Save delivery settings', 'auto-mation' ) );
		echo '</form>';
	}

	/**
	 * The templates form.
	 *
	 * @return void
	 */
	private function render_templates_form() {
		echo '<h2 id="templates">' . esc_html__( 'Message templates', 'auto-mation' ) . '</h2>';
		echo '<p class="description">'
			. esc_html__( 'Email and text are written separately — an email can carry a subject line and the full list of line items, a text needs to be one short sentence. Every email connector uses the same email template, so changing how mail is delivered never means rewriting your wording.', 'auto-mation' )
			. '</p>';

		echo '<p><strong>' . esc_html__( 'Available placeholders:', 'auto-mation' ) . '</strong></p>';
		echo '<ul style="columns:2;max-width:900px;">';
		foreach ( AMAC_Templates::tokens() as $token => $description ) {
			echo '<li><code>' . esc_html( $token ) . '</code> — ' . esc_html( $description ) . '</li>';
		}
		echo '</ul>';

		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( self::SAVE_TEMPLATES );
		echo '<input type="hidden" name="action" value="' . esc_attr( self::SAVE_TEMPLATES ) . '">';

		foreach ( AMAC_Templates::types() as $type => $definition ) {
			echo '<h3>' . esc_html( $definition['label'] ) . '</h3>';
			echo '<table class="form-table" role="presentation"><tbody>';

			foreach ( AMAC_Channels::all() as $channel => $channel_label ) {
				// Only email has a subject; a text message has no such concept.
				if ( AMAC_Channels::EMAIL === $channel ) {
					$field = 'amac_tpl_' . $type . '_' . $channel . '_subject';
					echo '<tr>';
					echo '<th scope="row"><label for="' . esc_attr( $field ) . '">'
						. esc_html__( 'Email subject', 'auto-mation' ) . '</label></th>';
					echo '<td><input type="text" class="large-text" id="' . esc_attr( $field ) . '" name="' . esc_attr( $field ) . '" value="'
						. esc_attr( AMAC_Templates::get( $type, $channel, 'subject' ) ) . '"></td>';
					echo '</tr>';
				}

				$field = 'amac_tpl_' . $type . '_' . $channel . '_body';
				$body  = AMAC_Templates::get( $type, $channel, 'body' );

				echo '<tr>';
				echo '<th scope="row"><label for="' . esc_attr( $field ) . '">'
					. esc_html(
						sprintf(
							/* translators: %s: channel label. */
							__( '%s message', 'auto-mation' ),
							$channel_label
						)
					)
					. '</label></th>';
				echo '<td><textarea class="large-text code" rows="' . ( AMAC_Channels::SMS === $channel ? 3 : 14 ) . '" id="'
					. esc_attr( $field ) . '" name="' . esc_attr( $field ) . '">' . esc_textarea( $body ) . '</textarea>';

				if ( AMAC_Channels::SMS === $channel ) {
					echo '<p class="description">'
						. esc_html__( 'Keep it short. Carriers split anything over 160 characters into multiple messages, and most providers bill per part. Do not use {line_items} here — it expands to a whole list.', 'auto-mation' )
						. '</p>';
				}

				echo '</td></tr>';
			}

			echo '</tbody></table>';
		}

		submit_button( __( 'Save templates', 'auto-mation' ) );
		echo '</form>';
	}

	/* --------------------------------------------------------------------- */
	/* Helpers                                                               */
	/* --------------------------------------------------------------------- */

	/**
	 * Capability + nonce check for a form handler.
	 *
	 * @param string $action Nonce action.
	 * @return void
	 */
	private function guard( $action ) {
		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to do that.', 'auto-mation' ) );
		}
		check_admin_referer( $action );
	}

	/**
	 * Stash a one-shot notice for the next page load.
	 *
	 * @param string $status 'success' or 'error'.
	 * @param string $text   Message.
	 * @return void
	 */
	private function notice( $status, $text ) {
		set_transient(
			'amac_notice_' . get_current_user_id(),
			array(
				'status'  => $status,
				'message' => $text,
			),
			MINUTE_IN_SECONDS
		);
	}

	/**
	 * Print and clear the stashed notice.
	 *
	 * @return void
	 */
	private function render_notice() {
		$key    = 'amac_notice_' . get_current_user_id();
		$notice = get_transient( $key );

		if ( ! is_array( $notice ) ) {
			return;
		}
		delete_transient( $key );

		printf(
			'<div class="notice notice-%1$s is-dismissible"><p>%2$s</p></div>',
			'success' === ( $notice['status'] ?? '' ) ? 'success' : 'error',
			esc_html( (string) ( $notice['message'] ?? '' ) )
		);
	}

	/**
	 * Redirect back to this settings page.
	 *
	 * @param string $fragment Optional anchor.
	 * @return void
	 */
	private function redirect_back( $fragment = '' ) {
		$url = add_query_arg( array( 'page' => AMAC_Provider::PAGE_SLUG ), admin_url( 'admin.php' ) );
		if ( '' !== $fragment ) {
			$url .= '#' . $fragment;
		}
		wp_safe_redirect( $url );
		exit;
	}
}
