<?php
/**
 * Email connector: WordPress's built-in wp_mail().
 *
 * @package AUTOmation_Comms
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Delivers email through wp_mail(), i.e. whatever the site is already set up to
 * use — bare PHP mail() on most hosts, or another plugin's SMTP if one is
 * installed and has hooked phpmailer_init.
 *
 * This is the zero-configuration route: nothing to set up, works immediately.
 * Its weakness is deliverability, not correctness — mail sent straight from a
 * webserver with no authentication (no SPF/DKIM alignment) is routinely
 * spam-filed or dropped without a bounce, and on a Local dev site there is
 * usually no mail transport at all, so wp_mail() returns false. Note what that
 * means for the return value below: wp_mail() reports whether the message was
 * *handed off*, never whether it was *delivered*. A 'sent' result here is not a
 * promise the customer received anything.
 *
 * The SMTP connector (a separate file, same channel) is the answer to that —
 * same email, authenticated route.
 */
class AMAC_Connector_Wp_Mail extends AMAC_Connector {

	/**
	 * Option holding the From name; blank falls back to the business name.
	 */
	const FROM_NAME_OPTION = 'amat_comms_from_name';

	/**
	 * Option holding the From address; blank falls back to WordPress's default.
	 */
	const FROM_EMAIL_OPTION = 'amat_comms_from_email';

	/**
	 * Stable machine slug.
	 *
	 * @return string
	 */
	public function slug() {
		return 'wp_mail';
	}

	/**
	 * Human label.
	 *
	 * @return string
	 */
	public function label() {
		return __( 'WordPress (wp_mail)', 'auto-mation' );
	}

	/**
	 * Channel delivered.
	 *
	 * @return string
	 */
	public function channel() {
		return AMAC_Channels::EMAIL;
	}

	/**
	 * Settings blurb.
	 *
	 * @return string
	 */
	public function description() {
		return __( 'Sends through the web server using WordPress\'s built-in mail function. Nothing to configure, but mail sent this way is often filtered as spam and will not send at all on a local dev site. Use SMTP for real customer mail.', 'auto-mation' );
	}

	/**
	 * Send an email.
	 *
	 * The From headers are applied via filters scoped to this single call and
	 * removed immediately afterwards, so this connector never changes the From
	 * address of unrelated WordPress mail (password resets, other plugins).
	 *
	 * @param string                             $to      Recipient email address.
	 * @param array{subject?:string,body:string} $message Rendered message parts.
	 * @param array<string,mixed>                $args    Optional context.
	 * @return array{status:string,message:string,external_id:string}
	 */
	public function send( $to, array $message, array $args = array() ) {
		$to = sanitize_email( $to );
		if ( ! is_email( $to ) ) {
			return $this->failure(
				sprintf(
					/* translators: %s: the invalid address. */
					__( 'Not a valid email address: %s', 'auto-mation' ),
					$to
				)
			);
		}

		$subject = (string) ( $message['subject'] ?? '' );
		$body    = (string) ( $message['body'] ?? '' );

		if ( '' === trim( $body ) ) {
			return $this->failure( __( 'Message body is empty.', 'auto-mation' ) );
		}

		$from_name  = $this->from_name();
		$from_email = $this->from_email();

		$name_filter = static function () use ( $from_name ) {
			return $from_name;
		};
		$mail_filter = static function () use ( $from_email ) {
			return $from_email;
		};

		// wp_mail() only returns a bool; the actual PHPMailer reason is passed
		// to the wp_mail_failed action. Capturing it means hooking BEFORE the
		// call — by the time wp_mail() has returned, the action has long fired.
		$reason  = '';
		$capture = static function ( $wp_error ) use ( &$reason ) {
			if ( is_wp_error( $wp_error ) ) {
				$reason = $wp_error->get_error_message();
			}
		};
		add_action( 'wp_mail_failed', $capture );

		if ( '' !== $from_name ) {
			add_filter( 'wp_mail_from_name', $name_filter, 99 );
		}
		if ( '' !== $from_email ) {
			add_filter( 'wp_mail_from', $mail_filter, 99 );
		}

		// wp_mail() can raise a PHPMailer exception on a badly misconfigured
		// host. Core's rule that a provider failure must never fatal the site
		// applies just as much to mail, so catch anything that escapes.
		try {
			$ok = wp_mail( $to, $subject, $body, array( 'Content-Type: text/plain; charset=UTF-8' ) );
		} catch ( \Throwable $e ) {
			$ok     = false;
			$reason = $e->getMessage();
		}

		// Unhook everything this call added, whatever happened, so no other
		// WordPress mail (password resets, other plugins) inherits our From
		// address or our error capture.
		remove_action( 'wp_mail_failed', $capture );
		if ( '' !== $from_name ) {
			remove_filter( 'wp_mail_from_name', $name_filter, 99 );
		}
		if ( '' !== $from_email ) {
			remove_filter( 'wp_mail_from', $mail_filter, 99 );
		}

		if ( $ok ) {
			// wp_mail() returns no message id of any kind.
			return $this->success();
		}

		return $this->failure(
			'' !== $reason
				? $reason
				: __( 'wp_mail() failed. The server may have no mail transport configured — this is normal on a local dev site.', 'auto-mation' )
		);
	}

	/**
	 * From name: the configured value, else the business name from core's
	 * My Business settings, else WordPress's default.
	 *
	 * @return string
	 */
	private function from_name() {
		$configured = trim( (string) get_option( self::FROM_NAME_OPTION, '' ) );
		if ( '' !== $configured ) {
			return $configured;
		}
		return trim( (string) get_option( 'amat_business_name', '' ) );
	}

	/**
	 * From address: the configured value, else WordPress's default.
	 *
	 * @return string
	 */
	private function from_email() {
		$configured = sanitize_email( (string) get_option( self::FROM_EMAIL_OPTION, '' ) );
		return is_email( $configured ) ? $configured : '';
	}
}
