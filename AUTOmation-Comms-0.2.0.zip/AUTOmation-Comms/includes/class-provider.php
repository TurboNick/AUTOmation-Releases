<?php
/**
 * Wires this plugin into core's extension points.
 *
 * @package AUTOmation_Comms
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Renders the send controls on core's estimate/invoice detail views, handles
 * the POSTs they issue, and registers this plugin's own settings submenu.
 *
 * Core fires neutral hooks and ships no listeners; this class is the only thing
 * that knows they mean "offer to message the customer". Nothing here requires a
 * change to core.
 */
class AMAC_Provider {

	/**
	 * Settings page slug.
	 */
	const PAGE_SLUG = 'amat-comms';

	/**
	 * Nonce action for the send buttons.
	 */
	const SEND_NONCE = 'amac_send_message';

	/**
	 * The `amat_action` value the send buttons post.
	 */
	const SEND_ACTION = 'amac_send';

	/**
	 * Stored hook suffix for the settings page, for scoped asset enqueue.
	 *
	 * @var string
	 */
	private $page_hook = '';

	/**
	 * The settings page, held so the form handlers and the render callback are
	 * the same object.
	 *
	 * @var AMAC_Settings_Page|null
	 */
	private $settings = null;

	/**
	 * Hook everything up.
	 *
	 * @return void
	 */
	public function register() {
		$this->settings = new AMAC_Settings_Page();
		$this->settings->register();

		// Intercept our POSTs before any output, mirroring core's PRG pattern.
		add_action( 'admin_init', array( $this, 'maybe_process' ) );

		add_action( 'amat_estimate_detail_actions', array( $this, 'render_estimate_actions' ) );
		add_action( 'amat_invoice_detail_actions', array( $this, 'render_invoice_actions' ) );

		// Our own submenu, at priority 20 so it lands after core's items.
		add_action( 'admin_menu', array( $this, 'add_menu' ), 20 );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
	}

	/* --------------------------------------------------------------------- */
	/* Menu                                                                  */
	/* --------------------------------------------------------------------- */

	/**
	 * Register the Comms submenu under the AUTOmation menu.
	 *
	 * The label carries the `↳` indent marker core uses to fake a hierarchy
	 * (WP admin menus are only two levels deep), matching the Wave companion's
	 * own submenu.
	 *
	 * @return void
	 */
	public function add_menu() {
		$this->page_hook = (string) add_submenu_page(
			AMAT_Admin::MENU_SLUG,
			__( 'Comms', 'auto-mation' ),
			__( '↳ Comms', 'auto-mation' ),
			AMAT_Admin::CAPABILITY,
			self::PAGE_SLUG,
			array( $this->settings, 'render' )
		);
	}

	/**
	 * Load core's admin stylesheet on our settings page only.
	 *
	 * @param string $hook Current admin page hook suffix.
	 * @return void
	 */
	public function enqueue_assets( $hook ) {
		if ( '' === $this->page_hook || $hook !== $this->page_hook ) {
			return;
		}
		wp_enqueue_style( 'amat-admin', AMAT_PLUGIN_URL . 'assets/admin.css', array(), AMAT_VERSION );
	}

	/* --------------------------------------------------------------------- */
	/* Handlers                                                              */
	/* --------------------------------------------------------------------- */

	/**
	 * Handle a send POST, then redirect back to the document (PRG).
	 *
	 * @return void
	 */
	public function maybe_process() {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce is checked below, once we know this is our action.
		$action = isset( $_POST['amat_action'] ) ? sanitize_key( wp_unslash( $_POST['amat_action'] ) ) : '';

		if ( self::SEND_ACTION !== $action ) {
			return;
		}

		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			return;
		}

		check_admin_referer( self::SEND_NONCE );

		$entity_type = isset( $_POST['amac_entity_type'] ) ? sanitize_key( wp_unslash( $_POST['amac_entity_type'] ) ) : '';
		$entity_id   = isset( $_POST['amac_entity_id'] ) ? absint( wp_unslash( $_POST['amac_entity_id'] ) ) : 0;
		$channel     = isset( $_POST['amac_channel'] ) ? sanitize_key( wp_unslash( $_POST['amac_channel'] ) ) : '';
		$type        = isset( $_POST['amac_message_type'] ) ? sanitize_key( wp_unslash( $_POST['amac_message_type'] ) ) : '';

		$result = AMAC_Comms::send_document(
			array(
				'entity_type'  => $entity_type,
				'entity_id'    => $entity_id,
				'channel'      => $channel,
				'message_type' => $type,
			)
		);

		$page = 'invoice' === $entity_type ? AMAT_Invoices_Page::PAGE_SLUG : AMAT_Estimates_Page::PAGE_SLUG;

		$redirect = add_query_arg(
			array(
				'page'   => $page,
				'action' => 'view',
				'id'     => $entity_id,
			),
			admin_url( 'admin.php' )
		);

		set_transient(
			'amat_flash_' . $page . '_' . get_current_user_id(),
			array(
				'status'  => 'success' === $result['status'] ? 'success' : 'error',
				'message' => $result['message'],
			),
			MINUTE_IN_SECONDS
		);

		wp_safe_redirect( $redirect );
		exit;
	}

	/* --------------------------------------------------------------------- */
	/* Detail-view UI                                                        */
	/* --------------------------------------------------------------------- */

	/**
	 * Render the send block on an estimate detail view.
	 *
	 * @param array<string,mixed> $estimate Estimate row.
	 * @return void
	 */
	public function render_estimate_actions( $estimate ) {
		$this->render_send_block( 'estimate', (array) $estimate );
	}

	/**
	 * Render the send block on an invoice detail view.
	 *
	 * @param array<string,mixed> $invoice Invoice row.
	 * @return void
	 */
	public function render_invoice_actions( $invoice ) {
		$this->render_send_block( 'invoice', (array) $invoice );
	}

	/**
	 * The "Send to customer" block: one button per channel, plus the history of
	 * what has already been sent about this document.
	 *
	 * @param string              $entity_type 'estimate' or 'invoice'.
	 * @param array<string,mixed> $doc         Document row.
	 * @return void
	 */
	private function render_send_block( $entity_type, array $doc ) {
		$id          = (int) ( $doc['id'] ?? 0 );
		$customer_id = (int) ( $doc['customer_id'] ?? 0 );
		$status      = (string) ( $doc['status'] ?? '' );

		if ( ! $id ) {
			return;
		}

		$types = AMAC_Templates::types_for_entity( $entity_type );
		if ( ! $types ) {
			return;
		}
		$message_type = $types[0];

		echo '<h2>' . esc_html__( 'Send to customer', 'auto-mation' ) . '</h2>';

		// A void document is a cancelled record. Sending one to a customer would
		// be actively wrong, so the block reports rather than offers.
		if ( 'void' === $status ) {
			echo '<p class="description">'
				. esc_html__( 'This document is void — it cannot be sent.', 'auto-mation' )
				. '</p>';
			$this->render_history( $entity_type, $id );
			return;
		}

		if ( AMAC_Comms::is_dry_run() ) {
			echo '<div class="notice notice-warning inline"><p>'
				. esc_html__( 'Dry-run mode is on: messages are rendered and recorded but not delivered. Turn it off in Settings → Comms when you are ready to send for real.', 'auto-mation' )
				. '</p></div>';
		}

		echo '<p>';
		foreach ( AMAC_Channels::all() as $channel => $label ) {
			$this->render_send_button( $entity_type, $id, $customer_id, $channel, $label, $message_type );
		}
		echo '</p>';

		$this->render_history( $entity_type, $id );
	}

	/**
	 * One channel's send button, or an explanation of why it can't be used.
	 *
	 * @param string $entity_type  'estimate' or 'invoice'.
	 * @param int    $id           Document id.
	 * @param int    $customer_id  Customer id.
	 * @param string $channel      Channel slug.
	 * @param string $label        Channel label.
	 * @param string $message_type Message type slug.
	 * @return void
	 */
	private function render_send_button( $entity_type, $id, $customer_id, $channel, $label, $message_type ) {
		$connector = AMAC_Connector_Registry::active( $channel );

		// No connector for this channel yet (SMS, until a provider ships) —
		// say so plainly rather than showing a button that cannot work.
		if ( ! $connector ) {
			printf(
				'<span class="description" style="margin-right:1em;">%s</span>',
				esc_html(
					sprintf(
						/* translators: %s: channel label, e.g. "Text message". */
						__( 'No %s connector is set up yet.', 'auto-mation' ),
						strtolower( $label )
					)
				)
			);
			return;
		}

		$address = AMAC_Channels::address_for( $customer_id, $channel );
		if ( '' === $address ) {
			printf(
				'<span class="description" style="margin-right:1em;">%s</span>',
				esc_html(
					AMAC_Channels::EMAIL === $channel
						? __( 'No email address on file for this customer.', 'auto-mation' )
						: __( 'No textable number on file (a Call Only number cannot be texted).', 'auto-mation' )
				)
			);
			return;
		}

		$button_label = sprintf(
			/* translators: 1: channel label, 2: recipient address. */
			__( 'Send %1$s to %2$s', 'auto-mation' ),
			strtolower( $label ),
			AMAC_Channels::EMAIL === $channel ? $address : AMAT_Contact_Method_Types::format( 'text_call', $address )
		);

		echo '<form method="post" style="display:inline-block;margin-right:.5em;">';
		wp_nonce_field( self::SEND_NONCE );
		echo '<input type="hidden" name="amat_action" value="' . esc_attr( self::SEND_ACTION ) . '">';
		echo '<input type="hidden" name="amac_entity_type" value="' . esc_attr( $entity_type ) . '">';
		echo '<input type="hidden" name="amac_entity_id" value="' . esc_attr( (string) $id ) . '">';
		echo '<input type="hidden" name="amac_channel" value="' . esc_attr( $channel ) . '">';
		echo '<input type="hidden" name="amac_message_type" value="' . esc_attr( $message_type ) . '">';
		echo '<button type="submit" class="button">' . esc_html( $button_label ) . '</button>';
		echo '</form>';
	}

	/**
	 * List what has already been sent about this document.
	 *
	 * @param string $entity_type Entity slug.
	 * @param int    $id          Document id.
	 * @return void
	 */
	private function render_history( $entity_type, $id ) {
		$messages = AMAC_Message_Model::for_entity( $entity_type, $id );

		if ( ! $messages ) {
			echo '<p class="description">' . esc_html__( 'Nothing sent yet.', 'auto-mation' ) . '</p>';
			return;
		}

		echo '<table class="widefat striped" style="max-width:900px;">';
		echo '<thead><tr>';
		echo '<th>' . esc_html__( 'When', 'auto-mation' ) . '</th>';
		echo '<th>' . esc_html__( 'Channel', 'auto-mation' ) . '</th>';
		echo '<th>' . esc_html__( 'To', 'auto-mation' ) . '</th>';
		echo '<th>' . esc_html__( 'Result', 'auto-mation' ) . '</th>';
		echo '</tr></thead><tbody>';

		foreach ( $messages as $message ) {
			$when   = (string) ( $message['sent_at'] ?? '' );
			$when   = '' !== $when && '0000-00-00 00:00:00' !== $when ? $when : (string) ( $message['created_at'] ?? '' );
			$ts     = strtotime( $when );
			$status = (string) ( $message['status'] ?? '' );
			$error  = trim( (string) ( $message['error'] ?? '' ) );

			echo '<tr>';
			echo '<td>' . esc_html( $ts ? wp_date( 'M j, Y g:i a', $ts ) : $when ) . '</td>';
			echo '<td>' . esc_html( AMAC_Channels::label( (string) ( $message['channel'] ?? '' ) ) ) . '</td>';
			echo '<td>' . esc_html( (string) ( $message['recipient'] ?? '' ) ) . '</td>';
			echo '<td>' . esc_html( AMAC_Message_Model::status_label( $status ) );
			if ( '' !== $error ) {
				echo '<br><span class="description">' . esc_html( $error ) . '</span>';
			}
			echo '</td>';
			echo '</tr>';
		}

		echo '</tbody></table>';
	}
}
