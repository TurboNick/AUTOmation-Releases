<?php
/**
 * Minimal .env reader for secrets that must stay out of the repo and DB.
 *
 * @package AUTOmation_Comms
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Reads key=value pairs from a git-ignored .env file in the plugin root.
 *
 * Connector secrets (an SMTP password, an SMS provider's auth token) live here,
 * never hardcoded, never committed, and never in an option — the settings page
 * only ever reports whether a key is *present*, not its value.
 *
 * This is a deliberate copy of the Wave companion's AMAT_Env rather than a
 * shared class. Sharing is not possible as written: that class hardcodes
 * `AMAW_DIR . '.env'`, so reusing it here would read Wave's .env file and never
 * find this plugin's keys. Each companion owning its own .env also keeps the two
 * plugins independent, which is the point of the split.
 *
 * Values are parsed once and cached for the request. A real environment variable
 * (getenv) takes precedence over the file so the same code works on hosts that
 * inject env vars directly.
 */
class AMAC_Env {

	/**
	 * Parsed key => value pairs from the .env file. Null until first load.
	 *
	 * @var array<string,string>|null
	 */
	private static $cache = null;

	/**
	 * Get a value by key, falling back to a default.
	 *
	 * @param string $key     Variable name, e.g. 'SMTP_PASSWORD'.
	 * @param string $default Value returned when the key is absent/empty.
	 * @return string
	 */
	public static function get( $key, $default = '' ) {
		// Real environment variables win over the file.
		$env = getenv( $key );
		if ( false !== $env && '' !== $env ) {
			return $env;
		}

		if ( null === self::$cache ) {
			self::$cache = self::load();
		}

		if ( isset( self::$cache[ $key ] ) && '' !== self::$cache[ $key ] ) {
			return self::$cache[ $key ];
		}

		return $default;
	}

	/**
	 * Whether a key has a non-empty value.
	 *
	 * Lets a settings page show "configured / not configured" without ever
	 * reading the secret into a template.
	 *
	 * @param string $key Variable name.
	 * @return bool
	 */
	public static function has( $key ) {
		return '' !== self::get( $key );
	}

	/**
	 * Drop the in-memory cache. Only useful in tests that rewrite the file.
	 *
	 * @return void
	 */
	public static function flush() {
		self::$cache = null;
	}

	/**
	 * Parse the .env file in the plugin root into an associative array.
	 *
	 * Supports `KEY=value`, optional `export ` prefix, `#` comments, and
	 * single/double quoted values. Intentionally tiny — no interpolation.
	 *
	 * @return array<string,string>
	 */
	private static function load() {
		$path = AMAC_DIR . '.env';
		$vars = array();

		if ( ! is_readable( $path ) ) {
			return $vars;
		}

		$lines = file( $path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES );
		if ( false === $lines ) {
			return $vars;
		}

		foreach ( $lines as $line ) {
			$line = trim( $line );

			if ( '' === $line || str_starts_with( $line, '#' ) ) {
				continue;
			}

			if ( str_starts_with( $line, 'export ' ) ) {
				$line = substr( $line, strlen( 'export ' ) );
			}

			$pos = strpos( $line, '=' );
			if ( false === $pos ) {
				continue;
			}

			$key   = trim( substr( $line, 0, $pos ) );
			$value = trim( substr( $line, $pos + 1 ) );

			// Strip surrounding matching quotes.
			if ( strlen( $value ) >= 2 ) {
				$first = $value[0];
				$last  = $value[ strlen( $value ) - 1 ];
				if ( ( '"' === $first && '"' === $last ) || ( "'" === $first && "'" === $last ) ) {
					$value = substr( $value, 1, -1 );
				}
			}

			if ( '' !== $key ) {
				$vars[ $key ] = $value;
			}
		}

		return $vars;
	}
}
