<?php
/**
 * Registry of available connectors, and which one is active per channel.
 *
 * @package AUTOmation_Comms
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Holds every registered connector and resolves the active one for a channel.
 *
 * This is the single place that knows what connectors exist. Adding one means
 * a new file under includes/connectors/ and one line in bootstrap() — the
 * Settings dropdown, the send path and the tests all read from here.
 */
class AMAC_Connector_Registry {

	/**
	 * Option holding the chosen connector slug for each channel, e.g.
	 * amat_comms_connector_email. Namespaced under core's amat_ prefix, as the
	 * Wave companion namespaces its own options.
	 */
	const OPTION_PREFIX = 'amat_comms_connector_';

	/**
	 * Registered connector instances, keyed by slug.
	 *
	 * @var array<string,AMAC_Connector>
	 */
	private static $connectors = array();

	/**
	 * Register the shipped connectors.
	 *
	 * Called once on plugins_loaded. Instantiating is cheap by contract — a
	 * connector must not do I/O or talk to its provider in its constructor,
	 * because every connector is built on every request just to populate a
	 * dropdown.
	 *
	 * @return void
	 */
	public static function bootstrap() {
		self::$connectors = array();

		self::register( new AMAC_Connector_Wp_Mail() );

		/**
		 * Let other code add a connector.
		 *
		 * Exists so a connector can live outside this plugin (a site-specific
		 * one-off, or a future paid provider add-on) without editing this file.
		 *
		 * @param AMAC_Connector_Registry $registry Unused marker arg; register via ::register().
		 */
		do_action( 'amac_register_connectors' );
	}

	/**
	 * Add a connector to the registry.
	 *
	 * @param AMAC_Connector $connector Connector instance.
	 * @return void
	 */
	public static function register( AMAC_Connector $connector ) {
		$slug = $connector->slug();
		if ( '' === $slug ) {
			return;
		}
		self::$connectors[ $slug ] = $connector;
	}

	/**
	 * All registered connectors, optionally narrowed to one channel.
	 *
	 * @param string $channel Channel slug, or '' for all.
	 * @return array<string,AMAC_Connector>
	 */
	public static function all( $channel = '' ) {
		if ( '' === $channel ) {
			return self::$connectors;
		}

		$out = array();
		foreach ( self::$connectors as $slug => $connector ) {
			if ( $connector->channel() === $channel ) {
				$out[ $slug ] = $connector;
			}
		}
		return $out;
	}

	/**
	 * Fetch one connector by slug.
	 *
	 * @param string $slug Connector slug.
	 * @return AMAC_Connector|null
	 */
	public static function get( $slug ) {
		return self::$connectors[ (string) $slug ] ?? null;
	}

	/**
	 * Option key holding the chosen connector for a channel.
	 *
	 * @param string $channel Channel slug.
	 * @return string
	 */
	public static function option_key( $channel ) {
		return self::OPTION_PREFIX . $channel;
	}

	/**
	 * The connector currently active for a channel.
	 *
	 * Falls back to the only registered connector for the channel when the
	 * setting is unset or points at something that no longer exists (a
	 * deactivated add-on, a renamed slug) — so a stale option degrades to a
	 * working default instead of silently sending nothing. With more than one
	 * candidate and no valid choice, returns null rather than guessing, and the
	 * Settings page asks.
	 *
	 * @param string $channel Channel slug.
	 * @return AMAC_Connector|null
	 */
	public static function active( $channel ) {
		$chosen    = (string) get_option( self::option_key( $channel ), '' );
		$connector = '' !== $chosen ? self::get( $chosen ) : null;

		if ( $connector && $connector->channel() === $channel ) {
			return $connector;
		}

		$available = self::all( $channel );
		return 1 === count( $available ) ? reset( $available ) : null;
	}

	/**
	 * Store the active connector for a channel.
	 *
	 * @param string $channel Channel slug.
	 * @param string $slug    Connector slug ('' clears the choice).
	 * @return void
	 */
	public static function set_active( $channel, $slug ) {
		update_option( self::option_key( $channel ), (string) $slug, false );
	}
}
