<?php
/**
 * Creates/updates this plugin's own tables.
 *
 * @package AUTOmation_Comms
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Schema owner for AUTOmation Comms.
 *
 * Only one table: the message log. Deliberately NOT core's `external_refs`,
 * which is a one-row-per-(provider, entity_type, entity_id) store — it models
 * "this local record is linked to that remote record". Comms is many-messages-
 * per-record (three reminders about one job), so external_refs would overwrite
 * the first send with the second. Nor is it core's `logs` table: that records
 * *outcomes*, is capped per row and prunes on a retention window, so it cannot
 * be the durable archive of what was actually sent to a customer. Comms writes
 * to both — the row here is the record, AMAT_Log is the event.
 *
 * The table name follows core's `{prefix}amat_` convention (giving
 * `wp_amat_comms_messages`), which also means core's schema-generic Backup tool
 * discovers and includes it automatically.
 */
class AMAC_Activator {

	/**
	 * Create or update tables, then stamp the schema version.
	 *
	 * dbDelta is additive — it never drops columns — so this is safe to run on
	 * every activation and on the on-load version check.
	 *
	 * @return void
	 */
	public static function activate() {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset = $wpdb->get_charset_collate();
		$table   = AMAC_Message_Model::table();

		// status: 'sent' | 'failed' | 'dry_run'.
		// entity_type/entity_id: what the message was about ('estimate'/'invoice'),
		// 0/'' when it was about nothing in particular.
		// external_id: the connector's own id for the message, when it returns one
		// (an SMS provider's message SID); blank for wp_mail, which has none.
		$sql = "CREATE TABLE {$table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			channel varchar(20) NOT NULL DEFAULT '',
			connector varchar(50) NOT NULL DEFAULT '',
			message_type varchar(50) NOT NULL DEFAULT '',
			customer_id bigint(20) unsigned NOT NULL DEFAULT 0,
			entity_type varchar(20) NOT NULL DEFAULT '',
			entity_id bigint(20) unsigned NOT NULL DEFAULT 0,
			recipient varchar(191) NOT NULL DEFAULT '',
			subject text NULL,
			body longtext NULL,
			status varchar(20) NOT NULL DEFAULT '',
			error text NULL,
			external_id varchar(191) NOT NULL DEFAULT '',
			sent_at datetime NULL,
			created_at datetime NULL,
			updated_at datetime NULL,
			PRIMARY KEY  (id),
			KEY customer_id (customer_id),
			KEY entity (entity_type,entity_id),
			KEY status (status)
		) {$charset};";

		dbDelta( $sql );

		update_option( 'amat_comms_db_version', AMAC_DB_VERSION, false );
	}
}
