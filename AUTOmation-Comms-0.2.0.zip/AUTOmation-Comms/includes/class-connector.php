<?php
/**
 * The contract every delivery connector implements.
 *
 * @package AUTOmation_Comms
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Abstract base for a thing that delivers a message.
 *
 * A CHANNEL is what kind of message it is (email, text). A CONNECTOR is the
 * route that delivers it. Several connectors may exist for one channel —
 * wp_mail and SMTP both put email on the wire, they just do it differently —
 * and exactly one is active per channel at a time.
 *
 * That split is why templates hang off the channel, not the connector: the
 * customer receives the same email whether it went out via wp_mail or SMTP, so
 * switching routes must never mean rewriting content. Email and SMS templates,
 * by contrast, are entirely separate — see AMAC_Templates.
 *
 * One file per connector under includes/connectors/, one class each, registered
 * in AMAC_Connector_Registry::bootstrap(). Adding a provider later is a new file
 * plus one line in that method; the Settings dropdown picks it up automatically.
 *
 * A connector's job is narrow on purpose: take an already-rendered message and
 * deliver it. It does not decide *what* to send (templates), *who* to send to
 * (channels), or *whether* to send (the dry-run gate) — those belong to
 * AMAC_Comms, so that policy stays identical across every connector rather than
 * being re-implemented, and drifting, in each one.
 */
abstract class AMAC_Connector {

	/**
	 * Stable machine slug, e.g. 'wp_mail'. Stored in settings and on message
	 * rows, so it must not change once shipped.
	 *
	 * @return string
	 */
	abstract public function slug();

	/**
	 * Human label for the settings dropdown.
	 *
	 * @return string
	 */
	abstract public function label();

	/**
	 * Which channel this connector delivers, an AMAC_Channels constant.
	 *
	 * @return string
	 */
	abstract public function channel();

	/**
	 * One-line description shown under the connector in Settings.
	 *
	 * @return string
	 */
	public function description() {
		return '';
	}

	/**
	 * Whether this connector has everything it needs to send.
	 *
	 * Checked before sending and surfaced in Settings, so a half-configured
	 * connector reports itself instead of failing at send time.
	 *
	 * @return bool
	 */
	public function is_configured() {
		return true;
	}

	/**
	 * Why the connector isn't configured — shown only when is_configured() is false.
	 *
	 * @return string
	 */
	public function config_hint() {
		return '';
	}

	/**
	 * Deliver a rendered message.
	 *
	 * Implementations must never throw and never fatal: a messaging failure is
	 * reported, logged and moved past, exactly as a provider failure is in the
	 * Wave companion. Return the result array instead.
	 *
	 * @param string                             $to      Recipient address for this channel.
	 * @param array{subject?:string,body:string} $message Rendered message parts.
	 * @param array<string,mixed>                $args    Optional context (customer_id, entity_type, entity_id).
	 * @return array{status:string,message:string,external_id:string}
	 *         status is 'sent' or 'failed'; message is a human-readable reason on failure.
	 */
	abstract public function send( $to, array $message, array $args = array() );

	/**
	 * Build a success result.
	 *
	 * @param string $external_id Connector's own message id, when it has one.
	 * @return array{status:string,message:string,external_id:string}
	 */
	protected function success( $external_id = '' ) {
		return array(
			'status'      => AMAC_Message_Model::STATUS_SENT,
			'message'     => '',
			'external_id' => (string) $external_id,
		);
	}

	/**
	 * Build a failure result.
	 *
	 * @param string $reason Human-readable reason.
	 * @return array{status:string,message:string,external_id:string}
	 */
	protected function failure( $reason ) {
		return array(
			'status'      => AMAC_Message_Model::STATUS_FAILED,
			'message'     => (string) $reason,
			'external_id' => '',
		);
	}
}
