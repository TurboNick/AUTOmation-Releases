<?php
/**
 * Data access for the message log.
 *
 * @package AUTOmation_Comms
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * One row per message this plugin attempted to send.
 *
 * Extends core's AMAT_Base_Model, so it inherits the same prepared-statement
 * CRUD, sanitizer types and managed timestamps as every core entity — there is
 * no reason for a companion to re-implement that layer.
 *
 * The row is written for a dry run too (status 'dry_run'), so the preview trail
 * is visible in the same place as real sends rather than vanishing.
 */
class AMAC_Message_Model extends AMAT_Base_Model {

	/**
	 * Message was handed to the connector and accepted.
	 */
	const STATUS_SENT = 'sent';

	/**
	 * Connector refused it or errored.
	 */
	const STATUS_FAILED = 'failed';

	/**
	 * Rendered and recorded, but deliberately not delivered (dry-run mode).
	 */
	const STATUS_DRY_RUN = 'dry_run';

	/**
	 * Table name without the WordPress + plugin prefix.
	 *
	 * @return string
	 */
	protected static function table_slug() {
		return 'comms_messages';
	}

	/**
	 * Writable columns with a sanitizer each.
	 *
	 * `body` is 'textarea' rather than 'text' so newlines survive — a message
	 * body is multi-line by nature and sanitize_text_field would flatten it.
	 *
	 * @return array<string,string>
	 */
	protected static function schema() {
		return array(
			'channel'      => 'text',
			'connector'    => 'text',
			'message_type' => 'text',
			'customer_id'  => 'int',
			'entity_type'  => 'text',
			'entity_id'    => 'int',
			'recipient'    => 'text',
			'subject'      => 'text',
			'body'         => 'textarea',
			'status'       => 'text',
			'error'        => 'textarea',
			'external_id'  => 'text',
			'sent_at'      => 'datetime',
		);
	}

	/**
	 * Messages sent about one entity, newest first.
	 *
	 * @param string $entity_type Entity slug, e.g. 'estimate'.
	 * @param int    $entity_id   Entity row id.
	 * @return array<int,array<string,mixed>>
	 */
	public static function for_entity( $entity_type, $entity_id ) {
		return static::all(
			array(
				'entity_type' => (string) $entity_type,
				'entity_id'   => (int) $entity_id,
			),
			array(
				'orderby' => 'id',
				'order'   => 'DESC',
			)
		);
	}

	/**
	 * Messages sent to one customer, newest first.
	 *
	 * @param int $customer_id Customer row id.
	 * @param int $limit       Max rows.
	 * @return array<int,array<string,mixed>>
	 */
	public static function for_customer( $customer_id, $limit = 50 ) {
		return static::all(
			array( 'customer_id' => (int) $customer_id ),
			array(
				'orderby' => 'id',
				'order'   => 'DESC',
				'limit'   => (int) $limit,
			)
		);
	}

	/**
	 * Human label for a stored status.
	 *
	 * @param string $status Stored status value.
	 * @return string
	 */
	public static function status_label( $status ) {
		$labels = array(
			self::STATUS_SENT    => __( 'Sent', 'auto-mation' ),
			self::STATUS_FAILED  => __( 'Failed', 'auto-mation' ),
			self::STATUS_DRY_RUN => __( 'Dry run (not delivered)', 'auto-mation' ),
		);
		return $labels[ $status ] ?? $status;
	}
}
