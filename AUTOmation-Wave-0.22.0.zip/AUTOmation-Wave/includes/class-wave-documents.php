<?php
/**
 * Document sync: push AUTOmation invoices to Wave and read payments back.
 *
 * Hangs off core's `amat_invoice_detail_actions` and `amat_job_invoice_actions`
 * hooks. Core stays unaware of Wave: the link lives in `external_refs` and every
 * outcome is written to core's generic event log via `AMAT_Log` on the 'wave'
 * channel.
 *
 * **Invoices only.** Estimates are not sent to Wave at all (Nick, 2026-10-07: "We
 * won't be using Wave for estimates. This is the whole point of building our own
 * solution. Wave will only be used for the invoice and collecting payment.").
 * They live in core and are approved in core's portal. An invoice is always
 * created directly in Wave — never by converting a Wave estimate. Estimates that
 * were pushed before then stay in Wave untouched, and their `external_refs` rows
 * are left in place, unused.
 *
 * **Who owns what.** AUTOmation is the source of truth for the invoice's
 * *content* — its line items, notes, who it is for. Wave owns the number it is
 * issued under and the money. So a push sends content one way, and the read-back
 * brings the number + payment status home.
 *
 * @package AUTOmation_Wave
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Pushes invoices to Wave and reflects Wave's number/payment status back.
 */
class AMAT_Wave_Documents {

	/**
	 * Our slug in core's job-document button/hand-off pair. Offered on invoices
	 * only; core tells us which type it saved.
	 *
	 * @var string
	 */
	const PUSH_ACTION = 'wave_push';

	const PUSH_INVOICE_ACTION = 'push_invoice_wave';
	const PUSH_INVOICE_NONCE  = 'amat_push_invoice_wave';

	/**
	 * Log channel for everything this class does (core's AMAT_Log).
	 *
	 * @var string
	 */
	const CHANNEL = 'wave';

	/**
	 * Provider slug used in external_refs.
	 *
	 * @var string
	 */
	const PROVIDER = 'wave';

	/**
	 * Hook into core's invoice detail + POST handling. Nothing is hooked on any
	 * estimate hook: estimates are not sent to Wave (2026-10-07).
	 *
	 * @return void
	 */
	public function register() {
		add_action( 'admin_init', array( $this, 'maybe_process' ) );
		add_action( 'amat_invoice_detail_actions', array( $this, 'render_invoice_actions' ) );

		// The same invoices, as edited on their job: a compact status row at the foot
		// of each invoice card on the job screen...
		add_action( 'amat_job_invoice_actions', array( $this, 'render_job_invoice_sync' ), 10, 2 );

		// ...and a button in the card's own action row, so core saves what the owner
		// typed before we push it. A push that sent the last-saved version instead of
		// what was on screen is exactly the bug this replaced (2026-09-22).
		add_filter( 'amat_job_document_buttons', array( $this, 'job_document_button' ), 10, 4 );
		add_filter( 'amat_job_document_saved_action', array( $this, 'handle_job_document_action' ), 10, 5 );
	}

	/**
	 * Intercept this class's POST actions on admin_init (before any output).
	 *
	 * @return void
	 */
	public function maybe_process() {
		$action = isset( $_POST['amat_action'] ) ? $_POST['amat_action'] : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce checked in each handler.
		if ( self::PUSH_INVOICE_ACTION === $action ) {
			$this->process_invoice_push();
		}
	}

	/* --------------------------------------------------------------------- */
	/* Compact sync row on the job edit page                                 */
	/* --------------------------------------------------------------------- */

	/**
	 * Listener for core's `amat_job_invoice_actions`.
	 *
	 * @param array<string,mixed> $invoice Invoice row.
	 * @param int                 $job_id  Owning job id.
	 * @return void
	 */
	public function render_job_invoice_sync( array $invoice, $job_id = 0 ) {
		$this->render_job_doc_sync( 'invoice', $invoice, (int) $job_id );
	}

	/**
	 * One invoice's sync state, as a single row at the foot of its card on the
	 * job screen. The push **button** is not here — it is contributed into core's
	 * own card form by job_document_button(), so the values the owner has typed are
	 * saved before anything is sent.
	 *
	 * Deliberately **compact**: the detail view's full Wave block (links table,
	 * payment summary, explanatory copy) would bury the line-item editor this page
	 * exists for. What is here is what you need without leaving: is it in Wave, how
	 * stale is it, and one button to send it. Everything else stays one click away
	 * on the document itself.
	 *
	 * @param string              $type   'invoice'.
	 * @param array<string,mixed> $doc    Document row.
	 * @param int                 $job_id Owning job id.
	 * @return void
	 */
	private function render_job_doc_sync( $type, array $doc, $job_id ) {
		$id = (int) ( $doc['id'] ?? 0 );
		if ( $id <= 0 ) {
			return;
		}

		$wave = new AMAT_Wave_Client();
		$ref  = AMAT_External_Ref_Model::get( self::PROVIDER, $type, $id );

		// No token and nothing ever pushed: say nothing at all rather than adding a
		// row about an integration this site isn't using.
		if ( ! $wave->is_configured() && ! $ref ) {
			return;
		}

		$linked = $ref && '' !== (string) $ref['external_id'];
		?>
		<div class="amat-doc-sync">
			<strong><?php esc_html_e( 'Wave', 'auto-mation' ); ?></strong>
			<?php
			$this->render_sync_status( $ref );

			if ( $linked ) {
				$this->render_links( $ref );
			}

			if ( ! $wave->is_configured() ) {
				echo '<span class="description">' . esc_html__( 'Wave is not configured.', 'auto-mation' ) . '</span>';
				echo '</div>';
				return;
			}

			// Say what is missing rather than offering a button that would just fail.
			$blocker = $this->invoice_push_blocker( $doc, $wave );
			if ( '' !== $blocker ) {
				echo '<span class="description">' . wp_kses_post( $blocker ) . '</span>';
				echo '</div>';
				return;
			}

			// The button itself is contributed to the card's own action row via
			// job_document_button() — it has to live inside core's form for the typed
			// values to be saved before the push.
			?>
		</div>
		<?php
	}

	/**
	 * Contribute the push button to an invoice's action row on the job screen
	 * (core's `amat_job_document_buttons`). Never to an estimate — estimates are
	 * not sent to Wave (2026-10-07).
	 *
	 * The button posts back into **core's** card form, so core saves the status,
	 * notes and line items the owner has just typed and only then calls
	 * handle_job_document_action() below. The label says so: this saves, then
	 * pushes. Offered only when a push could actually succeed — the status row
	 * explains the blocker otherwise.
	 *
	 * @param array<int,array<string,string>> $buttons Buttons so far.
	 * @param string                          $type    Document type; only 'invoice' gets a button.
	 * @param array<string,mixed>             $doc     Document row.
	 * @param int                             $job_id  Owning job id (unused).
	 * @return array<int,array<string,string>>
	 */
	public function job_document_button( $buttons, $type, $doc, $job_id = 0 ) {
		$buttons = (array) $buttons;
		$id      = (int) ( $doc['id'] ?? 0 );
		if ( $id <= 0 || 'invoice' !== $type ) {
			return $buttons;
		}

		$wave = new AMAT_Wave_Client();
		if ( ! $wave->is_configured() ) {
			return $buttons;
		}

		$blocker = $this->invoice_push_blocker( $doc, $wave );
		if ( '' !== $blocker ) {
			return $buttons;
		}

		$ref    = AMAT_External_Ref_Model::get( self::PROVIDER, $type, $id );
		$linked = $ref && '' !== (string) $ref['external_id'];

		$buttons[] = array(
			'action' => self::PUSH_ACTION,
			'label'  => $linked
				? __( 'Save & update in Wave', 'auto-mation' )
				: __( 'Save & push to Wave', 'auto-mation' ),
			'class'  => 'button',
		);

		return $buttons;
	}

	/**
	 * Push the document core has just saved (core's `amat_job_document_saved_action`).
	 *
	 * Runs after the save has landed, so what goes to Wave is what is on screen.
	 * Core owns the nonce, the capability check and the redirect back to the job;
	 * this returns the notice to flash there, and nothing else. A slug that is not
	 * ours is passed straight through — every provider sees every slug — and so is
	 * anything that is not an invoice (estimates are not sent to Wave).
	 *
	 * @param array<string,string>|null $notice Notice so far (null = core's default).
	 * @param string                    $action Provider action slug.
	 * @param string                    $type   Document type; only 'invoice' is pushed.
	 * @param int                       $doc_id Document id.
	 * @param int                       $job_id Owning job id (unused).
	 * @return array<string,string>|null
	 */
	public function handle_job_document_action( $notice, $action, $type, $doc_id, $job_id = 0 ) {
		if ( self::PUSH_ACTION !== $action || 'invoice' !== $type ) {
			return $notice;
		}

		$result = $this->push_invoice( (int) $doc_id );

		return array(
			'status'  => ( 'success' === $result['status'] ) ? 'success' : 'error',
			'message' => (string) $result['message'],
		);
	}

	/**
	 * The sync-status cell for one document.
	 *
	 * @param array<string,mixed>|null $ref external_refs row, or null.
	 * @return void
	 */
	private function render_sync_status( $ref ) {
		if ( ! $ref || '' === (string) $ref['external_id'] ) {
			$failed = $ref && 'failed' === $ref['status'];
			echo '<span class="description">';
			echo $failed
				? esc_html__( 'The last push failed — see Settings → Logs for why. Try again.', 'auto-mation' )
				: esc_html__( 'Not pushed to Wave yet.', 'auto-mation' );
			echo '</span>';
			return;
		}

		$when = ! empty( $ref['synced_at'] ) ? strtotime( (string) $ref['synced_at'] ) : 0;

		if ( 'failed' === $ref['status'] ) {
			echo '<span class="amat-status amat-log-badge-warning">' . esc_html__( 'Out of date', 'auto-mation' ) . '</span> ';
			echo '<span class="description">' . esc_html__( 'It is in Wave, but the last update failed — see Settings → Logs.', 'auto-mation' ) . '</span>';
			return;
		}

		echo '<span class="amat-status amat-log-badge-info">' . esc_html__( 'Synced', 'auto-mation' ) . '</span> ';
		if ( $when ) {
			echo '<span class="description">';
			printf(
				/* translators: %s: human-readable time difference, e.g. "5 mins". */
				esc_html__( 'last pushed %s ago', 'auto-mation' ),
				esc_html( human_time_diff( $when, (int) current_time( 'timestamp' ) ) )
			);
			echo '</span>';
		}
	}

	/**
	 * The view/PDF links for a synced document.
	 *
	 * Wave exposes a customer-facing `viewUrl` and a `pdfUrl`; it has **no**
	 * admin/edit URL field, so there is no "open in Wave's editor" link to give.
	 * Both are stored at push time rather than re-fetched on every page load.
	 *
	 * @param array<string,mixed> $ref external_refs row.
	 * @return void
	 */
	private function render_links( array $ref ) {
		$entity = (string) $ref['entity_type'];
		$links  = $this->stored_links( $entity, (int) $ref['entity_id'] );
		$label  = __( 'View invoice', 'auto-mation' );

		if ( empty( $links['viewUrl'] ) && empty( $links['pdfUrl'] ) ) {
			echo '<span class="description">' . esc_html__( 'Pushed. Open it from your Wave account.', 'auto-mation' ) . '</span>';
			return;
		}
		if ( ! empty( $links['viewUrl'] ) ) {
			echo '<a href="' . esc_url( $links['viewUrl'] ) . '" target="_blank" rel="noopener">' . esc_html( $label ) . '</a> ';
		}
		if ( ! empty( $links['pdfUrl'] ) ) {
			echo '<a href="' . esc_url( $links['pdfUrl'] ) . '" target="_blank" rel="noopener">' . esc_html__( 'PDF', 'auto-mation' ) . '</a>';
		}
	}

	/* --------------------------------------------------------------------- */
	/* Push                                                                  */
	/* --------------------------------------------------------------------- */

	/**
	 * Mark a document's external_ref 'failed' and log why, then return the error
	 * result. The ref carries the state (so the retry sweep can find it); the log
	 * carries the reason (core §4). Preserves any existing external_id.
	 *
	 * @param string              $entity  'invoice'.
	 * @param int                 $id      Document id.
	 * @param string              $message Human-readable failure reason.
	 * @param array<string,mixed> $context Extra log context.
	 * @return array{status:string,message:string,retryable:bool}
	 */
	private function mark_doc_failed( $entity, $id, $message, array $context ) {
		$existing = AMAT_External_Ref_Model::external_id( self::PROVIDER, $entity, (int) $id );
		AMAT_External_Ref_Model::set( self::PROVIDER, $entity, (int) $id, $existing, array( 'status' => 'failed' ) );
		AMAT_Log::error(
			self::CHANNEL,
			$message,
			array( 'entity_type' => $entity, 'entity_id' => (int) $id, 'context' => $context )
		);
		return array( 'status' => 'error', 'message' => $message, 'retryable' => true );
	}

	/**
	 * Build Wave line rows from an invoice's line items.
	 *
	 * Each line books to the parent product chosen in Settings (service lines →
	 * the service product, parts lines → the parts product) with our description
	 * riding along, because AUTOmation deliberately does not create per-item Wave
	 * products.
	 *
	 * @param array<int,array<string,mixed>> $items Core line-item rows.
	 * @param AMAT_Wave_Client               $wave  Client.
	 * @return array<int,array<string,mixed>>
	 */
	private function line_items_for_wave( array $items, AMAT_Wave_Client $wave ) {
		$service_product = $wave->get_service_product_id();
		$parts_product   = $wave->get_parts_product_id();

		$rows = array();
		foreach ( $items as $item ) {
			$is_part    = ( 'part' === $item['source_type'] );
			$product_id = $is_part ? $parts_product : $service_product;
			if ( '' === $product_id ) {
				continue; // invoice_push_blocker() already refuses this case.
			}
			$rows[] = array(
				'productId'   => $product_id,
				'description' => (string) $item['description'],
				'quantity'    => (float) $item['quantity'],
				'unitPrice'   => null === $item['unit_price'] ? 0 : (float) $item['unit_price'],
			);
		}

		return $rows;
	}

	/* --------------------------------------------------------------------- */
	/* Invoice detail UI                                                     */
	/* --------------------------------------------------------------------- */

	/**
	 * Render the Wave block on an invoice's read-only detail view.
	 *
	 * @param array<string,mixed> $invoice Invoice row.
	 * @return void
	 */
	public function render_invoice_actions( array $invoice ) {
		$id   = (int) $invoice['id'];
		$ref  = AMAT_External_Ref_Model::get( self::PROVIDER, 'invoice', $id );
		$wave = new AMAT_Wave_Client();
		?>
		<h2><?php esc_html_e( 'Wave', 'auto-mation' ); ?></h2>
		<table class="amat-detail-table">
			<tbody>
				<tr>
					<th><?php esc_html_e( 'Sync status', 'auto-mation' ); ?></th>
					<td><?php $this->render_sync_status( $ref ); ?></td>
				</tr>
				<?php if ( $ref && '' !== (string) $ref['external_id'] ) : ?>
					<tr>
						<th><?php esc_html_e( 'Payment', 'auto-mation' ); ?></th>
						<td><?php $this->render_payment_summary( $invoice ); ?></td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'In Wave', 'auto-mation' ); ?></th>
						<td><?php $this->render_links( $ref ); ?></td>
					</tr>
				<?php endif; ?>
			</tbody>
		</table>
		<?php

		if ( ! $wave->is_configured() ) {
			echo '<p class="description">' . esc_html__( 'Wave is not configured — add WAVE_API_TOKEN to .env to enable syncing.', 'auto-mation' ) . '</p>';
			return;
		}

		$blocker = $this->invoice_push_blocker( $invoice, $wave );
		if ( '' !== $blocker ) {
			echo '<p class="description">' . wp_kses_post( $blocker ) . '</p>';
			return;
		}

		$linked = $ref && '' !== (string) $ref['external_id'];
		?>
		<form method="post" class="amat-inline-form">
			<?php wp_nonce_field( self::PUSH_INVOICE_NONCE ); ?>
			<input type="hidden" name="amat_action" value="<?php echo esc_attr( self::PUSH_INVOICE_ACTION ); ?>" />
			<input type="hidden" name="id" value="<?php echo esc_attr( $id ); ?>" />
			<button type="submit" class="button amat-btn-primary">
				<?php echo $linked ? esc_html__( 'Update in Wave', 'auto-mation' ) : esc_html__( 'Push to Wave', 'auto-mation' ); ?>
			</button>
		</form>
		<p class="description">
			<?php if ( $linked ) : ?>
				<?php esc_html_e( 'Sends the current line items to the existing Wave invoice, and brings its payment status back.', 'auto-mation' ); ?>
			<?php else : ?>
				<?php esc_html_e( 'Creates a finalized invoice in Wave from these line items. Its number, due date and payment status come back here.', 'auto-mation' ); ?>
			<?php endif; ?>
		</p>
		<?php
	}

	/**
	 * The payment-summary cell: what Wave last told us about money.
	 *
	 * @param array<string,mixed> $invoice Invoice row.
	 * @return void
	 */
	private function render_payment_summary( array $invoice ) {
		$status = (string) $invoice['status'];
		$paid   = $invoice['amount_paid'];

		echo '<span class="amat-status amat-status-' . esc_attr( $status ) . '">' . esc_html( AMAT_Invoice_Model::status_label( $status ) ) . '</span> ';

		if ( null !== $paid && '' !== $paid ) {
			echo '<span class="description">';
			printf(
				/* translators: %s: formatted amount paid. */
				esc_html__( 'paid: %s', 'auto-mation' ),
				esc_html( AMAT_Money::format_amount( (float) $paid ) )
			);
			if ( ! empty( $invoice['paid_date'] ) ) {
				echo ' (' . esc_html( AMAT_Estimates_Page::date_display( (string) $invoice['paid_date'] ) ) . ')';
			}
			echo '</span>';
		}
	}

	/**
	 * Why this invoice cannot be pushed yet, as ready-to-print HTML ('' = it can).
	 *
	 * @param array<string,mixed> $invoice Invoice row.
	 * @param AMAT_Wave_Client    $wave    Client.
	 * @return string
	 */
	private function invoice_push_blocker( array $invoice, AMAT_Wave_Client $wave ) {
		$settings_url = add_query_arg( array( 'page' => AMAT_Wave_Provider::PAGE_SLUG ), admin_url( 'admin.php' ) );

		if ( 'void' === (string) $invoice['status'] ) {
			// Core's 'void' has no Wave counterpart, and invoiceDelete genuinely DESTROYS the accounting record (verified: it
			// reads back NOT_FOUND). Wave is the system of record for money, so we
			// refuse rather than delete. Void it in Wave by hand if truly needed.
			return esc_html__( 'This invoice is void, so it is not pushed to Wave. Wave is the record of your accounting — voiding there is a manual step, done in Wave.', 'auto-mation' );
		}

		if ( '' === AMAT_Wave_Client::customer_ref( (int) $invoice['customer_id'] ) ) {
			return esc_html__( 'The customer must be synced to Wave first — open the customer and use Sync to Wave.', 'auto-mation' );
		}

		$items = AMAT_Invoice_Item_Model::for_parent( (int) $invoice['id'] );
		if ( empty( $items ) ) {
			return esc_html__( 'Add at least one line item to this invoice first (edit it on its job).', 'auto-mation' );
		}

		$needs = array();
		foreach ( $items as $item ) {
			$needs[ 'part' === $item['source_type'] ? 'part' : 'service' ] = true;
		}
		if ( isset( $needs['service'] ) && '' === $wave->get_service_product_id() ) {
			return sprintf(
				/* translators: %s: URL of the Wave settings page. */
				wp_kses_post( __( 'This invoice has service lines, but no Wave product is chosen for them yet. Pick one under <a href="%s">Settings → Wave</a>.', 'auto-mation' ) ),
				esc_url( $settings_url )
			);
		}
		if ( isset( $needs['part'] ) && '' === $wave->get_parts_product_id() ) {
			return sprintf(
				/* translators: %s: URL of the Wave settings page. */
				wp_kses_post( __( 'This invoice has parts lines, but no Wave product is chosen for them yet. Pick one under <a href="%s">Settings → Wave</a>.', 'auto-mation' ) ),
				esc_url( $settings_url )
			);
		}

		return '';
	}

	/* --------------------------------------------------------------------- */
	/* Invoice push                                                          */
	/* --------------------------------------------------------------------- */

	/**
	 * Handle the invoice Push button: run the push, flash its result, redirect.
	 * The reusable work is in push_invoice() so auto-sync + the retry cron can
	 * drive the same code path without the request-lifecycle plumbing.
	 *
	 * @return void
	 */
	private function process_invoice_push() {
		check_admin_referer( self::PUSH_INVOICE_NONCE );
		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'auto-mation' ) );
		}

		$id     = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		$job_id = isset( $_POST['return_job'] ) ? absint( $_POST['return_job'] ) : 0;
		$result = $this->push_invoice( $id );

		$this->finish_push( 'invoice', $id, $job_id, $result );
	}

	/**
	 * Push one invoice to Wave, then bring its number/due-date/payment status home.
	 * Pure of the request lifecycle (no nonce/redirect/flash/exit) so the button
	 * handler, auto-sync and the retry cron can all call it. Marks the external_ref
	 * 'failed' + logs on a Wave error, so a failed push is findable and retryable.
	 *
	 * A first push always **creates** a finalized (SAVED) invoice; a re-push patches
	 * the existing one. An invoice is never made by converting a Wave estimate —
	 * even when its core estimate was once pushed to Wave — because estimates are
	 * no longer sent to Wave (Nick, 2026-10-07).
	 *
	 * @param int $id Invoice id.
	 * @return array{status:string,message:string,retryable?:bool,wave_id?:string,number?:string}
	 */
	public function push_invoice( $id ) {
		$id      = (int) $id;
		$invoice = $id ? AMAT_Invoice_Model::find( $id ) : null;

		if ( ! $invoice ) {
			return array( 'status' => 'error', 'message' => __( 'Invoice not found.', 'auto-mation' ), 'retryable' => false );
		}

		$wave = new AMAT_Wave_Client();
		if ( ! $wave->is_configured() ) {
			return array( 'status' => 'skipped', 'message' => __( 'Wave is not configured. Add WAVE_API_TOKEN to .env first.', 'auto-mation' ), 'retryable' => false );
		}

		$blocker = $this->invoice_push_blocker( $invoice, $wave );
		if ( '' !== $blocker ) {
			// Void / no customer link / no product: a precondition. A void invoice is
			// deliberately never pushed (Wave is the record of accounting) — skip, do
			// not mark failed.
			return array( 'status' => 'skipped', 'message' => wp_strip_all_tags( $blocker ), 'retryable' => false );
		}

		$items = $this->line_items_for_wave( AMAT_Invoice_Item_Model::for_parent( (int) $invoice['id'] ), $wave );
		if ( empty( $items ) ) {
			return $this->mark_doc_failed( 'invoice', $id, __( 'None of this invoice\'s lines could be sent to Wave.', 'auto-mation' ), array() );
		}

		$memo     = $this->build_memo( $invoice );
		$dates    = $this->invoice_dates( $invoice, $id );
		$issued   = $dates['invoiceDate'];
		$due      = $dates['dueDate'];
		$existing = AMAT_External_Ref_Model::external_id( self::PROVIDER, 'invoice', $id );
		$is_new   = ( '' === $existing );

		if ( $is_new ) {
			$result = $wave->create_invoice( array( 'customerId' => AMAT_Wave_Client::customer_ref( (int) $invoice['customer_id'] ), 'items' => $items, 'memo' => $memo, 'invoiceDate' => $issued, 'dueDate' => $due ) );
		} else {
			$result = $wave->update_invoice( array( 'id' => $existing, 'items' => $items, 'memo' => $memo, 'invoiceDate' => $issued, 'dueDate' => $due ) );
		}

		if ( is_wp_error( $result ) ) {
			return $this->mark_doc_failed(
				'invoice',
				$id,
				/* translators: %s: Wave error message. */
				sprintf( __( 'Wave push failed: %s', 'auto-mation' ), $result->get_error_message() ),
				array( 'code' => $result->get_error_code(), 'lines' => count( $items ) )
			);
		}

		AMAT_External_Ref_Model::set( self::PROVIDER, 'invoice', $id, $result['id'], array( 'status' => 'synced', 'synced_at' => current_time( 'mysql' ) ) );
		$this->store_links( 'invoice', $id, $result );

		$changes = $this->apply_invoice_readback( $invoice, $result );

		AMAT_Log::info(
			self::CHANNEL,
			$is_new ? __( 'Invoice created in Wave.', 'auto-mation' ) : __( 'Invoice updated in Wave.', 'auto-mation' ),
			array(
				'entity_type' => 'invoice',
				'entity_id'   => $id,
				'context'     => array(
					'wave_id'      => $result['id'],
					'wave_number'  => $result['number'],
					'wave_status'  => $result['status'],
					'lines'        => count( $items ),
					'applied'      => $changes,
				),
			)
		);

		$message = $is_new
			? __( 'Invoice created in Wave.', 'auto-mation' )
			: __( 'Invoice updated in Wave.', 'auto-mation' );
		if ( ! empty( $result['number'] ) ) {
			/* translators: %s: the invoice number Wave assigned. */
			$message .= ' ' . sprintf( __( 'Wave numbered it %s.', 'auto-mation' ), $result['number'] );
		}

		return array( 'status' => 'success', 'message' => $message, 'wave_id' => (string) $result['id'], 'number' => (string) $result['number'] );
	}

	/**
	 * Copy what Wave now says about one of our invoices - its payments, status,
	 * number and due date - without pushing anything (2026-10-24: payments taken in
	 * Wave were only ever read back when someone pressed "Save & update in Wave",
	 * so jobs closed as Paid kept unpaid invoices). Called by the Wave invoice
	 * history's import and nightly pass for each invoice that is ours. A void
	 * invoice of ours is left alone (we never put one in Wave on purpose).
	 *
	 * @param int                 $id   Local invoice id.
	 * @param array<string,mixed> $wave AMAT_Wave_Client invoice shape.
	 * @return array<string,string> What changed (empty when nothing did).
	 */
	public function readback( $id, array $wave ) {
		$invoice = AMAT_Invoice_Model::find( (int) $id );
		if ( ! $invoice || 'void' === (string) $invoice['status'] ) {
			return array();
		}
		$changes = $this->apply_invoice_readback( $invoice, $wave );
		if ( $changes ) {
			AMAT_Log::info(
				self::CHANNEL,
				__( 'Invoice brought up to date from Wave.', 'auto-mation' ),
				array(
					'entity_type' => 'invoice',
					'entity_id'   => (int) $id,
					'context'     => array( 'wave_id' => (string) ( $wave['id'] ?? '' ), 'wave_status' => (string) ( $wave['status'] ?? '' ), 'applied' => $changes ),
				)
			);
		}
		return $changes;
	}

	/**
	 * Reconcile an invoice's issue + due dates into something Wave will accept.
	 *
	 * Wave enforces `dueDate >= invoiceDate` and rejects the whole mutation with
	 * "Due date cannot be before invoice date" otherwise. Two ways to trip it:
	 *
	 *   1. **Not sending the issue date at all** — Wave then dates the invoice
	 *      TODAY, so every back-dated invoice (anything issued before today, i.e.
	 *      most of a real backlog) is rejected on its own due date. This is why
	 *      the issue date is now always sent.
	 *   2. **Core allowing due < issue.** Core does not validate the pair, so a
	 *      typo can persist locally and would otherwise fail forever against Wave.
	 *      Rather than refuse the push, the due date is clamped up to the issue
	 *      date and the divergence is logged. Note that the clamped value then
	 *      lands back on the local row: apply_invoice_readback() already treats
	 *      Wave's dueDate as authoritative, so core ends up agreeing with Wave
	 *      instead of holding a due date that precedes its own issue date.
	 *
	 * @param array<string,mixed> $invoice Local invoice row.
	 * @param int                 $id      Invoice id (for the log).
	 * @return array{invoiceDate:string,dueDate:string}
	 */
	private function invoice_dates( array $invoice, $id ) {
		$issued = trim( (string) ( $invoice['issue_date'] ?? '' ) );
		$due    = trim( (string) ( $invoice['due_date'] ?? '' ) );

		if ( '0000-00-00' === $issued ) {
			$issued = '';
		}
		if ( '0000-00-00' === $due ) {
			$due = '';
		}

		// With no issue date, Wave will stamp today — so today is the floor.
		$floor = ( '' !== $issued ) ? $issued : current_time( 'Y-m-d' );

		if ( '' !== $due && $due < $floor ) {
			AMAT_Log::warning(
				self::CHANNEL,
				__( 'Invoice due date is before its issue date; sent to Wave as the issue date instead.', 'auto-mation' ),
				array(
					'entity_type' => 'invoice',
					'entity_id'   => (int) $id,
					'context'     => array( 'issue_date' => $issued, 'due_date' => $due, 'sent_due_date' => $floor ),
				)
			);
			$due = $floor;
		}

		return array( 'invoiceDate' => $issued, 'dueDate' => $due );
	}

	/**
	 * Copy Wave's number, due date, payment status and amounts onto the invoice.
	 *
	 * Wave is the system of record for money, so the payment fields are always
	 * taken as authoritative: `amount_paid` from Wave's amountPaid, `paid_date`
	 * from the latest payment, and `status` from status_from_wave_invoice().
	 *
	 * @param array<string,mixed> $invoice Local invoice row (pre-push).
	 * @param array<string,mixed> $result  Wave's returned invoice.
	 * @return array<string,string> What changed (for the log).
	 */
	private function apply_invoice_readback( array $invoice, array $result ) {
		$id      = (int) $invoice['id'];
		$changes = array();
		$fields  = array();

		$number = trim( (string) ( $result['number'] ?? '' ) );
		if ( '' !== $number && $number !== (string) $invoice['number'] ) {
			$fields['number']  = $number;
			$changes['number'] = $number;
		}

		$due = trim( (string) ( $result['dueDate'] ?? '' ) );
		if ( '' !== $due && $due !== (string) $invoice['due_date'] ) {
			$fields['due_date']  = $due;
			$changes['due_date'] = $due;
		}

		// Money: Wave is authoritative. amountPaid comes back as a string like
		// "10.00"; an unpaid invoice reads "0.00", which we store as-is.
		if ( array_key_exists( 'amountPaid', $result ) && '' !== (string) $result['amountPaid'] ) {
			$paid = (string) $result['amountPaid'];
			if ( $paid !== (string) $invoice['amount_paid'] ) {
				$fields['amount_paid']  = $paid;
				$changes['amount_paid'] = $paid;
			}
		}

		$paid_date = trim( (string) ( $result['paidDate'] ?? '' ) );
		if ( '' !== $paid_date && $paid_date !== (string) $invoice['paid_date'] ) {
			$fields['paid_date']  = $paid_date;
			$changes['paid_date'] = $paid_date;
		}

		$status = self::status_from_wave_invoice( (string) ( $result['status'] ?? '' ) );
		if ( '' !== $status && $status !== (string) $invoice['status'] ) {
			$fields['status']  = $status;
			$changes['status'] = $status;
		}

		if ( $fields ) {
			AMAT_Invoice_Model::update( $id, $fields );

			// A payment arrives here, where core never sees it, so tell core's
			// workflow to look again: a paid invoice moves the job to its receipt.
			if ( ! empty( $invoice['job_id'] ) && class_exists( 'AMAT_Job_Workflow' ) ) {
				AMAT_Job_Workflow::reconcile( (int) $invoice['job_id'] );
			}
		}

		return $changes;
	}

	/**
	 * Map a Wave invoice status onto core's vocabulary.
	 *
	 * Returns '' when Wave's state is one core sets itself and Wave cannot improve
	 * on:
	 *
	 * - **DRAFT / SAVED** — the pre-send states. We only ever put a *finalized*
	 *   (SAVED) invoice into Wave, and core already knows it is finalized; importing
	 *   SAVED would just churn. Neither should drag a locally-progressed status back.
	 *
	 * Everything from SENT onward is genuinely Wave's to report — the customer
	 * seeing it, and every payment state — so those map through. UNPAID is Wave's
	 * "finalized + sent, nothing paid yet"; core mirrors it.
	 *
	 * @param string $wave_status Wave's InvoiceStatus value.
	 * @return string Core status slug, or '' to leave ours alone.
	 */
	public static function status_from_wave_invoice( $wave_status ) {
		$map = array(
			'SENT'     => 'sent',
			'VIEWED'   => 'viewed',
			'UNPAID'   => 'unpaid',
			'PARTIAL'  => 'partial',
			'PAID'     => 'paid',
			'OVERPAID' => 'overpaid',
			'OVERDUE'  => 'overdue',
		);

		return $map[ strtoupper( trim( $wave_status ) ) ] ?? '';
	}

	/* --------------------------------------------------------------------- */
	/* Stored links (viewUrl / pdfUrl)                                       */
	/* --------------------------------------------------------------------- */

	/**
	 * Option key holding the cached Wave links for one document.
	 *
	 * Wave's viewUrl/pdfUrl are stable per document, so they are stored at push
	 * time rather than re-fetched on every page view (§6: don't be chatty).
	 * external_refs has no field for them, and adding provider-shaped columns to a
	 * core table would break core's provider-agnosticism — so they live in this
	 * plugin's own option.
	 *
	 * @param string $entity 'invoice' (old 'estimate' link options may linger, unused).
	 * @param int    $id     Document id.
	 * @return string
	 */
	private function links_option( $entity, $id ) {
		return 'amat_wave_links_' . sanitize_key( $entity ) . '_' . (int) $id;
	}

	/**
	 * Remember a document's Wave links.
	 *
	 * @param string               $entity 'invoice'.
	 * @param int                  $id     Document id.
	 * @param array<string,string> $result Wave's returned document.
	 * @return void
	 */
	private function store_links( $entity, $id, array $result ) {
		update_option(
			$this->links_option( $entity, $id ),
			array(
				'viewUrl' => (string) ( $result['viewUrl'] ?? '' ),
				'pdfUrl'  => (string) ( $result['pdfUrl'] ?? '' ),
			),
			false
		);
	}

	/**
	 * A document's stored Wave links.
	 *
	 * @param string $entity 'invoice' (old 'estimate' link options may linger, unused).
	 * @param int    $id     Document id.
	 * @return array{viewUrl:string,pdfUrl:string}
	 */
	private function stored_links( $entity, $id ) {
		$stored = get_option( $this->links_option( $entity, $id ), array() );
		return array(
			'viewUrl' => (string) ( $stored['viewUrl'] ?? '' ),
			'pdfUrl'  => (string) ( $stored['pdfUrl'] ?? '' ),
		);
	}

	/**
	 * Listener for core's `amat_invoice_view_url`: where the customer views and
	 * pays this invoice - Wave's viewUrl, stored when it was pushed (Nick,
	 * 2026-10-09: the invoice email's link "will open directly to wave"). An
	 * invoice never pushed has none, and whatever another listener gave is kept.
	 * Reads the stored link; never a request to Wave per email.
	 *
	 * @param string              $url     The link so far.
	 * @param array<string,mixed> $invoice Invoice row.
	 * @return string
	 */
	public static function invoice_view_url( $url, $invoice ) {
		$id     = (int) ( is_array( $invoice ) ? ( $invoice['id'] ?? 0 ) : 0 );
		$stored = $id ? get_option( 'amat_wave_links_invoice_' . $id, array() ) : array();
		$view   = is_array( $stored ) ? trim( (string) ( $stored['viewUrl'] ?? '' ) ) : '';
		return '' !== $view ? $view : (string) $url;
	}

	/* --------------------------------------------------------------------- */
	/* Helpers                                                               */
	/* --------------------------------------------------------------------- */

	/**
	 * Build the memo pushed to Wave for a document: a vehicle header (VIN, the
	 * year/make/model/trim + colour, and the job's mileage) followed by the
	 * document's own notes. The header rides on the Wave invoice so the
	 * customer sees which vehicle it is for.
	 *
	 * Lines are emitted only for data that exists — no empty labels or placeholder
	 * lines (per Nick's spec). The layout, when everything is present:
	 *
	 *     1HGCM82633A004352
	 *     2019 Honda Accord EX-L (Silver)
	 *     Mileage: 87,432
	 *
	 *     <the invoice notes>
	 *
	 * The vehicle + mileage come from the document's parent job (the owner of both;
	 * customer/vehicle are inherited from it — core §4), falling back to the
	 * document's own vehicle_id if the job has none.
	 *
	 * @param array<string,mixed> $document Invoice row (has job_id, vehicle_id, notes).
	 * @return string
	 */
	private function build_memo( array $document ) {
		$notes = trim( (string) ( $document['notes'] ?? '' ) );

		$job     = ! empty( $document['job_id'] ) ? AMAT_Job_Model::find( (int) $document['job_id'] ) : null;
		$veh_id  = (int) ( $job['vehicle_id'] ?? 0 );
		$veh_id  = $veh_id > 0 ? $veh_id : (int) ( $document['vehicle_id'] ?? 0 );
		$vehicle = $veh_id > 0 ? AMAT_Vehicle_Model::find( $veh_id ) : null;

		$lines = array();

		if ( $vehicle ) {
			$vin = trim( (string) ( $vehicle['vin'] ?? '' ) );
			if ( '' !== $vin ) {
				$lines[] = $vin;
			}

			// "Year Make Model Trim", skipping any missing token; colour in parens.
			$desc = trim(
				implode(
					' ',
					array_filter(
						array(
							trim( (string) ( $vehicle['year'] ?? '' ) ),
							trim( (string) ( $vehicle['make'] ?? '' ) ),
							trim( (string) ( $vehicle['model'] ?? '' ) ),
							trim( (string) ( $vehicle['trim'] ?? '' ) ),
						)
					)
				)
			);
			if ( '' !== $desc ) {
				$color = trim( (string) ( $vehicle['color'] ?? '' ) );
				$lines[] = '' !== $color ? $desc . ' (' . $color . ')' : $desc;
			}
		}

		// Mileage lives on the job. Show only a real reading.
		$mileage = ( $job && null !== $job['mileage'] && '' !== (string) $job['mileage'] ) ? (int) $job['mileage'] : 0;
		if ( $mileage > 0 ) {
			/* translators: %s: formatted odometer reading. */
			$lines[] = sprintf( __( 'Mileage: %s', 'auto-mation' ), number_format( $mileage ) );
		}

		$header = implode( "\n", $lines );

		if ( '' === $header ) {
			return $notes;
		}
		if ( '' === $notes ) {
			return $header;
		}
		return $header . "\n\n" . $notes;
	}

	/**
	 * URL of an invoice's detail view.
	 *
	 * @param int $id Invoice id.
	 * @return string
	 */
	private function invoice_url( $id ) {
		return add_query_arg(
			array( 'page' => AMAT_Invoices_Page::PAGE_SLUG, 'action' => 'view', 'id' => (int) $id ),
			admin_url( 'admin.php' )
		);
	}

	/**
	 * URL of a job's screen with one document's card open — where a push launched
	 * from the job returns to. (Core v2.19.0 retired the job edit screen: a job's
	 * documents are edited in cards that expand from their rows on the job screen.)
	 *
	 * @param int    $id     Job id.
	 * @param string $type   'invoice'.
	 * @param int    $doc_id Document id.
	 * @return string
	 */
	private function job_url( $id, $type, $doc_id ) {
		$key = $type . '-' . (int) $doc_id;
		return add_query_arg(
			array( 'page' => AMAT_Jobs_Page::PAGE_SLUG, 'action' => 'view', 'id' => (int) $id, 'open' => $key ),
			admin_url( 'admin.php' )
		) . '#amat-doc-' . $key;
	}

	/**
	 * Flash a push's result and redirect — to the job that launched it when the
	 * push came from the job's document manager, otherwise to the document itself.
	 * Returning the owner to where they were working is the whole point of having
	 * the button on the job page; bouncing them to the invoice would undo it.
	 *
	 * Ends the request.
	 *
	 * @param string                      $type   'invoice'.
	 * @param int                         $id     Document id.
	 * @param int                         $job_id Job to return to, or 0.
	 * @param array{status:string,message:string} $result Push result.
	 * @return void
	 */
	private function finish_push( $type, $id, $job_id, array $result ) {
		$payload = array(
			'status'  => 'success' === $result['status'] ? 'success' : 'error',
			'message' => $result['message'],
		);

		// Only honour a job that actually exists — the id arrives in a POST field.
		if ( $job_id > 0 && AMAT_Job_Model::find( $job_id ) ) {
			$this->flash( $payload, AMAT_Jobs_Page::PAGE_SLUG );
			wp_safe_redirect( $this->job_url( $job_id, $type, $id ) );
			exit;
		}

		$this->flash( $payload, AMAT_Invoices_Page::PAGE_SLUG );
		wp_safe_redirect( $this->invoice_url( $id ) );
		exit;
	}

	/**
	 * Flash a one-shot notice onto a page (core's PRG flash format).
	 *
	 * @param array<string,string> $payload {status, message}.
	 * @param string               $slug    Page slug.
	 * @return void
	 */
	private function flash( array $payload, $slug ) {
		set_transient(
			'amat_flash_' . $slug . '_' . get_current_user_id(),
			$payload,
			MINUTE_IN_SECONDS
		);
	}
}
