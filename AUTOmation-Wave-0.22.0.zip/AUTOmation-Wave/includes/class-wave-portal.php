<?php
/**
 * A customer's Wave invoices in the portal's History (Nick, 2026-10-22).
 *
 * Many customers have invoices made in Wave before AUTOmation existed, or
 * outside it. This answers core's neutral `amat_portal_history_invoices` filter
 * with the linked Wave customer's invoices from the local copy
 * (AMAT_Wave_History) - never a call to Wave while a customer waits - leaving
 * out:
 *  - any linked to one of AUTOmation's invoices (it shows on its job - "don't
 *    duplicate listings of invoices that are already tied to a job");
 *  - DRAFT and SAVED ones, which the customer has never been sent.
 *
 * Core draws the rows; this only reads.
 *
 * @package AUTOmation_Wave
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Listener for amat_portal_history_invoices.
 */
class AMAT_Wave_Portal {

	/**
	 * The switch on the Wave settings page (Nick, 2026-10-22). Off until he turns
	 * it on, so an update changes nothing customers see by itself.
	 */
	const OPTION = 'amat_wave_portal_history';

	/** Wave statuses the customer has never been sent. */
	const UNSENT = array( 'DRAFT', 'SAVED' );

	/**
	 * Whether customers see their Wave invoices in History.
	 *
	 * @return bool
	 */
	public static function enabled() {
		return '1' === (string) get_option( self::OPTION, '0' );
	}

	/**
	 * Add the customer's stored Wave invoices that are not AUTOmation's own.
	 *
	 * @param mixed $invoices What other listeners gave (passed through).
	 * @param mixed $customer The customer row.
	 * @return mixed
	 */
	public static function history_invoices( $invoices, $customer ) {
		if ( ! self::enabled() || ! is_array( $invoices ) ) {
			return $invoices;
		}
		$customer_id = (int) ( is_array( $customer ) ? ( $customer['id'] ?? 0 ) : 0 );
		$wave_id     = $customer_id ? (string) AMAT_Wave_Client::customer_ref( $customer_id ) : '';
		$rows        = '' !== $wave_id ? AMAT_Wave_History::for_wave_customer( $wave_id ) : array();
		if ( ! $rows ) {
			return $invoices;
		}

		$ours = array();
		foreach ( AMAT_External_Ref_Model::all_for( 'wave', 'invoice' ) as $ref ) {
			$ours[ (string) $ref['external_id'] ] = true;
		}

		foreach ( $rows as $row ) {
			if ( isset( $ours[ (string) $row['wave_invoice_id'] ] ) || in_array( strtoupper( (string) $row['status'] ), self::UNSENT, true ) ) {
				continue;
			}
			$invoices[] = array(
				'number' => (string) $row['number'],
				'date'   => (string) $row['invoice_date'],
				'total'  => (string) $row['total'],
				'due'    => (string) $row['amount_due'],
				'status' => strtolower( (string) $row['status'] ),
				'url'    => (string) $row['view_url'],
			);
		}
		return $invoices;
	}
}
