<?php
/**
 * A local copy of the business's Wave invoices, for the customer portal's
 * History (Nick, 2026-10-23: "Would it be worth creating a table for this so we
 * don't need to query wave every time? This function really only exists for
 * businesses in my position who used wave before automation." - built as
 * option 1).
 *
 * - **The table** `{prefix}amat_wave_invoices` holds one row per Wave invoice:
 *   its Wave customer, number, status, dates, total, amount due and view link.
 *   Keyed by the *Wave* customer, so a customer linked to Wave later sees theirs
 *   at once. Every invoice is kept, ours included; what a customer is shown is
 *   decided when it is read (AMAT_Wave_Portal).
 * - **Import** reads the whole business a page at a time (100 invoices to a
 *   page) in the background on WP-Cron - a handful of requests, not one per
 *   customer. Started from Settings -> Wave.
 * - **Nightly** asks Wave only for invoices changed since the last pass
 *   (`modifiedAtAfter`), which brings in payments and invoices made directly in
 *   Wave, and the payments on our own invoices. Once an import has been done.
 * - A rate limit pauses and keeps its place; any other failure stops the run
 *   and says why on the settings page.
 *
 * Its rows are a copy of Wave's - nothing here is ever written back to Wave.
 *
 * @package AUTOmation_Wave
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The local store of Wave invoices, and the runs that fill it.
 */
class AMAT_Wave_History {

	/** Unprefixed table name (core's backup picks up every amat_ table). */
	const TABLE = 'amat_wave_invoices';

	/** This plugin's schema version, and where it is recorded. */
	const DB_VERSION = 1;
	const DB_OPTION  = 'amat_wave_db_version';

	/** The current or last run. */
	const STATE_OPTION = 'amat_wave_history_state';

	/** The Wave time (UTC, ISO) the next changes pass starts from. */
	const SYNCED_OPTION = 'amat_wave_history_synced_at';

	/** WP-Cron hooks. */
	const BATCH_HOOK   = 'amat_wave_history_batch';
	const NIGHTLY_HOOK = 'amat_wave_history_nightly';

	/** Pages read per background batch. */
	const PAGES_PER_BATCH = 3;

	/** Seconds to wait after Wave says "too many requests". */
	const RATE_LIMIT_WAIT = 60;

	/** Overlap kept between passes, for clocks that disagree a little. */
	const OVERLAP = 5 * MINUTE_IN_SECONDS;

	/** Invoices per page (tests make it small). @var int */
	public static $page_size = 100;

	/**
	 * Wire the cron callbacks (every context: they run in a cron request).
	 *
	 * @return void
	 */
	public static function register() {
		add_action( self::BATCH_HOOK, array( __CLASS__, 'run_batch' ) );
		add_action( self::NIGHTLY_HOOK, array( __CLASS__, 'nightly' ) );
	}

	/**
	 * The fully-prefixed table name.
	 *
	 * @return string
	 */
	public static function table() {
		global $wpdb;
		return $wpdb->prefix . self::TABLE;
	}

	/**
	 * Create or update the table when this plugin's schema version moves on.
	 * Cheap when current: one cached option read.
	 *
	 * @return void
	 */
	public static function maybe_install() {
		if ( (int) get_option( self::DB_OPTION, 0 ) >= self::DB_VERSION ) {
			return;
		}
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$charset = $wpdb->get_charset_collate();
		$table   = self::table();
		dbDelta(
			"CREATE TABLE {$table} (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			wave_invoice_id VARCHAR(191) NOT NULL DEFAULT '',
			wave_customer_id VARCHAR(191) NOT NULL DEFAULT '',
			number VARCHAR(64) NOT NULL DEFAULT '',
			status VARCHAR(20) NOT NULL DEFAULT '',
			invoice_date DATE NULL,
			due_date DATE NULL,
			total DECIMAL(12,2) NOT NULL DEFAULT 0,
			amount_due DECIMAL(12,2) NOT NULL DEFAULT 0,
			view_url TEXT NULL,
			wave_modified_at VARCHAR(40) NOT NULL DEFAULT '',
			synced_at DATETIME NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY wave_invoice_id (wave_invoice_id),
			KEY wave_customer_id (wave_customer_id)
			) {$charset};"
		);
		update_option( self::DB_OPTION, self::DB_VERSION, false );
	}

	/* --------------------------------------------------------------------- */
	/* Reading                                                               */
	/* --------------------------------------------------------------------- */

	/**
	 * One Wave customer's stored invoices, newest first.
	 *
	 * @param string $wave_customer_id Wave customer ID.
	 * @return array<int,array<string,mixed>>
	 */
	public static function for_wave_customer( $wave_customer_id ) {
		global $wpdb;
		$wave_customer_id = (string) $wave_customer_id;
		if ( '' === $wave_customer_id ) {
			return array();
		}
		$table = self::table();
		return (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE wave_customer_id = %s ORDER BY invoice_date DESC, id DESC", $wave_customer_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
	}

	/**
	 * How many invoices are stored.
	 *
	 * @return int
	 */
	public static function count() {
		global $wpdb;
		$table = self::table();
		return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
	}

	/**
	 * The Wave time the next changes pass starts from ('' before any import).
	 *
	 * @return string
	 */
	public static function last_synced() {
		return (string) get_option( self::SYNCED_OPTION, '' );
	}

	/**
	 * The site's offset from UTC at a moment, written out: "UTC−7", "UTC+5:30",
	 * or "UTC" (Nick, 2026-10-23: "list the timezone offset").
	 *
	 * @param int $timestamp Unix time.
	 * @return string
	 */
	public static function offset_label( $timestamp ) {
		$offset = wp_timezone()->getOffset( new DateTimeImmutable( '@' . (int) $timestamp ) );
		if ( 0 === $offset ) {
			return 'UTC';
		}
		$abs = abs( $offset );
		$min = (int) ( ( $abs % HOUR_IN_SECONDS ) / MINUTE_IN_SECONDS );
		return 'UTC' . ( $offset < 0 ? '−' : '+' ) . (int) floor( $abs / HOUR_IN_SECONDS ) . ( $min ? sprintf( ':%02d', $min ) : '' );
	}

	/**
	 * The current or last run.
	 *
	 * @return array{status:string,mode:string,page:int,pages:int,stored:int,total:int,since:string,started_at:string,finished_at:string,last_error:string}
	 */
	public static function state() {
		$blank = array(
			'status'      => 'idle',
			'mode'        => '',
			'page'        => 1,
			'pages'       => 0,
			'stored'      => 0,
			'total'       => 0,
			'since'       => '',
			'started_at'  => '',
			'finished_at' => '',
			'last_error'  => '',
		);
		$saved = get_option( self::STATE_OPTION, array() );
		return array_merge( $blank, is_array( $saved ) ? array_intersect_key( $saved, $blank ) : array() );
	}

	/* --------------------------------------------------------------------- */
	/* Runs                                                                  */
	/* --------------------------------------------------------------------- */

	/**
	 * Start a run in the background: 'import' (everything) or 'changes' (only
	 * what changed since the last pass - an import when there has been none).
	 *
	 * @param string $mode import or changes.
	 * @return true|WP_Error
	 */
	public static function start( $mode ) {
		if ( 'running' === self::state()['status'] ) {
			return new WP_Error( 'amat_wave_history_running', __( 'A Wave invoice check is already running.', 'auto-mation' ) );
		}
		$since = 'changes' === $mode ? self::last_synced() : '';
		$mode  = '' === $since ? 'import' : 'changes';
		update_option(
			self::STATE_OPTION,
			array(
				'status'     => 'running',
				'mode'       => $mode,
				'page'       => 1,
				'since'      => $since,
				'started_at' => gmdate( 'Y-m-d\TH:i:s\Z' ),
			),
			false
		);
		wp_clear_scheduled_hook( self::BATCH_HOOK );
		wp_schedule_single_event( time(), self::BATCH_HOOK );
		return true;
	}

	/**
	 * One background batch: a few pages, stored; then the next batch, or done.
	 *
	 * @return void
	 */
	public static function run_batch() {
		$state = self::state();
		if ( 'running' !== $state['status'] ) {
			return;
		}
		wp_clear_scheduled_hook( self::BATCH_HOOK );

		$client = new AMAT_Wave_Client();
		if ( ! $client->is_configured() ) {
			self::stop( $state, __( 'Wave is not configured.', 'auto-mation' ) );
			return;
		}

		// Our own invoices in Wave, by Wave id: their payments are read back as they
		// pass (2026-10-24 - a payment taken in Wave used to wait for someone to
		// press "Save & update in Wave").
		$ours = array();
		foreach ( AMAT_External_Ref_Model::all_for( 'wave', 'invoice' ) as $ref ) {
			$ours[ (string) $ref['external_id'] ] = (int) $ref['entity_id'];
		}
		$docs = new AMAT_Wave_Documents();

		for ( $i = 0; $i < self::PAGES_PER_BATCH; $i++ ) {
			$result = $client->get_invoices_page( $state['page'], self::$page_size, $state['since'] );
			if ( is_wp_error( $result ) ) {
				if ( AMAT_Wave_Client::is_rate_limited( $result ) ) {
					update_option( self::STATE_OPTION, $state, false );
					wp_schedule_single_event( time() + self::RATE_LIMIT_WAIT, self::BATCH_HOOK );
					return;
				}
				self::stop( $state, $result->get_error_message() );
				return;
			}
			foreach ( $result['rows'] as $row ) {
				self::store( $row );
				if ( isset( $ours[ (string) $row['id'] ] ) ) {
					$docs->readback( $ours[ (string) $row['id'] ], $row );
				}
			}
			$state['stored'] += count( $result['rows'] );
			$state['pages']   = max( 1, (int) $result['pages'] );
			$state['total']   = (int) $result['total'];
			++$state['page'];

			if ( $state['page'] > $state['pages'] ) {
				$state['status']      = 'done';
				$state['finished_at'] = gmdate( 'Y-m-d\TH:i:s\Z' );
				update_option( self::STATE_OPTION, $state, false );
				$from = strtotime( $state['started_at'] );
				update_option( self::SYNCED_OPTION, gmdate( 'Y-m-d\TH:i:s\Z', ( $from ? $from : time() ) - self::OVERLAP ), false );
				AMAT_Log::info( 'wave', sprintf( 'Wave invoice history %s finished: %d invoice(s) stored.', $state['mode'], $state['stored'] ) );
				return;
			}
		}
		update_option( self::STATE_OPTION, $state, false );
		wp_schedule_single_event( time() + 2, self::BATCH_HOOK );
	}

	/**
	 * End a run that failed, saying why.
	 *
	 * @param array<string,mixed> $state   The run.
	 * @param string              $message What went wrong.
	 * @return void
	 */
	private static function stop( array $state, $message ) {
		$state['status']      = 'failed';
		$state['last_error']  = (string) $message;
		$state['finished_at'] = gmdate( 'Y-m-d\TH:i:s\Z' );
		update_option( self::STATE_OPTION, $state, false );
		AMAT_Log::warning( 'wave', 'Wave invoice history stopped: ' . $message, array( 'context' => array( 'mode' => $state['mode'], 'page' => $state['page'] ) ) );
	}

	/**
	 * The nightly pass: what changed since last time. Only while the portal
	 * switch is on, and only after an import.
	 *
	 * @return void
	 */
	public static function nightly() {
		if ( '' === self::last_synced() || 'running' === self::state()['status'] ) {
			return;
		}
		self::start( 'changes' );
	}

	/**
	 * Keep the nightly pass scheduled while the switch is on or once an import has
	 * been done - it also brings payments taken in Wave back onto AUTOmation's own
	 * invoices (2026-10-24), which matters whether or not customers see the
	 * history. Off otherwise.
	 *
	 * @return void
	 */
	public static function schedule() {
		$next = wp_next_scheduled( self::NIGHTLY_HOOK );
		if ( ! AMAT_Wave_Portal::enabled() && '' === self::last_synced() ) {
			if ( $next ) {
				wp_clear_scheduled_hook( self::NIGHTLY_HOOK );
			}
			return;
		}
		if ( ! $next ) {
			// 3 AM site time, when nobody is waiting on anything.
			$at = new DateTimeImmutable( 'tomorrow 03:00', wp_timezone() );
			wp_schedule_event( $at->getTimestamp(), 'daily', self::NIGHTLY_HOOK );
		}
	}

	/**
	 * Store (or update) one invoice from Wave.
	 *
	 * @param array<string,mixed> $row AMAT_Wave_Client invoice shape.
	 * @return void
	 */
	private static function store( array $row ) {
		global $wpdb;
		$id = trim( (string) ( $row['id'] ?? '' ) );
		if ( '' === $id ) {
			return;
		}
		$date  = static fn( $d ) => preg_match( '/^\d{4}-\d{2}-\d{2}/', (string) $d ) ? substr( (string) $d, 0, 10 ) : null;
		$table = self::table();
		$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"INSERT INTO {$table} (wave_invoice_id, wave_customer_id, number, status, invoice_date, due_date, total, amount_due, view_url, wave_modified_at, synced_at)
				VALUES (%s, %s, %s, %s, NULLIF(%s, ''), NULLIF(%s, ''), %f, %f, %s, %s, %s)
				ON DUPLICATE KEY UPDATE wave_customer_id = VALUES(wave_customer_id), number = VALUES(number), status = VALUES(status), invoice_date = VALUES(invoice_date), due_date = VALUES(due_date), total = VALUES(total), amount_due = VALUES(amount_due), view_url = VALUES(view_url), wave_modified_at = VALUES(wave_modified_at), synced_at = VALUES(synced_at)", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$id,
				(string) ( $row['customerId'] ?? '' ),
				substr( (string) ( $row['number'] ?? '' ), 0, 64 ),
				strtoupper( substr( (string) ( $row['status'] ?? '' ), 0, 20 ) ),
				(string) $date( $row['invoiceDate'] ?? '' ),
				(string) $date( $row['dueDate'] ?? '' ),
				(float) str_replace( ',', '', (string) ( $row['total'] ?? 0 ) ),
				(float) str_replace( ',', '', (string) ( $row['amountDue'] ?? 0 ) ),
				esc_url_raw( (string) ( $row['viewUrl'] ?? '' ) ),
				substr( (string) ( $row['modifiedAt'] ?? '' ), 0, 40 ),
				current_time( 'mysql' )
			)
		);
	}
}
