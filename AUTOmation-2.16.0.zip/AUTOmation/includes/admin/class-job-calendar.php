<?php
/**
 * The server half of the Jobs calendar: jobs as FullCalendar events, the feed
 * for a visible date range, and the reschedule a drag or resize sends back.
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Jobs calendar data + AJAX endpoints (the calendar itself is FullCalendar,
 * assets/job-calendar.js; chosen 2026-09-23, see DECISIONS.md).
 *
 * Conventions the browser relies on:
 *  - Times are WALL-CLOCK, exactly as stored. The page runs FullCalendar with
 *    timeZone 'UTC', so no zone arithmetic happens on either side and a job at
 *    9:00 shows at 9:00 whatever the browser's zone.
 *  - A job saved with a date but no time is stored at 00:00 and is ALL-DAY when
 *    its end is empty or also 00:00. FullCalendar's all-day end is exclusive
 *    (the day after the last day); the stored end is the last day itself.
 *  - A timed job with no end is shown an hour long; hasEnd = false tells the
 *    page not to turn that display hour into a real end when the job is dragged.
 */
class AMAT_Job_Calendar {

	/**
	 * Nonce action shared by the feed and the reschedule endpoint.
	 */
	const NONCE = 'amat_job_calendar';

	/**
	 * How long a timed job with no end is drawn, in seconds.
	 */
	const DISPLAY_DURATION = HOUR_IN_SECONDS;

	/**
	 * Every scheduled job touching [$from, $to), as calendar events.
	 *
	 * @param string $from First day of the visible range, 'Y-m-d'.
	 * @param string $to   Day AFTER the last visible day, 'Y-m-d' (exclusive).
	 * @return array<int,array<string,mixed>>
	 */
	public static function events_between( $from, $to ) {
		$last = date_create( $to );
		if ( ! date_create( $from ) || ! $last ) {
			return array();
		}
		$last = $last->modify( '-1 day' )->format( 'Y-m-d' );

		$events = array();
		foreach ( AMAT_Job_Model::all() as $job ) {
			// scheduled_days() already answers "which days does this job occupy"
			// (and caps absurd ranges); the window keeps the answer to the view.
			if ( AMAT_Job_Model::scheduled_days( $job, $from, $last ) ) {
				$events[] = self::event( $job );
			}
		}
		return $events;
	}

	/**
	 * One job as a FullCalendar event object.
	 *
	 * @param array<string,mixed> $job Job row.
	 * @return array<string,mixed>
	 */
	public static function event( array $job ) {
		$start = self::parse_stored( $job['scheduled_start'] ?? '' );
		$end   = self::parse_stored( $job['scheduled_end'] ?? '' );
		if ( $end && $start && $end < $start ) {
			$end = null; // A reversed pair (older rows): show the start alone.
		}

		$all_day = $start && '00:00:00' === $start->format( 'H:i:s' ) && ( ! $end || '00:00:00' === $end->format( 'H:i:s' ) );

		if ( $all_day ) {
			$last      = $end ? $end : $start;
			$ev_start  = $start->format( 'Y-m-d' );
			$ev_end    = ( clone $last )->modify( '+1 day' )->format( 'Y-m-d' );
		} else {
			$ev_start = $start ? $start->format( 'Y-m-d\TH:i:s' ) : '';
			$shown    = $end ? $end : ( $start ? ( clone $start )->modify( '+' . self::DISPLAY_DURATION . ' seconds' ) : null );
			$ev_end   = $shown ? $shown->format( 'Y-m-d\TH:i:s' ) : '';
		}

		$status   = (string) ( $job['status'] ?? '' );
		$customer = ! empty( $job['customer_id'] ) ? AMAT_Customer_Model::find( (int) $job['customer_id'] ) : null;
		$who      = $customer ? AMAT_Customer_Model::display_name( $customer ) : __( '(no customer)', 'auto-mation' );
		$vehicle  = ! empty( $job['vehicle_id'] ) ? AMAT_Vehicle_Model::find( (int) $job['vehicle_id'] ) : null;

		return array(
			'id'            => (string) (int) $job['id'],
			'title'         => AMAT_Job_Model::label( $job, $who ),
			'start'         => $ev_start,
			'end'           => $ev_end,
			'allDay'        => $all_day,
			'url'           => add_query_arg(
				array( 'page' => AMAT_Jobs_Page::PAGE_SLUG, 'action' => 'view', 'id' => (int) $job['id'] ),
				admin_url( 'admin.php' )
			),
			'classNames'    => array( 'amat-cal-status-' . sanitize_html_class( $status ) ),
			'extendedProps' => array(
				'status'      => $status,
				'statusLabel' => AMAT_Job_Model::status_label( $status ),
				'customer'    => $who,
				'vehicle'     => $vehicle ? AMAT_Vehicle_Model::label( $vehicle ) : '',
				'service'     => self::first_service( (int) $job['id'] ),
				'hasEnd'      => (bool) $end,
			),
		);
	}

	/**
	 * Move/resize a job to a new start (and end), as sent by the calendar.
	 *
	 * Held to the same rule as the job form: the end may not be before the start.
	 * Only the two schedule columns change.
	 *
	 * @param int    $id      Job id.
	 * @param string $start   'Y-m-d' (all-day) or 'Y-m-dTH:i[:s]' (a trailing Z or
	 *                        offset is ignored - times are wall-clock).
	 * @param string $end     Same shapes, or '' for no end. All-day: EXCLUSIVE.
	 * @param bool   $all_day Whether the event is all-day.
	 * @return array{job:array,previous:array}|WP_Error
	 */
	public static function reschedule( $id, $start, $end, $all_day ) {
		$job = AMAT_Job_Model::find( (int) $id );
		if ( ! $job ) {
			return new WP_Error( 'amat_cal_no_job', __( 'That job no longer exists.', 'auto-mation' ) );
		}

		$new_start = self::parse_sent( $start, $all_day );
		$new_end   = '' === trim( (string) $end ) ? null : self::parse_sent( $end, $all_day );
		if ( ! $new_start || ( '' !== trim( (string) $end ) && ! $new_end ) ) {
			return new WP_Error( 'amat_cal_bad_date', __( 'The calendar sent a date it could not read. Nothing was changed.', 'auto-mation' ) );
		}

		if ( $all_day ) {
			$new_start = $new_start->setTime( 0, 0, 0 );
			if ( $new_end ) {
				// Exclusive end -> the last day itself.
				$new_end = $new_end->setTime( 0, 0, 0 )->modify( '-1 day' );
			}
		}

		if ( $new_end && $new_end < $new_start ) {
			return new WP_Error( 'amat_cal_end_before_start', __( 'The end of the job would be before its start. Nothing was changed.', 'auto-mation' ) );
		}

		$previous = self::event( $job );
		AMAT_Job_Model::update(
			(int) $id,
			array(
				'scheduled_start' => $new_start->format( 'Y-m-d H:i:s' ),
				'scheduled_end'   => $new_end ? $new_end->format( 'Y-m-d H:i:s' ) : '',
			)
		);
		$job = AMAT_Job_Model::find( (int) $id );

		// A drag is easy to make by accident, so it leaves a trail.
		AMAT_Log::info(
			'core',
			sprintf(
				/* translators: 1: job label, 2: new start. */
				__( 'Rescheduled "%1$s" on the calendar to %2$s.', 'auto-mation' ),
				$previous['title'],
				$new_start->format( $all_day ? 'Y-m-d' : 'Y-m-d H:i' )
			),
			array(
				'entity_type' => 'job',
				'entity_id'   => (int) $id,
				'context'     => array(
					'from' => array( 'start' => $previous['start'], 'end' => $previous['extendedProps']['hasEnd'] ? $previous['end'] : '' ),
					'to'   => array( 'start' => (string) $job['scheduled_start'], 'end' => (string) $job['scheduled_end'] ),
				),
			)
		);

		return array(
			'job'      => $job,
			// What Undo sends back: the old event, in the calendar's own shape.
			'previous' => array(
				'start'  => $previous['start'],
				'end'    => $previous['extendedProps']['hasEnd'] ? $previous['end'] : '',
				'allDay' => $previous['allDay'],
			),
		);
	}

	/* --------------------------------------------------------------------- */
	/* AJAX                                                                  */
	/* --------------------------------------------------------------------- */

	/**
	 * AJAX (wp_ajax_amat_calendar_events): the events for [start, end).
	 *
	 * @return void
	 */
	public static function ajax_events() {
		check_ajax_referer( self::NONCE, 'nonce' );
		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			wp_send_json_error( array( 'message' => __( 'Not allowed.', 'auto-mation' ) ), 403 );
		}

		$from = substr( sanitize_text_field( wp_unslash( $_POST['start'] ?? '' ) ), 0, 10 ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- checked above.
		$to   = substr( sanitize_text_field( wp_unslash( $_POST['end'] ?? '' ) ), 0, 10 ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- checked above.

		wp_send_json_success( self::events_between( $from, $to ) );
	}

	/**
	 * AJAX (wp_ajax_amat_calendar_reschedule): move/resize one job.
	 *
	 * @return void
	 */
	public static function ajax_reschedule() {
		check_ajax_referer( self::NONCE, 'nonce' );
		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			wp_send_json_error( array( 'message' => __( 'Not allowed.', 'auto-mation' ) ), 403 );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- checked above.
		$result = self::reschedule(
			isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0,
			sanitize_text_field( wp_unslash( $_POST['start'] ?? '' ) ),
			sanitize_text_field( wp_unslash( $_POST['end'] ?? '' ) ),
			! empty( $_POST['allDay'] ) && '0' !== (string) $_POST['allDay'] && 'false' !== (string) $_POST['allDay']
		);
		// phpcs:enable

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}
		wp_send_json_success( array( 'previous' => $result['previous'], 'event' => self::event( $result['job'] ) ) );
	}

	/* --------------------------------------------------------------------- */
	/* Helpers                                                               */
	/* --------------------------------------------------------------------- */

	/**
	 * First line-item description of the job's newest estimate, truncated for
	 * the calendar, or '' when there is none.
	 *
	 * @param int $job_id Job id.
	 * @param int $limit  Max characters before truncating with an ellipsis.
	 * @return string
	 */
	public static function first_service( $job_id, $limit = 40 ) {
		$ests = AMAT_Estimate_Model::all( array( 'job_id' => absint( $job_id ) ), array( 'orderby' => 'id', 'order' => 'DESC', 'limit' => 1 ) );
		if ( empty( $ests ) ) {
			return '';
		}
		$items = AMAT_Estimate_Item_Model::for_parent( (int) $ests[0]['id'] );
		if ( empty( $items ) ) {
			return '';
		}
		$name = (string) $items[0]['description'];
		if ( mb_strlen( $name ) > $limit ) {
			$name = mb_substr( $name, 0, $limit - 1 ) . '…';
		}
		return $name;
	}

	/**
	 * A stored datetime, or null when unset/zero/unreadable.
	 *
	 * @param mixed $value Stored value.
	 * @return DateTimeImmutable|null
	 */
	private static function parse_stored( $value ) {
		$value = trim( (string) $value );
		if ( '' === $value || 0 === strpos( $value, '0000' ) ) {
			return null;
		}
		$dt = DateTimeImmutable::createFromFormat( '!Y-m-d H:i:s', substr( str_replace( 'T', ' ', $value ), 0, 19 ) );
		return $dt ? $dt : null;
	}

	/**
	 * A date/time sent by the calendar, strictly validated (2026-02-30 is refused,
	 * not rolled into March), or null.
	 *
	 * @param string $value   'Y-m-d' or 'Y-m-dTH:i[:s]', optionally with a zone suffix.
	 * @param bool   $all_day Whether a bare date is expected.
	 * @return DateTimeImmutable|null
	 */
	private static function parse_sent( $value, $all_day ) {
		$value = trim( (string) $value );
		if ( ! preg_match( '/^(\d{4}-\d{2}-\d{2})(?:[T ](\d{2}:\d{2})(?::(\d{2}))?)?/', $value, $m ) ) {
			return null;
		}
		$time = isset( $m[2] ) ? $m[2] . ':' . ( isset( $m[3] ) ? $m[3] : '00' ) : '00:00:00';
		if ( ! $all_day && ! isset( $m[2] ) ) {
			$time = '00:00:00';
		}
		$text = $m[1] . ' ' . $time;
		$dt   = DateTimeImmutable::createFromFormat( '!Y-m-d H:i:s', $text );
		return ( $dt && $dt->format( 'Y-m-d H:i:s' ) === $text ) ? $dt : null;
	}
}
