<?php
/**
 * Job model.
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Data access for the jobs table.
 *
 * A job ties a customer + vehicle + location + work together and has many
 * parts orders. Front-end bookings are created as `requested` for the owner
 * to approve (§4 of CLAUDE.md).
 */
class AMAT_Job_Model extends AMAT_Base_Model {

	/**
	 * Allowed job statuses (§4 status vocabulary).
	 *
	 * `standby` sits next to `scheduled` deliberately: a standby job **is
	 * scheduled** — it has a real appointment the customer can rely on — but the
	 * customer would take an earlier slot if one frees up. It is therefore a
	 * variant of scheduled, not a stage before or after it, and it must keep its
	 * place on the calendar (which buckets by `scheduled_start`, not by status, so
	 * this happens on its own).
	 *
	 * @var string[]
	 */
	const STATUSES = array( 'requested', 'scheduled', 'standby', 'in_progress', 'completed', 'invoiced', 'cancelled' );

	/**
	 * Statuses that mean "this job has a confirmed place in the calendar".
	 *
	 * Both `scheduled` and `standby` qualify — the difference between them is
	 * whether the customer wants to move earlier, not whether the appointment is
	 * real. Anything counting or displaying booked work should use this rather
	 * than testing for 'scheduled' alone, or standby jobs quietly go missing.
	 *
	 * @var string[]
	 */
	const BOOKED_STATUSES = array( 'scheduled', 'standby' );

	/**
	 * {@inheritDoc}
	 */
	protected static function table_slug() {
		return 'jobs';
	}

	/**
	 * {@inheritDoc}
	 */
	protected static function schema() {
		return array(
			'customer_id'      => 'int',
			'vehicle_id'       => 'int',
			'location_id'      => 'int',
			'name'             => 'text',
			'scheduled_start'  => 'datetime',
			'scheduled_end'    => 'datetime',
			'status'           => 'text',
			'description'      => 'textarea',
			'mileage'          => 'int',
			'wave_estimate_id' => 'text',
			'wave_invoice_id'  => 'text',
		);
	}

	/**
	 * Human labels for each status slug, in workflow order.
	 *
	 * @return array<string,string>
	 */
	public static function statuses_labeled() {
		return array(
			'requested'   => __( 'Requested', 'auto-mation' ),
			'scheduled'   => __( 'Scheduled', 'auto-mation' ),
			'standby'     => __( 'Standby', 'auto-mation' ),
			'in_progress' => __( 'In progress', 'auto-mation' ),
			'completed'   => __( 'Completed', 'auto-mation' ),
			'invoiced'    => __( 'Invoiced', 'auto-mation' ),
			'cancelled'   => __( 'Cancelled', 'auto-mation' ),
		);
	}

	/**
	 * Human label for a status slug (falls back to the slug).
	 *
	 * @param string $status Status slug.
	 * @return string
	 */
	public static function status_label( $status ) {
		$labels = self::statuses_labeled();
		return $labels[ $status ] ?? (string) $status;
	}

	/**
	 * Sanitize, forcing status to the allowed vocabulary.
	 *
	 * @param array<string,mixed> $data Raw input.
	 * @return array<string,mixed>
	 */
	protected static function sanitize( array $data ) {
		$clean = parent::sanitize( $data );
		if ( isset( $clean['status'] ) && ! in_array( $clean['status'], self::STATUSES, true ) ) {
			$clean['status'] = 'requested';
		}
		return $clean;
	}

	/**
	 * The job's display label: its optional Name, else the given fallback
	 * (typically the customer's display name). Shown wherever a job is
	 * referenced — calendar, grid, detail heading, customer Jobs block.
	 *
	 * @param array<string,mixed> $job      Job row.
	 * @param string              $fallback Text to use when the job has no name.
	 * @return string
	 */
	public static function label( array $job, $fallback = '' ) {
		$name = trim( (string) ( $job['name'] ?? '' ) );
		return '' !== $name ? $name : (string) $fallback;
	}

	/**
	 * All jobs for a customer, by schedule.
	 *
	 * @param int $customer_id Customer id.
	 * @return array<int,array<string,mixed>>
	 */
	public static function for_customer( $customer_id ) {
		return self::all( array( 'customer_id' => absint( $customer_id ) ), array( 'orderby' => 'scheduled_start' ) );
	}

	/**
	 * The calendar days a job occupies, as `Y-m-d` strings.
	 *
	 * A job has a start *and an end*, so one that runs Monday to Thursday belongs on
	 * four days, not one. This is the single answer to "which days is this job on",
	 * shared by the month calendar and available to the portal and the mobile agenda
	 * view when they land — the calendar used to file a job under `scheduled_start`
	 * alone, which is why a long job only ever showed on its first day.
	 *
	 * Defensive about the data it is given, because a job is scheduled by hand:
	 *
	 * - No start date → no days at all (it belongs in the Unscheduled list).
	 * - No end, an unparseable end, or an end **before** its start → just the start
	 *   day. A reversed pair is rejected at save now, but rows predating that check
	 *   exist, and a calendar is the wrong place to discover one.
	 * - The window clamps the result, so a job running over a month boundary costs
	 *   only the days actually on screen. With no window, the span is capped at a
	 *   year so a mistyped end date cannot spin out a huge array.
	 *
	 * @param array<string,mixed> $job          Job row.
	 * @param string              $window_start Earliest day to return (`Y-m-d`), or '' for none.
	 * @param string              $window_end   Latest day to return (`Y-m-d`), or '' for none.
	 * @return array<int,string> Ordered list of `Y-m-d` days; empty when unscheduled.
	 */
	public static function scheduled_days( array $job, $window_start = '', $window_end = '' ) {
		$start = self::date_part( $job['scheduled_start'] ?? '' );
		if ( '' === $start ) {
			return array();
		}

		$end = self::date_part( $job['scheduled_end'] ?? '' );
		if ( '' === $end || $end < $start ) {
			$end = $start;
		}

		// Clamp to the caller's window before walking, not after.
		$from = ( '' !== $window_start && $window_start > $start ) ? $window_start : $start;
		$to   = ( '' !== $window_end && $window_end < $end ) ? $window_end : $end;
		if ( $from > $to ) {
			return array();
		}

		$days   = array();
		$cursor = date_create( $from );
		if ( ! $cursor ) {
			return array();
		}
		$guard = 0;
		while ( $guard < 366 ) {
			$day = $cursor->format( 'Y-m-d' );
			if ( $day > $to ) {
				break;
			}
			$days[] = $day;
			$cursor->modify( '+1 day' );
			++$guard;
		}

		return $days;
	}

	/**
	 * The `Y-m-d` part of a stored datetime, or '' when it holds no real date.
	 *
	 * MySQL hands back `0000-00-00 00:00:00` for a zeroed date and the column is
	 * nullable, so "is there a date here" needs asking properly rather than by
	 * truthiness.
	 *
	 * @param mixed $value Stored datetime.
	 * @return string
	 */
	private static function date_part( $value ) {
		$value = trim( (string) $value );
		if ( '' === $value || 0 === strpos( $value, '0000' ) ) {
			return '';
		}
		$date = substr( $value, 0, 10 );
		return preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ? $date : '';
	}
}
