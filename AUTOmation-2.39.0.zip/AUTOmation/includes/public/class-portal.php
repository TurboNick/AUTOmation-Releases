<?php
/**
 * The customer portal: what a customer sees of their own records, how they ask
 * for an appointment, and the public "Request service" form.
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The customer-facing side of AUTOmation (CLAUDE.md §1: "view and update their
 * contact information, view vehicle information and service history,
 * view/approve estimates, view/pay invoices and schedule service").
 *
 * It is delivered as two shortcodes so any theme can carry it - the website
 * (`mrgind-website`) puts them on its "My Account" and "Request Service" pages:
 *
 *  - [amat_portal]           a logged-in customer's dashboard, one of their
 *                            estimates, their contact details; the login form
 *                            for everyone else.
 *  - [amat_request_service]  how anyone asks for service - a new customer, or a
 *                            logged-in one picking their vehicle and address.
 *                            (My account's own "Book service" was removed
 *                            2026-10-06: one way to do each thing.)
 *
 * The rules everything here serves:
 *  - **A customer sees only their own records.** Every read goes through
 *    current_customer(), which is only ever the customer linked to the logged-in
 *    user (customers.wp_user_id) - never an id from the request.
 *  - **Nothing internal reaches a customer**: a job's notes and research; draft
 *    and void documents. (The Hold/Standby reason DOES reach them - it is
 *    written for them; the job screen says so.)
 *  - **A customer never books outright.** They ask for a time; it arrives as a
 *    PROPOSED time on a job, on the calendar as a tentative block, for the owner
 *    to confirm ("Customer picked this").
 *  - **Staff accounts are never portal logins** (grant_access()).
 *
 * Auth is WordPress's own login and "set your password" email; a magic-link
 * login is a Future Feature (FUTURE.md). Front-end forms post to admin-post.php,
 * so their handlers are registered in every request (register_handlers()).
 */
class AMAT_Portal {

	/**
	 * Custom role slug for portal customers.
	 *
	 * @var string
	 */
	const ROLE = 'amat_customer';

	/**
	 * The page carrying [amat_portal] (Settings -> Customer portal).
	 *
	 * @var string
	 */
	const PAGE_OPTION = 'amat_portal_page';

	/**
	 * The page carrying [amat_request_service].
	 *
	 * @var string
	 */
	const REQUEST_PAGE_OPTION = 'amat_request_page';

	/**
	 * Public requests accepted from one address per hour.
	 *
	 * @var int
	 */
	const REQUESTS_PER_HOUR = 5;

	/**
	 * A person takes at least this long to fill in the request form.
	 *
	 * @var int
	 */
	const MIN_FORM_SECONDS = 3;

	/**
	 * How many half-day times a customer may propose at once (Nick, 2026-10-01).
	 *
	 * @var int
	 */
	const MAX_PROPOSALS = 2;

	/**
	 * The page holding the business's Terms, linked from the text-alerts consent
	 * (Settings -> Customer portal). Privacy is WordPress's own Privacy Policy page.
	 *
	 * @var string
	 */
	const TERMS_PAGE_OPTION = 'amat_terms_page';

	/**
	 * VIN lookups the public form may make from one address per hour - the
	 * decoder is a free government service, and this endpoint is open to anyone.
	 *
	 * @var int
	 */
	const VIN_DECODES_PER_HOUR = 20;

	/**
	 * Hook the front end: shortcodes, styles, and keeping customers' logins
	 * pointed at the portal.
	 *
	 * @return void
	 */
	public function register() {
		add_shortcode( 'amat_portal', array( __CLASS__, 'shortcode_portal' ) );
		add_shortcode( 'amat_request_service', array( __CLASS__, 'shortcode_request' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
	}

	/**
	 * Hooks needed in every request: the form handlers (they run through
	 * admin-post.php, an admin request) and the rules that keep portal customers
	 * out of wp-admin.
	 *
	 * @return void
	 */
	public static function register_handlers() {
		add_action( 'admin_post_amat_portal_access', array( __CLASS__, 'handle_access' ) );
		add_action( 'admin_post_amat_portal_contact', array( __CLASS__, 'handle_contact' ) );
		// Accept or decline an estimate (Nick, 2026-10-07).
		add_action( 'admin_post_amat_portal_estimate', array( __CLASS__, 'handle_estimate_decision' ) );
		// A password set from an estimate's link opens that estimate (2026-10-07).
		add_action( 'after_password_reset', array( __CLASS__, 'after_password_reset' ) );
		// The portal's own "Choose your password" page (Nick, 2026-10-13): sent in
		// the background, or posted plainly without JavaScript - one handler.
		add_action( 'wp_ajax_amat_portal_password', array( __CLASS__, 'handle_set_password' ) );
		add_action( 'wp_ajax_nopriv_amat_portal_password', array( __CLASS__, 'handle_set_password' ) );
		add_action( 'admin_post_amat_portal_password', array( __CLASS__, 'handle_set_password' ) );
		add_action( 'admin_post_nopriv_amat_portal_password', array( __CLASS__, 'handle_set_password' ) );
		add_action( 'admin_post_nopriv_amat_portal_contact', array( __CLASS__, 'handle_contact' ) );
		add_action( 'admin_post_amat_request_service', array( __CLASS__, 'handle_request' ) );
		add_action( 'admin_post_nopriv_amat_request_service', array( __CLASS__, 'handle_request' ) );
		// The same handler answers the form's background send (JSON, nothing lost).
		add_action( 'wp_ajax_amat_request_service', array( __CLASS__, 'handle_request' ) );
		add_action( 'wp_ajax_nopriv_amat_request_service', array( __CLASS__, 'handle_request' ) );
		add_action( 'wp_ajax_amat_request_vin', array( __CLASS__, 'ajax_decode_vin' ) );
		add_action( 'wp_ajax_nopriv_amat_request_vin', array( __CLASS__, 'ajax_decode_vin' ) );
		// Someone we know, caught as they type (Nick, 2026-10-07).
		add_action( 'wp_ajax_amat_request_known', array( __CLASS__, 'ajax_known_contact' ) );
		add_action( 'wp_ajax_nopriv_amat_request_known', array( __CLASS__, 'ajax_known_contact' ) );
		// The thank-you's "Set account password" (Nick, 2026-10-07).
		add_action( 'wp_ajax_amat_request_account', array( __CLASS__, 'ajax_create_account' ) );
		add_action( 'wp_ajax_nopriv_amat_request_account', array( __CLASS__, 'ajax_create_account' ) );
		// A customer logs in with their phone number as well as their email.
		add_filter( 'authenticate', array( __CLASS__, 'authenticate_by_phone' ), 30, 3 );
		add_action( 'admin_init', array( __CLASS__, 'keep_out_of_admin' ) );
		add_filter( 'show_admin_bar', array( __CLASS__, 'admin_bar' ) );
		add_filter( 'login_redirect', array( __CLASS__, 'login_redirect' ), 10, 3 );
		// A request held because its email/phone was already ours moves onto that
		// customer's account when they log in (Nick, 2026-10-07).
		add_action( 'wp_login', array( __CLASS__, 'claim_held_requests' ), 10, 2 );
	}

	/**
	 * Ensure the customer role exists. Called from activation.
	 *
	 * A minimal role: portal customers can read their own data through the
	 * plugin but have no wp-admin capabilities.
	 *
	 * @return void
	 */
	public static function add_role() {
		if ( null === get_role( self::ROLE ) ) {
			// Untranslated, as WordPress's own role names are: this can run before
			// `init` (the upgrade routine), where translating is too early.
			add_role( self::ROLE, 'Customer', array( 'read' => true ) );
		}
	}

	/* --------------------------------------------------------------------- */
	/* Who is looking                                                        */
	/* --------------------------------------------------------------------- */

	/**
	 * The customer the owner is previewing while a portal page renders, or 0.
	 * Set and cleared inside shortcode_portal() only.
	 *
	 * @var int
	 */
	private static $preview = 0;

	/**
	 * "View portal as this customer": the customer named by ?amat_preview=, when
	 * the person asking holds the plugin's admin capability. Anyone else gets
	 * null - and with it their own portal, exactly as without the parameter.
	 *
	 * It shapes what is SHOWN only. current_customer(), which every form handler
	 * goes by, never sees it.
	 *
	 * @return array<string,mixed>|null
	 */
	private static function preview_customer() {
		if ( empty( $_GET['amat_preview'] ) || ! current_user_can( AMAT_Admin::CAPABILITY ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- a read-only view, behind the capability.
			return null;
		}
		$customer = AMAT_Customer_Model::find( absint( $_GET['amat_preview'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- as above.
		return $customer ? $customer : null;
	}

	/**
	 * The customer the logged-in user is linked to, if active - the only source
	 * of "whose records" anywhere in the portal.
	 *
	 * @return array<string,mixed>|null
	 */
	public static function current_customer() {
		$uid = get_current_user_id();
		if ( ! $uid ) {
			return null;
		}
		foreach ( AMAT_Customer_Model::all( array( 'wp_user_id' => $uid ) ) as $customer ) {
			if ( ! empty( $customer['is_active'] ) ) {
				return $customer;
			}
		}
		return null;
	}

	/**
	 * The portal page's address (home if none is set), with extra query args.
	 *
	 * @param array<string,string> $args Query args.
	 * @return string
	 */
	public static function portal_url( array $args = array() ) {
		if ( self::$preview ) {
			$args['amat_preview'] = (string) self::$preview; // a preview's links stay in the preview
		}
		return self::page_url( self::PAGE_OPTION, $args );
	}

	/**
	 * The request page's address (home if none is set), with extra query args.
	 *
	 * @param array<string,string> $args Query args.
	 * @return string
	 */
	public static function request_url( array $args = array() ) {
		return self::page_url( self::REQUEST_PAGE_OPTION, $args );
	}

	/**
	 * A configured page's address, or home.
	 *
	 * @param string               $option Option holding the page id.
	 * @param array<string,string> $args   Query args.
	 * @return string
	 */
	private static function page_url( $option, array $args ) {
		$page = (int) get_option( $option, 0 );
		$url  = $page && 'publish' === get_post_status( $page ) ? get_permalink( $page ) : home_url( '/' );
		return $args ? add_query_arg( $args, $url ) : $url;
	}

	/* --------------------------------------------------------------------- */
	/* Giving and removing access (the owner, on the customer screen)        */
	/* --------------------------------------------------------------------- */

	/**
	 * Give a customer a portal login: their email contact method becomes the
	 * login, and (by default) WordPress sends its own "set your password" email.
	 *
	 * Refused: a customer with no email; an email that already belongs to a site
	 * user who is anything other than a portal customer (a staff account is never
	 * linked); a login already linked to another customer.
	 *
	 * @param int  $customer_id Customer id.
	 * @param bool $notify      Send the "set your password" email.
	 * @return int|WP_Error The linked user id.
	 */
	public static function grant_access( $customer_id, $notify = true ) {
		$customer = AMAT_Customer_Model::find( (int) $customer_id );
		if ( ! $customer || empty( $customer['is_active'] ) ) {
			return new WP_Error( 'amat_portal_customer', __( 'That customer does not exist or is disabled.', 'auto-mation' ) );
		}
		if ( (int) $customer['wp_user_id'] && get_userdata( (int) $customer['wp_user_id'] ) ) {
			return (int) $customer['wp_user_id'];
		}

		$email = self::email_of( (int) $customer_id );
		if ( '' === $email ) {
			return new WP_Error( 'amat_portal_email', __( 'Add an email contact method first - it becomes their login.', 'auto-mation' ) );
		}

		$user = get_user_by( 'email', $email );
		if ( $user ) {
			if ( array( self::ROLE ) !== array_values( (array) $user->roles ) ) {
				return new WP_Error( 'amat_portal_staff', __( 'That email belongs to a site user who is not a portal customer, so it cannot be linked.', 'auto-mation' ) );
			}
			foreach ( AMAT_Customer_Model::all( array( 'wp_user_id' => (int) $user->ID ) ) as $other ) {
				if ( (int) $other['id'] !== (int) $customer_id ) {
					return new WP_Error( 'amat_portal_taken', __( 'That login already belongs to another customer.', 'auto-mation' ) );
				}
			}
			$user_id = (int) $user->ID;
		} else {
			$login = sanitize_user( strtolower( $email ), true );
			$base  = $login;
			for ( $n = 2; username_exists( $login ); $n++ ) {
				$login = $base . $n;
			}
			$user_id = wp_insert_user(
				array(
					'user_login'   => $login,
					'user_email'   => $email,
					'user_pass'    => wp_generate_password( 24 ),
					'role'         => self::ROLE,
					'first_name'   => (string) $customer['first_name'],
					'last_name'    => (string) $customer['last_name'],
					'display_name' => AMAT_Customer_Model::display_name( $customer ),
				)
			);
			if ( is_wp_error( $user_id ) ) {
				return $user_id;
			}
			$user_id = (int) $user_id;
		}

		AMAT_Customer_Model::update( (int) $customer_id, array( 'wp_user_id' => $user_id ) );
		if ( $notify ) {
			self::send_welcome( $user_id, $customer );
		}
		/* translators: %s: the login email. */
		AMAT_Log::info( 'core', sprintf( __( 'Portal access given (%s).', 'auto-mation' ), $email ), array( 'entity_type' => 'customer', 'entity_id' => (int) $customer_id ) );
		return $user_id;
	}

	/**
	 * The welcome a customer gets with their new account: who it is from, what the
	 * account is for, and a button to set their password (Nick, 2026-10-06: the
	 * WordPress one was "plain and unbranded"). The wording is Claude's draft, on
	 * Nick's checklist for approval. A theme can supply its logo through the
	 * `amat_email_logo_url` filter (else the site icon, else the business name).
	 *
	 * @param int                 $user_id  The customer's login.
	 * @param array<string,mixed> $customer The customer.
	 * @return void
	 */
	private static function send_welcome( $user_id, array $customer ) {
		$name = self::business_name();
		// The button opens the portal's branded password page (2026-10-13), not
		// WordPress's; with no target stored, they land on My jobs.
		AMAT_Welcome_Email::send(
			$user_id,
			array(
				/* translators: %s: the business name. */
				'subject' => sprintf( __( 'Welcome to your %s account', 'auto-mation' ), $name ),
				'first'   => (string) $customer['first_name'],
				/* translators: %s: the business name. */
				'intro'   => sprintf( __( 'Welcome to %s! We set up an account for you so everything about your vehicle is in one place:', 'auto-mation' ), $name ),
				'items'   => self::account_benefits(),
				'expired' => __( 'The link works once, for a limited time - if it has expired, use "Forgot your password?" on our website.', 'auto-mation' ),
				/* translators: %s: the business name. */
				'closing' => sprintf( __( 'Thanks for choosing %s.', 'auto-mation' ), $name ),
			),
			array( __CLASS__, 'password_url' )
		);
	}

	/**
	 * What an account is for - said by the welcome email and by the thank-you's
	 * invitation to make one (one list, so they never drift apart).
	 *
	 * @return string[]
	 */
	public static function account_benefits() {
		return array(
			__( 'See where your job is - every step from the first look to the final invoice.', 'auto-mation' ),
			__( 'Read your estimates and invoices in one place, whenever you like.', 'auto-mation' ),
			__( 'Book a time that suits you - we confirm it with you.', 'auto-mation' ),
			__( 'Keep your contact details up to date, so we can always reach you.', 'auto-mation' ),
		);
	}

	/**
	 * Remove a customer's portal access: unlink them, and delete the login if it
	 * is a portal-only one (it can do nothing else).
	 *
	 * @param int $customer_id Customer id.
	 * @return void
	 */
	public static function revoke_access( $customer_id ) {
		$customer = AMAT_Customer_Model::find( (int) $customer_id );
		if ( ! $customer || ! (int) $customer['wp_user_id'] ) {
			return;
		}
		$user_id = (int) $customer['wp_user_id'];
		AMAT_Customer_Model::update( (int) $customer_id, array( 'wp_user_id' => 0 ) );
		$user = get_userdata( $user_id );
		if ( $user && array( self::ROLE ) === array_values( (array) $user->roles ) ) {
			require_once ABSPATH . 'wp-admin/includes/user.php';
			wp_delete_user( $user_id );
		}
		AMAT_Log::info( 'core', __( 'Portal access removed.', 'auto-mation' ), array( 'entity_type' => 'customer', 'entity_id' => (int) $customer_id ) );
	}

	/**
	 * The customer's first email contact method, or ''.
	 *
	 * @param int $customer_id Customer id.
	 * @return string
	 */
	private static function email_of( $customer_id ) {
		foreach ( AMAT_Contact_Method_Model::for_customer( (int) $customer_id ) as $m ) {
			if ( 'email' === $m['type'] && is_email( $m['value'] ) ) {
				return (string) $m['value'];
			}
		}
		return '';
	}

	/**
	 * The customer screen's "Customer portal" block.
	 *
	 * @param array<string,mixed> $customer Customer row.
	 * @return void
	 */
	public static function render_admin_panel( array $customer ) {
		$user  = (int) $customer['wp_user_id'] ? get_userdata( (int) $customer['wp_user_id'] ) : false;
		$email = self::email_of( (int) $customer['id'] );
		?>
		<h2><?php esc_html_e( 'Customer portal', 'auto-mation' ); ?></h2>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="amat-portal-access">
			<?php wp_nonce_field( 'amat_portal_access' ); ?>
			<input type="hidden" name="action" value="amat_portal_access" />
			<input type="hidden" name="customer" value="<?php echo esc_attr( (string) (int) $customer['id'] ); ?>" />
			<?php if ( $user ) : ?>
				<p>
					<?php /* translators: %s: the login email. */ echo esc_html( sprintf( __( 'Can log in to the portal as %s.', 'auto-mation' ), $user->user_email ) ); ?>
				</p>
				<button type="submit" name="grant" value="0" class="button amat-btn-disable" onclick="return confirm('<?php echo esc_js( __( 'Remove this customer\'s portal login?', 'auto-mation' ) ); ?>');"><?php esc_html_e( 'Remove portal access', 'auto-mation' ); ?></button>
			<?php else : ?>
				<p class="description">
					<?php
					echo '' !== $email
						/* translators: %s: the customer's email. */
						? esc_html( sprintf( __( 'No portal login yet. Giving access emails %s a link to set a password.', 'auto-mation' ), $email ) )
						: esc_html__( 'No portal login yet. Add an email contact method first - it becomes their login.', 'auto-mation' );
					?>
				</p>
				<button type="submit" name="grant" value="1" class="button amat-btn-primary"<?php disabled( '' === $email ); ?>><?php esc_html_e( 'Give portal access', 'auto-mation' ); ?></button>
			<?php endif; ?>
		</form>
		<?php
		$page = (int) get_option( self::PAGE_OPTION, 0 );
		if ( $page && 'publish' === get_post_status( $page ) ) {
			echo '<p><a class="button" target="_blank" rel="noopener" href="' . esc_url( add_query_arg( 'amat_preview', (int) $customer['id'], get_permalink( $page ) ) ) . '">' . esc_html__( 'View portal as this customer', 'auto-mation' ) . '</a></p>';
		} else {
			echo '<p class="description">' . esc_html__( 'To see the portal as this customer does, choose the portal page under Settings → Portal pages.', 'auto-mation' ) . '</p>';
		}
	}

	/**
	 * The customer screen's Give / Remove portal access button.
	 *
	 * @return void
	 */
	public static function handle_access() {
		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'auto-mation' ) );
		}
		check_admin_referer( 'amat_portal_access' );

		$customer = isset( $_POST['customer'] ) ? absint( $_POST['customer'] ) : 0;
		if ( ! empty( $_POST['grant'] ) ) {
			$result = self::grant_access( $customer );
			$notice = is_wp_error( $result )
				? array( 'status' => 'error', 'message' => $result->get_error_message() )
				: array( 'status' => 'success', 'message' => __( 'Portal access given - they have been emailed a link to set a password.', 'auto-mation' ) );
		} else {
			self::revoke_access( $customer );
			$notice = array( 'status' => 'success', 'message' => __( 'Portal access removed.', 'auto-mation' ) );
		}

		set_transient( 'amat_flash_' . AMAT_Customers_Page::PAGE_SLUG . '_' . get_current_user_id(), $notice, MINUTE_IN_SECONDS );
		wp_safe_redirect( add_query_arg( array( 'page' => AMAT_Customers_Page::PAGE_SLUG, 'action' => 'view', 'id' => $customer ), admin_url( 'admin.php' ) ) );
		exit;
	}

	/* --------------------------------------------------------------------- */
	/* Keeping customers out of wp-admin                                     */
	/* --------------------------------------------------------------------- */

	/**
	 * Whether the current user is a portal customer and nothing more.
	 *
	 * @return bool
	 */
	private static function is_portal_only_user() {
		$user = wp_get_current_user();
		return $user && $user->exists() && in_array( self::ROLE, (array) $user->roles, true ) && ! current_user_can( AMAT_Admin::CAPABILITY );
	}

	/**
	 * A portal customer who wanders into wp-admin lands on the portal instead.
	 * The form handlers (admin-post.php) and AJAX are left alone.
	 *
	 * @return void
	 */
	public static function keep_out_of_admin() {
		global $pagenow;
		if ( wp_doing_ajax() || 'admin-post.php' === $pagenow || ! self::is_portal_only_user() ) {
			return;
		}
		wp_safe_redirect( self::portal_url() );
		exit;
	}

	/**
	 * No WordPress toolbar for portal customers.
	 *
	 * @param bool $show Whether to show it.
	 * @return bool
	 */
	public static function admin_bar( $show ) {
		return self::is_portal_only_user() ? false : $show;
	}

	/**
	 * After logging in, a portal customer goes where the login asked to - the
	 * request form's "Log in" brings them back to the form - as long as that is on
	 * this site and not wp-admin. Otherwise, and when nothing was asked for, the
	 * portal.
	 *
	 * @param string           $to        Where WordPress would go.
	 * @param string           $requested Where was asked for.
	 * @param WP_User|WP_Error $user      Who logged in.
	 * @return string
	 */
	public static function login_redirect( $to, $requested, $user ) {
		if ( ! ( $user instanceof WP_User && array( self::ROLE ) === array_values( (array) $user->roles ) ) ) {
			return $to;
		}
		$asked = '' !== (string) $requested ? wp_validate_redirect( (string) $requested, '' ) : '';
		if ( '' !== $asked && 0 !== strpos( $asked, admin_url() ) && false === strpos( $asked, 'wp-login.php' ) ) {
			return $asked;
		}
		return self::portal_url();
	}

	/* --------------------------------------------------------------------- */
	/* The portal page: [amat_portal]                                         */
	/* --------------------------------------------------------------------- */

	/**
	 * Styles for the portal and request pages - only where they are used. The
	 * theme dresses them; these keep them usable on any theme.
	 *
	 * @return void
	 */
	public static function enqueue() {
		$post = get_post();
		if ( $post && ( has_shortcode( (string) $post->post_content, 'amat_portal' ) || has_shortcode( (string) $post->post_content, 'amat_request_service' ) ) ) {
			wp_enqueue_style( 'amat-portal', AMAT_PLUGIN_URL . 'assets/portal.css', array(), AMAT_VERSION );
			wp_enqueue_script( 'amat-fullcalendar', AMAT_PLUGIN_URL . 'assets/fullcalendar/fullcalendar.min.js', array(), '6.1.15', true );
			wp_enqueue_script( 'amat-portal-booking', AMAT_PLUGIN_URL . 'assets/portal-booking.js', array( 'amat-fullcalendar' ), AMAT_VERSION, true );
			wp_enqueue_script( 'amat-portal-forms', AMAT_PLUGIN_URL . 'assets/portal-forms.js', array(), AMAT_VERSION, true );
		}
		if ( $post && has_shortcode( (string) $post->post_content, 'amat_request_service' ) ) {
			wp_enqueue_script( 'amat-portal-request', AMAT_PLUGIN_URL . 'assets/portal-request.js', array(), AMAT_VERSION, true );
		}
	}

	/**
	 * [amat_portal]: the login form, or the logged-in customer's portal.
	 *
	 * @param array<string,string>|string $atts Shortcode attributes (none used).
	 * @return string HTML.
	 */
	public static function shortcode_portal( $atts ) {
		unset( $atts );
		ob_start();
		echo '<div class="amat-portal">';
		self::notice();

		// "Choose your password", from a message's link (2026-10-13) - shown
		// logged out, before the login form would be.
		if ( 'password' === ( isset( $_GET['amat'] ) ? sanitize_key( wp_unslash( $_GET['amat'] ) ) : '' ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- a view choice; the key is checked.
			self::view_password();
			echo '</div>';
			return (string) ob_get_clean();
		}

		if ( ! is_user_logged_in() ) {
			echo '<section class="amat-portal-login"><h2>' . esc_html__( 'Log in', 'auto-mation' ) . '</h2>';
			// Logging in from a link to one estimate comes back to it.
			$doc = isset( $_GET['doc'] ) ? absint( $_GET['doc'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- where to return to, nothing more.
			$on  = isset( $_GET['amat'] ) ? sanitize_key( wp_unslash( $_GET['amat'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- as above.
			wp_login_form(
				array(
					'redirect'       => $doc && in_array( $on, array( 'estimate', 'invoice' ), true ) ? self::portal_url( array( 'amat' => $on, 'doc' => (string) $doc ) ) : self::portal_url(),
					'label_username' => __( 'Email or phone', 'auto-mation' ),
				)
			);
			echo '<p><a href="' . esc_url( wp_lostpassword_url( self::portal_url() ) ) . '">' . esc_html__( 'Forgot your password?', 'auto-mation' ) . '</a></p></section>'
				. '<section class="amat-portal-new"><h2>' . esc_html__( 'New here?', 'auto-mation' ) . '</h2><p>' . esc_html__( 'Tell us about your vehicle and what it needs, and we will be in touch.', 'auto-mation' ) . '</p>'
				. '<p><a class="amat-button" href="' . esc_url( self::request_url() ) . '">' . esc_html__( 'Request service', 'auto-mation' ) . '</a></p></section>';
			echo '</div>';
			return (string) ob_get_clean();
		}

		$preview  = self::preview_customer();
		$customer = $preview ? $preview : self::current_customer();
		if ( ! $customer ) {
			echo '<p>' . esc_html__( 'Your login is not linked to a customer account yet. Please give us a call and we will set it up.', 'auto-mation' ) . '</p></div>';
			return (string) ob_get_clean();
		}

		self::$preview = $preview ? (int) $preview['id'] : 0;
		try {
			if ( $preview ) {
				echo '<p class="amat-portal-preview">'
					/* translators: %s: the customer's name. */
					. esc_html( sprintf( __( 'Previewing the portal as %s. Read-only: nothing here can be sent or saved.', 'auto-mation' ), AMAT_Customer_Model::display_name( $preview ) ) )
					. '</p>';
			}
			$view = isset( $_GET['amat'] ) ? sanitize_key( wp_unslash( $_GET['amat'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only view choice.
			self::nav( $view, $preview );
			switch ( $view ) {
				case 'estimate':
					self::view_estimate( $customer, isset( $_GET['doc'] ) ? absint( $_GET['doc'] ) : 0 ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only; scoped to the customer.
					break;
				case 'account':
					self::view_account( $customer );
					break;
				default:
					self::view_dashboard( $customer );
			}
		} finally {
			self::$preview = 0;
		}
		echo '</div>';
		$html = (string) ob_get_clean();
		// A preview's forms are for looking at: every submit button is disabled.
		return $preview ? str_replace( '<button type="submit"', '<button type="submit" disabled', $html ) : $html;
	}

	/**
	 * The portal's own navigation.
	 *
	 * @param string                   $view    The current view.
	 * @param array<string,mixed>|null $preview The customer being previewed, if any.
	 * @return void
	 */
	private static function nav( $view, $preview = null ) {
		$items = array(
			''        => __( 'My jobs', 'auto-mation' ),
			'account' => __( 'My details', 'auto-mation' ),
		);
		echo '<nav class="amat-portal-nav" aria-label="' . esc_attr__( 'Account', 'auto-mation' ) . '">';
		foreach ( $items as $key => $label ) {
			$url = '' === $key ? self::portal_url() : self::portal_url( array( 'amat' => $key ) );
			echo '<a href="' . esc_url( $url ) . '"' . ( $key === $view ? ' aria-current="page" class="is-current"' : '' ) . '>' . esc_html( $label ) . '</a>';
		}
		if ( $preview ) {
			// Not Log out: that would log the owner out. Back to the customer instead.
			$back = add_query_arg( array( 'page' => AMAT_Customers_Page::PAGE_SLUG, 'action' => 'view', 'id' => (int) $preview['id'] ), admin_url( 'admin.php' ) );
			echo '<a href="' . esc_url( $back ) . '" class="amat-portal-exit">' . esc_html__( 'Back to the customer', 'auto-mation' ) . '</a></nav>';
			return;
		}
		echo '<a href="' . esc_url( wp_logout_url( self::portal_url() ) ) . '" class="amat-portal-logout">' . esc_html__( 'Log out', 'auto-mation' ) . '</a></nav>';
	}

	/**
	 * A one-line message after a form, chosen by ?amat_msg=.
	 *
	 * @return void
	 */
	private static function notice() {
		$key      = isset( $_GET['amat_msg'] ) ? sanitize_key( wp_unslash( $_GET['amat_msg'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- a message key, nothing more.
		$messages = self::messages();
		if ( isset( $messages[ $key ] ) ) {
			echo '<p class="amat-portal-notice is-' . esc_attr( $messages[ $key ][0] ) . '" role="status">' . esc_html( $messages[ $key ][1] ) . '</p>';
		}
	}

	/**
	 * The forms' messages, by key: [ 'success'|'error', text ].
	 *
	 * @return array<string,array{0:string,1:string}>
	 */
	private static function messages() {
		return array(
			'request_fix'     => array( 'error', __( 'Almost there - please fix the fields marked below.', 'auto-mation' ) ),
			'requested'       => array( 'success', __( 'Thanks - your request is in. We will confirm the time with you shortly.', 'auto-mation' ) ),
			'requested_call'  => array( 'success', __( "Thanks - your request is in. That time was just taken, so we'll contact you to arrange another.", 'auto-mation' ) ),
			'requested_no_time' => array( 'success', __( "Thanks - your request is in. We'll contact you to arrange a time.", 'auto-mation' ) ),
			'slot_taken'      => array( 'error', __( 'Sorry - a time you picked was just taken. Please pick again.', 'auto-mation' ) ),
			'too_many_times'  => array( 'error', __( 'Please pick no more than two times.', 'auto-mation' ) ),
			'request_invalid' => array( 'error', __( 'Please give your name, a phone number or email we can reach you on, and what the vehicle needs.', 'auto-mation' ) ),
			'vin_needed'      => array( 'error', __( 'Please enter your vehicle\'s VIN - it is on the driver\'s side of the dashboard, at the bottom of the windshield, and on your registration and insurance card.', 'auto-mation' ) ),
			'request_pick'    => array( 'error', __( 'Please choose your vehicle and where it is, and tell us what it needs.', 'auto-mation' ) ),
			'too_many'        => array( 'error', __( 'We have had several requests from you already - please give us a call instead.', 'auto-mation' ) ),
			'contact_saved'   => array( 'success', __( 'Your contact details are saved.', 'auto-mation' ) ),
			'estimate_accepted' => array( 'success', __( 'Thanks - you accepted this estimate. We will be in touch about the next step.', 'auto-mation' ) ),
			'estimate_declined' => array( 'success', __( 'You declined this estimate. Thanks for letting us know.', 'auto-mation' ) ),
			'estimate_changed'  => array( 'error', __( 'This estimate changed while you were reading it - please read it again before you decide.', 'auto-mation' ) ),
			'estimate_closed'   => array( 'error', __( 'This estimate can no longer be accepted or declined here - please contact us.', 'auto-mation' ) ),
			'contact_invalid' => array( 'error', __( 'One of those contact details does not look right - nothing was changed.', 'auto-mation' ) ),
			'contact_needed'  => array( 'error', __( 'Please keep at least one way for us to reach you.', 'auto-mation' ) ),
			'login'           => array( 'error', __( 'Please log in first.', 'auto-mation' ) ),
			'password_short'  => array( 'error', __( 'Please use at least 8 characters - your password was not set.', 'auto-mation' ) ),
			'expired'         => array( 'error', __( 'That form had expired - please try again.', 'auto-mation' ) ),
		);
	}

	/**
	 * The dashboard: jobs under way, estimates, invoices, vehicles, past work.
	 *
	 * @param array<string,mixed> $customer The current customer.
	 * @return void
	 */
	private static function view_dashboard( array $customer ) {
		$cid  = (int) $customer['id'];
		$jobs = AMAT_Job_Model::all( array( 'customer_id' => $cid ), array( 'orderby' => 'id', 'order' => 'DESC' ) );
		$open = array_filter( $jobs, static fn( $j ) => '' === (string) $j['closed_reason'] );
		$past = array_filter( $jobs, static fn( $j ) => 'paid' === (string) $j['closed_reason'] );

		/* translators: %s: the customer's first name. */
		echo '<h2>' . esc_html( sprintf( __( 'Hi %s', 'auto-mation' ), (string) $customer['first_name'] ) ) . '</h2>';

		echo '<section class="amat-portal-jobs"><h3>' . esc_html__( 'Jobs under way', 'auto-mation' ) . '</h3>';
		if ( ! $open ) {
			echo '<p>' . esc_html__( 'Nothing under way right now.', 'auto-mation' ) . ' <a href="' . esc_url( self::request_url( array( 'request' => '1' ) ) . '#request' ) . '">' . esc_html__( 'Request service', 'auto-mation' ) . '</a></p>';
		}
		foreach ( $open as $job ) {
			self::job_card( $job, $customer );
		}
		echo '</section>';

		self::documents( $cid );

		echo '<section class="amat-portal-vehicles"><h3>' . esc_html__( 'My vehicles', 'auto-mation' ) . '</h3><ul>';
		foreach ( AMAT_Vehicle_Model::for_customer( $cid ) as $v ) {
			if ( ! empty( $v['is_active'] ) ) {
				echo '<li>' . esc_html( AMAT_Vehicle_Model::label( $v ) ) . ( '' !== AMAT_Vehicle_Model::plate_label( $v ) ? ' <span class="amat-muted">' . esc_html( AMAT_Vehicle_Model::plate_label( $v ) ) . '</span>' : '' ) . '</li>';
			}
		}
		echo '</ul></section>';

		if ( $past ) {
			echo '<section class="amat-portal-past"><h3>' . esc_html__( 'Past work', 'auto-mation' ) . '</h3><ul>';
			foreach ( $past as $job ) {
				$vehicle = $job['vehicle_id'] ? AMAT_Vehicle_Model::find( (int) $job['vehicle_id'] ) : null;
				$when    = substr( (string) ( $job['closed_at'] ?: $job['scheduled_start'] ), 0, 10 );
				echo '<li><strong>' . esc_html( AMAT_Job_Model::label( $job, __( 'Service', 'auto-mation' ) ) ) . '</strong> '
					. esc_html( implode( ' · ', array_filter( array( $vehicle ? AMAT_Vehicle_Model::label( $vehicle ) : '', $when ? AMAT_Job_Workflow::short_date( $when ) . ', ' . substr( $when, 0, 4 ) : '' ) ) ) ) . '</li>';
			}
			echo '</ul></section>';
		}
	}

	/**
	 * One job under way, as the customer should see it: where it is (by stage),
	 * when, and why it is paused or on standby - never the notes or research.
	 *
	 * @param array<string,mixed> $job      Job row.
	 * @param array<string,mixed> $customer The current customer.
	 * @return void
	 */
	private static function job_card( array $job, array $customer ) {
		$vehicle = $job['vehicle_id'] ? AMAT_Vehicle_Model::find( (int) $job['vehicle_id'] ) : null;
		$stage   = AMAT_Job_Workflow::stage( $job );
		$keys    = array_keys( AMAT_Job_Workflow::stages() );
		$at      = array_search( $stage, $keys, true );

		$start = AMAT_Job_Workflow::parse_when( (string) $job['scheduled_start'] );
		if ( ! empty( $job['on_hold'] ) ) {
			$until  = substr( (string) ( $job['hold_until'] ?? '' ), 0, 10 );
			$status = ( '' !== $until && '0000-00-00' !== $until )
				/* translators: %s: a date, e.g. "Oct 2". */
				? sprintf( __( 'Paused for now - we expect to carry on around %s.', 'auto-mation' ), AMAT_Job_Workflow::short_date( $until ) )
				: __( 'Paused for now - we will let you know when we can carry on.', 'auto-mation' );
		} elseif ( $start ) {
			/* translators: %s: the appointment. */
			$status = sprintf( __( 'Appointment: %s', 'auto-mation' ), AMAT_Job_Workflow::describe_slot( $start, AMAT_Job_Workflow::parse_when( (string) $job['scheduled_end'] ) ) );
		} else {
			$asked = implode(
				' ' . __( 'or', 'auto-mation' ) . ' ',
				array_map(
					static fn( $p ) => AMAT_Job_Workflow::describe_slot( AMAT_Job_Workflow::parse_when( (string) $p['start_at'] ), AMAT_Job_Workflow::parse_when( (string) $p['end_at'] ) ),
					AMAT_Job_Proposal_Model::for_job( (int) $job['id'] )
				)
			);
			$status = '' !== $asked
				/* translators: %s: the requested time. */
				? sprintf( __( 'You asked for %s - we will confirm it shortly.', 'auto-mation' ), $asked )
				: __( 'We will be in touch to arrange a time.', 'auto-mation' );
		}

		echo '<article class="amat-portal-job"><h4>' . esc_html( AMAT_Job_Model::label( $job, __( 'Service', 'auto-mation' ) ) ) . '</h4>';
		if ( $vehicle ) {
			echo '<p class="amat-muted">' . esc_html( AMAT_Vehicle_Model::label( $vehicle ) ) . '</p>';
		}
		echo '<ol class="amat-portal-stages">';
		foreach ( AMAT_Job_Workflow::stages() as $key => $label ) {
			$i = array_search( $key, $keys, true );
			echo '<li class="' . ( $i < $at ? 'is-done' : ( $i === $at ? 'is-now' : '' ) ) . '"' . ( $i === $at ? ' aria-current="step"' : '' ) . '>' . esc_html( $label ) . '</li>';
		}
		echo '</ol><p>' . esc_html( $status ) . '</p>';
		// Hold and Standby share one Reason, and it is the customer's to read
		// (Nick, 2026-10-06: "keep them in the loop") - the job screen says so.
		if ( ! empty( $job['standby'] ) ) {
			echo '<p class="amat-portal-standby">' . esc_html__( 'You are on standby - if an earlier time opens up, we will offer it to you.', 'auto-mation' ) . '</p>';
		}
		$reason = trim( (string) ( $job['hold_reason'] ?? '' ) );
		if ( '' !== $reason && ( ! empty( $job['on_hold'] ) || ! empty( $job['standby'] ) ) ) {
			echo '<p class="amat-portal-reason">' . esc_html( $reason ) . '</p>';
		}
		echo '</article>';
		unset( $customer );
	}

	/**
	 * The customer's estimates and invoices - never drafts or void ones.
	 *
	 * @param int $cid Customer id.
	 * @return void
	 */
	private static function documents( $cid ) {
		$estimates = array_filter( AMAT_Estimate_Model::for_customer( $cid ), static fn( $e ) => self::visible( $e ) );
		$invoices  = array_filter( AMAT_Invoice_Model::for_customer( $cid ), static fn( $i ) => self::visible( $i ) );

		if ( $estimates ) {
			echo '<section class="amat-portal-estimates"><h3>' . esc_html__( 'Estimates', 'auto-mation' ) . '</h3><table class="amat-portal-table"><thead><tr><th>' . esc_html__( 'Estimate', 'auto-mation' ) . '</th><th>' . esc_html__( 'Status', 'auto-mation' ) . '</th><th class="num">' . esc_html__( 'Total', 'auto-mation' ) . '</th></tr></thead><tbody>';
			foreach ( $estimates as $e ) {
				echo '<tr><td><a href="' . esc_url( self::portal_url( array( 'amat' => 'estimate', 'doc' => (string) (int) $e['id'] ) ) ) . '">' . esc_html( AMAT_Estimates_Page::label( $e ) ) . '</a></td>'
					. '<td>' . esc_html( self::status_for_customer( 'AMAT_Estimate_Model', $e['status'] ) ) . '</td>'
					. '<td class="num">' . esc_html( AMAT_Money::format_amount( AMAT_Estimate_Model::total( (int) $e['id'] ) ) ) . '</td></tr>';
			}
			echo '</tbody></table></section>';
		}

		if ( $invoices ) {
			echo '<section class="amat-portal-invoices"><h3>' . esc_html__( 'Invoices', 'auto-mation' ) . '</h3><table class="amat-portal-table"><thead><tr><th>' . esc_html__( 'Invoice', 'auto-mation' ) . '</th><th>' . esc_html__( 'Status', 'auto-mation' ) . '</th><th class="num">' . esc_html__( 'Balance', 'auto-mation' ) . '</th><th></th></tr></thead><tbody>';
			foreach ( $invoices as $inv ) {
				$total = (float) AMAT_Invoice_Model::total( (int) $inv['id'] );
				$paid  = (float) ( $inv['amount_paid'] ?? 0 );
				echo '<tr><td>' . esc_html( AMAT_Invoices_Page::label( $inv ) ) . ( '' !== (string) $inv['due_date'] ? '<br /><span class="amat-muted">' . esc_html( sprintf( /* translators: %s: due date. */ __( 'Due %s', 'auto-mation' ), AMAT_Job_Workflow::short_date( substr( (string) $inv['due_date'], 0, 10 ) ) ) ) . '</span>' : '' ) . '</td>'
					. '<td>' . esc_html( self::status_for_customer( 'AMAT_Invoice_Model', $inv['status'] ) ) . '</td>'
					. '<td class="num">' . esc_html( AMAT_Money::format_amount( $total - $paid ) ) . '</td><td>';
				// Pay online (Nick, 2026-10-09): the payment provider's own page, from
				// core's neutral amat_invoice_view_url filter - only while something is
				// owed. Shown in the owner's preview too: it is only a link.
				$pay = AMAT_Invoice_Model::view_url( $inv );
				if ( '' !== $pay && $total - $paid > 0.004 && ! in_array( (string) $inv['status'], array( 'paid', 'overpaid', 'void' ), true ) ) {
					echo '<a class="amat-button amat-pay-online" href="' . esc_url( $pay ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'Pay online', 'auto-mation' ) . '</a> ';
				}
				/**
				 * More actions on an invoice in the customer portal. (Pay online is
				 * core's own, from amat_invoice_view_url; payments are the provider's, §9.)
				 *
				 * @param array<string,mixed> $invoice The invoice row.
				 */
				do_action( 'amat_portal_invoice_actions', $inv );
				echo '</td></tr>';
			}
			echo '</tbody></table></section>';
		}
	}

	/**
	 * Whether a document is for the customer's eyes: not a draft, not void.
	 *
	 * @param array<string,mixed> $doc Estimate or invoice row.
	 * @return bool
	 */
	private static function visible( array $doc ) {
		return ! in_array( (string) $doc['status'], array( 'draft', 'void' ), true );
	}

	/**
	 * One of the customer's estimates, with its lines.
	 *
	 * @param array<string,mixed> $customer The current customer.
	 * @param int                 $id       Estimate id.
	 * @return void
	 */
	private static function view_estimate( array $customer, $id ) {
		$est = $id ? AMAT_Estimate_Model::find( $id ) : null;
		if ( ! $est || (int) $est['customer_id'] !== (int) $customer['id'] || ! self::visible( $est ) ) {
			echo '<p>' . esc_html__( 'That estimate could not be found.', 'auto-mation' ) . '</p>';
			return;
		}
		$vehicle = $est['vehicle_id'] ? AMAT_Vehicle_Model::find( (int) $est['vehicle_id'] ) : null;
		echo '<article class="amat-portal-estimate"><h2>' . esc_html( AMAT_Estimates_Page::label( $est ) ) . '</h2>'
			. '<p class="amat-muted">' . esc_html( implode( ' · ', array_filter( array( self::status_for_customer( 'AMAT_Estimate_Model', $est['status'] ), $vehicle ? AMAT_Vehicle_Model::label( $vehicle ) : '', (string) $est['issue_date'] ) ) ) ) . '</p>'
			. '<table class="amat-portal-table"><thead><tr><th>' . esc_html__( 'Item', 'auto-mation' ) . '</th><th class="num">' . esc_html__( 'Qty', 'auto-mation' ) . '</th><th class="num">' . esc_html__( 'Price', 'auto-mation' ) . '</th><th class="num">' . esc_html__( 'Amount', 'auto-mation' ) . '</th></tr></thead><tbody>';
		foreach ( AMAT_Estimate_Item_Model::for_parent( (int) $est['id'] ) as $line ) {
			$qty   = (float) $line['quantity'];
			$price = (float) $line['unit_price'];
			echo '<tr><td>' . esc_html( (string) $line['description'] ) . '</td><td class="num">' . esc_html( AMAT_Money::quantity( $line['quantity'] ) ) . '</td>'
				. '<td class="num">' . esc_html( AMAT_Money::format_amount( $price ) ) . '</td><td class="num">' . esc_html( AMAT_Money::format_amount( $qty * $price ) ) . '</td></tr>';
		}
		echo '</tbody><tfoot><tr><th colspan="3">' . esc_html__( 'Total', 'auto-mation' ) . '</th><td class="num"><strong>' . esc_html( AMAT_Money::format_amount( AMAT_Estimate_Model::total( (int) $est['id'] ) ) ) . '</strong></td></tr></tfoot></table>';
		if ( '' !== trim( (string) $est['notes'] ) ) {
			echo '<p>' . nl2br( esc_html( (string) $est['notes'] ) ) . '</p>';
		}
		self::estimate_decision( $est );
		echo '<p><a href="' . esc_url( self::portal_url() ) . '">' . esc_html__( '← Back to my jobs', 'auto-mation' ) . '</a></p></article>';
	}

	/**
	 * User meta: where a customer goes once they set their password from an
	 * estimate's link.
	 *
	 * @var string
	 */
	const AFTER_PASSWORD_META = 'amat_after_password';

	/**
	 * The link an estimate is sent with (Nick, 2026-10-07): the estimate in the
	 * portal. A customer with no login, on a real send ($create), has one made
	 * quietly - no welcome email, the estimate's is the one - and the link sets
	 * their password, after which they are logged in on the estimate. A preview
	 * or dry run passes $create false and changes nothing. With no email there is
	 * no login to make, and the plain link is all there is.
	 *
	 * @param int  $estimate_id Estimate id.
	 * @param bool $create      Make a login if they have none.
	 * @return string URL.
	 */
	public static function estimate_link( $estimate_id, $create = false ) {
		$url = self::portal_url( array( 'amat' => 'estimate', 'doc' => (string) (int) $estimate_id ) );
		$est = AMAT_Estimate_Model::find( (int) $estimate_id );
		return $est ? self::customer_link( (int) $est['customer_id'], $url, $create ) : $url;
	}

	/**
	 * The link a message to a customer carries, to a page of their portal - the
	 * estimate's, or My jobs for an appointment confirmation (2026-10-09). A
	 * customer who already has a login gets $url itself. One without, on a real
	 * send ($create), has a login made quietly - no welcome email, the message
	 * is the one - and gets a link that sets their password, after which they are
	 * logged in on $url (once only). A preview or dry run passes $create false
	 * and changes nothing; with no email there is no login to make.
	 *
	 * @param int    $customer_id Customer id.
	 * @param string $url         The portal page to land on.
	 * @param bool   $create      Make a login if they have none.
	 * @return string URL.
	 */
	public static function customer_link( $customer_id, $url, $create = false ) {
		$url = (string) $url;
		$c   = AMAT_Customer_Model::find( (int) $customer_id );
		if ( ! $c || ! $create || ( (int) $c['wp_user_id'] && get_userdata( (int) $c['wp_user_id'] ) ) || '' === self::email_of( (int) $c['id'] ) ) {
			return $url;
		}
		$user_id = self::grant_access( (int) $c['id'], false );
		$user    = is_wp_error( $user_id ) ? false : get_userdata( (int) $user_id );
		$key     = $user ? get_password_reset_key( $user ) : new WP_Error( 'amat_no_user', '' );
		if ( is_wp_error( $key ) ) {
			return $url;
		}
		update_user_meta( (int) $user->ID, self::AFTER_PASSWORD_META, $url );
		return self::password_url( $user, $key );
	}

	/**
	 * The portal's branded "Choose your password" page for a login and its reset
	 * key (Nick, 2026-10-13: not WordPress's "unbranded" wp-login.php form).
	 *
	 * @param WP_User $user The login.
	 * @param string  $key  Its password reset key (get_password_reset_key()).
	 * @return string URL.
	 */
	public static function password_url( $user, $key ) {
		return self::page_url(
			self::PAGE_OPTION,
			array(
				'amat'  => 'password',
				'key'   => rawurlencode( (string) $key ),
				'login' => rawurlencode( (string) $user->user_login ),
			)
		);
	}

	/**
	 * Whether a link sets a password before it opens anything - the portal's page
	 * or WordPress's own - so a message can say "First time? You'll choose a
	 * password" under it.
	 *
	 * @param string $url A link.
	 * @return bool
	 */
	public static function is_set_password_link( $url ) {
		parse_str( (string) wp_parse_url( (string) $url, PHP_URL_QUERY ), $q );
		if ( empty( $q['key'] ) || empty( $q['login'] ) ) {
			return false;
		}
		return 'password' === ( $q['amat'] ?? '' ) || 'rp' === ( $q['action'] ?? '' );
	}

	/**
	 * The "Choose your password" view: the form for a good link, a way forward
	 * for a used or expired one, and "you're already logged in" for someone who is.
	 * Styled like the request thank-you's "Create your account".
	 *
	 * @return void
	 */
	private static function view_password() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- the reset key is the check.
		$key   = sanitize_text_field( wp_unslash( $_GET['key'] ?? '' ) );
		$login = sanitize_text_field( wp_unslash( $_GET['login'] ?? '' ) );
		// phpcs:enable
		$user = ( '' !== $key && '' !== $login ) ? check_password_reset_key( $key, $login ) : new WP_Error( 'amat_no_key', '' );

		echo '<section class="amat-account-invite amat-password-page"><h2>' . esc_html__( 'Choose your password', 'auto-mation' ) . '</h2>';

		if ( is_user_logged_in() ) {
			$to = self::portal_url();
			if ( ! is_wp_error( $user ) && (int) $user->ID === get_current_user_id() ) {
				$to = self::after_password_target( $user, false );
			}
			echo '<p>' . esc_html__( "You're already logged in.", 'auto-mation' ) . '</p>'
				. '<p><a class="amat-button" href="' . esc_url( $to ) . '">' . esc_html__( 'Continue', 'auto-mation' ) . '</a></p></section>';
			return;
		}

		if ( is_wp_error( $user ) ) {
			echo '<p class="amat-portal-notice is-error" role="alert">' . esc_html__( 'This link has expired or was already used.', 'auto-mation' ) . '</p>'
				. '<p>' . esc_html__( 'If you have already chosen your password, just log in. If not, use "Forgot your password?" and we will email you a new link.', 'auto-mation' ) . '</p>'
				. '<p><a class="amat-button" href="' . esc_url( self::portal_url() ) . '">' . esc_html__( 'Log in', 'auto-mation' ) . '</a> '
				. '<a class="amat-password-forgot" href="' . esc_url( wp_lostpassword_url( self::portal_url() ) ) . '">' . esc_html__( 'Forgot your password?', 'auto-mation' ) . '</a></p></section>';
			return;
		}

		$has_phone = false;
		foreach ( AMAT_Customer_Model::all( array( 'wp_user_id' => (int) $user->ID ) ) as $c ) {
			foreach ( AMAT_Contact_Method_Model::for_customer( (int) $c['id'] ) as $m ) {
				$has_phone = $has_phone || AMAT_Contact_Method_Types::is_phone_type( (string) $m['type'] );
			}
		}
		$shown = is_email( $user->user_email ) && strtolower( $user->user_email ) === strtolower( $user->user_login ) ? $user->user_email : $user->user_login;
		$who   = $has_phone
			/* translators: %s: their login (usually their email address). */
			? sprintf( __( "You'll log in with %s - or your phone number.", 'auto-mation' ), $shown )
			/* translators: %s: their login (usually their email address). */
			: sprintf( __( "You'll log in with %s.", 'auto-mation' ), $shown );

		$items = '';
		foreach ( self::account_benefits() as $item ) {
			$items .= '<li>' . esc_html( $item ) . '</li>';
		}
		echo '<p class="amat-password-who">' . esc_html( $who ) . '</p>'
			. '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="amat-portal-form amat-account-form amat-password-form" data-submit="' . esc_url( admin_url( 'admin-ajax.php' ) ) . '">'
			. '<input type="hidden" name="action" value="amat_portal_password" />'
			. '<input type="hidden" name="nonce" value="' . esc_attr( wp_create_nonce( 'amat_portal_password' ) ) . '" />'
			. '<input type="hidden" name="key" value="' . esc_attr( $key ) . '" />'
			. '<input type="hidden" name="login" value="' . esc_attr( $login ) . '" />'
			// For password managers: the login the new password belongs to.
			. '<input type="text" name="username" value="' . esc_attr( $shown ) . '" autocomplete="username" readonly hidden />'
			. '<p class="amat-field amat-field-password"><label for="amat-new-password">' . esc_html__( 'Password', 'auto-mation' ) . '</label>'
			. '<input type="password" name="password" id="amat-new-password" autocomplete="new-password" minlength="8" required />'
			. '<span class="amat-muted amat-field-hint">' . esc_html__( 'At least 8 characters.', 'auto-mation' ) . '</span></p>'
			. '<p><button type="submit" class="amat-button">' . esc_html__( 'Set my password', 'auto-mation' ) . '</button></p>'
			. '</form>'
			. '<p class="amat-account-why">' . esc_html__( 'Your account keeps everything about your vehicle in one place:', 'auto-mation' ) . '</p>'
			. '<ul class="amat-account-benefits">' . $items . '</ul>'
			. '</section>';
	}

	/**
	 * Where a login goes once its password is set: the page its message meant
	 * (stored by customer_link()), else My jobs.
	 *
	 * @param WP_User $user  The login.
	 * @param bool    $clear Forget it (once only).
	 * @return string URL.
	 */
	private static function after_password_target( $user, $clear ) {
		$to = (string) get_user_meta( (int) $user->ID, self::AFTER_PASSWORD_META, true );
		if ( $clear ) {
			delete_user_meta( (int) $user->ID, self::AFTER_PASSWORD_META );
		}
		return '' !== $to ? wp_validate_redirect( $to, self::portal_url() ) : self::portal_url();
	}

	/**
	 * "Set my password" on the portal's password page: check the link's key
	 * again, refuse a short password by field (nothing changed), set it, log them
	 * in, and send them where the link meant. Sent in the background it answers
	 * JSON - { redirect } - and an old page is given a fresh nonce to send again;
	 * posted plainly (no JavaScript) it redirects.
	 *
	 * The password is set with wp_set_password(), not reset_password(): that
	 * fires after_password_reset, whose listeners redirect-and-exit (ours) or
	 * email the site admin (WordPress's), neither right for a JSON answer.
	 *
	 * @return void
	 */
	public static function handle_set_password() {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- verified first thing.
		$key   = sanitize_text_field( wp_unslash( $_POST['key'] ?? '' ) );
		$login = sanitize_text_field( wp_unslash( $_POST['login'] ?? '' ) );
		$back  = self::page_url(
			self::PAGE_OPTION,
			array(
				'amat'  => 'password',
				'key'   => rawurlencode( $key ),
				'login' => rawurlencode( $login ),
			)
		);
		$ajax  = wp_doing_ajax();

		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ?? '' ) ), 'amat_portal_password' ) ) {
			if ( $ajax ) {
				wp_send_json_error(
					array(
						'message' => self::messages()['expired'][1],
						'nonce'   => wp_create_nonce( 'amat_portal_password' ),
						'fields'  => (object) array(),
					)
				);
			}
			self::go( $back, 'expired' );
		}
		if ( is_user_logged_in() ) {
			if ( $ajax ) {
				wp_send_json_error( array( 'message' => __( "You're already logged in.", 'auto-mation' ), 'redirect' => self::portal_url(), 'fields' => (object) array() ) );
			}
			wp_safe_redirect( self::portal_url() );
			exit;
		}

		$user = ( '' !== $key && '' !== $login ) ? check_password_reset_key( $key, $login ) : new WP_Error( 'amat_no_key', '' );
		if ( is_wp_error( $user ) ) {
			if ( $ajax ) {
				wp_send_json_error( array( 'message' => __( 'This link has expired or was already used. Use "Forgot your password?" to get a new one.', 'auto-mation' ), 'fields' => (object) array() ) );
			}
			wp_safe_redirect( $back ); // the page says so itself
			exit;
		}

		$password = (string) wp_unslash( $_POST['password'] ?? '' ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- a password is taken as typed.
		// phpcs:enable
		if ( strlen( $password ) < 8 ) {
			if ( $ajax ) {
				wp_send_json_error( array( 'message' => __( 'Nearly - check the marked field.', 'auto-mation' ), 'fields' => (object) array( 'password' => __( 'Use at least 8 characters.', 'auto-mation' ) ) ) );
			}
			self::go( $back, 'password_short' );
		}

		$to = self::after_password_target( $user, true );
		wp_set_password( $password, (int) $user->ID ); // also clears the reset key: the link is used up
		foreach ( AMAT_Customer_Model::all( array( 'wp_user_id' => (int) $user->ID ) ) as $c ) {
			AMAT_Log::info( 'core', __( 'Chose their password from the link we sent.', 'auto-mation' ), array( 'entity_type' => 'customer', 'entity_id' => (int) $c['id'] ) );
		}

		wp_set_current_user( (int) $user->ID );
		if ( ! headers_sent() ) {
			wp_set_auth_cookie( (int) $user->ID, true );
		}
		if ( $ajax ) {
			wp_send_json_success(
				array(
					'message'  => __( 'Your password is set, and you are logged in.', 'auto-mation' ),
					'redirect' => $to,
				)
			);
		}
		wp_safe_redirect( $to );
		exit;
	}

	/**
	 * Once a customer sets their password through WordPress's own form from a
	 * link that stored a target (links made before 2026-10-13): log them in and
	 * open it (once only).
	 *
	 * @param WP_User $user Who set it.
	 * @return void
	 */
	public static function after_password_reset( $user ) {
		$to = (string) get_user_meta( (int) $user->ID, self::AFTER_PASSWORD_META, true );
		if ( '' === $to ) {
			return;
		}
		delete_user_meta( (int) $user->ID, self::AFTER_PASSWORD_META );
		wp_set_current_user( (int) $user->ID );
		if ( ! headers_sent() ) {
			wp_set_auth_cookie( (int) $user->ID, true );
		}
		wp_safe_redirect( $to );
		exit;
	}

	/**
	 * Whether the customer may still accept or decline this estimate: sent or
	 * viewed, and not already turned into an invoice.
	 *
	 * @param array<string,mixed> $est Estimate row.
	 * @return bool
	 */
	private static function decidable( array $est ) {
		return in_array( (string) $est['status'], array( 'sent', 'viewed' ), true ) && ! AMAT_Invoice_Model::for_estimate( (int) $est['id'] );
	}

	/**
	 * What accepting authorises - shown above the button, and stored with the
	 * acceptance as the wording agreed to.
	 *
	 * @param float $total The estimate's total.
	 * @return string
	 */
	private static function acceptance_text( $total ) {
		/* translators: %s: the estimate's total. */
		return sprintf( __( 'By accepting, you authorize the labor and parts on this estimate, up to %s.', 'auto-mation' ), AMAT_Money::format_amount( $total ) );
	}

	/**
	 * Accept or Decline under an open estimate - one button, being logged in is
	 * the signature (Nick, 2026-10-07) - or, once decided, what they decided. In
	 * the owner's preview the buttons show but do nothing.
	 *
	 * @param array<string,mixed> $est Estimate row.
	 * @return void
	 */
	private static function estimate_decision( array $est ) {
		$when = '' !== (string) ( $est['decision_at'] ?? '' ) ? AMAT_Job_Workflow::short_date( substr( (string) $est['decision_at'], 0, 10 ) ) : '';
		if ( 'accepted' === $est['status'] && '' !== $when ) {
			/* translators: %s: the date. */
			echo '<p class="amat-portal-notice is-success">' . esc_html( sprintf( __( 'You accepted this estimate on %s.', 'auto-mation' ), $when ) ) . '</p>';
			return;
		}
		if ( 'declined' === $est['status'] && '' !== $when ) {
			/* translators: %s: the date. */
			echo '<p class="amat-portal-notice">' . esc_html( sprintf( __( 'You declined this estimate on %s.', 'auto-mation' ), $when ) ) . '</p>';
			return;
		}
		if ( ! self::decidable( $est ) ) {
			return;
		}
		$total = (float) AMAT_Estimate_Model::total( (int) $est['id'] );
		$off   = self::$preview ? ' disabled' : '';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="amat-portal-form amat-estimate-decision">'
			. wp_nonce_field( 'amat_portal_estimate', '_wpnonce', true, false )
			. '<input type="hidden" name="action" value="amat_portal_estimate" />'
			. '<input type="hidden" name="estimate_id" value="' . esc_attr( (string) (int) $est['id'] ) . '" />'
			. '<input type="hidden" name="total" value="' . esc_attr( number_format( $total, 2, '.', '' ) ) . '" />'
			. '<p class="amat-estimate-authorize">' . esc_html( self::acceptance_text( $total ) ) . '</p>'
			. '<p><button type="submit" name="decision" value="accept" class="amat-button"' . $off . '>' . esc_html__( 'Accept estimate', 'auto-mation' ) . '</button></p>'
			. '<details class="amat-estimate-decline"><summary>' . esc_html__( 'Decline this estimate', 'auto-mation' ) . '</summary>'
			. '<p class="amat-field"><label for="amat-decline-reason">' . esc_html__( 'Why? (it helps us)', 'auto-mation' ) . '</label>'
			. '<textarea name="reason" id="amat-decline-reason" rows="3" maxlength="1000"' . $off . '></textarea></p>'
			. '<p><button type="submit" name="decision" value="decline" class="amat-link-button"' . $off . '>' . esc_html__( 'Decline estimate', 'auto-mation' ) . '</button></p>'
			. '</details></form>';
	}

	/**
	 * The portal's Accept / Decline on an estimate. Only the customer's own, only
	 * while it is open, and only the version they read: a changed total sends
	 * them back to read it again. The decision is recorded on the estimate, the
	 * estimate is announced (a provider may follow), and the job moves on.
	 *
	 * @return void
	 */
	public static function handle_estimate_decision() {
		$id   = absint( $_POST['estimate_id'] ?? 0 );
		$back = self::portal_url( array( 'amat' => 'estimate', 'doc' => (string) $id ) );
		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ?? '' ) ), 'amat_portal_estimate' ) ) {
			self::go( $back, 'expired' );
		}
		$customer = self::current_customer();
		if ( ! $customer ) {
			self::go( self::portal_url(), 'login' );
		}
		$est = $id ? AMAT_Estimate_Model::find( $id ) : null;
		if ( ! $est || (int) $est['customer_id'] !== (int) $customer['id'] || ! self::decidable( $est ) ) {
			self::go( $back, 'estimate_closed' );
		}
		$total = (float) AMAT_Estimate_Model::total( $id );
		$seen  = (float) sanitize_text_field( wp_unslash( $_POST['total'] ?? '' ) );
		if ( abs( $total - $seen ) > 0.004 ) {
			self::go( $back, 'estimate_changed' );
		}

		$accept = 'accept' === sanitize_key( wp_unslash( $_POST['decision'] ?? '' ) );
		$record = array(
			'status'         => $accept ? 'accepted' : 'declined',
			'decision_at'    => current_time( 'mysql' ),
			'decision_by'    => get_current_user_id(),
			'decision_ip'    => substr( sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ?? '' ) ), 0, 45 ),
			'decision_total' => number_format( $total, 2, '.', '' ),
			'decision_text'  => $accept ? self::acceptance_text( $total ) : __( 'Decline estimate', 'auto-mation' ),
		);
		if ( ! $accept ) {
			$record['decline_reason'] = sanitize_textarea_field( wp_unslash( $_POST['reason'] ?? '' ) );
		}
		AMAT_Estimate_Model::update( $id, $record );
		AMAT_Log::info(
			'core',
			/* translators: 1: the estimate, 2: its total. */
			sprintf( $accept ? __( '%1$s accepted by the customer in the portal (%2$s).', 'auto-mation' ) : __( '%1$s declined by the customer in the portal (%2$s).', 'auto-mation' ), AMAT_Estimates_Page::label( $est ), AMAT_Money::format_amount( $total ) ),
			array( 'entity_type' => 'job', 'entity_id' => (int) $est['job_id'] )
		);
		/** This action is documented in includes/admin/class-jobs-page.php */
		do_action( 'amat_after_estimate_save', $id, false );
		if ( (int) $est['job_id'] ) {
			AMAT_Job_Workflow::reconcile( (int) $est['job_id'] );
		}
		self::go( $back, $accept ? 'estimate_accepted' : 'estimate_declined' );
	}

	/**
	 * The customer's contact details, to keep up to date.
	 *
	 * @param array<string,mixed> $customer The current customer.
	 * @return void
	 */
	private static function view_account( array $customer ) {
		$types = array();
		foreach ( AMAT_Contact_Method_Types::definitions() as $slug => $def ) {
			$types[ $slug ] = $def['label'];
		}
		$rows = AMAT_Contact_Method_Model::for_customer( (int) $customer['id'] );
		$rows[] = array( 'type' => 'call_text', 'value' => '' );

		echo '<h2>' . esc_html__( 'My details', 'auto-mation' ) . '</h2><p><strong>' . esc_html( AMAT_Customer_Model::display_name( $customer ) ) . '</strong></p>'
			. '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="amat-portal-form">'
			. wp_nonce_field( 'amat_portal_contact', '_wpnonce', true, false )
			. '<input type="hidden" name="action" value="amat_portal_contact" />'
			. '<fieldset><legend>' . esc_html__( 'How to reach me (the first is the one we try first)', 'auto-mation' ) . '</legend>';
		foreach ( $rows as $i => $m ) {
			$type  = (string) $m['type'];
			$value = '' === (string) $m['value'] ? '' : AMAT_Contact_Method_Types::format( $type, (string) $m['value'] );
			echo '<div class="amat-portal-cm"><label class="screen-reader-text" for="amat-cm-type-' . (int) $i . '">' . esc_html__( 'Type', 'auto-mation' ) . '</label><select name="cm_type[]" id="amat-cm-type-' . (int) $i . '">';
			foreach ( $types as $slug => $label ) {
				echo '<option value="' . esc_attr( $slug ) . '"' . selected( $slug, $type, false ) . '>' . esc_html( $label ) . '</option>';
			}
			echo '</select><label class="screen-reader-text" for="amat-cm-value-' . (int) $i . '">' . esc_html__( 'Number or email', 'auto-mation' ) . '</label>'
				. '<input type="text" name="cm_value[]" id="amat-cm-value-' . (int) $i . '" value="' . esc_attr( $value ) . '" /></div>';
		}
		echo '</fieldset><p class="amat-muted">' . esc_html__( 'Clear a box to remove it. Call Only means we will never text that number.', 'auto-mation' ) . '</p>'
			. '<p><button type="submit" class="amat-button">' . esc_html__( 'Save my details', 'auto-mation' ) . '</button></p></form>';
	}

	/**
	 * The portal's Save my details.
	 *
	 * @return void
	 */
	public static function handle_contact() {
		$back = self::portal_url( array( 'amat' => 'account' ) );
		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ?? '' ) ), 'amat_portal_contact' ) ) {
			self::go( $back, 'expired' );
		}
		$customer = self::current_customer();
		if ( ! $customer ) {
			self::go( self::portal_url(), 'login' );
		}

		list( $methods, $errors ) = AMAT_Customers_Page::parse_contact_methods();
		if ( $errors ) {
			self::go( $back, 'contact_invalid' );
		}
		if ( ! $methods ) {
			self::go( $back, 'contact_needed' );
		}
		AMAT_Contact_Method_Model::replace_for_customer( (int) $customer['id'], $methods );
		AMAT_Log::info( 'core', __( 'Contact details updated by the customer in the portal.', 'auto-mation' ), array( 'entity_type' => 'customer', 'entity_id' => (int) $customer['id'] ) );

		/** This action is documented in includes/admin/class-customers-page.php */
		do_action( 'amat_after_customer_save', (int) $customer['id'], false );
		self::go( $back, 'contact_saved' );
	}

	/* --------------------------------------------------------------------- */
	/* Asking for a time                                                     */
	/* --------------------------------------------------------------------- */

	/**
	 * The open times: a radio button for each, grouped by day, which is what the
	 * form posts (and what a browser without JavaScript chooses from), plus the
	 * same times as data for assets/portal-booking.js, which draws them on a
	 * calendar and ticks the matching radio when one is picked.
	 *
	 * @return string HTML.
	 */
	private static function slot_picker() {
		$days = AMAT_Availability::slots( current_time( 'Y-m-d' ), (int) AMAT_Availability::settings()['horizon_days'] + 1 );
		if ( ! $days ) {
			return '<p class="amat-muted">' . esc_html__( 'There are no times to pick online right now - send your request and we will contact you to arrange one.', 'auto-mation' ) . '</p>';
		}
		$list  = '<div class="amat-slot-days">';
		$data  = array();
		$n     = 0;
		foreach ( $days as $date => $slots ) {
			$day   = DateTimeImmutable::createFromFormat( '!Y-m-d', $date );
			$list .= '<fieldset class="amat-slot-day"><legend>' . esc_html( $day ? $day->format( 'D M j' ) : $date ) . '</legend>';
			foreach ( $slots as $slot ) {
				$n++;
				$list  .= '<label class="amat-slot"><input type="checkbox" name="slot[]" value="' . esc_attr( $slot['start'] ) . '" id="amat-slot-' . $n . '" /> ' . esc_html( $slot['label'] ) . '</label>';
				$data[] = array(
					'start' => str_replace( ' ', 'T', $slot['start'] ),
					'end'   => str_replace( ' ', 'T', $slot['end'] ),
					'label' => $slot['label'],
					'name'  => $slot['name'],
					'times' => $slot['times'],
				);
			}
			$list .= '</fieldset>';
		}
		$list .= '</div>';

		$config = array(
			'slots' => $data,
			'max'   => self::MAX_PROPOSALS,
			'i18n'  => array(
				'month'  => __( 'Month', 'auto-mation' ),
				'week'   => __( 'Week', 'auto-mation' ),
				'days3'  => __( '3 days', 'auto-mation' ),
				'today'  => __( 'Today', 'auto-mation' ),
				'open'   => __( 'Open', 'auto-mation' ),
				'pick'   => __( 'Pick a day with open times, then morning or afternoon.', 'auto-mation' ),
				'first'  => __( '1st choice', 'auto-mation' ),
				'second' => __( '2nd choice', 'auto-mation' ),
				'full'   => __( 'You can pick two times - remove one to pick another.', 'auto-mation' ),
				'none'   => __( 'No open times that day.', 'auto-mation' ),
				'chosen' => __( 'Your times:', 'auto-mation' ),
				'change' => __( 'Remove', 'auto-mation' ),
			),
		);
		return '<div class="amat-slot-picker" data-slots="' . esc_attr( (string) wp_json_encode( $config ) ) . '">'
			. '<p class="amat-slot-hint">' . esc_html__( 'You can pick up to two times that suit you - we will confirm one.', 'auto-mation' ) . '</p>'
			. '<div class="amat-slot-calendar"></div>'
			. '<div class="amat-slot-daylist" aria-live="polite"></div>'
			. '<div class="amat-slot-chosen" aria-live="polite"></div>'
			. $list
			. '</div>';
	}

	/**
	 * The times a form sent, as 'Y-m-d H:i:s' strings: none, one or several
	 * (slot[] - a customer may propose up to MAX_PROPOSALS), each once.
	 *
	 * @return string[]
	 */
	private static function posted_slots() {
		$raw = wp_unslash( $_POST['slot'] ?? array() ); // phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- each handler verifies first; sanitized below.
		$out = array();
		foreach ( (array) $raw as $start ) {
			$start = trim( sanitize_text_field( (string) $start ) );
			if ( '' !== $start ) {
				$out[ $start ] = true;
			}
		}
		return array_keys( $out );
	}

	/**
	 * A new job from a customer's request: at the start of the workflow (the
	 * facts carry it on), at their primary location, with the time they asked for
	 * proposed.
	 *
	 * @param int                                          $cid       Customer id.
	 * @param int                                          $vehicle   Vehicle id (0 = none).
	 * @param string                                       $complaint In their words.
	 * @param array<int,array<string,string>> $slots The times asked for (open, checked).
	 * @param string                                       $how       For the log.
	 * @param int                                          $location  Where (0 = their primary location).
	 * @param string                                       $name      The job's name ('' = shown as the customer's).
	 * @param array{reason:string,source:string}|null      $review    Hold it for review from the start.
	 * @return int Job id.
	 */
	private static function create_request( $cid, $vehicle, $complaint, array $slots, $how, $location = 0, $name = '', $review = null ) {
		if ( ! $location ) {
			$primary  = AMAT_Location_Model::primary_for_customer( $cid );
			$location = $primary ? (int) $primary['id'] : 0;
		}
		$job = (int) AMAT_Job_Model::create(
			array(
				'customer_id' => $cid,
				'name'        => (string) $name,
				'vehicle_id'  => (int) $vehicle,
				'location_id' => (int) $location,
				'complaint'   => $complaint,
				'step'        => AMAT_Job_Workflow::FIRST_STEP,
			)
		);
		AMAT_Log::info( 'core', $how, array( 'entity_type' => 'job', 'entity_id' => $job ) );
		/**
		 * Should this new request wait for review before it moves on? A provider
		 * syncing the customer elsewhere (Wave) holds it in Info until it confirms
		 * them - and marks it for review if it can't (Nick, 2026-10-06).
		 *
		 * @param array{reason:string,source:string}|null $review      Null: no.
		 * @param int                                      $customer_id Whose request.
		 * @param int                                      $job_id      The new job.
		 */
		$review = apply_filters( 'amat_new_request_review', $review, $cid, $job );
		if ( is_array( $review ) && '' !== trim( (string) ( $review['reason'] ?? '' ) ) ) {
			AMAT_Job_Workflow::set_review( $job, (string) $review['reason'], (string) ( $review['source'] ?? 'core' ) );
		}
		AMAT_Job_Workflow::reconcile( $job );
		foreach ( $slots as $slot ) {
			AMAT_Job_Workflow::propose( $job, $slot['start'], $slot['end'] );
		}
		return $job;
	}

	/* --------------------------------------------------------------------- */
	/* The public "Request service" form: [amat_request_service]             */
	/* --------------------------------------------------------------------- */

	/**
	 * A signed form timestamp: "<time>.<hmac>". The form carries it; a reply that
	 * comes back too fast, too late, or unsigned is a bot's.
	 *
	 * @param int $time Unix time the form was drawn.
	 * @return string
	 */
	public static function form_token( $time ) {
		return (int) $time . '.' . substr( hash_hmac( 'sha256', 'amat-request-' . (int) $time, wp_salt( 'nonce' ) ), 0, 24 );
	}

	/**
	 * Whether a form token is genuine and its form was filled in at a human pace.
	 *
	 * @param string $token As posted.
	 * @return bool
	 */
	private static function human_pace( $token ) {
		$parts = explode( '.', (string) $token, 2 );
		if ( 2 !== count( $parts ) || ! ctype_digit( $parts[0] ) || ! hash_equals( self::form_token( (int) $parts[0] ), (string) $token ) ) {
			return false;
		}
		$age = time() - (int) $parts[0];
		return $age >= self::MIN_FORM_SECONDS && $age <= DAY_IN_SECONDS;
	}

	/**
	 * A document's status in the customer's words. The owner's "Approved by me"
	 * (wp-admin) would read to a customer as if THEY approved it, so here it is
	 * "Approved by <business>" (Nick, 2026-10-05); every other label is as is.
	 *
	 * @param string $model  AMAT_Estimate_Model or AMAT_Invoice_Model.
	 * @param string $status Status slug.
	 * @return string
	 */
	private static function status_for_customer( $model, $status ) {
		if ( 'approved' === (string) $status ) {
			/* translators: %s: the business name. */
			return sprintf( __( 'Approved by %s', 'auto-mation' ), self::business_name() );
		}
		return $model::status_label( $status );
	}

	/**
	 * The business's name, as customers know it (Settings -> My Business), else
	 * the site title.
	 *
	 * @return string
	 */
	private static function business_name() {
		return AMAT_Welcome_Email::business_name();
	}

	/**
	 * The text-alerts consent, with "Terms" and "Privacy" linked when their pages
	 * are published (plain words until then).
	 *
	 * @param bool $links Link Terms and Privacy (false: the plain wording, as stored).
	 * @return string HTML when $links, else plain text.
	 */
	private static function sms_consent( $links ) {
		$terms_id = (int) get_option( self::TERMS_PAGE_OPTION, 0 );
		$terms    = $terms_id && 'publish' === get_post_status( $terms_id ) ? get_permalink( $terms_id ) : '';
		$privacy  = get_privacy_policy_url();
		$word     = static function ( $text, $url ) use ( $links ) {
			return $links && $url ? '<a href="' . esc_url( $url ) . '" target="_blank" rel="noopener">' . esc_html( $text ) . '</a>' : ( $links ? esc_html( $text ) : $text );
		};
		$name = $links ? esc_html( self::business_name() ) : self::business_name();
		/* translators: 1: business name, 2: "Terms", 3: "Privacy". */
		$text = __( 'I agree to receive automated text messages from %1$s and agree to our %2$s and %3$s. Consent is not a condition of any purchase. Msg frequency varies. Msg and data rates may apply. Reply HELP for help and STOP to cancel.', 'auto-mation' );
		return sprintf( $links ? esc_html( $text ) : $text, $name, $word( __( 'Terms', 'auto-mation' ), $terms ), $word( __( 'Privacy', 'auto-mation' ), $privacy ) );
	}

	/**
	 * The exact consent wording a customer agrees to by ticking Text alerts - what
	 * is stored on their phone number as proof.
	 *
	 * @return string
	 */
	public static function sms_consent_text() {
		return self::sms_consent( false );
	}

	/**
	 * [amat_request_service]: how a customer asks for service. A newcomer tells us
	 * who they are; a logged-in customer is shown by name and picks one of their
	 * vehicles and addresses, or adds another.
	 *
	 * @param array<string,string>|string $atts Shortcode attributes (none used).
	 * @return string HTML.
	 */
	public static function shortcode_request( $atts ) {
		unset( $atts );
		$customer = self::current_customer();
		// One field: its label, input and hint - every field says what it wants
		// and is formatted as it is typed (Nick, 2026-10-07; portal-forms.js).
		$field    = static function ( $name, $label, $type = 'text', $extra = '', $hint = '' ) {
			return '<p class="amat-field amat-field-' . esc_attr( $name ) . '"><label for="amat-req-' . esc_attr( $name ) . '">' . esc_html( $label ) . '</label>'
				. '<input type="' . esc_attr( $type ) . '" name="' . esc_attr( $name ) . '" id="amat-req-' . esc_attr( $name ) . '"' . $extra . ' />'
				. ( '' !== $hint ? '<span class="amat-muted amat-field-hint">' . esc_html( $hint ) . '</span>' : '' ) . '</p>';
		};
		// A newcomer must give the VIN; for a customer it is only asked when they
		// add a vehicle (the script requires it while those fields show).
		$vehicle_fields = $field( 'vin', __( 'VIN', 'auto-mation' ), 'text', ' maxlength="17" autocomplete="off" autocapitalize="characters" spellcheck="false"' . ( $customer ? ' data-required' : ' required' ), __( 'On the driver\'s side of the dashboard, at the bottom of the windshield, and on your registration and insurance card.', 'auto-mation' ) )
			. $field( 'vehicle', __( 'Year, make and model', 'auto-mation' ), 'text', ' placeholder="2015 Ford F-150"', __( 'Filled in from your VIN - change it if it is not right.', 'auto-mation' ) )
			// The plate and its state side by side (Nick, 2026-10-07).
			. '<div class="amat-field-row">'
			. $field( 'license_plate', __( 'License plate', 'auto-mation' ), 'text', ' maxlength="20" autocapitalize="characters" autocomplete="off" data-format="upper"', __( 'As it is on the plate, e.g. ABC 123.', 'auto-mation' ) )
			. $field( 'plate_state', __( 'State', 'auto-mation' ), 'text', ' maxlength="2" autocapitalize="characters" autocomplete="off" data-format="state" placeholder="AZ"', __( 'e.g. AZ', 'auto-mation' ) )
			. '</div>'
			. $field( 'color', __( 'Color', 'auto-mation' ), 'text', ' maxlength="50"', __( 'Helps us find it, e.g. Silver.', 'auto-mation' ) );
		$address_fields = $field( 'street_1', __( 'Street address', 'auto-mation' ), 'text', ' autocomplete="address-line1"' . ( $customer ? ' data-required' : '' ) )
			. $field( 'city', __( 'City', 'auto-mation' ), 'text', ' autocomplete="address-level2"' )
			. $field( 'state', __( 'State', 'auto-mation' ), 'text', ' maxlength="2" autocapitalize="characters" autocomplete="address-level1" data-format="state" placeholder="IN"', __( 'Two letters, e.g. IN.', 'auto-mation' ) )
			. $field( 'zipcode', __( 'ZIP code', 'auto-mation' ), 'text', ' autocomplete="postal-code" inputmode="numeric" maxlength="10" data-format="zip" placeholder="46000"', __( '5 digits.', 'auto-mation' ) )
			. $field( 'code', __( 'Gate or access code', 'auto-mation' ), 'text', ' maxlength="100" autocomplete="off"', __( 'Anything we need to get to the vehicle - a gate code, which door, where the keys are.', 'auto-mation' ) );

		ob_start();
		echo '<div class="amat-portal amat-request">';
		self::notice();
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="amat-portal-form amat-request-form" data-vin-decode="' . esc_url( admin_url( 'admin-ajax.php' ) ) . '" data-submit="' . esc_url( admin_url( 'admin-ajax.php' ) ) . '"' . ( $customer ? '' : ' data-known="' . esc_url( admin_url( 'admin-ajax.php' ) ) . '"' ) . '>'
			. wp_nonce_field( 'amat_request_service', '_wpnonce', true, false )
			. '<input type="hidden" name="action" value="amat_request_service" />';
		if ( ! $customer ) {
			echo '<input type="hidden" name="amat_t" value="' . esc_attr( self::form_token( time() ) ) . '" />';
		}

		// About you.
		echo '<fieldset><legend>' . esc_html__( 'About you', 'auto-mation' ) . '</legend>';
		if ( $customer ) {
			echo '<p class="amat-request-who">' . esc_html__( 'Requesting as', 'auto-mation' ) . ' <strong>' . esc_html( AMAT_Customer_Model::display_name( $customer ) ) . '</strong></p>';
		} else {
			echo '<p class="amat-login-line">' . esc_html__( 'Already have an account?', 'auto-mation' ) . ' <a class="amat-login-link" href="' . esc_url( self::portal_url() ) . '">' . esc_html__( 'Log in', 'auto-mation' ) . '</a></p>'
				. $field( 'first_name', __( 'First name', 'auto-mation' ), 'text', ' required autocomplete="given-name"' ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in $field.
				. $field( 'last_name', __( 'Last name', 'auto-mation' ), 'text', ' autocomplete="family-name"' ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				. $field( 'phone', __( 'Phone', 'auto-mation' ), 'tel', ' autocomplete="tel" inputmode="tel" placeholder="555-444-3333"', __( 'A 10-digit number we can reach you on.', 'auto-mation' ) ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				. '<p class="amat-field amat-field-sms"><label class="amat-check"><input type="checkbox" name="sms_consent" id="amat-req-sms" value="1" /> ' . esc_html__( 'Text alerts', 'auto-mation' ) . '</label>'
				. '<span class="amat-consent amat-muted">' . self::sms_consent( true ) . '</span></p>' // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built escaped.
				. $field( 'email', __( 'Email', 'auto-mation' ), 'email', ' autocomplete="email" inputmode="email"', __( 'For your estimates, invoices and account. A phone number or an email is needed.', 'auto-mation' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		echo '</fieldset>';

		// About your vehicle.
		echo '<fieldset><legend>' . esc_html__( 'About your vehicle', 'auto-mation' ) . '</legend>';
		if ( $customer ) {
			$vehicles = array_filter( AMAT_Vehicle_Model::for_customer( (int) $customer['id'] ), static fn( $v ) => ! empty( $v['is_active'] ) );
			echo '<p class="amat-field amat-field-vehicle_id"><label for="amat-req-vehicle_id">' . esc_html__( 'Which vehicle?', 'auto-mation' ) . '</label><select name="vehicle_id" id="amat-req-vehicle_id" data-reveals="amat-new-vehicle">';
			foreach ( $vehicles as $v ) {
				$plate = AMAT_Vehicle_Model::plate_label( $v );
				$plate = '' !== $plate ? ' - ' . $plate : '';
				echo '<option value="' . esc_attr( (string) (int) $v['id'] ) . '">' . esc_html( AMAT_Vehicle_Model::label( $v ) . $plate ) . '</option>';
			}
			echo '<option value="new"' . ( $vehicles ? '' : ' selected' ) . '>' . esc_html__( 'A different vehicle…', 'auto-mation' ) . '</option></select></p>'
				. '<div class="amat-new-vehicle" id="amat-new-vehicle">' . $vehicle_fields . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in $field.
		} else {
			echo $vehicle_fields; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in $field.
		}
		echo '<p class="amat-field amat-field-complaint"><label for="amat-req-complaint">' . esc_html__( 'What does it need?', 'auto-mation' ) . '</label><textarea name="complaint" id="amat-req-complaint" rows="4" required></textarea></p>'
			. '</fieldset>';

		// Where is the vehicle?
		echo '<fieldset><legend>' . esc_html__( 'Where is the vehicle?', 'auto-mation' ) . '</legend>';
		if ( $customer ) {
			$places = array_filter( AMAT_Location_Model::for_customer( (int) $customer['id'] ), static fn( $l ) => ! empty( $l['is_active'] ) );
			usort( $places, static fn( $a, $b ) => (int) $b['is_primary'] <=> (int) $a['is_primary'] );
			echo '<p class="amat-field amat-field-location_id"><label for="amat-req-location_id">' . esc_html__( 'Where?', 'auto-mation' ) . '</label><select name="location_id" id="amat-req-location_id" data-reveals="amat-new-location">';
			foreach ( $places as $l ) {
				$label = trim( (string) $l['label'] );
				echo '<option value="' . esc_attr( (string) (int) $l['id'] ) . '">' . esc_html( ( '' !== $label ? $label . ' - ' : '' ) . AMAT_Location_Model::one_line( $l ) ) . '</option>';
			}
			echo '<option value="new"' . ( $places ? '' : ' selected' ) . '>' . esc_html__( 'Somewhere else…', 'auto-mation' ) . '</option></select></p>'
				. '<div class="amat-new-location" id="amat-new-location">' . $address_fields . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in $field.
		} else {
			echo $address_fields; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in $field.
		}
		echo '</fieldset>';

		echo '<fieldset><legend>' . esc_html__( 'Pick a time', 'auto-mation' ) . '</legend>'
			. self::slot_picker() // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped internally.
			// Standby: the customer would take the earliest time that frees up
			// (Nick, 2026-10-06). The customer's own reason box was taken off the
			// form 2026-10-07 - parked in FUTURE.md; the job's Reason is the owner's.
			. '<p class="amat-field amat-field-standby"><label class="amat-check"><input type="checkbox" name="standby" id="amat-req-standby" value="1" /> ' . esc_html__( 'Request Standby (earliest available time)', 'auto-mation' ) . '</label>'
			. '<span class="amat-muted amat-field-hint">' . esc_html__( 'If an earlier time opens up, we will offer it to you.', 'auto-mation' ) . '</span></p>'
			. '</fieldset>';
		if ( ! $customer ) {
			echo '<div class="amat-hp" aria-hidden="true"><label for="amat-req-website">' . esc_html__( 'Leave this empty', 'auto-mation' ) . '</label><input type="text" name="website" id="amat-req-website" tabindex="-1" autocomplete="off" /></div>';
		}
		echo '<p><button type="submit" class="amat-button">' . esc_html__( 'Send my request', 'auto-mation' ) . '</button></p>'
			. '<p class="amat-muted">' . esc_html__( 'We will get back to you to confirm the details and the time.', 'auto-mation' ) . '</p></form>';
		echo '</div>';
		return (string) ob_get_clean();
	}

	/**
	 * The vehicle fields as posted: VIN (normalized, '' when unusable), the
	 * year/make/model text, plate (upper case) and colour.
	 *
	 * @return array{vin:string,vehicle:string,license_plate:string,color:string}
	 */
	private static function posted_vehicle() {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- the handler verified it.
		$vin = AMAT_Vin_Decoder::normalize( sanitize_text_field( wp_unslash( $_POST['vin'] ?? '' ) ) );
		if ( '' !== $vin && is_wp_error( AMAT_Vin_Decoder::validate( $vin ) ) ) {
			$vin = '';
		}
		$out = array(
			'vin'           => $vin,
			'vehicle'       => trim( sanitize_text_field( wp_unslash( $_POST['vehicle'] ?? '' ) ) ),
			'license_plate' => strtoupper( trim( sanitize_text_field( wp_unslash( $_POST['license_plate'] ?? '' ) ) ) ),
			'plate_state'   => strtoupper( trim( sanitize_text_field( wp_unslash( $_POST['plate_state'] ?? '' ) ) ) ),
			'color'         => trim( sanitize_text_field( wp_unslash( $_POST['color'] ?? '' ) ) ),
		);
		// phpcs:enable
		return $out;
	}

	/**
	 * A new vehicle for a customer from the posted fields.
	 *
	 * @param int                                                          $cid Customer id.
	 * @param array{vin:string,vehicle:string,license_plate:string,color:string} $v   From posted_vehicle().
	 * @return int Vehicle id.
	 */
	private static function add_vehicle( $cid, array $v ) {
		return AMAT_Vehicle_Model::create_from_text( $cid, $v['vehicle'], array_filter( array( 'vin' => $v['vin'], 'license_plate' => $v['license_plate'], 'plate_state' => $v['plate_state'], 'color' => $v['color'] ), 'strlen' ) );
	}

	/**
	 * The times asked for that are still free - a request always arrives; more
	 * than allowed, and none are proposed (the times are then arranged by phone).
	 *
	 * @param string[] $starts From posted_slots().
	 * @return array<int,array<string,string>>
	 */
	private static function free_slots( array $starts ) {
		$slots = array();
		if ( count( $starts ) <= self::MAX_PROPOSALS ) {
			foreach ( $starts as $start ) {
				$slot = AMAT_Availability::is_open( $start );
				if ( $slot ) {
					$slots[] = $slot;
				}
			}
		}
		return $slots;
	}

	/**
	 * The public Send my request.
	 *
	 * @return void
	 */
	public static function handle_request() {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- verified first thing.
		$back = self::request_url();
		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ?? '' ) ), 'amat_request_service' ) ) {
			// Sent in the background, the form gets a fresh key and sends again by
			// itself - an old page never costs the customer their answers.
			if ( wp_doing_ajax() ) {
				wp_send_json_error( array( 'message' => self::messages()['expired'][1], 'nonce' => wp_create_nonce( 'amat_request_service' ) ) );
			}
			self::go( $back, 'expired' );
		}
		$customer = self::current_customer();
		if ( $customer ) {
			self::handle_customer_request( $customer, $back );
		}
		// A bot is thanked and ignored: telling it why would teach it.
		if ( '' !== trim( (string) wp_unslash( $_POST['website'] ?? '' ) ) || ! self::human_pace( sanitize_text_field( wp_unslash( $_POST['amat_t'] ?? '' ) ) ) ) {
			self::answer( $back, 'requested' );
		}
		$ip_key = 'amat_req_' . md5( (string) ( $_SERVER['REMOTE_ADDR'] ?? '' ) );
		$count  = (int) get_transient( $ip_key );
		if ( $count >= self::REQUESTS_PER_HOUR ) {
			self::answer( $back, 'too_many' );
		}

		$f = array();
		foreach ( array( 'first_name', 'last_name', 'phone', 'email', 'street_1', 'city', 'state', 'zipcode', 'code' ) as $key ) {
			$f[ $key ] = trim( sanitize_text_field( wp_unslash( $_POST[ $key ] ?? '' ) ) );
		}
		$complaint = trim( sanitize_textarea_field( wp_unslash( $_POST['complaint'] ?? '' ) ) );
		$texts_ok  = ! empty( $_POST['sms_consent'] );
		// phpcs:enable

		// Every problem at once, by field - never just the first (Nick, 2026-10-06).
		$fields  = array();
		$methods = array();
		foreach ( array( 'call_text' => $f['phone'], 'email' => $f['email'] ) as $type => $value ) {
			if ( '' === $value ) {
				continue;
			}
			$normal = AMAT_Contact_Method_Types::validate( $type, $value );
			if ( is_wp_error( $normal ) ) {
				$fields[ 'email' === $type ? 'email' : 'phone' ] = 'email' === $type
					? __( 'That email address does not look right.', 'auto-mation' )
					: __( 'A phone number needs all 10 digits, e.g. 555-444-3333.', 'auto-mation' );
				continue;
			}
			$method = array( 'type' => $type, 'value' => $normal );
			if ( 'call_text' === $type && $texts_ok ) {
				// The proof a carrier can ask for: when, and the exact wording.
				$method['sms_consent_at']   = current_time( 'mysql' );
				$method['sms_consent_text'] = self::sms_consent_text();
			}
			$methods[] = $method;
		}
		$state = strtoupper( $f['state'] );
		if ( '' === $f['first_name'] ) {
			$fields['first_name'] = __( 'Please give your first name.', 'auto-mation' );
		}
		if ( ! $methods && ! isset( $fields['phone'] ) && ! isset( $fields['email'] ) ) {
			$fields['phone'] = __( 'Give us a phone number or an email, so we can reach you.', 'auto-mation' );
		}
		if ( '' !== $state && ! AMAT_Location_Model::is_valid_state( $state ) ) {
			$fields['state'] = self::bad_state( $state );
		}
		$zip = AMAT_Location_Model::normalize_zip( $f['zipcode'] );
		if ( is_wp_error( $zip ) ) {
			$fields['zipcode'] = $zip->get_error_message();
		}
		$vehicle = self::posted_vehicle();
		if ( '' === $vehicle['vin'] ) {
			$fields['vin'] = self::messages()['vin_needed'][1];
		}
		if ( '' !== $vehicle['plate_state'] && ! AMAT_Location_Model::is_valid_state( $vehicle['plate_state'] ) ) {
			$fields['plate_state'] = self::bad_state( $vehicle['plate_state'] );
		}
		if ( '' === $complaint ) {
			$fields['complaint'] = __( 'Tell us what the vehicle needs.', 'auto-mation' );
		}
		if ( $fields ) {
			self::answer( $back, array( 'vin' ) === array_keys( $fields ) ? 'vin_needed' : 'request_invalid', $fields );
		}

		// Someone we already know (same phone or email)? The request is saved, but
		// held, and the new record is not announced - so it never reaches Wave as
		// a second customer (Nick, 2026-10-07).
		$known = self::known_customers( $methods );

		$cid = (int) AMAT_Customer_Model::create(
			array(
				'first_name'         => $f['first_name'],
				'last_name'          => $f['last_name'],
				'referred_by_source' => 'website',
				'is_active'          => 1,
			)
		);
		AMAT_Contact_Method_Model::replace_for_customer( $cid, $methods );
		if ( '' !== $f['street_1'] ) {
			AMAT_Location_Model::create(
				array(
					'customer_id' => $cid,
					'label'       => __( 'Home', 'auto-mation' ),
					'street_1'    => $f['street_1'],
					'city'        => $f['city'],
					'state'       => $state,
					'zipcode'     => (string) $zip,
					'code'        => $f['code'],
					'is_primary'  => 1,
					'is_billing'  => 1,
					'is_active'   => 1,
				)
			);
		}
		// A new customer, complete (contacts and address written): announce them
		// as a save, so a provider (Wave) syncs them automatically. Unlike the
		// portal's other paths this is not the owner saving - it is the customer,
		// and their record must reach Wave to be invoiced (Nick, 2026-10-06).
		if ( ! $known ) {
			/** This action is documented in includes/admin/class-customers-page.php */
			do_action( 'amat_after_customer_save', $cid, true );
		}

		$vid    = self::add_vehicle( $cid, $vehicle );
		$starts = self::posted_slots();
		$slots  = self::free_slots( $starts );

		// Someone we know: held from the start, so it never moves past Info.
		$review = $known ? array(
			'reason' => sprintf(
				/* translators: %s: the existing customer(s). */
				__( 'Same phone or email as %s - probably the same person. It moves to their account by itself if they log in; otherwise check it and press Mark reviewed (it then counts as a new customer).', 'auto-mation' ),
				implode( ', ', array_map( static fn( $c ) => AMAT_Customer_Model::display_name( $c ), $known ) )
			),
			'source' => self::DUPLICATE,
		) : null;
		$job = self::create_request( $cid, $vid, $complaint, $slots, __( 'Requested through the website.', 'auto-mation' ), 0, self::web_request_name(), $review );
		self::maybe_standby( $job );
		set_transient( $ip_key, $count + 1, HOUR_IN_SECONDS );

		// Someone we know gets the ordinary thanks: the form already asked them to
		// log in (Nick, 2026-10-07: "Change it back to 'Thanks - your request is in.'").
		// Anyone new is invited to make their account there and then.
		// (Not for someone logged in - staff sending it for a customer: setting the
		// password would log them in as that customer.)
		self::answer( $back, self::request_message( $starts, $slots ), array(), $known || is_user_logged_in() ? array() : array( 'invite' => self::account_invite( $cid ) ) );
	}

	/**
	 * Send my request from a logged-in customer: one of their vehicles or a new one
	 * (VIN required; a VIN they already have is that vehicle), one of their
	 * addresses or a new one (never made primary), and what it needs.
	 *
	 * @param array<string,mixed> $customer The current customer.
	 * @param string              $back     Where to send them.
	 * @return void
	 */
	private static function handle_customer_request( array $customer, $back ) {
		$cid = (int) $customer['id'];
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- handle_request() verified it.
		$vehicle_choice  = sanitize_text_field( wp_unslash( $_POST['vehicle_id'] ?? '' ) );
		$location_choice = sanitize_text_field( wp_unslash( $_POST['location_id'] ?? '' ) );
		$complaint       = trim( sanitize_textarea_field( wp_unslash( $_POST['complaint'] ?? '' ) ) );
		$address         = array();
		foreach ( array( 'street_1', 'city', 'state', 'zipcode', 'code' ) as $key ) {
			$address[ $key ] = trim( sanitize_text_field( wp_unslash( $_POST[ $key ] ?? '' ) ) );
		}
		// phpcs:enable
		$address['state'] = strtoupper( $address['state'] );
		$mine             = static fn( $row ) => $row && (int) $row['customer_id'] === $cid && ! empty( $row['is_active'] );
		$fields           = array();

		// Where.
		$location = 0;
		if ( 'new' === $location_choice ) {
			if ( '' === $address['street_1'] ) {
				$fields['street_1'] = __( 'Give the street address.', 'auto-mation' );
			}
			if ( '' !== $address['state'] && ! AMAT_Location_Model::is_valid_state( $address['state'] ) ) {
				$fields['state'] = self::bad_state( $address['state'] );
			}
			$zip = AMAT_Location_Model::normalize_zip( $address['zipcode'] );
			if ( is_wp_error( $zip ) ) {
				$fields['zipcode'] = $zip->get_error_message();
			} else {
				$address['zipcode'] = $zip;
			}
		} else {
			$row = AMAT_Location_Model::find( absint( $location_choice ) );
			if ( $mine( $row ) ) {
				$location = (int) $row['id'];
			} else {
				$fields['location_id'] = __( 'Choose where the vehicle is.', 'auto-mation' );
			}
		}

		// Which vehicle.
		$vehicle = 0;
		$typed   = null;
		if ( 'new' === $vehicle_choice ) {
			$typed = self::posted_vehicle();
			if ( '' === $typed['vin'] ) {
				$fields['vin'] = self::messages()['vin_needed'][1];
			}
			if ( '' !== $typed['plate_state'] && ! AMAT_Location_Model::is_valid_state( $typed['plate_state'] ) ) {
				$fields['plate_state'] = self::bad_state( $typed['plate_state'] );
			}
			foreach ( AMAT_Vehicle_Model::for_customer( $cid ) as $v ) {
				if ( '' !== $typed['vin'] && strtoupper( (string) $v['vin'] ) === $typed['vin'] && ! empty( $v['is_active'] ) ) {
					$vehicle = (int) $v['id'];
					break;
				}
			}
		} else {
			$row = AMAT_Vehicle_Model::find( absint( $vehicle_choice ) );
			if ( $mine( $row ) ) {
				$vehicle = (int) $row['id'];
			} else {
				$fields['vehicle_id'] = __( 'Choose your vehicle.', 'auto-mation' );
			}
		}

		if ( '' === $complaint ) {
			$fields['complaint'] = __( 'Tell us what the vehicle needs.', 'auto-mation' );
		}
		if ( $fields ) {
			self::answer( $back, array( 'vin' ) === array_keys( $fields ) ? 'vin_needed' : 'request_pick', $fields );
		}

		// Everything checked: now write.
		if ( ! $location ) {
			$location = (int) AMAT_Location_Model::create(
				array_merge(
					$address,
					array(
						'customer_id' => $cid,
						'label'       => '',
						'is_primary'  => 0,
						'is_billing'  => 0,
						'is_active'   => 1,
					)
				)
			);
		}
		if ( ! $vehicle ) {
			$vehicle = self::add_vehicle( $cid, $typed );
		}
		$starts = self::posted_slots();
		$slots  = self::free_slots( $starts );
		$job = self::create_request( $cid, $vehicle, $complaint, $slots, __( 'Requested by the customer on the website.', 'auto-mation' ), $location, self::web_request_name() );
		self::maybe_standby( $job );
		self::answer( $back, self::request_message( $starts, $slots ) );
	}

	/**
	 * The review source marking a request held because its email or phone already
	 * belongs to a customer.
	 *
	 * @var string
	 */
	const DUPLICATE = 'duplicate';

	/**
	 * Active customers already holding one of these phone numbers or emails.
	 *
	 * @param array<int,array{type:string,value:string}> $methods Normalized methods.
	 * @return array<int,array<string,mixed>> Customer rows, by id.
	 */
	private static function known_customers( array $methods ) {
		$out = array();
		foreach ( $methods as $m ) {
			foreach ( AMAT_Contact_Method_Model::all( array( 'value' => (string) $m['value'] ) ) as $row ) {
				$c = AMAT_Customer_Model::find( (int) $row['customer_id'] );
				if ( $c && ! empty( $c['is_active'] ) ) {
					$out[ (int) $c['id'] ] = $c;
				}
			}
		}
		return $out;
	}

	/**
	 * On login: requests held because their email or phone was this customer's
	 * move onto this customer's account - the job, its vehicle (theirs, if the
	 * VIN matches one they have), its address (never made primary) and any text
	 * consent on the number - and the duplicate customer is removed. The hold
	 * then clears and the job moves on (Nick, 2026-10-07).
	 *
	 * @param string  $login Login name.
	 * @param WP_User $user  Who logged in.
	 * @return void
	 */
	public static function claim_held_requests( $login, $user ) {
		unset( $login );
		$mine = null;
		foreach ( AMAT_Customer_Model::all( array( 'wp_user_id' => (int) $user->ID ) ) as $c ) {
			if ( ! empty( $c['is_active'] ) ) {
				$mine = $c;
				break;
			}
		}
		if ( ! $mine ) {
			return;
		}
		$cid    = (int) $mine['id'];
		$values = array_column( AMAT_Contact_Method_Model::for_customer( $cid ), 'value' );
		foreach ( AMAT_Job_Model::all( array( 'review_source' => self::DUPLICATE ) ) as $job ) {
			$dup = (int) $job['customer_id'];
			if ( '' !== (string) $job['closed_reason'] || $dup === $cid ) {
				continue;
			}
			$theirs = AMAT_Contact_Method_Model::for_customer( $dup );
			if ( ! array_intersect( array_column( $theirs, 'value' ), $values ) ) {
				continue;
			}
			self::move_request( (int) $job['id'], $dup, $cid, $theirs );
		}
	}

	/**
	 * Move a held request from its duplicate customer onto the real one.
	 *
	 * @param int                              $job    Job id.
	 * @param int                              $dup    The duplicate customer.
	 * @param int                              $cid    The customer they really are.
	 * @param array<int,array<string,mixed>>   $theirs The duplicate's contact methods.
	 * @return void
	 */
	private static function move_request( $job, $dup, $cid, array $theirs ) {
		$row     = AMAT_Job_Model::find( $job );
		$vehicle = (int) $row['vehicle_id'];
		$v       = $vehicle ? AMAT_Vehicle_Model::find( $vehicle ) : null;
		if ( $v && (int) $v['customer_id'] === $dup ) {
			$same = '' !== (string) $v['vin'] ? array_values( array_filter( AMAT_Vehicle_Model::for_customer( $cid ), static fn( $o ) => strtoupper( (string) $o['vin'] ) === strtoupper( (string) $v['vin'] ) ) ) : array();
			if ( $same ) {
				AMAT_Vehicle_Model::delete( $vehicle );
				$vehicle = (int) $same[0]['id'];
			} else {
				AMAT_Vehicle_Model::update( $vehicle, array( 'customer_id' => $cid ) );
			}
		}
		$location = (int) $row['location_id'];
		$l        = $location ? AMAT_Location_Model::find( $location ) : null;
		if ( $l && (int) $l['customer_id'] === $dup ) {
			AMAT_Location_Model::update( $location, array( 'customer_id' => $cid, 'is_primary' => 0, 'is_billing' => 0, 'label' => '' !== (string) $l['label'] ? $l['label'] : __( 'From a web request', 'auto-mation' ) ) );
		}
		// A number's text consent travels with it (DB v24).
		$mine = AMAT_Contact_Method_Model::for_customer( $cid );
		foreach ( $theirs as $t ) {
			if ( empty( $t['sms_consent_at'] ) ) {
				continue;
			}
			foreach ( $mine as $m ) {
				if ( (string) $m['value'] === (string) $t['value'] && empty( $m['sms_consent_at'] ) ) {
					AMAT_Contact_Method_Model::update( (int) $m['id'], array( 'sms_consent_at' => $t['sms_consent_at'], 'sms_consent_text' => $t['sms_consent_text'] ) );
				}
			}
		}
		AMAT_Job_Model::update( $job, array( 'customer_id' => $cid, 'vehicle_id' => $vehicle, 'location_id' => $location ) );
		AMAT_Contact_Method_Model::replace_for_customer( $dup, array() );
		AMAT_Customer_Model::delete( $dup );
		/* translators: %s: the customer. */
		AMAT_Log::info( 'core', sprintf( __( 'Moved onto %s\'s account when they logged in.', 'auto-mation' ), AMAT_Customer_Model::display_name( AMAT_Customer_Model::find( $cid ) ) ), array( 'entity_type' => 'job', 'entity_id' => $job ) );
		AMAT_Job_Workflow::set_review( $job, '', self::DUPLICATE );
	}

	/**
	 * The name every job from the request form gets, so the board shows where it
	 * came from (Nick, 2026-10-06: "Web Request" for now).
	 *
	 * @return string
	 */
	private static function web_request_name() {
		return __( 'Web Request', 'auto-mation' );
	}

	/**
	 * Put a just-made request on Standby when the customer asked, with their reason.
	 *
	 * @param int $job Job id.
	 * @return void
	 */
	private static function maybe_standby( $job ) {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- the handler verified it.
		if ( empty( $_POST['standby'] ) ) {
			return;
		}
		AMAT_Job_Workflow::set_flag( (int) $job, 'standby' );
		// phpcs:enable
	}

	/**
	 * Which thank-you a request gets: a time asked for and held, one asked for but
	 * taken, or none asked for at all.
	 *
	 * @param string[]                        $starts Times asked for.
	 * @param array<int,array<string,string>> $slots  Those still free.
	 * @return string Message key.
	 */
	private static function request_message( array $starts, array $slots ) {
		if ( ! $starts ) {
			return 'requested_no_time';
		}
		return $slots ? 'requested' : 'requested_call';
	}

	/**
	 * How long the thank-you's invitation to make an account stays good.
	 *
	 * @var int
	 */
	const INVITE_TTL = HOUR_IN_SECONDS;

	/**
	 * The thank-you's invitation to make an account (Nick, 2026-10-07): their
	 * login - their email, else their phone, theirs to change to a username - a
	 * password, "Set account password", and below it what the account is for.
	 * It carries a one-time token tied to this new customer, so nobody else can
	 * set a password on them.
	 *
	 * @param int $customer_id The customer the request just made.
	 * @return string HTML.
	 */
	private static function account_invite( $customer_id ) {
		$token = wp_generate_password( 32, false );
		set_transient( 'amat_acct_' . md5( $token ), (int) $customer_id, self::INVITE_TTL );

		$login = self::email_of( (int) $customer_id );
		if ( '' === $login ) {
			foreach ( AMAT_Contact_Method_Model::for_customer( (int) $customer_id ) as $m ) {
				if ( AMAT_Contact_Method_Types::is_phone_type( (string) $m['type'] ) ) {
					$login = AMAT_Contact_Method_Types::format( (string) $m['type'], (string) $m['value'] );
					break;
				}
			}
		}
		$items = '';
		foreach ( self::account_benefits() as $item ) {
			$items .= '<li>' . esc_html( $item ) . '</li>';
		}
		return '<div class="amat-account-invite">'
			. '<h3>' . esc_html__( 'Create your account', 'auto-mation' ) . '</h3>'
			. '<form method="post" class="amat-portal-form amat-account-form" data-submit="' . esc_url( admin_url( 'admin-ajax.php' ) ) . '">'
			. '<input type="hidden" name="action" value="amat_request_account" />'
			. '<input type="hidden" name="nonce" value="' . esc_attr( wp_create_nonce( 'amat_request_service' ) ) . '" />'
			. '<input type="hidden" name="token" value="' . esc_attr( $token ) . '" />'
			. '<p class="amat-field amat-field-login"><label for="amat-acct-login">' . esc_html__( 'Username or phone', 'auto-mation' ) . '</label>'
			. '<input type="text" name="login" id="amat-acct-login" value="' . esc_attr( $login ) . '" autocomplete="username" autocapitalize="none" spellcheck="false" />'
			. '<span class="amat-muted amat-field-hint">' . esc_html__( 'What you log in with. Your email and phone number work too.', 'auto-mation' ) . '</span></p>'
			. '<p class="amat-field amat-field-password"><label for="amat-acct-password">' . esc_html__( 'Password', 'auto-mation' ) . '</label>'
			. '<input type="password" name="password" id="amat-acct-password" autocomplete="new-password" minlength="8" required />'
			. '<span class="amat-muted amat-field-hint">' . esc_html__( 'At least 8 characters.', 'auto-mation' ) . '</span></p>'
			. '<p><button type="submit" class="amat-button">' . esc_html__( 'Set account password', 'auto-mation' ) . '</button></p>'
			. '</form>'
			. '<p class="amat-account-why">' . esc_html__( 'An account keeps everything about your vehicle in one place:', 'auto-mation' ) . '</p>'
			. '<ul class="amat-account-benefits">' . $items . '</ul>'
			. '</div>';
	}

	/**
	 * "Set account password" on the thank-you: make the new customer's login with
	 * the password they chose, link it, and log them in. Needs the invite's token
	 * (once only). The login is their email or phone - stored as the login itself,
	 * so either works - or a username of their own if they typed one.
	 *
	 * @return void Sends JSON.
	 */
	public static function ajax_create_account() {
		check_ajax_referer( 'amat_request_service', 'nonce' );
		if ( is_user_logged_in() ) {
			wp_send_json_error( array( 'message' => __( 'You are already logged in.', 'auto-mation' ), 'fields' => (object) array() ) );
		}
		$token = sanitize_text_field( wp_unslash( $_POST['token'] ?? '' ) );
		$key   = 'amat_acct_' . md5( $token );
		$cid   = '' !== $token ? (int) get_transient( $key ) : 0;
		$c     = $cid ? AMAT_Customer_Model::find( $cid ) : null;
		if ( ! $c || (int) $c['wp_user_id'] ) {
			wp_send_json_error( array( 'message' => __( 'This has expired. You can still make your account: use "Forgot your password?" when you log in, or ask us.', 'auto-mation' ), 'fields' => (object) array() ) );
		}

		$password = (string) wp_unslash( $_POST['password'] ?? '' ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- a password is taken as typed.
		$typed    = trim( sanitize_text_field( wp_unslash( $_POST['login'] ?? '' ) ) );
		$email    = self::email_of( $cid );
		$phones   = array();
		foreach ( AMAT_Contact_Method_Model::for_customer( $cid ) as $m ) {
			if ( AMAT_Contact_Method_Types::is_phone_type( (string) $m['type'] ) ) {
				$phones[] = (string) $m['value'];
			}
		}
		$fields = array();
		if ( '' === $typed ) {
			$typed = '' !== $email ? $email : ( $phones[0] ?? '' );
		}
		$as_contact = self::contact_value( $typed );
		if ( '' !== $email && strtolower( $typed ) === $email ) {
			$login = sanitize_user( $email, true );
		} elseif ( '' !== $as_contact && in_array( $as_contact, $phones, true ) ) {
			$login = $as_contact;
		} elseif ( false !== strpos( $typed, '@' ) || '' !== $as_contact ) {
			$fields['login'] = __( 'Use your own email or phone number from the form - or a username.', 'auto-mation' );
			$login           = '';
		} else {
			$login = strtolower( sanitize_user( $typed, true ) );
			if ( '' === $login ) {
				$fields['login'] = __( 'Choose a username: letters and numbers.', 'auto-mation' );
			}
		}
		if ( '' !== $login && username_exists( $login ) ) {
			$fields['login'] = __( 'That username is taken - try another, or use your email or phone number.', 'auto-mation' );
		}
		if ( strlen( $password ) < 8 ) {
			$fields['password'] = __( 'Use at least 8 characters.', 'auto-mation' );
		}
		if ( $fields ) {
			wp_send_json_error( array( 'message' => __( 'Nearly - check the marked field.', 'auto-mation' ), 'fields' => (object) $fields ) );
		}

		$user_id = wp_insert_user(
			array(
				'user_login'   => $login,
				'user_email'   => $email,
				'user_pass'    => $password,
				'role'         => self::ROLE,
				'first_name'   => (string) $c['first_name'],
				'last_name'    => (string) $c['last_name'],
				'display_name' => AMAT_Customer_Model::display_name( $c ),
			)
		);
		if ( is_wp_error( $user_id ) ) {
			wp_send_json_error( array( 'message' => __( 'We could not make your account just now - please log in with "Forgot your password?", or ask us.', 'auto-mation' ), 'fields' => (object) array() ) );
		}
		delete_transient( $key );
		AMAT_Customer_Model::update( $cid, array( 'wp_user_id' => (int) $user_id ) );
		AMAT_Log::info( 'core', __( 'Made their account from the request form\'s thank-you.', 'auto-mation' ), array( 'entity_type' => 'customer', 'entity_id' => $cid ) );

		wp_set_current_user( (int) $user_id );
		if ( ! headers_sent() ) {
			wp_set_auth_cookie( (int) $user_id, true );
		}
		wp_send_json_success(
			array(
				'message' => __( 'Your account is ready, and you are logged in.', 'auto-mation' ),
				'account' => self::portal_url(),
			)
		);
	}

	/**
	 * How many "do we know you?" checks one address may make in an hour. Past it
	 * the answer is simply no: the form carries on, and the review hold catches
	 * anyone it should have.
	 *
	 * @var int
	 */
	const KNOWN_CHECKS_PER_HOUR = 30;

	/**
	 * The request form asks, as a newcomer types their phone or email, whether it
	 * already belongs to a customer who can log in - so the form can ask them to
	 * log in before they send it (Nick, 2026-10-07: "lets try to solve the
	 * problem before it is one"). The answer is only yes or no - no name, no
	 * login - and only yes for an active customer with a working login: there is
	 * nothing to ask of anyone else. Rate-limited, like the VIN lookup.
	 *
	 * @return void Sends JSON: { known: bool }.
	 */
	public static function ajax_known_contact() {
		check_ajax_referer( 'amat_request_service', 'nonce' );
		$key   = 'amat_known_' . md5( (string) ( $_SERVER['REMOTE_ADDR'] ?? '' ) );
		$count = (int) get_transient( $key );
		if ( $count >= self::KNOWN_CHECKS_PER_HOUR ) {
			wp_send_json_success( array( 'known' => false ) );
		}
		set_transient( $key, $count + 1, HOUR_IN_SECONDS );

		$value = self::contact_value( sanitize_text_field( wp_unslash( $_POST['value'] ?? '' ) ) );
		$known = '' !== $value && (bool) self::logins_for( $value );
		wp_send_json_success( array( 'known' => $known ) );
	}

	/**
	 * A typed phone number or email as it is stored, or '' when it is neither.
	 *
	 * @param string $raw What was typed.
	 * @return string
	 */
	private static function contact_value( $raw ) {
		$raw   = trim( (string) $raw );
		$type  = false !== strpos( $raw, '@' ) ? 'email' : 'call_text';
		$clean = '' === $raw ? new WP_Error( 'empty', '' ) : AMAT_Contact_Method_Types::validate( $type, $raw );
		return is_wp_error( $clean ) ? '' : (string) $clean;
	}

	/**
	 * The logins of the active customers holding this (stored-form) phone number
	 * or email.
	 *
	 * @param string $value A stored contact value.
	 * @return array<int,WP_User> By user id.
	 */
	private static function logins_for( $value ) {
		$users = array();
		foreach ( self::known_customers( array( array( 'value' => $value ) ) ) as $c ) {
			$user = (int) $c['wp_user_id'] ? get_userdata( (int) $c['wp_user_id'] ) : false;
			if ( $user ) {
				$users[ (int) $user->ID ] = $user;
			}
		}
		return $users;
	}

	/**
	 * Log in with a phone number (Nick, 2026-10-07: "we don't use phone numbers
	 * for login, but we should"). When the name typed is a phone number that
	 * belongs to exactly one customer's login, check the password against that
	 * login. A number two logins share logs neither in - they use their email.
	 *
	 * @param WP_User|WP_Error|null $user     What earlier checks decided.
	 * @param string                $username What was typed as the login.
	 * @param string                $password The password.
	 * @return WP_User|WP_Error|null
	 */
	public static function authenticate_by_phone( $user, $username, $password ) {
		if ( $user instanceof WP_User || '' === (string) $password || false !== strpos( (string) $username, '@' ) ) {
			return $user;
		}
		$value = self::contact_value( (string) $username );
		if ( '' === $value ) {
			return $user;
		}
		$logins = self::logins_for( $value );
		if ( 1 !== count( $logins ) ) {
			return $user;
		}
		return wp_authenticate_username_password( null, reset( $logins )->user_login, $password );
	}

	/**
	 * The public form's VIN lookup: year, make and model - nothing more - for the
	 * form to fill in. Needs the form's nonce, and is limited per address per hour
	 * (it is open to anyone, and vPIC is a free service).
	 *
	 * @return void
	 */
	public static function ajax_decode_vin() {
		check_ajax_referer( 'amat_request_service', 'nonce' );
		$key   = 'amat_vin_' . md5( (string) ( $_SERVER['REMOTE_ADDR'] ?? '' ) );
		$count = (int) get_transient( $key );
		if ( $count >= self::VIN_DECODES_PER_HOUR ) {
			wp_send_json_error( array( 'message' => __( 'Too many lookups from here just now - please type the year, make and model instead.', 'auto-mation' ) ) );
		}
		set_transient( $key, $count + 1, HOUR_IN_SECONDS );

		$vin    = sanitize_text_field( wp_unslash( $_POST['vin'] ?? '' ) );
		$result = ( new AMAT_Vin_Decoder() )->decode_full( $vin );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}
		if ( 'error' === $result['level'] ) {
			wp_send_json_error( array( 'message' => __( 'We could not find that VIN - check it, or type the year, make and model yourself.', 'auto-mation' ) ) );
		}
		$f = $result['fields'];
		wp_send_json_success(
			array(
				'year'  => (string) $f['year'],
				'make'  => (string) $f['make'],
				'model' => (string) $f['model'],
				'text'  => trim( implode( ' ', array_filter( array( (string) $f['year'], (string) $f['make'], (string) $f['model'] ), 'strlen' ) ) ),
			)
		);
	}

	/**
	 * Finish a request: sent in the background (the form's normal way), answer
	 * JSON - the message, and for a refusal every bad field by name, so the form
	 * keeps everything typed and marks what to fix. Posted plainly (no
	 * JavaScript), redirect with the message as before.
	 *
	 * @param string               $back   Where a plain post goes back to.
	 * @param string               $key    Message key.
	 * @param array<string,string> $fields Field name => what is wrong with it.
	 * @param array<string,mixed>  $extra  More for a successful answer (the invite).
	 * @return void
	 */
	private static function answer( $back, $key, array $fields = array(), array $extra = array() ) {
		if ( ! wp_doing_ajax() ) {
			self::go( $back, $key );
		}
		$messages = self::messages();
		$message  = $messages[ $key ][1] ?? '';
		if ( 'success' === ( $messages[ $key ][0] ?? '' ) ) {
			wp_send_json_success( array( 'message' => $message, 'key' => $key ) + $extra );
		}
		wp_send_json_error(
			array(
				'message' => $fields ? $messages['request_fix'][1] : $message,
				'key'     => $key,
				'fields'  => (object) $fields,
			)
		);
	}

	/**
	 * What to say about a State that isn't one.
	 *
	 * @param string $state What was typed.
	 * @return string
	 */
	private static function bad_state( $state ) {
		/* translators: %s: what was typed. */
		return sprintf( __( '"%s" is not a US state - use the two-letter code, e.g. IN.', 'auto-mation' ), $state );
	}

	/**
	 * Redirect with a message key, and stop.
	 *
	 * @param string $url Where to.
	 * @param string $msg Message key.
	 * @return void
	 */
	private static function go( $url, $msg ) {
		wp_safe_redirect( add_query_arg( 'amat_msg', $msg, $url ) );
		exit;
	}
}
