/**
 * The customer-facing forms ([amat_request_service], [amat_portal]'s My details):
 * phone numbers format as they are typed - 555-444-3333 - exactly as they do in
 * wp-admin (admin.js formatPhone; Nick, 2026-10-06: "all like fields should match
 * their formatting"). The server still normalises and checks every value.
 * Also sends the portal's "Choose your password" form in the background.
 */
( function () {
	'use strict';

	/**
	 * Group raw input into a US phone number (555-444-3333) as it is typed; a
	 * leading 1 is dropped. Mirrors admin.js formatPhone().
	 *
	 * @param {string} raw Field value.
	 * @return {string}
	 */
	function formatPhone( raw ) {
		var d = ( raw || '' ).replace( /\D/g, '' );
		if ( 11 === d.length && '1' === d.charAt( 0 ) ) {
			d = d.slice( 1 );
		}
		d = d.slice( 0, 10 );
		if ( d.length > 6 ) {
			return d.slice( 0, 3 ) + '-' + d.slice( 3, 6 ) + '-' + d.slice( 6 );
		}
		if ( d.length > 3 ) {
			return d.slice( 0, 3 ) + '-' + d.slice( 3 );
		}
		return d;
	}

	/**
	 * A ZIP as it is typed: digits only, and ZIP+4 gets its dash (46000-1234).
	 * Mirrors AMAT_Location_Model::normalize_zip(), which still checks on save.
	 *
	 * @param {string} raw Field value.
	 * @return {string}
	 */
	function formatZip( raw ) {
		var d = ( raw || '' ).replace( /\D/g, '' ).slice( 0, 9 );
		return d.length > 5 ? d.slice( 0, 5 ) + '-' + d.slice( 5 ) : d;
	}

	// data-format on an input says how it is typed (Nick, 2026-10-07: every
	// field formatted, like wp-admin's).
	var formats = {
		zip: formatZip,
		state: function ( raw ) {
			return ( raw || '' ).toUpperCase().replace( /[^A-Z]/g, '' ).slice( 0, 2 );
		},
		upper: function ( raw ) {
			return ( raw || '' ).toUpperCase();
		}
	};
	document.querySelectorAll( '.amat-portal input[data-format]' ).forEach( function ( input ) {
		var format = formats[ input.getAttribute( 'data-format' ) ];
		if ( format ) {
			input.addEventListener( 'input', function () {
				input.value = format( input.value );
			} );
		}
	} );

	// The request form's Phone.
	document.querySelectorAll( '.amat-portal input[type="tel"][name="phone"]' ).forEach( function ( input ) {
		input.addEventListener( 'input', function () {
			input.value = formatPhone( input.value );
		} );
	} );

	// "Choose your password" (2026-10-13): sent in the background, so a refusal
	// marks the field and keeps the page; an old page gets a fresh key and sends
	// again by itself; once set, on to where the link meant (they are logged in).
	// Without this script the form posts plainly and the server redirects.
	document.querySelectorAll( '.amat-password-form[data-submit]' ).forEach( function ( form ) {
		if ( ! window.fetch || ! window.FormData ) {
			return;
		}
		var button = form.querySelector( 'button[type="submit"]' );
		var nonce = form.querySelector( 'input[name="nonce"]' );
		var note = null;
		var clear = function () {
			form.querySelectorAll( '.amat-field.is-invalid' ).forEach( function ( field ) {
				field.classList.remove( 'is-invalid' );
				var err = field.querySelector( '.amat-field-error' );
				if ( err ) {
					err.remove();
				}
			} );
			if ( note ) {
				note.remove();
				note = null;
			}
		};
		var send = function ( retried ) {
			button.disabled = true;
			fetch( form.getAttribute( 'data-submit' ), { method: 'POST', credentials: 'same-origin', body: new FormData( form ) } )
				.then( function ( r ) {
					return r.json();
				} )
				.then( function ( res ) {
					var d = ( res && res.data ) || {};
					if ( ( res && res.success ) || d.redirect ) {
						window.location.assign( d.redirect );
						return;
					}
					if ( d.nonce && ! retried && nonce ) {
						nonce.value = d.nonce;
						send( true );
						return;
					}
					button.disabled = false;
					note = document.createElement( 'p' );
					note.className = 'amat-portal-notice is-error';
					note.setAttribute( 'role', 'alert' );
					note.textContent = d.message || 'Something went wrong - please try again.';
					form.insertAdjacentElement( 'afterbegin', note );
					Object.keys( d.fields || {} ).forEach( function ( name ) {
						var input = form.querySelector( '[name="' + name + '"]' );
						var field = input ? input.closest( '.amat-field' ) : null;
						if ( field ) {
							field.classList.add( 'is-invalid' );
							var err = document.createElement( 'span' );
							err.className = 'amat-field-error';
							err.textContent = d.fields[ name ];
							field.appendChild( err );
							input.focus();
						}
					} );
				} )
				.catch( function () {
					button.disabled = false;
					clear();
					note = document.createElement( 'p' );
					note.className = 'amat-portal-notice is-error';
					note.setAttribute( 'role', 'alert' );
					note.textContent = 'We could not send that - check your connection and try again.';
					form.insertAdjacentElement( 'afterbegin', note );
				} );
		};
		form.addEventListener( 'submit', function ( e ) {
			e.preventDefault();
			clear();
			send( false );
		} );
	} );

	// My details: every row but an Email one holds a phone number.
	document.querySelectorAll( '.amat-portal-cm' ).forEach( function ( row ) {
		var type = row.querySelector( 'select[name="cm_type[]"]' );
		var value = row.querySelector( 'input[name="cm_value[]"]' );
		if ( ! type || ! value ) {
			return;
		}
		var mask = function () {
			if ( 'email' !== type.value ) {
				value.value = formatPhone( value.value );
			}
		};
		value.addEventListener( 'input', mask );
		type.addEventListener( 'change', mask );
	} );
}() );
