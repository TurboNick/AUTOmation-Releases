<?php
/**
 * Plugin Name:       AUTOmation Comms
 * Plugin URI:        https://mrgind.com/
 * Update URI:        https://raw.githubusercontent.com/TurboNick/AUTOmation-Releases/main/automation-comms.json
 * Description:       Email and text messaging for the AUTOmation plugin. Send estimates and invoices to customers through pluggable connectors (wp_mail, SMTP, and later SMS providers). Requires the AUTOmation plugin.
 * Version:           0.3.0
 * Requires at least: 7.0
 * Requires PHP:      8.2
 * Author:            Nick G
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       auto-mation
 *
 * @package AUTOmation_Comms
 */

// Abort if this file is called directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Plugin version.
 */
define( 'AMAC_VERSION', '0.3.0' );

/**
 * Schema version for this plugin's own tables. Bump on any schema change so the
 * on-load upgrade check runs dbDelta without needing a manual reactivate.
 */
define( 'AMAC_DB_VERSION', 1 );

/**
 * Absolute path to this plugin's directory (with trailing slash). class-env.php
 * reads the git-ignored .env (connector secrets) from here.
 */
define( 'AMAC_DIR', plugin_dir_path( __FILE__ ) );

/**
 * This plugin's main file, for update checks and (de)activation hooks.
 */
define( 'AMAC_FILE', __FILE__ );

/**
 * URL to this plugin's directory (with trailing slash).
 */
define( 'AMAC_URL', plugin_dir_url( __FILE__ ) );

/**
 * Autoloader for this plugin's classes.
 *
 * Unlike the Wave companion — whose classes kept their original AMAT_Wave_*
 * names when they were extracted out of core — this plugin is greenfield, so
 * everything uses one prefix: AMAC_. Maps e.g. AMAC_Connector_Registry ->
 * includes/class-connector-registry.php, searching includes/ and its sub-dirs.
 *
 * @param string $class Fully-qualified class name being loaded.
 * @return void
 */
function amac_autoload( $class ) {
	if ( 0 !== strpos( $class, 'AMAC_' ) ) {
		return;
	}

	// Strip the AMAC_ prefix, lowercase, underscores -> hyphens.
	$slug = strtolower( str_replace( '_', '-', substr( $class, strlen( 'AMAC_' ) ) ) );
	$file = 'class-' . $slug . '.php';

	foreach ( array( '', 'connectors/', 'admin/' ) as $dir ) {
		$path = AMAC_DIR . 'includes/' . $dir . $file;
		if ( is_readable( $path ) ) {
			require_once $path;
			return;
		}
	}
}
spl_autoload_register( 'amac_autoload' );

/**
 * Boot the plugin once all plugins are loaded.
 *
 * Runs at priority 20 — after AUTOmation's own bootstrap (priority 10) — so the
 * core hooks this listens on already exist. If AUTOmation isn't active, show a
 * notice and bail rather than fatal (the same runtime-guard pattern as the Wave
 * companion; we deliberately omit a `Requires Plugins:` header because its slug
 * matching is unreliable for a non-wordpress.org, locally-installed plugin).
 *
 * @return void
 */
function amac_init() {
	if ( ! class_exists( 'AMAT_Admin' ) || ! class_exists( 'AMAT_Base_Model' ) ) {
		add_action( 'admin_notices', 'amac_dependency_notice' );
		return;
	}

	amac_maybe_upgrade();

	// Connectors register themselves into the registry before anything asks it
	// which one is active. Registration is cheap (no I/O, no provider calls).
	AMAC_Connector_Registry::bootstrap();

	// All Comms UI is admin-side for now. When triggered/scheduled sends land
	// they will need registering in every context (cron is not is_admin()).
	if ( is_admin() ) {
		// Self-hosted updates, using core's shared updater (this plugin already
		// requires core, so there is no independence lost by sharing it).
		( new AMAT_Updater( AMAC_FILE, AMAT_Updater::manifest_url( 'automation-comms' ), AMAC_VERSION ) )->register();
		( new AMAC_Provider() )->register();
	}
}
add_action( 'plugins_loaded', 'amac_init', 20 );

/**
 * Create/update this plugin's tables when the stored schema version is behind.
 *
 * Mirrors core's on-load upgrade check so a deploy that changes the schema
 * applies itself on the next page load, rather than silently doing nothing
 * until someone remembers to deactivate/reactivate.
 *
 * @return void
 */
function amac_maybe_upgrade() {
	if ( (int) get_option( 'amat_comms_db_version', 0 ) === AMAC_DB_VERSION ) {
		return;
	}
	AMAC_Activator::activate();
}

/**
 * Create tables on activation.
 *
 * @return void
 */
function amac_activate() {
	// The guard in amac_init() can't help here: activation runs on its own
	// request, so check for core before touching anything that extends it.
	if ( ! class_exists( 'AMAT_Base_Model' ) ) {
		return;
	}
	AMAC_Activator::activate();
}
register_activation_hook( __FILE__, 'amac_activate' );

/**
 * Admin notice shown when the required AUTOmation plugin isn't active.
 *
 * @return void
 */
function amac_dependency_notice() {
	if ( ! current_user_can( 'activate_plugins' ) ) {
		return;
	}
	echo '<div class="notice notice-error"><p>'
		. esc_html__( 'AUTOmation Comms requires the AUTOmation plugin to be installed and active. Messaging features are disabled until it is.', 'auto-mation' )
		. '</p></div>';
}
