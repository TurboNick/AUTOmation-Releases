<?php
/**
 * Document sync: push AUTOmation estimates (and later invoices) to Wave.
 *
 * Hangs off core's `amat_estimate_detail_actions` hook. Core stays unaware of
 * Wave: the link lives in `external_refs` and every outcome is written to core's
 * generic event log via `AMAT_Log` on the 'wave' channel.
 *
 * **Who owns what.** AUTOmation is the source of truth for the estimate's
 * *content* — its line items, notes, who it is for. Wave owns what happens to it
 * *out in the world*: the number it is issued under, and whether the customer has
 * seen, accepted or rejected it. So a push sends content one way, and the read-back
 * brings the number + status home. Wave is never told what its status should be.
 *
 * @package AUTOmation_Wave
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Pushes estimates to Wave and reflects Wave's number/status back.
 */
class AMAT_Wave_Documents {

	const PUSH_ESTIMATE_ACTION = 'push_estimate_wave';
	const PUSH_ESTIMATE_NONCE  = 'amat_push_estimate_wave';
	const PUSH_INVOICE_ACTION  = 'push_invoice_wave';
	const PUSH_INVOICE_NONCE   = 'amat_push_invoice_wave';

	/**
	 * Log channel for everything this class does (core's AMAT_Log).
	 *
	 * @var string
	 */
	const CHANNEL = 'wave';

	/**
	 * Provider slug used in external_refs.
	 *
	 * @var string
	 */
	const PROVIDER = 'wave';

	/**
	 * Hook into core's estimate detail + POST handling.
	 *
	 * @return void
	 */
	public function register() {
		add_action( 'admin_init', array( $this, 'maybe_process' ) );
		add_action( 'amat_estimate_detail_actions', array( $this, 'render_estimate_actions' ) );
		add_action( 'amat_invoice_detail_actions', array( $this, 'render_invoice_actions' ) );
	}

	/**
	 * Intercept this class's POST actions on admin_init (before any output).
	 *
	 * @return void
	 */
	public function maybe_process() {
		$action = isset( $_POST['amat_action'] ) ? $_POST['amat_action'] : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce checked in each handler.
		if ( self::PUSH_ESTIMATE_ACTION === $action ) {
			$this->process_estimate_push();
		} elseif ( self::PUSH_INVOICE_ACTION === $action ) {
			$this->process_invoice_push();
		}
	}

	/* --------------------------------------------------------------------- */
	/* Estimate detail UI                                                    */
	/* --------------------------------------------------------------------- */

	/**
	 * Render the Wave block on an estimate's read-only detail view.
	 *
	 * @param array<string,mixed> $estimate Estimate row.
	 * @return void
	 */
	public function render_estimate_actions( array $estimate ) {
		$id   = (int) $estimate['id'];
		$ref  = AMAT_External_Ref_Model::get( self::PROVIDER, 'estimate', $id );
		$wave = new AMAT_Wave_Client();
		?>
		<h2><?php esc_html_e( 'Wave', 'auto-mation' ); ?></h2>
		<table class="amat-detail-table">
			<tbody>
				<tr>
					<th><?php esc_html_e( 'Sync status', 'auto-mation' ); ?></th>
					<td><?php $this->render_sync_status( $ref ); ?></td>
				</tr>
				<?php if ( $ref && '' !== (string) $ref['external_id'] ) : ?>
					<tr>
						<th><?php esc_html_e( 'In Wave', 'auto-mation' ); ?></th>
						<td><?php $this->render_links( $ref ); ?></td>
					</tr>
				<?php endif; ?>
			</tbody>
		</table>
		<?php

		if ( ! $wave->is_configured() ) {
			echo '<p class="description">' . esc_html__( 'Wave is not configured — add WAVE_API_TOKEN to .env to enable syncing.', 'auto-mation' ) . '</p>';
			return;
		}

		// Once it is in Wave, show the estimate's activity (sent / viewed / accepted)
		// — before the push controls, and regardless of any current push blocker.
		if ( $ref && '' !== (string) $ref['external_id'] ) {
			$this->render_estimate_history( (string) $ref['external_id'] );
		}

		// Say what is missing rather than showing a button that will just fail.
		$blocker = $this->push_blocker( $estimate, $wave );
		if ( '' !== $blocker ) {
			echo '<p class="description">' . wp_kses_post( $blocker ) . '</p>';
			return;
		}

		$linked = $ref && '' !== (string) $ref['external_id'];
		?>
		<form method="post" class="amat-inline-form">
			<?php wp_nonce_field( self::PUSH_ESTIMATE_NONCE ); ?>
			<input type="hidden" name="amat_action" value="<?php echo esc_attr( self::PUSH_ESTIMATE_ACTION ); ?>" />
			<input type="hidden" name="id" value="<?php echo esc_attr( $id ); ?>" />
			<button type="submit" class="button amat-btn-primary">
				<?php echo $linked ? esc_html__( 'Update in Wave', 'auto-mation' ) : esc_html__( 'Push to Wave', 'auto-mation' ); ?>
			</button>
		</form>
		<p class="description">
			<?php if ( $linked ) : ?>
				<?php esc_html_e( 'Sends the current line items to the existing Wave estimate, and brings its number and status back.', 'auto-mation' ); ?>
			<?php else : ?>
				<?php esc_html_e( 'Creates a draft estimate in Wave from these line items. You send it from Wave; its number and the customer\'s response come back here.', 'auto-mation' ); ?>
			<?php endif; ?>
		</p>
		<?php
	}

	/**
	 * The sync-status cell for one document.
	 *
	 * @param array<string,mixed>|null $ref external_refs row, or null.
	 * @return void
	 */
	private function render_sync_status( $ref ) {
		if ( ! $ref || '' === (string) $ref['external_id'] ) {
			$failed = $ref && 'failed' === $ref['status'];
			echo '<span class="description">';
			echo $failed
				? esc_html__( 'The last push failed — see Settings → Logs for why. Try again.', 'auto-mation' )
				: esc_html__( 'Not pushed to Wave yet.', 'auto-mation' );
			echo '</span>';
			return;
		}

		$when = ! empty( $ref['synced_at'] ) ? strtotime( (string) $ref['synced_at'] ) : 0;

		if ( 'failed' === $ref['status'] ) {
			echo '<span class="amat-status amat-log-badge-warning">' . esc_html__( 'Out of date', 'auto-mation' ) . '</span> ';
			echo '<span class="description">' . esc_html__( 'It is in Wave, but the last update failed — see Settings → Logs.', 'auto-mation' ) . '</span>';
			return;
		}

		echo '<span class="amat-status amat-log-badge-info">' . esc_html__( 'Synced', 'auto-mation' ) . '</span> ';
		if ( $when ) {
			echo '<span class="description">';
			printf(
				/* translators: %s: human-readable time difference, e.g. "5 mins". */
				esc_html__( 'last pushed %s ago', 'auto-mation' ),
				esc_html( human_time_diff( $when, (int) current_time( 'timestamp' ) ) )
			);
			echo '</span>';
		}
	}

	/**
	 * The view/PDF links for a synced document.
	 *
	 * Wave exposes a customer-facing `viewUrl` and a `pdfUrl`; it has **no**
	 * admin/edit URL field, so there is no "open in Wave's editor" link to give.
	 * Both are stored at push time rather than re-fetched on every page load.
	 *
	 * @param array<string,mixed> $ref external_refs row.
	 * @return void
	 */
	private function render_links( array $ref ) {
		$entity = (string) $ref['entity_type'];
		$links  = $this->stored_links( $entity, (int) $ref['entity_id'] );
		$label  = 'invoice' === $entity ? __( 'View invoice', 'auto-mation' ) : __( 'View estimate', 'auto-mation' );

		if ( empty( $links['viewUrl'] ) && empty( $links['pdfUrl'] ) ) {
			echo '<span class="description">' . esc_html__( 'Pushed. Open it from your Wave account.', 'auto-mation' ) . '</span>';
			return;
		}
		if ( ! empty( $links['viewUrl'] ) ) {
			echo '<a href="' . esc_url( $links['viewUrl'] ) . '" target="_blank" rel="noopener">' . esc_html( $label ) . '</a> ';
		}
		if ( ! empty( $links['pdfUrl'] ) ) {
			echo '<a href="' . esc_url( $links['pdfUrl'] ) . '" target="_blank" rel="noopener">' . esc_html__( 'PDF', 'auto-mation' ) . '</a>';
		}
	}

	/**
	 * Why this estimate cannot be pushed yet, as ready-to-print HTML ('' = it can).
	 *
	 * @param array<string,mixed> $estimate Estimate row.
	 * @param AMAT_Wave_Client    $wave     Client.
	 * @return string
	 */
	private function push_blocker( array $estimate, AMAT_Wave_Client $wave ) {
		$settings_url = add_query_arg( array( 'page' => AMAT_Wave_Provider::PAGE_SLUG ), admin_url( 'admin.php' ) );

		if ( 'void' === (string) $estimate['status'] ) {
			// Core's 'void' has no Wave counterpart (Wave's estimate vocabulary has
			// DELETED, not void). Rather than guess that void should delete the Wave
			// copy, refuse and say so — see the Wave round plan in core's CLAUDE.md.
			return esc_html__( 'This estimate is void, so it is not pushed to Wave. Voiding a document that already exists in Wave is not handled yet — remove it in Wave if you need to.', 'auto-mation' );
		}

		if ( '' === AMAT_Wave_Client::customer_ref( (int) $estimate['customer_id'] ) ) {
			return esc_html__( 'The customer must be synced to Wave first — open the customer and use Sync to Wave.', 'auto-mation' );
		}

		$items = AMAT_Estimate_Item_Model::for_parent( (int) $estimate['id'] );
		if ( empty( $items ) ) {
			return esc_html__( 'Add at least one line item to this estimate first (edit it on its job).', 'auto-mation' );
		}

		// Every Wave line must reference a product; we never create products, so the
		// parent product for each kind of line present has to be chosen in Settings.
		$needs = array();
		foreach ( $items as $item ) {
			$needs[ 'part' === $item['source_type'] ? 'part' : 'service' ] = true;
		}
		if ( isset( $needs['service'] ) && '' === $wave->get_service_product_id() ) {
			return sprintf(
				/* translators: %s: URL of the Wave settings page. */
				wp_kses_post( __( 'This estimate has service lines, but no Wave product is chosen for them yet. Pick one under <a href="%s">Settings → Wave</a>.', 'auto-mation' ) ),
				esc_url( $settings_url )
			);
		}
		if ( isset( $needs['part'] ) && '' === $wave->get_parts_product_id() ) {
			return sprintf(
				/* translators: %s: URL of the Wave settings page. */
				wp_kses_post( __( 'This estimate has parts lines, but no Wave product is chosen for them yet. Pick one under <a href="%s">Settings → Wave</a>.', 'auto-mation' ) ),
				esc_url( $settings_url )
			);
		}

		return '';
	}

	/* --------------------------------------------------------------------- */
	/* Push                                                                  */
	/* --------------------------------------------------------------------- */

	/**
	 * Handle the estimate Push button: run the push, flash its result, redirect.
	 * The reusable work is in push_estimate() so auto-sync + the retry cron can
	 * drive the same code path without the request-lifecycle plumbing.
	 *
	 * @return void
	 */
	private function process_estimate_push() {
		check_admin_referer( self::PUSH_ESTIMATE_NONCE );
		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'auto-mation' ) );
		}

		$id     = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		$result = $this->push_estimate( $id );

		$this->flash(
			array(
				'status'  => 'success' === $result['status'] ? 'success' : 'error',
				'message' => $result['message'],
			)
		);
		wp_safe_redirect( $this->estimate_url( $id ) );
		exit;
	}

	/**
	 * Push one estimate to Wave: create it, or update the existing one, then bring
	 * Wave's number + status back onto the native record. Pure of the request
	 * lifecycle (no nonce/redirect/flash/exit) so the button handler, auto-sync and
	 * the retry cron can all call it. Marks the external_ref 'failed' + logs on a
	 * Wave error, so a failed push is findable and retryable (core §4).
	 *
	 * @param int $id Estimate id.
	 * @return array{status:string,message:string,retryable?:bool,wave_id?:string,number?:string}
	 */
	public function push_estimate( $id ) {
		$id       = (int) $id;
		$estimate = $id ? AMAT_Estimate_Model::find( $id ) : null;

		if ( ! $estimate ) {
			return array( 'status' => 'error', 'message' => __( 'Estimate not found.', 'auto-mation' ), 'retryable' => false );
		}

		$wave = new AMAT_Wave_Client();
		if ( ! $wave->is_configured() ) {
			// A precondition, not a transient failure — do not mark failed/retry.
			return array( 'status' => 'skipped', 'message' => __( 'Wave is not configured. Add WAVE_API_TOKEN to .env first.', 'auto-mation' ), 'retryable' => false );
		}

		$blocker = $this->push_blocker( $estimate, $wave );
		if ( '' !== $blocker ) {
			// Void / no customer link / no product chosen: a precondition. Retrying
			// won't help, so skip quietly rather than marking the ref failed.
			return array( 'status' => 'skipped', 'message' => wp_strip_all_tags( $blocker ), 'retryable' => false );
		}

		$items = $this->line_items_for_wave( AMAT_Estimate_Item_Model::for_parent( (int) $estimate['id'] ), $wave );
		if ( empty( $items ) ) {
			return $this->mark_doc_failed( 'estimate', $id, __( 'None of this estimate\'s lines could be sent to Wave.', 'auto-mation' ), array() );
		}

		$payload = array(
			'customerId' => AMAT_Wave_Client::customer_ref( (int) $estimate['customer_id'] ),
			'items'      => $items,
			'memo'       => $this->build_memo( $estimate ),
		);
		if ( ! empty( $estimate['valid_until'] ) ) {
			$payload['dueDate'] = (string) $estimate['valid_until'];
		}

		$existing = AMAT_External_Ref_Model::external_id( self::PROVIDER, 'estimate', $id );
		$is_new   = ( '' === $existing );

		if ( $is_new ) {
			$result = $wave->create_estimate( $payload );
		} else {
			$payload['id'] = $existing;
			$result        = $wave->update_estimate( $payload );
		}

		if ( is_wp_error( $result ) ) {
			return $this->mark_doc_failed(
				'estimate',
				$id,
				/* translators: %s: Wave error message. */
				sprintf( __( 'Wave push failed: %s', 'auto-mation' ), $result->get_error_message() ),
				array( 'code' => $result->get_error_code(), 'lines' => count( $items ) )
			);
		}

		// Wave will not let a DRAFT be sent to the customer, so clear its
		// "Approve draft" gate on Nick's behalf — he already built and approved
		// this thing in AUTOmation and has no interest in doing it twice. Patching
		// an approved estimate still works, so this does not lock it.
		if ( $is_new && 'DRAFT' === strtoupper( (string) $result['status'] ) ) {
			$approved = $wave->approve_estimate( $result['id'] );
			if ( is_wp_error( $approved ) ) {
				// Non-fatal: it IS in Wave, it just needs the button clicked there.
				// Say so rather than pretending the push was clean.
				AMAT_Log::warning(
					self::CHANNEL,
					__( 'Estimate pushed to Wave, but approving the draft failed — it cannot be sent until it is approved in Wave.', 'auto-mation' ),
					array(
						'entity_type' => 'estimate',
						'entity_id'   => $id,
						'context'     => array( 'wave_id' => $result['id'], 'error' => $approved->get_error_message() ),
					)
				);
			} else {
				$result = $approved;
			}
		}

		// Link + mark synced.
		AMAT_External_Ref_Model::set(
			self::PROVIDER,
			'estimate',
			$id,
			$result['id'],
			array( 'status' => 'synced', 'synced_at' => current_time( 'mysql' ) )
		);
		$this->store_links( 'estimate', $id, $result );
		delete_transient( self::history_cache_key( (string) $result['id'] ) ); // activity may have changed.

		// Bring Wave's own number/status home.
		$changes = $this->apply_readback( $estimate, $result );

		AMAT_Log::info(
			self::CHANNEL,
			$is_new ? __( 'Estimate created in Wave.', 'auto-mation' ) : __( 'Estimate updated in Wave.', 'auto-mation' ),
			array(
				'entity_type' => 'estimate',
				'entity_id'   => $id,
				'context'     => array(
					'wave_id'     => $result['id'],
					'wave_number' => $result['number'],
					'wave_status' => $result['status'],
					'lines'       => count( $items ),
					'applied'     => $changes,
				),
			)
		);

		$message = $is_new
			? __( 'Estimate created in Wave as a draft.', 'auto-mation' )
			: __( 'Estimate updated in Wave.', 'auto-mation' );
		if ( ! empty( $result['number'] ) ) {
			/* translators: %s: the estimate number Wave assigned. */
			$message .= ' ' . sprintf( __( 'Wave numbered it %s.', 'auto-mation' ), $result['number'] );
		}

		return array( 'status' => 'success', 'message' => $message, 'wave_id' => (string) $result['id'], 'number' => (string) $result['number'] );
	}

	/**
	 * Mark a document's external_ref 'failed' and log why, then return the error
	 * result. The ref carries the state (so the retry sweep can find it); the log
	 * carries the reason (core §4). Preserves any existing external_id.
	 *
	 * @param string              $entity  'estimate' or 'invoice'.
	 * @param int                 $id      Document id.
	 * @param string              $message Human-readable failure reason.
	 * @param array<string,mixed> $context Extra log context.
	 * @return array{status:string,message:string,retryable:bool}
	 */
	private function mark_doc_failed( $entity, $id, $message, array $context ) {
		$existing = AMAT_External_Ref_Model::external_id( self::PROVIDER, $entity, (int) $id );
		AMAT_External_Ref_Model::set( self::PROVIDER, $entity, (int) $id, $existing, array( 'status' => 'failed' ) );
		AMAT_Log::error(
			self::CHANNEL,
			$message,
			array( 'entity_type' => $entity, 'entity_id' => (int) $id, 'context' => $context )
		);
		return array( 'status' => 'error', 'message' => $message, 'retryable' => true );
	}

	/**
	 * Copy Wave's number, validity date and (when meaningful) status onto the
	 * native record.
	 *
	 * - **number** — Wave's to assign. Nick's books have years of history under
	 *   Wave's own sequence, so ours would collide. Overwrites our (read-only) field.
	 * - **valid_until** — the validity window is only computed when the estimate is
	 *   actually going to the customer, which is this moment: it is drafted in
	 *   AUTOmation with no date, and the push (which clears Wave's send gate) is
	 *   what dates it. Wave defaults dueDate to the issue date when none is sent,
	 *   so the client always sends one. Taking it back keeps both sides identical.
	 * - **status** — only when Wave knows something we don't; see status_from_wave().
	 *
	 * @param array<string,mixed>  $estimate Local estimate row (pre-push).
	 * @param array<string,string> $result   Wave's returned estimate.
	 * @return array<string,string> What was actually changed (for the log).
	 */
	private function apply_readback( array $estimate, array $result ) {
		$id      = (int) $estimate['id'];
		$changes = array();
		$fields  = array();

		$number = trim( (string) ( $result['number'] ?? '' ) );
		if ( '' !== $number && $number !== (string) $estimate['number'] ) {
			$fields['number']  = $number;
			$changes['number'] = $number;
		}

		$due = trim( (string) ( $result['dueDate'] ?? '' ) );
		if ( '' !== $due && $due !== (string) $estimate['valid_until'] ) {
			$fields['valid_until']  = $due;
			$changes['valid_until'] = $due;
		}

		$status = self::status_from_wave( (string) ( $result['status'] ?? '' ) );
		if ( '' !== $status && $status !== (string) $estimate['status'] ) {
			$fields['status']  = $status;
			$changes['status'] = $status;
		}

		if ( $fields ) {
			AMAT_Estimate_Model::update( $id, $fields );
		}

		return $changes;
	}

	/**
	 * Map a Wave estimate status onto core's vocabulary.
	 *
	 * Returns '' for "Wave has no opinion worth importing". Three deliberate cases:
	 *
	 * - **DRAFT** — every estimate is created in Wave as a draft (its create
	 *   vocabulary has no other value), so importing it would drag a local status
	 *   backwards to Draft on the very first push. Wave may only ever *advance*
	 *   our status with something it actually knows.
	 * - **APPROVED** — ⚠ **the same word, a different thing.** Wave's APPROVED is a
	 *   *pre-send gate*: a draft cannot be sent (and its "valid until" is ignored)
	 *   until someone clicks "Approve draft". Core's `approved` is a *post-send*
	 *   state meaning "this has the go-ahead to become an invoice". Importing one
	 *   as the other would mark an estimate ready-to-invoice before the customer
	 *   has even seen it. Core deliberately does not model Wave's gate at all —
	 *   drafts are built in AUTOmation, and the push clicks that button for Nick
	 *   (see AMAT_Wave_Client::approve_estimate()), so the state is transient and
	 *   uninteresting to us.
	 * - **CONVERTED** — core's source of truth for "converted" is the
	 *   estimate→invoice link, not a status, so that an accepted estimate keeps
	 *   its acceptance on record (core §4).
	 *
	 * Known fidelity loss: Wave cannot distinguish "the customer accepted" from
	 * "Nick marked it accepted on their behalf" — both are ACCEPTED — so a
	 * read-back always lands on core's `accepted`. Core's `approved` (Nick's own
	 * go-ahead) is therefore only ever set by hand in AUTOmation. That is core
	 * being richer than the provider, which is the point of the superset (§4).
	 *
	 * @param string $wave_status Wave's EstimateStatus value.
	 * @return string Core status slug, or '' to leave ours alone.
	 */
	public static function status_from_wave( $wave_status ) {
		$map = array(
			'SENT'     => 'sent',
			'VIEWED'   => 'viewed',
			'ACCEPTED' => 'accepted',
			'REJECTED' => 'declined',
			'EXPIRED'  => 'expired',
			'DELETED'  => 'void',
		);

		return $map[ strtoupper( trim( $wave_status ) ) ] ?? '';
	}

	/**
	 * Build Wave line rows from a document's line items (estimate OR invoice — they
	 * share the same line shape).
	 *
	 * Each line books to the parent product chosen in Settings (service lines →
	 * the service product, parts lines → the parts product) with our description
	 * riding along, because AUTOmation deliberately does not create per-item Wave
	 * products.
	 *
	 * @param array<int,array<string,mixed>> $items Core line-item rows.
	 * @param AMAT_Wave_Client               $wave  Client.
	 * @return array<int,array<string,mixed>>
	 */
	private function line_items_for_wave( array $items, AMAT_Wave_Client $wave ) {
		$service_product = $wave->get_service_product_id();
		$parts_product   = $wave->get_parts_product_id();

		$rows = array();
		foreach ( $items as $item ) {
			$is_part    = ( 'part' === $item['source_type'] );
			$product_id = $is_part ? $parts_product : $service_product;
			if ( '' === $product_id ) {
				continue; // push_blocker() already refuses this case.
			}
			$rows[] = array(
				'productId'   => $product_id,
				'description' => (string) $item['description'],
				'quantity'    => (float) $item['quantity'],
				'unitPrice'   => null === $item['unit_price'] ? 0 : (float) $item['unit_price'],
			);
		}

		return $rows;
	}

	/* --------------------------------------------------------------------- */
	/* Estimate acceptance history                                           */
	/* --------------------------------------------------------------------- */

	/**
	 * Render the estimate's activity table (Wave's acceptance history): each send,
	 * view and accept/decline, with who did it and when. Read live from Wave (short
	 * transient cache), degrading to a note on error — never fatal.
	 *
	 * @param string $wave_estimate_id Wave estimate ID.
	 * @return void
	 */
	private function render_estimate_history( $wave_estimate_id ) {
		$events = $this->estimate_history( $wave_estimate_id );
		?>
		<h2><?php esc_html_e( 'Estimate activity', 'auto-mation' ); ?></h2>
		<?php
		if ( is_wp_error( $events ) ) {
			echo '<p class="description">' . esc_html__( 'Could not load this estimate\'s activity from Wave just now.', 'auto-mation' ) . '</p>';
			return;
		}
		if ( empty( $events ) ) {
			echo '<p class="description">' . esc_html__( 'No activity yet — Wave records each send, view and response once the estimate is out with the customer.', 'auto-mation' ) . '</p>';
			return;
		}

		// Newest first. ISO-8601 timestamps sort lexically.
		usort(
			$events,
			static function ( $a, $b ) {
				return strcmp( (string) $b['timestamp'], (string) $a['timestamp'] );
			}
		);

		$fmt = get_option( 'date_format' ) . ' ' . get_option( 'time_format' );
		?>
		<table class="amat-detail-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'When', 'auto-mation' ); ?></th>
					<th><?php esc_html_e( 'Activity', 'auto-mation' ); ?></th>
					<th><?php esc_html_e( 'By', 'auto-mation' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $events as $event ) : ?>
					<?php
					$ts    = trim( (string) $event['timestamp'] );
					$stamp = ( '' !== $ts ) ? strtotime( $ts ) : false;
					$when  = $stamp ? wp_date( $fmt, $stamp ) : $ts; // fall back to the raw value if unparseable.
					$name  = trim( (string) $event['name'] );
					$email = trim( (string) $event['email'] );
					$who   = self::history_actor_label( (string) $event['entityType'] );
					if ( '' !== $name ) {
						$who .= ' — ' . $name;
					}
					?>
					<tr>
						<td><?php echo esc_html( $when ); ?></td>
						<td><?php echo esc_html( self::history_state_label( (string) $event['state'] ) ); ?></td>
						<td>
							<?php echo esc_html( $who ); ?>
							<?php if ( '' !== $email ) : ?>
								<br /><a href="<?php echo esc_attr( 'mailto:' . antispambot( $email ) ); ?>"><?php echo esc_html( $email ); ?></a>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}

	/**
	 * This estimate's Wave history, cached briefly so refreshing the detail page
	 * doesn't re-hit Wave. History changes as the customer acts, so the cache is
	 * short (and cleared on a push); an error is not cached.
	 *
	 * @param string $wave_estimate_id Wave estimate ID.
	 * @return array<int,array<string,string>>|WP_Error
	 */
	private function estimate_history( $wave_estimate_id ) {
		$key    = self::history_cache_key( $wave_estimate_id );
		$cached = get_transient( $key );
		if ( is_array( $cached ) ) {
			return $cached;
		}

		$events = ( new AMAT_Wave_Client() )->get_estimate_history( $wave_estimate_id );
		if ( ! is_wp_error( $events ) ) {
			set_transient( $key, $events, 5 * MINUTE_IN_SECONDS );
		}
		return $events;
	}

	/**
	 * Transient key caching one estimate's Wave history.
	 *
	 * @param string $wave_estimate_id Wave estimate ID.
	 * @return string
	 */
	private static function history_cache_key( $wave_estimate_id ) {
		return 'amat_wave_esthist_' . md5( (string) $wave_estimate_id );
	}

	/**
	 * Human label for a history actor (Wave's EstimateHistoryEntityType).
	 *
	 * @param string $entity_type BUSINESS_OWNER | CUSTOMER.
	 * @return string
	 */
	public static function history_actor_label( $entity_type ) {
		switch ( strtoupper( trim( $entity_type ) ) ) {
			case 'BUSINESS_OWNER':
				return __( 'You', 'auto-mation' );
			case 'CUSTOMER':
				return __( 'Customer', 'auto-mation' );
			default:
				return (string) $entity_type;
		}
	}

	/**
	 * Human label for a history state. Known Wave states get a friendly phrase;
	 * anything else is prettified generically, so an unfamiliar state still reads
	 * sensibly rather than shouting UPPER_SNAKE at the owner.
	 *
	 * @param string $state Wave history state string.
	 * @return string
	 */
	public static function history_state_label( $state ) {
		$key = strtoupper( trim( $state ) );
		$map = array(
			'CREATED'  => __( 'Created', 'auto-mation' ),
			'APPROVED' => __( 'Approved (ready to send)', 'auto-mation' ),
			'SENT'     => __( 'Sent', 'auto-mation' ),
			'VIEWED'   => __( 'Viewed', 'auto-mation' ),
			'ACCEPTED' => __( 'Accepted', 'auto-mation' ),
			'REJECTED' => __( 'Declined', 'auto-mation' ),
			'EXPIRED'  => __( 'Expired', 'auto-mation' ),
			'MODIFIED' => __( 'Modified', 'auto-mation' ),
		);
		if ( isset( $map[ $key ] ) ) {
			return $map[ $key ];
		}
		if ( '' === $key ) {
			return '';
		}
		return ucwords( strtolower( str_replace( '_', ' ', $key ) ) );
	}

	/* --------------------------------------------------------------------- */
	/* Invoice detail UI                                                     */
	/* --------------------------------------------------------------------- */

	/**
	 * Render the Wave block on an invoice's read-only detail view.
	 *
	 * @param array<string,mixed> $invoice Invoice row.
	 * @return void
	 */
	public function render_invoice_actions( array $invoice ) {
		$id   = (int) $invoice['id'];
		$ref  = AMAT_External_Ref_Model::get( self::PROVIDER, 'invoice', $id );
		$wave = new AMAT_Wave_Client();
		?>
		<h2><?php esc_html_e( 'Wave', 'auto-mation' ); ?></h2>
		<table class="amat-detail-table">
			<tbody>
				<tr>
					<th><?php esc_html_e( 'Sync status', 'auto-mation' ); ?></th>
					<td><?php $this->render_sync_status( $ref ); ?></td>
				</tr>
				<?php if ( $ref && '' !== (string) $ref['external_id'] ) : ?>
					<tr>
						<th><?php esc_html_e( 'Payment', 'auto-mation' ); ?></th>
						<td><?php $this->render_payment_summary( $invoice ); ?></td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'In Wave', 'auto-mation' ); ?></th>
						<td><?php $this->render_links( $ref ); ?></td>
					</tr>
				<?php endif; ?>
			</tbody>
		</table>
		<?php

		if ( ! $wave->is_configured() ) {
			echo '<p class="description">' . esc_html__( 'Wave is not configured — add WAVE_API_TOKEN to .env to enable syncing.', 'auto-mation' ) . '</p>';
			return;
		}

		$blocker = $this->invoice_push_blocker( $invoice, $wave );
		if ( '' !== $blocker ) {
			echo '<p class="description">' . wp_kses_post( $blocker ) . '</p>';
			return;
		}

		$linked   = $ref && '' !== (string) $ref['external_id'];
		$can_conv = ! $linked && $this->convertible_estimate_ref( $invoice );
		?>
		<form method="post" class="amat-inline-form">
			<?php wp_nonce_field( self::PUSH_INVOICE_NONCE ); ?>
			<input type="hidden" name="amat_action" value="<?php echo esc_attr( self::PUSH_INVOICE_ACTION ); ?>" />
			<input type="hidden" name="id" value="<?php echo esc_attr( $id ); ?>" />
			<button type="submit" class="button amat-btn-primary">
				<?php echo $linked ? esc_html__( 'Update in Wave', 'auto-mation' ) : esc_html__( 'Push to Wave', 'auto-mation' ); ?>
			</button>
		</form>
		<p class="description">
			<?php if ( $linked ) : ?>
				<?php esc_html_e( 'Sends the current line items to the existing Wave invoice, and brings its payment status back.', 'auto-mation' ); ?>
			<?php elseif ( $can_conv ) : ?>
				<?php esc_html_e( 'Converts the linked estimate in Wave into an invoice (so Wave keeps the two linked), finalizes it, and brings its number and payment status back.', 'auto-mation' ); ?>
			<?php else : ?>
				<?php esc_html_e( 'Creates a finalized invoice in Wave from these line items. Its number, due date and payment status come back here.', 'auto-mation' ); ?>
			<?php endif; ?>
		</p>
		<?php
	}

	/**
	 * The payment-summary cell: what Wave last told us about money.
	 *
	 * @param array<string,mixed> $invoice Invoice row.
	 * @return void
	 */
	private function render_payment_summary( array $invoice ) {
		$status = (string) $invoice['status'];
		$paid   = $invoice['amount_paid'];

		echo '<span class="amat-status amat-status-' . esc_attr( $status ) . '">' . esc_html( AMAT_Invoice_Model::status_label( $status ) ) . '</span> ';

		if ( null !== $paid && '' !== $paid ) {
			echo '<span class="description">';
			printf(
				/* translators: %s: formatted amount paid. */
				esc_html__( 'paid: %s', 'auto-mation' ),
				esc_html( AMAT_Money::format_amount( (float) $paid ) )
			);
			if ( ! empty( $invoice['paid_date'] ) ) {
				echo ' (' . esc_html( AMAT_Estimates_Page::date_display( (string) $invoice['paid_date'] ) ) . ')';
			}
			echo '</span>';
		}
	}

	/**
	 * Why this invoice cannot be pushed yet, as ready-to-print HTML ('' = it can).
	 *
	 * @param array<string,mixed> $invoice Invoice row.
	 * @param AMAT_Wave_Client    $wave    Client.
	 * @return string
	 */
	private function invoice_push_blocker( array $invoice, AMAT_Wave_Client $wave ) {
		$settings_url = add_query_arg( array( 'page' => AMAT_Wave_Provider::PAGE_SLUG ), admin_url( 'admin.php' ) );

		if ( 'void' === (string) $invoice['status'] ) {
			// Core's 'void' has no Wave counterpart, and — unlike an estimate —
			// invoiceDelete genuinely DESTROYS the accounting record (verified: it
			// reads back NOT_FOUND). Wave is the system of record for money, so we
			// refuse rather than delete. Void it in Wave by hand if truly needed.
			return esc_html__( 'This invoice is void, so it is not pushed to Wave. Wave is the record of your accounting — voiding there is a manual step, done in Wave.', 'auto-mation' );
		}

		if ( '' === AMAT_Wave_Client::customer_ref( (int) $invoice['customer_id'] ) ) {
			return esc_html__( 'The customer must be synced to Wave first — open the customer and use Sync to Wave.', 'auto-mation' );
		}

		$items = AMAT_Invoice_Item_Model::for_parent( (int) $invoice['id'] );
		if ( empty( $items ) ) {
			return esc_html__( 'Add at least one line item to this invoice first (edit it on its job).', 'auto-mation' );
		}

		$needs = array();
		foreach ( $items as $item ) {
			$needs[ 'part' === $item['source_type'] ? 'part' : 'service' ] = true;
		}
		if ( isset( $needs['service'] ) && '' === $wave->get_service_product_id() ) {
			return sprintf(
				/* translators: %s: URL of the Wave settings page. */
				wp_kses_post( __( 'This invoice has service lines, but no Wave product is chosen for them yet. Pick one under <a href="%s">Settings → Wave</a>.', 'auto-mation' ) ),
				esc_url( $settings_url )
			);
		}
		if ( isset( $needs['part'] ) && '' === $wave->get_parts_product_id() ) {
			return sprintf(
				/* translators: %s: URL of the Wave settings page. */
				wp_kses_post( __( 'This invoice has parts lines, but no Wave product is chosen for them yet. Pick one under <a href="%s">Settings → Wave</a>.', 'auto-mation' ) ),
				esc_url( $settings_url )
			);
		}

		return '';
	}

	/**
	 * The Wave estimate ID this invoice could be converted from, or '' if none.
	 *
	 * An invoice qualifies for the convert-in-Wave path when it was converted from
	 * an estimate in core AND that estimate is itself linked to Wave — so Wave can
	 * record the estimate→invoice relationship instead of getting a stray invoice.
	 *
	 * @param array<string,mixed> $invoice Invoice row.
	 * @return string Wave estimate ID, or ''.
	 */
	private function convertible_estimate_ref( array $invoice ) {
		$estimate_id = (int) ( $invoice['estimate_id'] ?? 0 );
		if ( $estimate_id <= 0 ) {
			return '';
		}
		return AMAT_External_Ref_Model::external_id( self::PROVIDER, 'estimate', $estimate_id );
	}

	/* --------------------------------------------------------------------- */
	/* Invoice push                                                          */
	/* --------------------------------------------------------------------- */

	/**
	 * Push one invoice to Wave, then bring its number/due-date/payment status home.
	 *
	 * A first push either **converts** the linked Wave estimate (keeping Wave's
	 * estimate→invoice link) or **creates** a finalized invoice; a re-push patches
	 * the existing one. Convert produces a DRAFT in Wave, so it is finalized to
	 * SAVED in the same sync patch.
	 *
	 * @return void
	 */
	private function process_invoice_push() {
		check_admin_referer( self::PUSH_INVOICE_NONCE );
		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'auto-mation' ) );
		}

		$id     = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		$result = $this->push_invoice( $id );

		$this->flash(
			array(
				'status'  => 'success' === $result['status'] ? 'success' : 'error',
				'message' => $result['message'],
			),
			AMAT_Invoices_Page::PAGE_SLUG
		);
		wp_safe_redirect( $this->invoice_url( $id ) );
		exit;
	}

	/**
	 * Push one invoice to Wave, then bring its number/due-date/payment status home.
	 * Pure of the request lifecycle (see push_estimate()) so auto-sync + the retry
	 * cron can drive it.
	 *
	 * A first push either **converts** the linked Wave estimate (keeping Wave's
	 * estimate→invoice link) or **creates** a finalized invoice; a re-push patches
	 * the existing one. Convert produces a DRAFT in Wave, so it is finalized to
	 * SAVED in the same sync patch.
	 *
	 * @param int $id Invoice id.
	 * @return array{status:string,message:string,retryable?:bool,wave_id?:string,number?:string}
	 */
	public function push_invoice( $id ) {
		$id      = (int) $id;
		$invoice = $id ? AMAT_Invoice_Model::find( $id ) : null;

		if ( ! $invoice ) {
			return array( 'status' => 'error', 'message' => __( 'Invoice not found.', 'auto-mation' ), 'retryable' => false );
		}

		$wave = new AMAT_Wave_Client();
		if ( ! $wave->is_configured() ) {
			return array( 'status' => 'skipped', 'message' => __( 'Wave is not configured. Add WAVE_API_TOKEN to .env first.', 'auto-mation' ), 'retryable' => false );
		}

		$blocker = $this->invoice_push_blocker( $invoice, $wave );
		if ( '' !== $blocker ) {
			// Void / no customer link / no product: a precondition. A void invoice is
			// deliberately never pushed (Wave is the record of accounting) — skip, do
			// not mark failed.
			return array( 'status' => 'skipped', 'message' => wp_strip_all_tags( $blocker ), 'retryable' => false );
		}

		$items = $this->line_items_for_wave( AMAT_Invoice_Item_Model::for_parent( (int) $invoice['id'] ), $wave );
		if ( empty( $items ) ) {
			return $this->mark_doc_failed( 'invoice', $id, __( 'None of this invoice\'s lines could be sent to Wave.', 'auto-mation' ), array() );
		}

		$memo     = $this->build_memo( $invoice );
		$dates    = $this->invoice_dates( $invoice, $id );
		$issued   = $dates['invoiceDate'];
		$due      = $dates['dueDate'];
		$existing = AMAT_External_Ref_Model::external_id( self::PROVIDER, 'invoice', $id );
		$is_new   = ( '' === $existing );
		$via      = 'create';

		if ( ! $is_new ) {
			$result = $wave->update_invoice( array( 'id' => $existing, 'items' => $items, 'memo' => $memo, 'invoiceDate' => $issued, 'dueDate' => $due ) );
		} else {
			// Prefer converting the linked Wave estimate, so Wave keeps the link.
			$estimate_wave_id = $this->convertible_estimate_ref( $invoice );
			$result           = null;

			if ( '' !== $estimate_wave_id ) {
				$converted = $wave->convert_estimate_to_invoice( $estimate_wave_id );
				if ( is_wp_error( $converted ) ) {
					// Convert can legitimately fail (estimate not in a convertible
					// state, or already converted). Fall back to a fresh invoice
					// rather than block the push — just note why.
					AMAT_Log::warning(
						self::CHANNEL,
						__( 'Could not convert the Wave estimate; creating a fresh invoice instead.', 'auto-mation' ),
						array( 'entity_type' => 'invoice', 'entity_id' => $id, 'context' => array( 'error' => $converted->get_error_message() ) )
					);
				} else {
					// Convert yields a DRAFT; finalize to SAVED and sync core's lines
					// in one patch, so Wave never holds a draft invoice from us.
					$via    = 'convert';
					$result = $wave->update_invoice( array( 'id' => $converted['id'], 'items' => $items, 'memo' => $memo, 'invoiceDate' => $issued, 'dueDate' => $due, 'status' => 'SAVED' ) );
				}
			}

			if ( null === $result ) {
				$via    = 'create';
				$result = $wave->create_invoice( array( 'customerId' => AMAT_Wave_Client::customer_ref( (int) $invoice['customer_id'] ), 'items' => $items, 'memo' => $memo, 'invoiceDate' => $issued, 'dueDate' => $due ) );
			}
		}

		if ( is_wp_error( $result ) ) {
			return $this->mark_doc_failed(
				'invoice',
				$id,
				/* translators: %s: Wave error message. */
				sprintf( __( 'Wave push failed: %s', 'auto-mation' ), $result->get_error_message() ),
				array( 'code' => $result->get_error_code(), 'via' => $via, 'lines' => count( $items ) )
			);
		}

		AMAT_External_Ref_Model::set( self::PROVIDER, 'invoice', $id, $result['id'], array( 'status' => 'synced', 'synced_at' => current_time( 'mysql' ) ) );
		$this->store_links( 'invoice', $id, $result );

		$changes = $this->apply_invoice_readback( $invoice, $result );

		AMAT_Log::info(
			self::CHANNEL,
			$is_new ? __( 'Invoice created in Wave.', 'auto-mation' ) : __( 'Invoice updated in Wave.', 'auto-mation' ),
			array(
				'entity_type' => 'invoice',
				'entity_id'   => $id,
				'context'     => array(
					'wave_id'      => $result['id'],
					'wave_number'  => $result['number'],
					'wave_status'  => $result['status'],
					'via'          => $via,
					'lines'        => count( $items ),
					'applied'      => $changes,
				),
			)
		);

		$message = $is_new
			? ( 'convert' === $via ? __( 'Estimate converted to an invoice in Wave.', 'auto-mation' ) : __( 'Invoice created in Wave.', 'auto-mation' ) )
			: __( 'Invoice updated in Wave.', 'auto-mation' );
		if ( ! empty( $result['number'] ) ) {
			/* translators: %s: the invoice number Wave assigned. */
			$message .= ' ' . sprintf( __( 'Wave numbered it %s.', 'auto-mation' ), $result['number'] );
		}

		return array( 'status' => 'success', 'message' => $message, 'wave_id' => (string) $result['id'], 'number' => (string) $result['number'] );
	}

	/**
	 * Reconcile an invoice's issue + due dates into something Wave will accept.
	 *
	 * Wave enforces `dueDate >= invoiceDate` and rejects the whole mutation with
	 * "Due date cannot be before invoice date" otherwise. Two ways to trip it:
	 *
	 *   1. **Not sending the issue date at all** — Wave then dates the invoice
	 *      TODAY, so every back-dated invoice (anything issued before today, i.e.
	 *      most of a real backlog) is rejected on its own due date. This is why
	 *      the issue date is now always sent.
	 *   2. **Core allowing due < issue.** Core does not validate the pair, so a
	 *      typo can persist locally and would otherwise fail forever against Wave.
	 *      Rather than refuse the push, the due date is clamped up to the issue
	 *      date and the divergence is logged. Note that the clamped value then
	 *      lands back on the local row: apply_invoice_readback() already treats
	 *      Wave's dueDate as authoritative, so core ends up agreeing with Wave
	 *      instead of holding a due date that precedes its own issue date.
	 *
	 * @param array<string,mixed> $invoice Local invoice row.
	 * @param int                 $id      Invoice id (for the log).
	 * @return array{invoiceDate:string,dueDate:string}
	 */
	private function invoice_dates( array $invoice, $id ) {
		$issued = trim( (string) ( $invoice['issue_date'] ?? '' ) );
		$due    = trim( (string) ( $invoice['due_date'] ?? '' ) );

		if ( '0000-00-00' === $issued ) {
			$issued = '';
		}
		if ( '0000-00-00' === $due ) {
			$due = '';
		}

		// With no issue date, Wave will stamp today — so today is the floor.
		$floor = ( '' !== $issued ) ? $issued : current_time( 'Y-m-d' );

		if ( '' !== $due && $due < $floor ) {
			AMAT_Log::warning(
				self::CHANNEL,
				__( 'Invoice due date is before its issue date; sent to Wave as the issue date instead.', 'auto-mation' ),
				array(
					'entity_type' => 'invoice',
					'entity_id'   => (int) $id,
					'context'     => array( 'issue_date' => $issued, 'due_date' => $due, 'sent_due_date' => $floor ),
				)
			);
			$due = $floor;
		}

		return array( 'invoiceDate' => $issued, 'dueDate' => $due );
	}

	/**
	 * Copy Wave's number, due date, payment status and amounts onto the invoice.
	 *
	 * Wave is the system of record for money, so the payment fields are always
	 * taken as authoritative: `amount_paid` from Wave's amountPaid, `paid_date`
	 * from the latest payment, and `status` from status_from_wave_invoice().
	 *
	 * @param array<string,mixed> $invoice Local invoice row (pre-push).
	 * @param array<string,mixed> $result  Wave's returned invoice.
	 * @return array<string,string> What changed (for the log).
	 */
	private function apply_invoice_readback( array $invoice, array $result ) {
		$id      = (int) $invoice['id'];
		$changes = array();
		$fields  = array();

		$number = trim( (string) ( $result['number'] ?? '' ) );
		if ( '' !== $number && $number !== (string) $invoice['number'] ) {
			$fields['number']  = $number;
			$changes['number'] = $number;
		}

		$due = trim( (string) ( $result['dueDate'] ?? '' ) );
		if ( '' !== $due && $due !== (string) $invoice['due_date'] ) {
			$fields['due_date']  = $due;
			$changes['due_date'] = $due;
		}

		// Money: Wave is authoritative. amountPaid comes back as a string like
		// "10.00"; an unpaid invoice reads "0.00", which we store as-is.
		if ( array_key_exists( 'amountPaid', $result ) && '' !== (string) $result['amountPaid'] ) {
			$paid = (string) $result['amountPaid'];
			if ( $paid !== (string) $invoice['amount_paid'] ) {
				$fields['amount_paid']  = $paid;
				$changes['amount_paid'] = $paid;
			}
		}

		$paid_date = trim( (string) ( $result['paidDate'] ?? '' ) );
		if ( '' !== $paid_date && $paid_date !== (string) $invoice['paid_date'] ) {
			$fields['paid_date']  = $paid_date;
			$changes['paid_date'] = $paid_date;
		}

		$status = self::status_from_wave_invoice( (string) ( $result['status'] ?? '' ) );
		if ( '' !== $status && $status !== (string) $invoice['status'] ) {
			$fields['status']  = $status;
			$changes['status'] = $status;
		}

		if ( $fields ) {
			AMAT_Invoice_Model::update( $id, $fields );
		}

		return $changes;
	}

	/**
	 * Map a Wave invoice status onto core's vocabulary.
	 *
	 * Returns '' when Wave's state is one core sets itself and Wave cannot improve
	 * on:
	 *
	 * - **DRAFT / SAVED** — the pre-send states. We only ever put a *finalized*
	 *   (SAVED) invoice into Wave, and core already knows it is finalized; importing
	 *   SAVED would just churn. Neither should drag a locally-progressed status back.
	 *
	 * Everything from SENT onward is genuinely Wave's to report — the customer
	 * seeing it, and every payment state — so those map through. UNPAID is Wave's
	 * "finalized + sent, nothing paid yet"; core mirrors it.
	 *
	 * @param string $wave_status Wave's InvoiceStatus value.
	 * @return string Core status slug, or '' to leave ours alone.
	 */
	public static function status_from_wave_invoice( $wave_status ) {
		$map = array(
			'SENT'     => 'sent',
			'VIEWED'   => 'viewed',
			'UNPAID'   => 'unpaid',
			'PARTIAL'  => 'partial',
			'PAID'     => 'paid',
			'OVERPAID' => 'overpaid',
			'OVERDUE'  => 'overdue',
		);

		return $map[ strtoupper( trim( $wave_status ) ) ] ?? '';
	}

	/* --------------------------------------------------------------------- */
	/* Stored links (viewUrl / pdfUrl)                                       */
	/* --------------------------------------------------------------------- */

	/**
	 * Option key holding the cached Wave links for one document.
	 *
	 * Wave's viewUrl/pdfUrl are stable per document, so they are stored at push
	 * time rather than re-fetched on every page view (§6: don't be chatty).
	 * external_refs has no field for them, and adding provider-shaped columns to a
	 * core table would break core's provider-agnosticism — so they live in this
	 * plugin's own option.
	 *
	 * @param string $entity 'estimate' or 'invoice'.
	 * @param int    $id     Document id.
	 * @return string
	 */
	private function links_option( $entity, $id ) {
		return 'amat_wave_links_' . sanitize_key( $entity ) . '_' . (int) $id;
	}

	/**
	 * Remember a document's Wave links.
	 *
	 * @param string               $entity 'estimate' or 'invoice'.
	 * @param int                  $id     Document id.
	 * @param array<string,string> $result Wave's returned document.
	 * @return void
	 */
	private function store_links( $entity, $id, array $result ) {
		update_option(
			$this->links_option( $entity, $id ),
			array(
				'viewUrl' => (string) ( $result['viewUrl'] ?? '' ),
				'pdfUrl'  => (string) ( $result['pdfUrl'] ?? '' ),
			),
			false
		);
	}

	/**
	 * A document's stored Wave links.
	 *
	 * @param string $entity 'estimate' or 'invoice'.
	 * @param int    $id     Document id.
	 * @return array{viewUrl:string,pdfUrl:string}
	 */
	private function stored_links( $entity, $id ) {
		$stored = get_option( $this->links_option( $entity, $id ), array() );
		return array(
			'viewUrl' => (string) ( $stored['viewUrl'] ?? '' ),
			'pdfUrl'  => (string) ( $stored['pdfUrl'] ?? '' ),
		);
	}

	/* --------------------------------------------------------------------- */
	/* Helpers                                                               */
	/* --------------------------------------------------------------------- */

	/**
	 * Build the memo pushed to Wave for a document: a vehicle header (VIN, the
	 * year/make/model/trim + colour, and the job's mileage) followed by the
	 * document's own notes. The header rides on the Wave estimate/invoice so the
	 * customer sees which vehicle it is for.
	 *
	 * Lines are emitted only for data that exists — no empty labels or placeholder
	 * lines (per Nick's spec). The layout, when everything is present:
	 *
	 *     1HGCM82633A004352
	 *     2019 Honda Accord EX-L (Silver)
	 *     Mileage: 87,432
	 *
	 *     <the estimate/invoice notes>
	 *
	 * The vehicle + mileage come from the document's parent job (the owner of both;
	 * customer/vehicle are inherited from it — core §4), falling back to the
	 * document's own vehicle_id if the job has none.
	 *
	 * @param array<string,mixed> $document Estimate or invoice row (has job_id, vehicle_id, notes).
	 * @return string
	 */
	private function build_memo( array $document ) {
		$notes = trim( (string) ( $document['notes'] ?? '' ) );

		$job     = ! empty( $document['job_id'] ) ? AMAT_Job_Model::find( (int) $document['job_id'] ) : null;
		$veh_id  = (int) ( $job['vehicle_id'] ?? 0 );
		$veh_id  = $veh_id > 0 ? $veh_id : (int) ( $document['vehicle_id'] ?? 0 );
		$vehicle = $veh_id > 0 ? AMAT_Vehicle_Model::find( $veh_id ) : null;

		$lines = array();

		if ( $vehicle ) {
			$vin = trim( (string) ( $vehicle['vin'] ?? '' ) );
			if ( '' !== $vin ) {
				$lines[] = $vin;
			}

			// "Year Make Model Trim", skipping any missing token; colour in parens.
			$desc = trim(
				implode(
					' ',
					array_filter(
						array(
							trim( (string) ( $vehicle['year'] ?? '' ) ),
							trim( (string) ( $vehicle['make'] ?? '' ) ),
							trim( (string) ( $vehicle['model'] ?? '' ) ),
							trim( (string) ( $vehicle['trim'] ?? '' ) ),
						)
					)
				)
			);
			if ( '' !== $desc ) {
				$color = trim( (string) ( $vehicle['color'] ?? '' ) );
				$lines[] = '' !== $color ? $desc . ' (' . $color . ')' : $desc;
			}
		}

		// Mileage lives on the job. Show only a real reading.
		$mileage = ( $job && null !== $job['mileage'] && '' !== (string) $job['mileage'] ) ? (int) $job['mileage'] : 0;
		if ( $mileage > 0 ) {
			/* translators: %s: formatted odometer reading. */
			$lines[] = sprintf( __( 'Mileage: %s', 'auto-mation' ), number_format( $mileage ) );
		}

		$header = implode( "\n", $lines );

		if ( '' === $header ) {
			return $notes;
		}
		if ( '' === $notes ) {
			return $header;
		}
		return $header . "\n\n" . $notes;
	}

	/**
	 * URL of an estimate's detail view.
	 *
	 * @param int $id Estimate id.
	 * @return string
	 */
	private function estimate_url( $id ) {
		return add_query_arg(
			array( 'page' => AMAT_Estimates_Page::PAGE_SLUG, 'action' => 'view', 'id' => (int) $id ),
			admin_url( 'admin.php' )
		);
	}

	/**
	 * URL of an invoice's detail view.
	 *
	 * @param int $id Invoice id.
	 * @return string
	 */
	private function invoice_url( $id ) {
		return add_query_arg(
			array( 'page' => AMAT_Invoices_Page::PAGE_SLUG, 'action' => 'view', 'id' => (int) $id ),
			admin_url( 'admin.php' )
		);
	}

	/**
	 * Flash a one-shot notice onto a document page (core's PRG flash format).
	 *
	 * @param array<string,string> $payload {status, message}.
	 * @param string               $slug    Page slug; defaults to the estimates page.
	 * @return void
	 */
	private function flash( array $payload, $slug = null ) {
		if ( null === $slug ) {
			$slug = AMAT_Estimates_Page::PAGE_SLUG;
		}
		set_transient(
			'amat_flash_' . $slug . '_' . get_current_user_id(),
			$payload,
			MINUTE_IN_SECONDS
		);
	}
}
