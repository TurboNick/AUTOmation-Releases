<?php
/**
 * Wave (waveapps) GraphQL client. ALL Wave API calls live here.
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Thin, defensive wrapper around Wave's public GraphQL API.
 *
 * Per §6 of CLAUDE.md every Wave call is isolated in this one file so a
 * schema change only touches here. The client never fatals the site on a Wave
 * failure: requests return a WP_Error and callers decide how to degrade.
 * Auth uses a Full Access Token read from .env (never hardcoded/committed).
 */
class AMAT_Wave_Client {

	/**
	 * Wave public GraphQL endpoint.
	 *
	 * @var string
	 */
	const ENDPOINT = 'https://gql.waveapps.com/graphql/public';

	/**
	 * Transient key caching the auto-picked business ID (fallback only).
	 *
	 * @var string
	 */
	const BUSINESS_ID_TRANSIENT = 'amat_wave_business_id';

	/**
	 * Option key storing the business ID the owner explicitly chose in Settings.
	 *
	 * When set, this overrides the auto-pick so a multi-business Wave account
	 * syncs to the intended business rather than whichever one Wave lists first.
	 *
	 * @var string
	 */
	const BUSINESS_ID_OPTION = 'amat_wave_business_id';

	/**
	 * Transient key caching the list of businesses on the token's account.
	 *
	 * @var string
	 */
	const BUSINESSES_TRANSIENT = 'amat_wave_businesses';

	/**
	 * Transient key caching the target business's Wave customers (for match-on-sync).
	 *
	 * Stores { business_id, rows } so a business switch invalidates it. Short TTL
	 * because customers change; refreshed on demand and on clear_business_cache().
	 *
	 * @var string
	 */
	const CUSTOMERS_TRANSIENT = 'amat_wave_customers';

	/**
	 * Transient key caching the target business's products (for the parent-product
	 * pickers and line-item product resolution).
	 *
	 * Stores { business_id, rows } so a business switch invalidates it: product IDs
	 * are business-scoped, so the cache (and any chosen parent product) must not
	 * leak across businesses.
	 *
	 * @var string
	 */
	const PRODUCTS_TRANSIENT = 'amat_wave_products';

	/**
	 * Option key storing the Wave "parent" product that SERVICE estimate/invoice
	 * lines reference (chosen in Settings). AUTOmation does not create per-service
	 * products; every service line books to this one product with the service name
	 * as the line description. Empty means not configured.
	 *
	 * @var string
	 */
	const SERVICE_PRODUCT_OPTION = 'amat_wave_service_product_id';

	/**
	 * Option key storing the Wave "parent" product that PART estimate/invoice lines
	 * reference (chosen in Settings). Counterpart to SERVICE_PRODUCT_OPTION; part
	 * lines book to this one product with the part name as the line description.
	 *
	 * @var string
	 */
	const PARTS_PRODUCT_OPTION = 'amat_wave_parts_product_id';

	/**
	 * Option key storing how many days out a new estimate's "valid until" date is
	 * set (chosen in Settings). Empty/unset falls back to the default below.
	 *
	 * @var string
	 */
	const ESTIMATE_EXPIRY_DAYS_OPTION = 'amat_wave_estimate_expiry_days';

	/**
	 * Default estimate validity window in days when none is configured.
	 *
	 * @var int
	 */
	const DEFAULT_ESTIMATE_EXPIRY_DAYS = 30;

	/**
	 * Option key storing how Wave pushes fire: 'manual' (only when a Sync/Push
	 * button is clicked) or 'auto' (also automatically when a record is saved).
	 * Manual is the default. See AMAT_Wave_Sync.
	 *
	 * @var string
	 */
	const SYNC_MODE_OPTION = 'amat_wave_sync_mode';

	/**
	 * Sync mode: only push when a button is clicked (the default).
	 *
	 * @var string
	 */
	const SYNC_MODE_MANUAL = 'manual';

	/**
	 * Sync mode: also push automatically when a record is created/updated, and
	 * retry failed pushes on a schedule.
	 *
	 * @var string
	 */
	const SYNC_MODE_AUTO = 'auto';

	/**
	 * Full Access Token, loaded from .env.
	 *
	 * @var string
	 */
	private $token;

	/**
	 * Construct, pulling the token from the environment.
	 */
	public function __construct() {
		$this->token = AMAT_Env::get( 'WAVE_API_TOKEN' );
	}

	/**
	 * Whether a token is present. Callers should check before using the client.
	 *
	 * @return bool
	 */
	public function is_configured() {
		return '' !== $this->token;
	}

	/**
	 * Provider slug used for this integration's external_refs rows.
	 *
	 * @var string
	 */
	const PROVIDER = 'wave';

	/**
	 * Legacy `jobs` columns that still store Wave IDs directly (the job→Wave
	 * estimate path, retired later). The customer link moved to external_refs.
	 * The Unlink tool clears these in addition to the external_refs rows.
	 *
	 * @return array<string,string[]>
	 */
	public static function legacy_link_columns() {
		return array(
			'jobs' => array( 'wave_estimate_id', 'wave_invoice_id' ),
		);
	}

	/**
	 * The Wave customer ID linked to a local customer, or '' when unlinked.
	 *
	 * Reads the generic external_refs store (provider=wave, entity_type=customer)
	 * — core no longer keeps a wave_customer_id column. This + set_customer_ref()
	 * are the single storage point so the eventual companion-plugin move is clean.
	 *
	 * @param int $customer_id Local customer id.
	 * @return string
	 */
	public static function customer_ref( $customer_id ) {
		return AMAT_External_Ref_Model::external_id( self::PROVIDER, 'customer', $customer_id );
	}

	/**
	 * Link (or update the link from) a local customer to a Wave customer ID.
	 *
	 * @param int    $customer_id Local customer id.
	 * @param string $wave_id     Wave customer ID.
	 * @return int|false external_refs row id, or false.
	 */
	public static function set_customer_ref( $customer_id, $wave_id ) {
		// Mark 'synced' as well as stamping the time: a customer ref that had been
		// left 'failed' (by an auto-sync/retry failure) must flip back to synced
		// once the push succeeds, or the retry sweep would keep re-syncing it.
		return AMAT_External_Ref_Model::set(
			self::PROVIDER,
			'customer',
			$customer_id,
			$wave_id,
			array( 'status' => 'synced', 'synced_at' => current_time( 'mysql' ) )
		);
	}

	/**
	 * Count of customers linked to Wave.
	 *
	 * @return int
	 */
	public static function linked_customer_count() {
		return AMAT_External_Ref_Model::count_for( self::PROVIDER, 'customer' );
	}

	/**
	 * Every Wave customer ID already claimed by some *other* local customer.
	 *
	 * Feeds match_customer()'s exclusion list. A Wave customer that another local
	 * record is already linked to is not a candidate for this one — adopting it
	 * would point two local customers at a single Wave customer, silently merging
	 * two people's invoices. That is easy to trip in a bulk run: creating a
	 * customer in Wave puts it in the (15-minute) customer cache, so a later
	 * same-named local customer would match the record we just made for someone
	 * else.
	 *
	 * @param int $exclude_customer_id Local customer whose own link doesn't count.
	 * @return string[] Wave customer IDs.
	 */
	public static function claimed_customer_refs( $exclude_customer_id = 0 ) {
		$exclude = (int) $exclude_customer_id;
		$claimed = array();

		foreach ( AMAT_External_Ref_Model::all_for( self::PROVIDER, 'customer' ) as $ref ) {
			if ( (int) ( $ref['entity_id'] ?? 0 ) === $exclude ) {
				continue;
			}
			$id = trim( (string) ( $ref['external_id'] ?? '' ) );
			if ( '' !== $id ) {
				$claimed[] = $id;
			}
		}

		return array_values( array_unique( $claimed ) );
	}

	/**
	 * Whether a WP_Error from query() is Wave telling us to slow down.
	 *
	 * Checks the HTTP status **and** the message, because Wave uses both. Observed
	 * live on 2026-08-17, during a 108-customer mass-link: Wave answered
	 * **HTTP 200 with a GraphQL error** reading "Too many requests, please try
	 * again shortly." — not the 429 the documentation's silence let us assume.
	 * A status-only check therefore missed it entirely and recorded a rate limit
	 * as a permanent failure. Keep both tests: 429 is still the documented-ish
	 * behaviour and may be what a different endpoint returns.
	 *
	 * @param mixed $error Possible WP_Error.
	 * @return bool
	 */
	public static function is_rate_limited( $error ) {
		if ( 429 === self::http_status( $error ) ) {
			return true;
		}
		if ( ! is_wp_error( $error ) ) {
			return false;
		}

		$message = strtolower( $error->get_error_message() );
		foreach ( array( 'too many requests', 'rate limit', 'rate-limit', 'throttl' ) as $needle ) {
			if ( false !== strpos( $message, $needle ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * The HTTP status behind a query() WP_Error, or 0 when it wasn't an HTTP error
	 * (transport failure, GraphQL error, missing token).
	 *
	 * @param mixed $error Possible WP_Error.
	 * @return int
	 */
	public static function http_status( $error ) {
		if ( ! is_wp_error( $error ) ) {
			return 0;
		}
		$data = $error->get_error_data();
		return is_array( $data ) ? (int) ( $data['status'] ?? 0 ) : 0;
	}

	/**
	 * Seconds Wave asked us to wait, when it said so. 0 when it didn't.
	 *
	 * @param mixed $error Possible WP_Error.
	 * @return int
	 */
	public static function retry_after( $error ) {
		if ( ! is_wp_error( $error ) ) {
			return 0;
		}
		$data = $error->get_error_data();
		return is_array( $data ) ? max( 0, (int) ( $data['retry_after'] ?? 0 ) ) : 0;
	}

	/**
	 * The configured estimate validity window in days (clamped to 1–365), or the
	 * default when unset. The single read point for the Settings option.
	 *
	 * @return int
	 */
	public static function estimate_expiry_days() {
		$days = (int) get_option( self::ESTIMATE_EXPIRY_DAYS_OPTION, 0 );
		if ( $days < 1 ) {
			return self::DEFAULT_ESTIMATE_EXPIRY_DAYS;
		}
		return min( $days, 365 );
	}

	/**
	 * The configured sync mode ('manual' or 'auto'), defaulting to manual. The
	 * single read point for the Settings option; any unrecognized value reads as
	 * manual (the safe default — nothing pushes without a click).
	 *
	 * @return string
	 */
	public static function sync_mode() {
		$mode = (string) get_option( self::SYNC_MODE_OPTION, self::SYNC_MODE_MANUAL );
		return self::SYNC_MODE_AUTO === $mode ? self::SYNC_MODE_AUTO : self::SYNC_MODE_MANUAL;
	}

	/**
	 * Whether pushes fire automatically on save (and failed pushes are retried).
	 *
	 * @return bool
	 */
	public static function is_auto_sync() {
		return self::SYNC_MODE_AUTO === self::sync_mode();
	}

	/**
	 * Execute a GraphQL query/mutation against Wave.
	 *
	 * @param string              $query     GraphQL document.
	 * @param array<string,mixed> $variables Query variables.
	 * @return array<string,mixed>|WP_Error Decoded `data`, or WP_Error on failure.
	 */
	public function query( $query, array $variables = array() ) {
		if ( ! $this->is_configured() ) {
			return new WP_Error( 'amat_wave_no_token', __( 'Wave API token is not configured.', 'auto-mation' ) );
		}

		$response = wp_remote_post(
			self::ENDPOINT,
			array(
				'timeout' => 20,
				'headers' => array(
					'Authorization' => 'Bearer ' . $this->token,
					'Content-Type'  => 'application/json',
					'Accept'        => 'application/json',
				),
				'body'    => wp_json_encode(
					array(
						'query'     => $query,
						'variables' => (object) $variables,
					)
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			$this->log( 'HTTP transport error: ' . $response->get_error_message() );
			return $response;
		}

		$code = wp_remote_retrieve_response_code( $response );
		$raw  = wp_remote_retrieve_body( $response );
		$body = json_decode( $raw, true );

		// GraphQL transports errors in a top-level `errors` array — including on a
		// 400, where it carries the actual schema/validation problem. Surface that
		// message (not just the bare status) so a schema mismatch is diagnosable.
		if ( is_array( $body ) && ! empty( $body['errors'] ) ) {
			$message = isset( $body['errors'][0]['message'] ) ? $body['errors'][0]['message'] : 'Unknown GraphQL error';
			$this->log( 'GraphQL error (HTTP ' . $code . '): ' . $message );
			return new WP_Error( 'amat_wave_graphql', $message, $body['errors'] );
		}

		if ( 200 !== (int) $code ) {
			// No structured errors to surface — include a trimmed body snippet so a
			// non-GraphQL failure (gateway, auth, HTML error page) is still legible.
			$snippet = trim( wp_strip_all_tags( (string) $raw ) );
			if ( strlen( $snippet ) > 300 ) {
				$snippet = substr( $snippet, 0, 300 ) . '…';
			}
			$this->log( 'Non-200 from Wave: HTTP ' . $code . ' — ' . $snippet );
			return new WP_Error(
				'amat_wave_http',
				'' !== $snippet
					/* translators: 1: HTTP status code, 2: response body snippet. */
					? sprintf( __( 'Wave returned HTTP %1$d: %2$s', 'auto-mation' ), (int) $code, $snippet )
					/* translators: %d: HTTP status code. */
					: sprintf( __( 'Wave returned HTTP %d.', 'auto-mation' ), (int) $code ),
				// The status is carried as DATA, not just baked into the message, so a
				// caller can act on it — the mass-link backs off on a 429 rather than
				// burning through its work list against a rate limit. Wave documents no
				// Retry-After header, but honour one if it ever sends it.
				array(
					'status'      => (int) $code,
					'retry_after' => (int) wp_remote_retrieve_header( $response, 'retry-after' ),
				)
			);
		}

		if ( ! is_array( $body ) ) {
			$this->log( 'Unparseable Wave response body.' );
			return new WP_Error( 'amat_wave_bad_body', __( 'Could not parse the Wave response.', 'auto-mation' ) );
		}

		return isset( $body['data'] ) && is_array( $body['data'] ) ? $body['data'] : array();
	}

	/**
	 * Resolve the business ID most queries need to be scoped to.
	 *
	 * Prefers the business explicitly chosen in Settings (BUSINESS_ID_OPTION);
	 * otherwise falls back to auto-picking the first business on the account and
	 * caches that for an hour. The explicit choice is what makes a multi-business
	 * account sync to the right place.
	 *
	 * @param bool $force Bypass the auto-pick cache and re-fetch.
	 * @return string|WP_Error Business ID, or WP_Error.
	 */
	public function get_business_id( $force = false ) {
		// An explicit choice always wins and needs no API call.
		$chosen = trim( (string) get_option( self::BUSINESS_ID_OPTION, '' ) );
		if ( '' !== $chosen ) {
			return $chosen;
		}

		if ( ! $force ) {
			$cached = get_transient( self::BUSINESS_ID_TRANSIENT );
			if ( is_string( $cached ) && '' !== $cached ) {
				return $cached;
			}
		}

		$data = $this->query( 'query { businesses(page: 1, pageSize: 1) { edges { node { id name } } } }' );
		if ( is_wp_error( $data ) ) {
			return $data;
		}

		$id = $data['businesses']['edges'][0]['node']['id'] ?? '';
		if ( '' === $id ) {
			return new WP_Error( 'amat_wave_no_business', __( 'No Wave business found for this token.', 'auto-mation' ) );
		}

		// Cache for an hour; the business ID is stable.
		set_transient( self::BUSINESS_ID_TRANSIENT, $id, HOUR_IN_SECONDS );
		return $id;
	}

	/**
	 * List the businesses on the token's account, as [ id, name ] rows.
	 *
	 * Cached for an hour; pass $force (or call clear_business_cache()) to refetch.
	 * Drives the Settings business picker so the owner can choose the sync target.
	 *
	 * @param bool $force Bypass the cache and re-fetch.
	 * @return array<int,array{id:string,name:string}>|WP_Error
	 */
	public function get_businesses( $force = false ) {
		if ( ! $force ) {
			$cached = get_transient( self::BUSINESSES_TRANSIENT );
			if ( is_array( $cached ) ) {
				return $cached;
			}
		}

		$data = $this->query( 'query { businesses(page: 1, pageSize: 50) { edges { node { id name } } } }' );
		if ( is_wp_error( $data ) ) {
			return $data;
		}

		$out = array();
		foreach ( $data['businesses']['edges'] ?? array() as $edge ) {
			$node = $edge['node'] ?? array();
			$id   = (string) ( $node['id'] ?? '' );
			if ( '' !== $id ) {
				$out[] = array( 'id' => $id, 'name' => (string) ( $node['name'] ?? $id ) );
			}
		}

		set_transient( self::BUSINESSES_TRANSIENT, $out, HOUR_IN_SECONDS );
		return $out;
	}

	/**
	 * Resolve a business ID to its display name (via the cached list), or '' .
	 *
	 * @param string $id Business ID.
	 * @return string
	 */
	public function get_business_name( $id ) {
		$id = trim( (string) $id );
		if ( '' === $id ) {
			return '';
		}
		$list = $this->get_businesses();
		if ( is_wp_error( $list ) ) {
			return '';
		}
		foreach ( $list as $business ) {
			if ( $business['id'] === $id ) {
				return $business['name'];
			}
		}
		return '';
	}

	/**
	 * Drop the cached business ID + businesses list + customer index so the next
	 * call refetches. Called when the target business changes.
	 *
	 * @return void
	 */
	public function clear_business_cache() {
		delete_transient( self::BUSINESS_ID_TRANSIENT );
		delete_transient( self::BUSINESSES_TRANSIENT );
		delete_transient( self::CUSTOMERS_TRANSIENT );
		delete_transient( self::PRODUCTS_TRANSIENT );
	}

	/* --------------------------------------------------------------------- */
	/* Parent products (estimate/invoice lines reference one, by category)    */
	/* --------------------------------------------------------------------- */

	/**
	 * The Wave parent product SERVICE lines reference, or '' when unset/stranded.
	 *
	 * AUTOmation does not create per-service products; every service line books to
	 * this one product (chosen in Settings) with the service name as the line
	 * description. Validated against the current business's products so a business
	 * switch self-heals (a stranded choice reads as unset); the stored ID is trusted
	 * if the product list can't be loaded, leaving Wave to reject a bad ID.
	 *
	 * @return string Wave product ID, or '' when not configured for this business.
	 */
	public function get_service_product_id() {
		return $this->resolve_parent_product( self::SERVICE_PRODUCT_OPTION );
	}

	/**
	 * The Wave parent product PART lines reference, or '' when unset/stranded.
	 * Counterpart to get_service_product_id() for parts.
	 *
	 * @return string Wave product ID, or '' when not configured for this business.
	 */
	public function get_parts_product_id() {
		return $this->resolve_parent_product( self::PARTS_PRODUCT_OPTION );
	}

	/**
	 * Resolve a stored parent-product option to a usable product ID.
	 *
	 * @param string $option Option key (SERVICE_PRODUCT_OPTION / PARTS_PRODUCT_OPTION).
	 * @return string Product ID, or '' when unset or stranded across a business switch.
	 */
	private function resolve_parent_product( $option ) {
		$chosen = trim( (string) get_option( $option, '' ) );
		if ( '' === $chosen ) {
			return '';
		}

		$products = $this->get_products();
		if ( is_wp_error( $products ) ) {
			// Can't validate right now — trust the stored ID; Wave validates on use.
			return $chosen;
		}
		foreach ( $products as $product ) {
			if ( $product['id'] === $chosen ) {
				return $chosen;
			}
		}
		return ''; // Stranded (e.g. after a business switch) — treat as unset.
	}

	/**
	 * Resolve a product ID to its display name (via the cached list), or ''.
	 *
	 * @param string $id Wave product ID.
	 * @return string
	 */
	public function get_product_name( $id ) {
		$id = trim( (string) $id );
		if ( '' === $id ) {
			return '';
		}
		$products = $this->get_products();
		if ( is_wp_error( $products ) ) {
			return '';
		}
		foreach ( $products as $product ) {
			if ( $product['id'] === $id ) {
				return $product['name'];
			}
		}
		return '';
	}

	/* --------------------------------------------------------------------- */
	/* Match-and-adopt: link to an existing Wave customer, never duplicate    */
	/* --------------------------------------------------------------------- */

	/**
	 * Fetch the target business's customers (id + name + email + phones), paged
	 * and cached, for match-on-sync. Nick has years of Wave history, so the sync
	 * must adopt an existing record rather than create a duplicate (Wave does not
	 * dedupe). The cache is keyed to the business so switching invalidates it.
	 *
	 * @param bool $force Bypass the cache and re-fetch.
	 * @return array<int,array{id:string,name:string,first:string,last:string,email:string,phones:string[]}>|WP_Error
	 */
	public function get_customers( $force = false ) {
		$business_id = $this->get_business_id();
		if ( is_wp_error( $business_id ) ) {
			return $business_id;
		}

		if ( ! $force ) {
			$cached = get_transient( self::CUSTOMERS_TRANSIENT );
			if ( is_array( $cached ) && isset( $cached['rows'] ) && ( $cached['business_id'] ?? '' ) === $business_id ) {
				return $cached['rows'];
			}
		}

		$query = 'query GetCustomers($id: ID!, $page: Int!, $pageSize: Int!) {
			business(id: $id) {
				customers(page: $page, pageSize: $pageSize) {
					pageInfo { currentPage totalPages }
					edges { node { id name firstName lastName email phone mobile } }
				}
			}
		}';

		$rows  = array();
		$page  = 1;
		$pages = 1;
		$guard = 0;
		do {
			$data = $this->query( $query, array( 'id' => $business_id, 'page' => $page, 'pageSize' => 100 ) );
			if ( is_wp_error( $data ) ) {
				return $data;
			}
			$conn = $data['business']['customers'] ?? null;
			if ( ! is_array( $conn ) ) {
				break;
			}
			foreach ( $conn['edges'] ?? array() as $edge ) {
				$node = $edge['node'] ?? array();
				if ( empty( $node['id'] ) ) {
					continue;
				}
				$rows[] = array(
					'id'     => (string) $node['id'],
					'name'   => (string) ( $node['name'] ?? '' ),
					'first'  => (string) ( $node['firstName'] ?? '' ),
					'last'   => (string) ( $node['lastName'] ?? '' ),
					'email'  => self::normalize_email( (string) ( $node['email'] ?? '' ) ),
					'phones' => array_values(
						array_filter(
							array(
								self::normalize_phone( (string) ( $node['phone'] ?? '' ) ),
								self::normalize_phone( (string) ( $node['mobile'] ?? '' ) ),
							)
						)
					),
				);
			}
			$pages = (int) ( $conn['pageInfo']['totalPages'] ?? 1 );
			++$page;
			++$guard;
		} while ( $page <= $pages && $guard < 100 );

		set_transient( self::CUSTOMERS_TRANSIENT, array( 'business_id' => $business_id, 'rows' => $rows ), 15 * MINUTE_IN_SECONDS );
		return $rows;
	}

	/**
	 * Find existing Wave customers matching a local customer, to adopt-not-create.
	 *
	 * Counts how many fields (email, phone, exact name) each Wave customer matches.
	 * Auto-adopt is only confident enough on a STRONG match — 2 or more fields —
	 * and only when exactly one such candidate exists; otherwise the owner decides.
	 * Returns a verdict:
	 *   - status 'none'      → nothing matched any field; safe to create.
	 *   - status 'unique'    → exactly one 2+-field match; adopt + patch it.
	 *   - status 'ambiguous' → otherwise (several strong, or only partial 1-field
	 *                          matches) → show the picker (candidates + create-new).
	 *
	 * @param array<string,mixed> $payload     Local payload from the customer wave_payload().
	 * @param string[]            $exclude_ids Wave customer IDs to ignore entirely —
	 *                                         normally the ones other local customers
	 *                                         are already linked to (see
	 *                                         claimed_customer_refs()). Excluding them
	 *                                         before the verdict is what lets a run of
	 *                                         same-named customers stay separate.
	 * @return array{status:string,match:?string,reason:string,candidates:array<int,array{id:string,name:string,email:string,phone:string,reason:string,count:int}>}|WP_Error
	 */
	public function match_customer( array $payload, array $exclude_ids = array() ) {
		$customers = $this->get_customers();
		if ( is_wp_error( $customers ) ) {
			return $customers;
		}

		$email  = self::normalize_email( (string) ( $payload['email'] ?? '' ) );
		$phones = array_values(
			array_filter(
				array(
					self::normalize_phone( (string) ( $payload['phone'] ?? '' ) ),
					self::normalize_phone( (string) ( $payload['mobile'] ?? '' ) ),
				)
			)
		);
		$names = array_values(
			array_filter(
				array_map(
					static function ( $n ) {
						return strtolower( trim( (string) $n ) );
					},
					array(
						$payload['name'] ?? '',
						trim( (string) ( $payload['firstName'] ?? '' ) . ' ' . (string) ( $payload['lastName'] ?? '' ) ),
					)
				)
			)
		);

		// Every Wave customer that matches at least one field, with the count.
		$candidates = array();
		foreach ( $customers as $c ) {
			$fields = array();
			if ( '' !== $email && $c['email'] === $email ) {
				$fields[] = 'email';
			}
			if ( ! empty( $phones ) && array_intersect( $phones, $c['phones'] ) ) {
				$fields[] = 'phone';
			}
			$c_names = array( strtolower( trim( $c['name'] ) ), strtolower( trim( $c['first'] . ' ' . $c['last'] ) ) );
			if ( array_intersect( $names, array_filter( $c_names ) ) ) {
				$fields[] = 'name';
			}

			if ( ! empty( $fields ) ) {
				$row = $this->candidate_row( $c, implode( ',', $fields ) );
				// A Wave customer another local record already owns is not a candidate
				// for this one — see claimed_customer_refs() for why this matters most
				// in a bulk run.
				if ( in_array( $row['id'], $exclude_ids, true ) ) {
					continue;
				}
				$row['count'] = count( $fields );
				$candidates[] = $row;
			}
		}

		if ( empty( $candidates ) ) {
			return array( 'status' => 'none', 'match' => null, 'reason' => '', 'candidates' => array() );
		}

		// Best matches first.
		usort(
			$candidates,
			static function ( $a, $b ) {
				return $b['count'] <=> $a['count'];
			}
		);

		// Strong = 2+ fields. Auto-adopt only when exactly one strong candidate.
		$strong = array_values(
			array_filter(
				$candidates,
				static function ( $c ) {
					return $c['count'] >= 2;
				}
			)
		);
		if ( 1 === count( $strong ) ) {
			return array( 'status' => 'unique', 'match' => $strong[0]['id'], 'reason' => $strong[0]['reason'], 'candidates' => array( $strong[0] ) );
		}

		// Otherwise the owner decides: show the strong ones if there are several,
		// else the partial (single-field) matches.
		$show = ! empty( $strong ) ? $strong : $candidates;
		return array( 'status' => 'ambiguous', 'match' => null, 'reason' => '', 'candidates' => $show );
	}

	/**
	 * Shape one candidate row for display/selection in the adopt UI.
	 *
	 * @param array<string,mixed> $c      Cached Wave customer row.
	 * @param string              $reason Comma-joined matched field keys (e.g. "email,phone").
	 * @return array{id:string,name:string,email:string,phone:string,reason:string}
	 */
	private function candidate_row( array $c, $reason ) {
		return array(
			'id'     => (string) $c['id'],
			'name'   => '' !== trim( (string) $c['name'] ) ? (string) $c['name'] : trim( (string) $c['first'] . ' ' . (string) $c['last'] ),
			'email'  => (string) $c['email'],
			'phone'  => ! empty( $c['phones'] ) ? (string) $c['phones'][0] : '',
			'reason' => $reason,
		);
	}

	/**
	 * Normalize a phone to comparable digits (last 10), or '' when too short.
	 *
	 * @param string $value Raw phone.
	 * @return string
	 */
	private static function normalize_phone( $value ) {
		$digits = preg_replace( '/\D+/', '', (string) $value );
		if ( strlen( $digits ) > 10 ) {
			$digits = substr( $digits, -10 );
		}
		return strlen( $digits ) >= 10 ? $digits : '';
	}

	/**
	 * Normalize an email for comparison (trimmed, lowercased), or '' if invalid.
	 *
	 * @param string $value Raw email.
	 * @return string
	 */
	private static function normalize_email( $value ) {
		$value = strtolower( trim( (string) $value ) );
		return ( '' !== $value && false !== strpos( $value, '@' ) ) ? $value : '';
	}

	/**
	 * Create a customer in Wave and return its Wave ID.
	 *
	 * Mirrors a local customers row to Wave; store the returned ID on
	 * customers.wave_customer_id (§6). The Wave customer name is the local
	 * display_name. AUTOmation is the source of truth, so this only ever pushes
	 * to Wave — it never reads customer data back.
	 *
	 * @param array<string,mixed> $customer Local customer fields (see customer_input()).
	 * @return string|WP_Error Wave customer ID, or WP_Error.
	 */
	public function create_customer( array $customer ) {
		$business_id = $this->get_business_id();
		if ( is_wp_error( $business_id ) ) {
			return $business_id;
		}

		$mutation = 'mutation CreateCustomer($input: CustomerCreateInput!) {
			customerCreate(input: $input) {
				didSucceed
				inputErrors { message path }
				customer { id name }
			}
		}';

		$input               = $this->customer_input( $customer );
		$input['businessId'] = $business_id;

		$data = $this->query( $mutation, array( 'input' => $input ) );
		if ( is_wp_error( $data ) ) {
			return $data;
		}

		$result = $data['customerCreate'] ?? array();
		if ( empty( $result['didSucceed'] ) ) {
			$message = $result['inputErrors'][0]['message'] ?? __( 'Wave rejected the customer.', 'auto-mation' );
			return new WP_Error( 'amat_wave_customer_create', $message );
		}

		return $result['customer']['id'] ?? '';
	}

	/**
	 * Update (patch) an existing Wave customer from local fields.
	 *
	 * Used when our customers.wave_customer_id is already set: AUTOmation is the
	 * source of truth, so a re-sync pushes the current local values onto the
	 * existing Wave record rather than creating a duplicate.
	 *
	 * @param string              $wave_id  Wave customer ID to patch.
	 * @param array<string,mixed> $customer Local customer fields (see customer_input()).
	 * @return string|WP_Error Wave customer ID, or WP_Error.
	 */
	public function update_customer( $wave_id, array $customer ) {
		$wave_id = trim( (string) $wave_id );
		if ( '' === $wave_id ) {
			return new WP_Error( 'amat_wave_customer_patch', __( 'Missing Wave customer ID.', 'auto-mation' ) );
		}

		$mutation = 'mutation PatchCustomer($input: CustomerPatchInput!) {
			customerPatch(input: $input) {
				didSucceed
				inputErrors { message path }
				customer { id name }
			}
		}';

		$input       = $this->customer_input( $customer );
		$input['id'] = $wave_id;

		$data = $this->query( $mutation, array( 'input' => $input ) );
		if ( is_wp_error( $data ) ) {
			return $data;
		}

		$result = $data['customerPatch'] ?? array();
		if ( empty( $result['didSucceed'] ) ) {
			$message = $result['inputErrors'][0]['message'] ?? __( 'Wave rejected the customer update.', 'auto-mation' );
			return new WP_Error( 'amat_wave_customer_patch', $message );
		}

		return $result['customer']['id'] ?? $wave_id;
	}

	/* --------------------------------------------------------------------- */
	/* Products + estimates                                                   */
	/* --------------------------------------------------------------------- */

	/**
	 * Fetch the target business's products (id + name), paged and cached, for
	 * match-on-create. Nick already uses generic Wave products ("Labor", "Parts"),
	 * so a service should adopt a same-named product rather than duplicating it and
	 * splitting his history. Cache keyed to the business so a switch invalidates it.
	 *
	 * @param bool $force Bypass the cache and re-fetch.
	 * @return array<int,array{id:string,name:string}>|WP_Error
	 */
	public function get_products( $force = false ) {
		$business_id = $this->get_business_id();
		if ( is_wp_error( $business_id ) ) {
			return $business_id;
		}

		if ( ! $force ) {
			$cached = get_transient( self::PRODUCTS_TRANSIENT );
			if ( is_array( $cached ) && isset( $cached['rows'] ) && ( $cached['business_id'] ?? '' ) === $business_id ) {
				return $cached['rows'];
			}
		}

		$query = 'query GetProducts($id: ID!, $page: Int!, $pageSize: Int!) {
			business(id: $id) {
				products(page: $page, pageSize: $pageSize) {
					pageInfo { currentPage totalPages }
					edges { node { id name } }
				}
			}
		}';

		$rows  = array();
		$page  = 1;
		$pages = 1;
		$guard = 0;
		do {
			$data = $this->query( $query, array( 'id' => $business_id, 'page' => $page, 'pageSize' => 100 ) );
			if ( is_wp_error( $data ) ) {
				return $data;
			}
			$conn = $data['business']['products'] ?? null;
			if ( ! is_array( $conn ) ) {
				break;
			}
			foreach ( $conn['edges'] ?? array() as $edge ) {
				$node = $edge['node'] ?? array();
				if ( empty( $node['id'] ) ) {
					continue;
				}
				$rows[] = array( 'id' => (string) $node['id'], 'name' => (string) ( $node['name'] ?? '' ) );
			}
			$pages = (int) ( $conn['pageInfo']['totalPages'] ?? 1 );
			++$page;
			++$guard;
		} while ( $page <= $pages && $guard < 100 );

		set_transient( self::PRODUCTS_TRANSIENT, array( 'business_id' => $business_id, 'rows' => $rows ), 15 * MINUTE_IN_SECONDS );
		return $rows;
	}

	/**
	 * Create an estimate in Wave from a customer + line items.
	 *
	 * Each item references an existing Wave parent product (chosen in Settings —
	 * see get_service_product_id()/get_parts_product_id()); the AUTOmation item's
	 * name rides along as the line description. The estimate is created in Wave's
	 * default DRAFT state (estimates have no "finalized" create status); the owner
	 * sends it from Wave. Returns the estimate ID to store.
	 *
	 * @param array{customerId:string,items:array<int,array{productId:string,description?:string,quantity?:float,unitPrice?:float}>,memo?:string} $estimate Estimate fields.
	 * @return array{id:string,number:string,viewUrl:string,pdfUrl:string}|WP_Error
	 */
	public function create_estimate( array $estimate ) {
		$business_id = $this->get_business_id();
		if ( is_wp_error( $business_id ) ) {
			return $business_id;
		}

		$customer_id = trim( (string) ( $estimate['customerId'] ?? '' ) );
		if ( '' === $customer_id ) {
			return new WP_Error( 'amat_wave_estimate_create', __( 'The customer must be synced to Wave first.', 'auto-mation' ) );
		}

		$items = self::estimate_items_input( $estimate['items'] ?? array() );
		if ( empty( $items ) ) {
			return new WP_Error( 'amat_wave_estimate_create', __( 'An estimate needs at least one service line.', 'auto-mation' ) );
		}

		// The selection was `id`-only while the URL/number fields were unverified (a
		// non-existent field in a selection 400s the whole query). Introspection has
		// since confirmed all four on AREstimate, so we read back what we need in the
		// same round trip: Wave assigns the number, and we surface it + its links on
		// the native record.
		$mutation = 'mutation CreateEstimate($input: EstimateCreateInput!) {
			estimateCreate(input: $input) {
				didSucceed
				inputErrors { message path }
				estimate { id estimateNumber status viewUrl pdfUrl estimateDate dueDate }
			}
		}';

		// Note: estimates are created in Wave's default DRAFT state — unlike invoices
		// there is no "finalized" create status (EstimateCreateStatus has no SAVED),
		// so the owner reviews/sends the estimate from Wave. Sending it could be a
		// follow-up estimateSend/approve mutation later if wanted.
		$input = array(
			'businessId' => $business_id,
			'customerId' => $customer_id,
			'items'      => $items,
		);

		// "Valid until" — EstimateCreateInput has no expiration field (verified via
		// introspection: its forward date is `dueDate`), so map the Settings-
		// configured validity window onto dueDate. Callers may override by passing an
		// explicit 'dueDate'. estimateDate is left unset so Wave dates it today.
		$due = trim( (string) ( $estimate['dueDate'] ?? '' ) );
		if ( '' === $due ) {
			$days = self::estimate_expiry_days();
			$due  = gmdate( 'Y-m-d', strtotime( '+' . $days . ' days', current_time( 'timestamp' ) ) );
		}
		$input['dueDate'] = $due;

		$memo = trim( (string) ( $estimate['memo'] ?? '' ) );
		if ( '' !== $memo ) {
			$input['memo'] = $memo;
		}

		$data = $this->query( $mutation, array( 'input' => $input ) );
		if ( is_wp_error( $data ) ) {
			return $data;
		}

		$result = $data['estimateCreate'] ?? array();
		if ( empty( $result['didSucceed'] ) ) {
			$message = $result['inputErrors'][0]['message'] ?? __( 'Wave rejected the estimate.', 'auto-mation' );
			return new WP_Error( 'amat_wave_estimate_create', $message );
		}

		$node = $result['estimate'] ?? array();
		$id   = (string) ( $node['id'] ?? '' );
		if ( '' === $id ) {
			return new WP_Error( 'amat_wave_estimate_create', __( 'Wave did not return an estimate ID.', 'auto-mation' ) );
		}

		return self::estimate_shape( $node );
	}

	/**
	 * Approve a draft estimate in Wave (its DRAFT → APPROVED step).
	 *
	 * Wave will not let an estimate be sent to a customer while it is a DRAFT, and
	 * it ignores the "valid until" date in that state — so a pushed estimate is
	 * stuck until someone clicks "Approve draft". AUTOmation does that click for
	 * Nick: he builds the draft in AUTOmation and has no interest in approving his
	 * own paperwork a second time in Wave.
	 *
	 * Note this is **Wave's** notion of approval (a pre-send gate), which is NOT
	 * core's `approved` status (the go-ahead to invoice, after sending). They share
	 * a word and mean different things — see AMAT_Wave_Documents::status_from_wave().
	 *
	 * Safe on an already-approved estimate is NOT assumed: callers should only
	 * approve what they just created as a draft.
	 *
	 * @param string $estimate_id Wave estimate ID.
	 * @return array{id:string,number:string,status:string,viewUrl:string,pdfUrl:string}|WP_Error
	 */
	public function approve_estimate( $estimate_id ) {
		$estimate_id = trim( (string) $estimate_id );
		if ( '' === $estimate_id ) {
			return new WP_Error( 'amat_wave_estimate_approve', __( 'No Wave estimate ID to approve.', 'auto-mation' ) );
		}

		$mutation = 'mutation ApproveEstimate($input: EstimateApproveInput!) {
			estimateApprove(input: $input) {
				didSucceed
				inputErrors { message path }
				estimate { id estimateNumber status viewUrl pdfUrl estimateDate dueDate }
			}
		}';

		// EstimateApproveInput's field is `estimateId`, not `id`.
		$data = $this->query( $mutation, array( 'input' => array( 'estimateId' => $estimate_id ) ) );
		if ( is_wp_error( $data ) ) {
			return $data;
		}

		$result = $data['estimateApprove'] ?? array();
		if ( empty( $result['didSucceed'] ) ) {
			$message = $result['inputErrors'][0]['message'] ?? __( 'Wave rejected the estimate approval.', 'auto-mation' );
			return new WP_Error( 'amat_wave_estimate_approve', $message );
		}

		return self::estimate_shape( $result['estimate'] ?? array() );
	}

	/**
	 * Read one estimate back from Wave.
	 *
	 * Used to reflect Wave's own number/status onto the native record (Wave is
	 * where the customer actually views and accepts it), and to read the current
	 * values before a patch — EstimatePatchInput is a full replace, so we cannot
	 * send a partial update without first knowing what is there.
	 *
	 * @param string $estimate_id Wave estimate ID.
	 * @return array{id:string,number:string,status:string,viewUrl:string,pdfUrl:string,customerId:string,title:string,estimateDate:string,dueDate:string,currency:string,exchangeRate:string}|WP_Error
	 */
	public function get_estimate( $estimate_id ) {
		$business_id = $this->get_business_id();
		if ( is_wp_error( $business_id ) ) {
			return $business_id;
		}

		$estimate_id = trim( (string) $estimate_id );
		if ( '' === $estimate_id ) {
			return new WP_Error( 'amat_wave_estimate_get', __( 'No Wave estimate ID to read.', 'auto-mation' ) );
		}

		// Selects everything estimatePatch needs to round-trip, not just what we
		// display: the patch is a full replace, so any field we fail to re-send is
		// blanked (this is how the estimate number got wiped the first time).
		$query = 'query GetEstimate($businessId: ID!, $id: ID!) {
			business(id: $businessId) {
				estimate(id: $id) {
					id
					estimateNumber
					poNumber
					status
					viewUrl
					pdfUrl
					title
					subhead
					memo
					footer
					estimateDate
					dueDate
					exchangeRate
					customer { id }
					currency { code }
				}
			}
		}';

		$data = $this->query( $query, array( 'businessId' => $business_id, 'id' => $estimate_id ) );
		if ( is_wp_error( $data ) ) {
			return $data;
		}

		$node = $data['business']['estimate'] ?? null;
		if ( ! is_array( $node ) || empty( $node['id'] ) ) {
			// A deleted estimate reads back as null — the caller decides whether
			// that is an error or simply a link to forget.
			return new WP_Error( 'amat_wave_estimate_missing', __( 'That estimate no longer exists in Wave.', 'auto-mation' ) );
		}

		return self::estimate_shape( $node );
	}

	/**
	 * Update an existing Wave estimate from a customer + line items.
	 *
	 * `estimatePatch` is a **full replace**, not a sparse patch: id, customerId,
	 * status, title, estimateDate, currency, exchangeRate and dueDate are all
	 * non-null on EstimatePatchInput (verified by introspection). So we read the
	 * estimate first and re-send its current values for everything we do not
	 * manage — otherwise a patch would blank them.
	 *
	 * @param array{id:string,customerId:string,items:array<int,array<string,mixed>>,memo?:string,dueDate?:string} $estimate Fields.
	 * @return array{id:string,number:string,status:string,viewUrl:string,pdfUrl:string}|WP_Error
	 */
	public function update_estimate( array $estimate ) {
		$estimate_id = trim( (string) ( $estimate['id'] ?? '' ) );
		if ( '' === $estimate_id ) {
			return new WP_Error( 'amat_wave_estimate_update', __( 'No Wave estimate ID to update.', 'auto-mation' ) );
		}

		// Read first: the patch input is a full replace (see above).
		$current = $this->get_estimate( $estimate_id );
		if ( is_wp_error( $current ) ) {
			return $current;
		}

		$items = self::estimate_items_input( $estimate['items'] ?? array() );
		if ( empty( $items ) ) {
			return new WP_Error( 'amat_wave_estimate_update', __( 'An estimate needs at least one line.', 'auto-mation' ) );
		}

		$mutation = 'mutation PatchEstimate($input: EstimatePatchInput!) {
			estimatePatch(input: $input) {
				didSucceed
				inputErrors { message path }
				estimate { id estimateNumber status viewUrl pdfUrl estimateDate dueDate }
			}
		}';

		$customer_id = trim( (string) ( $estimate['customerId'] ?? '' ) );

		// A FULL REPLACE: anything omitted here is wiped, optional fields included
		// (a patch that left out estimateNumber silently blanked the estimate's
		// number in Wave — caught by the test suite). So re-send everything we read
		// back, and override only the fields we actually own.
		$input = array(
			'id'             => $estimate_id,
			'customerId'     => '' !== $customer_id ? $customer_id : $current['customerId'],
			// Wave owns the status once the estimate lives there (the customer
			// accepts it in Wave), so echo back what it already has rather than
			// overwriting a real decision with our local guess.
			'status'         => $current['status'],
			'title'          => $current['title'],
			'estimateNumber' => $current['number'],
			'estimateDate'   => $current['estimateDate'],
			'currency'       => $current['currency'],
			'exchangeRate'   => $current['exchangeRate'],
			'dueDate'        => trim( (string) ( $estimate['dueDate'] ?? '' ) ) ?: $current['dueDate'],
			'items'          => $items,
		);

		// Optional text fields: preserve Wave's current value unless we set them.
		foreach ( array( 'poNumber', 'subhead', 'footer' ) as $key ) {
			if ( '' !== $current[ $key ] ) {
				$input[ $key ] = $current[ $key ];
			}
		}

		// memo is ours (the estimate's notes), but only when the caller says so.
		$input['memo'] = array_key_exists( 'memo', $estimate ) ? (string) $estimate['memo'] : $current['memo'];

		$data = $this->query( $mutation, array( 'input' => $input ) );
		if ( is_wp_error( $data ) ) {
			return $data;
		}

		$result = $data['estimatePatch'] ?? array();
		if ( empty( $result['didSucceed'] ) ) {
			$message = $result['inputErrors'][0]['message'] ?? __( 'Wave rejected the estimate update.', 'auto-mation' );
			return new WP_Error( 'amat_wave_estimate_update', $message );
		}

		return self::estimate_shape( $result['estimate'] ?? array() );
	}

	/**
	 * Read an estimate's acceptance history from Wave.
	 *
	 * `AREstimate.history` is a `[AREstimateAcceptanceHistory!]` — the full event
	 * log Wave keeps for an estimate once it is out with the customer (each send,
	 * view, and acceptance/decline), with who did it and when. This is the "table of
	 * all of it" Nick wanted; Wave offers it for estimates only (an `Invoice` has no
	 * history field — core §11 / the round plan). Read-only: we never write history.
	 *
	 * @param string $estimate_id Wave estimate ID.
	 * @return array<int,array{entityType:string,state:string,name:string,email:string,timestamp:string}>|WP_Error
	 */
	public function get_estimate_history( $estimate_id ) {
		$business_id = $this->get_business_id();
		if ( is_wp_error( $business_id ) ) {
			return $business_id;
		}

		$estimate_id = trim( (string) $estimate_id );
		if ( '' === $estimate_id ) {
			return new WP_Error( 'amat_wave_estimate_history', __( 'No Wave estimate ID to read history for.', 'auto-mation' ) );
		}

		$query = 'query GetEstimateHistory($businessId: ID!, $id: ID!) {
			business(id: $businessId) {
				estimate(id: $id) {
					id
					history { entityType state name email timestamp }
				}
			}
		}';

		$data = $this->query( $query, array( 'businessId' => $business_id, 'id' => $estimate_id ) );
		if ( is_wp_error( $data ) ) {
			return $data;
		}

		$node = $data['business']['estimate'] ?? null;
		if ( ! is_array( $node ) || empty( $node['id'] ) ) {
			return new WP_Error( 'amat_wave_estimate_missing', __( 'That estimate no longer exists in Wave.', 'auto-mation' ) );
		}

		$rows = array();
		foreach ( (array) ( $node['history'] ?? array() ) as $event ) {
			$rows[] = array(
				'entityType' => (string) ( $event['entityType'] ?? '' ),
				'state'      => (string) ( $event['state'] ?? '' ),
				'name'       => (string) ( $event['name'] ?? '' ),
				'email'      => (string) ( $event['email'] ?? '' ),
				'timestamp'  => (string) ( $event['timestamp'] ?? '' ),
			);
		}
		return $rows;
	}

	/**
	 * Normalize an AREstimate node into the flat shape our callers expect.
	 *
	 * @param array<string,mixed> $node Raw AREstimate selection.
	 * @return array<string,string>
	 */
	private static function estimate_shape( array $node ) {
		return array(
			'id'           => (string) ( $node['id'] ?? '' ),
			'number'       => (string) ( $node['estimateNumber'] ?? '' ),
			'poNumber'     => (string) ( $node['poNumber'] ?? '' ),
			'status'       => (string) ( $node['status'] ?? '' ),
			'viewUrl'      => (string) ( $node['viewUrl'] ?? '' ),
			'pdfUrl'       => (string) ( $node['pdfUrl'] ?? '' ),
			'title'        => (string) ( $node['title'] ?? '' ),
			'subhead'      => (string) ( $node['subhead'] ?? '' ),
			'memo'         => (string) ( $node['memo'] ?? '' ),
			'footer'       => (string) ( $node['footer'] ?? '' ),
			'estimateDate' => (string) ( $node['estimateDate'] ?? '' ),
			'dueDate'      => (string) ( $node['dueDate'] ?? '' ),
			'exchangeRate' => (string) ( $node['exchangeRate'] ?? '1' ),
			'customerId'   => (string) ( $node['customer']['id'] ?? '' ),
			'currency'     => (string) ( $node['currency']['code'] ?? 'USD' ),
		);
	}

	/**
	 * Build Wave's line-item input from our plain line rows.
	 *
	 * Each line must reference an existing Wave product — the parent product
	 * chosen in Settings (§6) — with our item name riding along as the line
	 * description. Lines with no product are dropped rather than sent, since
	 * Wave would reject the whole mutation.
	 *
	 * @param array<int,array<string,mixed>> $items Plain rows.
	 * @return array<int,array<string,mixed>> Wave EstimateCreateItemInput rows.
	 */
	private static function estimate_items_input( array $items ) {
		return self::line_items_input( $items );
	}

	/**
	 * Build Wave's line-item input from our plain line rows.
	 *
	 * Estimate and invoice line inputs are the same shape (productId + quantity +
	 * unitPrice + optional description), so one builder serves both. Lines with no
	 * product are dropped rather than sent, since Wave rejects the whole mutation.
	 *
	 * @param array<int,array<string,mixed>> $items Plain rows.
	 * @return array<int,array<string,mixed>>
	 */
	private static function line_items_input( array $items ) {
		$rows = array();

		foreach ( $items as $item ) {
			$product_id = trim( (string) ( $item['productId'] ?? '' ) );
			if ( '' === $product_id ) {
				continue;
			}
			$row = array(
				'productId' => $product_id,
				'quantity'  => isset( $item['quantity'] ) ? (float) $item['quantity'] : 1,
				'unitPrice' => isset( $item['unitPrice'] ) ? (float) $item['unitPrice'] : 0,
			);
			$description = trim( (string) ( $item['description'] ?? '' ) );
			if ( '' !== $description ) {
				$row['description'] = $description;
			}
			$rows[] = $row;
		}

		return $rows;
	}

	/* --------------------------------------------------------------------- */
	/* Invoices                                                              */
	/* --------------------------------------------------------------------- */

	/**
	 * Create an invoice in Wave from a customer + line items.
	 *
	 * Created **SAVED** (finalized / ready to send), not DRAFT — verified that
	 * `InvoiceCreateStatus` accepts SAVED and it lands in one call, so unlike an
	 * estimate (create-then-approve) there is no separate approve step. This suits
	 * Nick's model: invoices are drafted in AUTOmation and only a finalized one
	 * ever reaches Wave. Unlike an estimate draft, a SAVED invoice's `pdfUrl` is
	 * populated immediately.
	 *
	 * `invoiceDate` matters and must be sent. Wave defaults it to TODAY when it is
	 * omitted, and then rejects any `dueDate` earlier than that with "Due date
	 * cannot be before invoice date" — so every invoice issued before today (i.e.
	 * most of them, the moment there is a backlog) failed to push. Core owns the
	 * issue date, so it is passed through. Verified by introspection: `invoiceDate`
	 * is an optional `Date` on both InvoiceCreateInput and InvoicePatchInput.
	 *
	 * @param array{customerId:string,items:array<int,array<string,mixed>>,memo?:string,dueDate?:string,invoiceDate?:string} $invoice Fields.
	 * @return array<string,string>|WP_Error Normalized invoice shape, or WP_Error.
	 */
	public function create_invoice( array $invoice ) {
		$business_id = $this->get_business_id();
		if ( is_wp_error( $business_id ) ) {
			return $business_id;
		}

		$customer_id = trim( (string) ( $invoice['customerId'] ?? '' ) );
		if ( '' === $customer_id ) {
			return new WP_Error( 'amat_wave_invoice_create', __( 'The customer must be synced to Wave first.', 'auto-mation' ) );
		}

		$items = self::line_items_input( $invoice['items'] ?? array() );
		if ( empty( $items ) ) {
			return new WP_Error( 'amat_wave_invoice_create', __( 'An invoice needs at least one line.', 'auto-mation' ) );
		}

		$mutation = 'mutation CreateInvoice($input: InvoiceCreateInput!) {
			invoiceCreate(input: $input) {
				didSucceed
				inputErrors { message path }
				invoice { id invoiceNumber status viewUrl pdfUrl invoiceDate dueDate amountPaid { value } payments { paymentDate amount } }
			}
		}';

		$input = array(
			'businessId' => $business_id,
			'customerId' => $customer_id,
			'status'     => 'SAVED',
			'items'      => $items,
		);

		// Send the issue date, or Wave stamps today and rejects an older due date.
		$issued = trim( (string) ( $invoice['invoiceDate'] ?? '' ) );
		if ( '' !== $issued ) {
			$input['invoiceDate'] = $issued;
		}
		$due = trim( (string) ( $invoice['dueDate'] ?? '' ) );
		if ( '' !== $due ) {
			$input['dueDate'] = $due;
		}
		$memo = trim( (string) ( $invoice['memo'] ?? '' ) );
		if ( '' !== $memo ) {
			$input['memo'] = $memo;
		}

		$data = $this->query( $mutation, array( 'input' => $input ) );
		if ( is_wp_error( $data ) ) {
			return $data;
		}

		$result = $data['invoiceCreate'] ?? array();
		if ( empty( $result['didSucceed'] ) ) {
			$message = $result['inputErrors'][0]['message'] ?? __( 'Wave rejected the invoice.', 'auto-mation' );
			return new WP_Error( 'amat_wave_invoice_create', $message );
		}

		$node = $result['invoice'] ?? array();
		if ( '' === (string) ( $node['id'] ?? '' ) ) {
			return new WP_Error( 'amat_wave_invoice_create', __( 'Wave did not return an invoice ID.', 'auto-mation' ) );
		}

		return $this->invoice_shape( $node );
	}

	/**
	 * Read one invoice back from Wave, including its payment state.
	 *
	 * The payment fields are the read-back's whole point: Wave is the system of
	 * record for money, and AUTOmation only mirrors it. `Invoice` has no paid-date
	 * field, so the paid date is derived from the latest of its `payments`.
	 *
	 * @param string $invoice_id Wave invoice ID.
	 * @return array<string,mixed>|WP_Error Invoice shape (+ amountPaid, paidDate), or WP_Error.
	 */
	public function get_invoice( $invoice_id ) {
		$business_id = $this->get_business_id();
		if ( is_wp_error( $business_id ) ) {
			return $business_id;
		}

		$invoice_id = trim( (string) $invoice_id );
		if ( '' === $invoice_id ) {
			return new WP_Error( 'amat_wave_invoice_get', __( 'No Wave invoice ID to read.', 'auto-mation' ) );
		}

		$query = 'query GetInvoice($businessId: ID!, $id: ID!) {
			business(id: $businessId) {
				invoice(id: $id) {
					id
					invoiceNumber
					status
					viewUrl
					pdfUrl
					invoiceDate
					dueDate
					amountDue { value }
					amountPaid { value }
					total { value }
					payments { paymentDate amount }
				}
			}
		}';

		$data = $this->query( $query, array( 'businessId' => $business_id, 'id' => $invoice_id ) );
		if ( is_wp_error( $data ) ) {
			return $data;
		}

		$node = $data['business']['invoice'] ?? null;
		if ( ! is_array( $node ) || empty( $node['id'] ) ) {
			return new WP_Error( 'amat_wave_invoice_missing', __( 'That invoice no longer exists in Wave.', 'auto-mation' ) );
		}

		return $this->invoice_shape( $node );
	}

	/**
	 * Update an existing Wave invoice's line items / memo / due date.
	 *
	 * `invoicePatch` is a **sparse** patch (verified: patching with only `items`
	 * left the number intact), unlike the estimate patch — so we send only what we
	 * manage and omit the rest. Crucially we **never send `status`**: an invoice's
	 * status is driven by payments (SENT/PARTIAL/PAID/…), which `InvoiceCreateStatus`
	 * (DRAFT|SAVED only) cannot even express, so touching it could drag a paid
	 * invoice backwards.
	 *
	 * The one exception is the convert path, which passes `status => SAVED` to
	 * finalize a freshly-converted DRAFT invoice. Only DRAFT|SAVED are honoured.
	 *
	 * `invoiceDate` is sent when supplied, for the same reason as on create: the
	 * convert path patches an invoice Wave dated today, so a back-dated document
	 * would keep today's date (and reject its own due date) without it.
	 *
	 * @param array{id:string,items:array<int,array<string,mixed>>,memo?:string,dueDate?:string,invoiceDate?:string,status?:string} $invoice Fields.
	 * @return array<string,mixed>|WP_Error
	 */
	public function update_invoice( array $invoice ) {
		$invoice_id = trim( (string) ( $invoice['id'] ?? '' ) );
		if ( '' === $invoice_id ) {
			return new WP_Error( 'amat_wave_invoice_update', __( 'No Wave invoice ID to update.', 'auto-mation' ) );
		}

		$items = self::line_items_input( $invoice['items'] ?? array() );
		if ( empty( $items ) ) {
			return new WP_Error( 'amat_wave_invoice_update', __( 'An invoice needs at least one line.', 'auto-mation' ) );
		}

		$mutation = 'mutation PatchInvoice($input: InvoicePatchInput!) {
			invoicePatch(input: $input) {
				didSucceed
				inputErrors { message path }
				invoice { id invoiceNumber status viewUrl pdfUrl invoiceDate dueDate amountPaid { value } payments { paymentDate amount } }
			}
		}';

		$input = array(
			'id'    => $invoice_id,
			'items' => $items,
		);
		if ( array_key_exists( 'memo', $invoice ) ) {
			$input['memo'] = (string) $invoice['memo'];
		}
		$issued = trim( (string) ( $invoice['invoiceDate'] ?? '' ) );
		if ( '' !== $issued ) {
			$input['invoiceDate'] = $issued;
		}
		$due = trim( (string) ( $invoice['dueDate'] ?? '' ) );
		if ( '' !== $due ) {
			$input['dueDate'] = $due;
		}
		// Only DRAFT|SAVED are valid here (InvoiceCreateStatus); the convert path
		// passes SAVED to finalize a fresh draft. Anything else is left off, so a
		// normal re-push never touches the payment-driven status.
		$status = strtoupper( trim( (string) ( $invoice['status'] ?? '' ) ) );
		if ( in_array( $status, array( 'DRAFT', 'SAVED' ), true ) ) {
			$input['status'] = $status;
		}

		$data = $this->query( $mutation, array( 'input' => $input ) );
		if ( is_wp_error( $data ) ) {
			return $data;
		}

		$result = $data['invoicePatch'] ?? array();
		if ( empty( $result['didSucceed'] ) ) {
			$message = $result['inputErrors'][0]['message'] ?? __( 'Wave rejected the invoice update.', 'auto-mation' );
			return new WP_Error( 'amat_wave_invoice_update', $message );
		}

		return $this->invoice_shape( $result['invoice'] ?? array() );
	}

	/**
	 * Convert a Wave estimate into a Wave invoice, keeping Wave's own linkage.
	 *
	 * Preferred over a fresh `invoiceCreate` when the source estimate already
	 * lives in Wave, so Wave records the estimate→invoice relationship instead of
	 * ending up with two unrelated documents. Returns the new Wave invoice's shape
	 * (read back, since the mutation returns only an ID).
	 *
	 * @param string $estimate_id Wave estimate ID.
	 * @return array<string,mixed>|WP_Error
	 */
	public function convert_estimate_to_invoice( $estimate_id ) {
		$estimate_id = trim( (string) $estimate_id );
		if ( '' === $estimate_id ) {
			return new WP_Error( 'amat_wave_convert', __( 'No Wave estimate ID to convert.', 'auto-mation' ) );
		}

		$mutation = 'mutation Convert($input: ConvertEstimateToInvoiceInput!) {
			convertEstimateToInvoice(input: $input) {
				didSucceed
				inputErrors { message path }
				invoiceId
			}
		}';

		$data = $this->query( $mutation, array( 'input' => array( 'estimateId' => $estimate_id ) ) );
		if ( is_wp_error( $data ) ) {
			return $data;
		}

		$result = $data['convertEstimateToInvoice'] ?? array();
		if ( empty( $result['didSucceed'] ) || empty( $result['invoiceId'] ) ) {
			$message = $result['inputErrors'][0]['message'] ?? __( 'Wave could not convert the estimate to an invoice.', 'auto-mation' );
			return new WP_Error( 'amat_wave_convert', $message );
		}

		// The mutation yields only an ID; read the invoice for its number/links/dates.
		return $this->get_invoice( (string) $result['invoiceId'] );
	}

	/**
	 * Normalize an Invoice node into the flat shape our callers expect.
	 *
	 * Derives `paidDate` from the latest payment, since Wave's Invoice has no
	 * paid-date field of its own.
	 *
	 * @param array<string,mixed> $node Raw Invoice selection.
	 * @return array<string,mixed>
	 */
	private function invoice_shape( array $node ) {
		$paid_date = '';
		foreach ( (array) ( $node['payments'] ?? array() ) as $payment ) {
			$date = trim( (string) ( $payment['paymentDate'] ?? '' ) );
			if ( '' !== $date && $date > $paid_date ) {
				$paid_date = $date; // ISO dates sort lexically; keep the latest.
			}
		}

		return array(
			'id'          => (string) ( $node['id'] ?? '' ),
			'number'      => (string) ( $node['invoiceNumber'] ?? '' ),
			'status'      => (string) ( $node['status'] ?? '' ),
			'viewUrl'     => (string) ( $node['viewUrl'] ?? '' ),
			'pdfUrl'      => (string) ( $node['pdfUrl'] ?? '' ),
			'invoiceDate' => (string) ( $node['invoiceDate'] ?? '' ),
			'dueDate'     => (string) ( $node['dueDate'] ?? '' ),
			'amountPaid'  => (string) ( $node['amountPaid']['value'] ?? '' ),
			'amountDue'   => (string) ( $node['amountDue']['value'] ?? '' ),
			'total'       => (string) ( $node['total']['value'] ?? '' ),
			'paidDate'    => $paid_date,
		);
	}

	/**
	 * Map our plain customer fields onto Wave's CustomerCreate/Patch input shape.
	 *
	 * Keeps all Wave-schema knowledge in this one file (§6). The caller passes
	 * brand-neutral keys; this translates them to Wave's GraphQL field names and
	 * drops empties (so a patch never blanks a field we don't have).
	 *
	 * Accepted keys: name (required), firstName, lastName, email, phone, mobile,
	 * and address => { line1, line2, city, state (2-letter), postal }.
	 *
	 * @param array<string,mixed> $customer Local fields.
	 * @return array<string,mixed> Wave input object (sans id/businessId).
	 */
	private function customer_input( array $customer ) {
		$input = array( 'name' => (string) ( $customer['name'] ?? '' ) );

		// firstName/lastName are always sent (even empty) so a patch can CLEAR the
		// Wave contact name — the caller deliberately blanks them for a non-business
		// customer whose name already is "First Last" (see Customer_Model::wave_payload).
		// email/phone/mobile keep drop-empties so a patch never blanks a value we
		// simply don't have locally.
		$input['firstName'] = trim( (string) ( $customer['firstName'] ?? '' ) );
		$input['lastName']  = trim( (string) ( $customer['lastName'] ?? '' ) );

		foreach ( array( 'email', 'phone', 'mobile' ) as $key ) {
			$value = trim( (string) ( $customer[ $key ] ?? '' ) );
			if ( '' !== $value ) {
				$input[ $key ] = $value;
			}
		}

		$address = $this->address_input( isset( $customer['address'] ) && is_array( $customer['address'] ) ? $customer['address'] : array() );
		if ( ! empty( $address ) ) {
			$input['address'] = $address;
		}

		return $input;
	}

	/**
	 * Map a plain address onto Wave's CustomerAddressInput, or [] when empty.
	 *
	 * Wave wants provinceCode like "US-CA" and a countryCode enum ("US"); this
	 * business is US-only, so country is fixed. Returns [] when there is nothing
	 * to send so we never push an empty address block.
	 *
	 * @param array{line1?:string,line2?:string,city?:string,state?:string,postal?:string} $addr Plain address.
	 * @return array<string,mixed>
	 */
	private function address_input( array $addr ) {
		$line1  = trim( (string) ( $addr['line1'] ?? '' ) );
		$line2  = trim( (string) ( $addr['line2'] ?? '' ) );
		$city   = trim( (string) ( $addr['city'] ?? '' ) );
		$state  = strtoupper( trim( (string) ( $addr['state'] ?? '' ) ) );
		$postal = trim( (string) ( $addr['postal'] ?? '' ) );

		if ( '' === $line1 && '' === $line2 && '' === $city && '' === $state && '' === $postal ) {
			return array();
		}

		$out = array( 'countryCode' => 'US' );
		if ( '' !== $line1 ) {
			$out['addressLine1'] = $line1;
		}
		if ( '' !== $line2 ) {
			$out['addressLine2'] = $line2;
		}
		if ( '' !== $city ) {
			$out['city'] = $city;
		}
		if ( '' !== $state ) {
			$out['provinceCode'] = 'US-' . $state;
		}
		if ( '' !== $postal ) {
			$out['postalCode'] = $postal;
		}

		return $out;
	}

	/**
	 * Write a message to the error log, namespaced for grep-ability.
	 *
	 * Only logs when WP_DEBUG is on so production stays quiet (§6).
	 *
	 * @param string $message Message to record.
	 * @return void
	 */
	private function log( $message ) {
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			error_log( '[AUTOmation Wave] ' . $message ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
		}
	}
}
