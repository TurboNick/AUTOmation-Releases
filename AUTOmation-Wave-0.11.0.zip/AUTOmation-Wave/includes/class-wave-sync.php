<?php
/**
 * Automatic sync + retry orchestration for the Wave integration.
 *
 * The manual Sync/Push buttons live on the customer/estimate/invoice detail
 * views. This class adds the *automatic* half (opt-in via Settings → Wave →
 * Sync mode = Automatic):
 *
 * - **Auto-push on save.** It listens on core's `amat_after_{customer,estimate,
 *   invoice}_save` lifecycle hooks (which fire from the admin save paths, never
 *   the models — see core §3) and, when auto mode is on, schedules a one-shot
 *   background event to push that record. The push runs *after* the save via
 *   WP-Cron, deliberately, so a slow or failing Wave call never blocks the owner's
 *   save, and a failure degrades to a logged, retryable state rather than a fatal.
 * - **Hourly retry.** A recurring event re-drives every `external_refs` row this
 *   provider left in the `failed` state. The ref carries the retry state; the log
 *   carries why it failed (core §4) — no separate queue table (core §10, round 2).
 *
 * The actual push logic is NOT here: it lives in the same methods the buttons use
 * (AMAT_Wave_Provider::sync_customer(), AMAT_Wave_Documents::push_estimate() /
 * ::push_invoice()), so manual and automatic paths can never drift. This class is
 * the scheduler + dispatcher that calls them.
 *
 * Registered even in a non-admin (WP-Cron) request — the cron callbacks must be
 * attached there — while all the UI stays admin-only.
 *
 * @package AUTOmation_Wave
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Schedules automatic Wave pushes and retries failed ones.
 */
class AMAT_Wave_Sync {

	/**
	 * Single-shot cron hook that pushes one record. Args: (entity_type, id).
	 *
	 * @var string
	 */
	const SYNC_EVENT_HOOK = 'amaw_sync_entity';

	/**
	 * Recurring cron hook that retries every failed push.
	 *
	 * @var string
	 */
	const RETRY_HOOK = 'amaw_retry_failed_syncs';

	/**
	 * Log channel (core's AMAT_Log), shared with AMAT_Wave_Documents.
	 *
	 * @var string
	 */
	const CHANNEL = 'wave';

	/**
	 * How long after a save the background push fires. A few seconds is enough to
	 * let the save's redirect complete; it also coalesces a rapid re-save, since
	 * an identical event already scheduled within ~10 min is not duplicated.
	 *
	 * @var int
	 */
	const AUTO_SYNC_DELAY = 5;

	/**
	 * Most records the retry sweep will process in a single run — a safety cap so a
	 * large backlog of failures can't fan out into an unbounded burst of Wave calls
	 * (rate limits are unpublished; be conservative — core §11). The remainder is
	 * picked up on the next hourly run.
	 *
	 * @var int
	 */
	const RETRY_MAX_PER_RUN = 25;

	/**
	 * The entity types this class knows how to push.
	 *
	 * @var string[]
	 */
	const ENTITIES = array( 'customer', 'estimate', 'invoice' );

	/**
	 * Wire up the lifecycle listeners + cron callbacks, and ensure the retry cron
	 * is scheduled. Safe to call in any request context (admin or cron).
	 *
	 * @return void
	 */
	public function register() {
		// Auto-push triggers. These core hooks only ever fire from admin save paths,
		// so attaching them in a cron context is harmless (they simply never fire).
		add_action( 'amat_after_customer_save', array( $this, 'on_customer_save' ), 10, 2 );
		add_action( 'amat_after_estimate_save', array( $this, 'on_estimate_save' ), 10, 2 );
		add_action( 'amat_after_invoice_save', array( $this, 'on_invoice_save' ), 10, 2 );

		// Cron callbacks — MUST be registered in the cron request too (which is not
		// is_admin()), or the scheduled events would fire with no listener.
		add_action( self::SYNC_EVENT_HOOK, array( $this, 'run_sync_event' ), 10, 2 );
		add_action( self::RETRY_HOOK, array( $this, 'retry_failed' ) );

		self::schedule();
	}

	/* --------------------------------------------------------------------- */
	/* Auto-push on save                                                     */
	/* --------------------------------------------------------------------- */

	/**
	 * @param int  $id     Customer id.
	 * @param bool $is_new Whether the save created the record (unused; we push either way).
	 * @return void
	 */
	public function on_customer_save( $id, $is_new = false ) {
		$this->maybe_schedule_push( 'customer', (int) $id );
	}

	/**
	 * @param int  $id     Estimate id.
	 * @param bool $is_new Unused.
	 * @return void
	 */
	public function on_estimate_save( $id, $is_new = false ) {
		$this->maybe_schedule_push( 'estimate', (int) $id );
	}

	/**
	 * @param int  $id     Invoice id.
	 * @param bool $is_new Unused.
	 * @return void
	 */
	public function on_invoice_save( $id, $is_new = false ) {
		$this->maybe_schedule_push( 'invoice', (int) $id );
	}

	/**
	 * Schedule a background push of one record, when auto mode is on and Wave is
	 * configured. Skips scheduling a duplicate for the same record already queued.
	 *
	 * @param string $entity Entity type.
	 * @param int    $id     Record id.
	 * @return void
	 */
	private function maybe_schedule_push( $entity, $id ) {
		$id = (int) $id;
		if ( $id <= 0 || ! in_array( $entity, self::ENTITIES, true ) ) {
			return;
		}
		if ( ! AMAT_Wave_Client::is_auto_sync() ) {
			return;
		}
		if ( ! ( new AMAT_Wave_Client() )->is_configured() ) {
			return;
		}

		$args = array( $entity, $id );
		if ( ! wp_next_scheduled( self::SYNC_EVENT_HOOK, $args ) ) {
			wp_schedule_single_event( time() + self::AUTO_SYNC_DELAY, self::SYNC_EVENT_HOOK, $args );
		}
	}

	/**
	 * Cron callback for one scheduled push.
	 *
	 * @param string $entity Entity type.
	 * @param int    $id     Record id.
	 * @return void
	 */
	public function run_sync_event( $entity, $id ) {
		$this->run_sync( (string) $entity, (int) $id );
	}

	/* --------------------------------------------------------------------- */
	/* Retry sweep                                                           */
	/* --------------------------------------------------------------------- */

	/**
	 * Re-drive every Wave push this provider left in the `failed` state. Gated on
	 * auto mode — in manual mode the owner drives everything, so a background retry
	 * would contradict that (a manual failure is theirs to re-push). Serial, capped
	 * per run for rate-limit safety.
	 *
	 * @return void
	 */
	public function retry_failed() {
		if ( ! AMAT_Wave_Client::is_auto_sync() ) {
			return;
		}
		if ( ! ( new AMAT_Wave_Client() )->is_configured() ) {
			return;
		}

		$processed = 0;
		foreach ( AMAT_External_Ref_Model::all_for( AMAT_Wave_Client::PROVIDER ) as $ref ) {
			if ( 'failed' !== (string) ( $ref['status'] ?? '' ) ) {
				continue;
			}
			$entity = (string) ( $ref['entity_type'] ?? '' );
			if ( ! in_array( $entity, self::ENTITIES, true ) ) {
				continue;
			}

			$this->run_sync( $entity, (int) $ref['entity_id'] );

			if ( ++$processed >= self::RETRY_MAX_PER_RUN ) {
				AMAT_Log::warning(
					self::CHANNEL,
					__( 'Wave retry sweep hit its per-run cap; the rest will be retried on the next run.', 'auto-mation' ),
					array( 'context' => array( 'processed' => $processed, 'cap' => self::RETRY_MAX_PER_RUN ) )
				);
				break;
			}
		}
	}

	/* --------------------------------------------------------------------- */
	/* Dispatcher                                                            */
	/* --------------------------------------------------------------------- */

	/**
	 * Run one record's push through the same code path the buttons use, and return
	 * its result. Shared by the auto-push cron event and the retry sweep (and by the
	 * tests). Customer pushes don't self-mark a failed ref the way document pushes
	 * do, so this marks one on a retryable customer failure so the sweep can find it.
	 *
	 * @param string $entity Entity type ('customer'|'estimate'|'invoice').
	 * @param int    $id     Record id.
	 * @return array{status:string,message:string} Push result (see the push methods).
	 */
	public function run_sync( $entity, $id ) {
		$id = (int) $id;

		switch ( $entity ) {
			case 'customer':
				$result = ( new AMAT_Wave_Provider() )->sync_customer( $id );
				break;
			case 'estimate':
				$result = ( new AMAT_Wave_Documents() )->push_estimate( $id );
				break;
			case 'invoice':
				$result = ( new AMAT_Wave_Documents() )->push_invoice( $id );
				break;
			default:
				return array( 'status' => 'error', 'message' => __( 'Unknown record type.', 'auto-mation' ) );
		}

		// A customer with several possible Wave matches can't be auto-resolved — the
		// owner must pick. Log it (so it's visible) but leave the ref alone: it isn't
		// a failure to retry, it's a decision to make by hand.
		if ( 'ambiguous' === $result['status'] ) {
			AMAT_Log::warning(
				self::CHANNEL,
				__( 'Automatic sync skipped a customer with several possible Wave matches — sync it by hand to choose.', 'auto-mation' ),
				array( 'entity_type' => 'customer', 'entity_id' => $id )
			);
			return $result;
		}

		// Document pushes already mark their own ref failed; customers do not, so do
		// it here so a failed auto-sync lands in the retry sweep (preserving any
		// existing external_id).
		if ( 'customer' === $entity && 'error' === $result['status'] && ! empty( $result['retryable'] ) ) {
			$existing = AMAT_External_Ref_Model::external_id( AMAT_Wave_Client::PROVIDER, 'customer', $id );
			AMAT_External_Ref_Model::set( AMAT_Wave_Client::PROVIDER, 'customer', $id, $existing, array( 'status' => 'failed' ) );
			AMAT_Log::error(
				self::CHANNEL,
				$result['message'],
				array( 'entity_type' => 'customer', 'entity_id' => $id )
			);
		}

		return $result;
	}

	/* --------------------------------------------------------------------- */
	/* Cron scheduling                                                       */
	/* --------------------------------------------------------------------- */

	/**
	 * Ensure the hourly retry sweep is scheduled. Idempotent — safe to call on
	 * every load. The single-shot push events are scheduled on demand, not here.
	 *
	 * @return void
	 */
	public static function schedule() {
		if ( ! wp_next_scheduled( self::RETRY_HOOK ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'hourly', self::RETRY_HOOK );
		}
	}

	/**
	 * Remove this integration's scheduled events. Called on deactivation so a
	 * disabled plugin leaves no orphaned cron behind.
	 *
	 * @return void
	 */
	public static function unschedule() {
		wp_clear_scheduled_hook( self::RETRY_HOOK );
		wp_clear_scheduled_hook( self::SYNC_EVENT_HOOK );
	}
}
