<?php
/**
 * Secret resolution for the Wave integration.
 *
 * ⚠ **A `.env` inside the plugin directory does not survive a plugin update.**
 * WordPress's updater deletes the whole plugin folder before unpacking the new
 * zip, and package.ps1 deliberately excludes `.env` (a token inside a
 * distributable archive is a leak that travels). Those two correct decisions
 * combine into a wrong outcome: every update silently wipes the token and Wave
 * sync stops. That is not hypothetical — it happened on production on 2026-08-17,
 * the first time an update was installed.
 *
 * So the token is looked for in several places, most durable first, and the
 * plugin-directory `.env` is last:
 *
 *   1. **A PHP constant** in `wp-config.php` — `define( 'WAVE_API_TOKEN', '…' )`.
 *      Outside the plugin, outside the database, never in a backup. Best choice
 *      wherever wp-config.php can be edited.
 *   2. **A real environment variable** — for hosts that inject them.
 *   3. **`wp-content/.env`** — a file, but one level above anything an update
 *      touches. The right answer when there is file access but no wp-config edit.
 *   4. **`.env` in the plugin directory** — the dev-machine convenience, and the
 *      one that gets wiped. Still supported, because it is what Local uses.
 *   5. **A WordPress option**, set in Settings → Wave. The only route on a host
 *      with no file access at all (wp-admin upload only), which is exactly this
 *      project's production setup. Registered with core's backup exclusion filter
 *      so a downloaded snapshot never carries the token.
 *
 * `source()` reports which of these answered, so Settings can say so plainly —
 * and warn when the answer is the one an update is about to delete.
 *
 * @package AUTOmation_Wave
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Reads secrets from a constant, the environment, a .env file, or an option.
 */
class AMAT_Env {

	/**
	 * Parsed key => value pairs per file path. Null entries mean "not loaded".
	 *
	 * @var array<string,array<string,string>>
	 */
	private static $cache = array();

	/**
	 * Source labels, in the order they are tried.
	 *
	 * @var string
	 */
	const SOURCE_CONSTANT   = 'constant';
	const SOURCE_ENV        = 'environment';
	const SOURCE_CONTENT    = 'wp-content';
	const SOURCE_PLUGIN     = 'plugin';
	const SOURCE_OPTION     = 'option';
	const SOURCE_NONE       = '';

	/**
	 * The option a key falls back to, e.g. WAVE_API_TOKEN -> amat_wave_env_wave_api_token.
	 *
	 * @param string $key Variable name.
	 * @return string
	 */
	public static function option_name( $key ) {
		return 'amat_wave_env_' . strtolower( preg_replace( '/[^A-Za-z0-9_]/', '', (string) $key ) );
	}

	/**
	 * Every option this class may store a secret in, for the backup exclusion.
	 *
	 * @return string[]
	 */
	public static function secret_options() {
		return array( self::option_name( 'WAVE_API_TOKEN' ) );
	}

	/**
	 * Get a value by key, falling back to a default.
	 *
	 * @param string $key     Variable name, e.g. 'WAVE_API_TOKEN'.
	 * @param string $default Value returned when the key is absent/empty.
	 * @return string
	 */
	public static function get( $key, $default = '' ) {
		$found = self::resolve( $key );
		return '' !== $found['value'] ? $found['value'] : $default;
	}

	/**
	 * Which source supplied a key: one of the SOURCE_* constants ('' = nowhere).
	 *
	 * @param string $key Variable name.
	 * @return string
	 */
	public static function source( $key ) {
		return self::resolve( $key )['source'];
	}

	/**
	 * Human label for a source, for the settings page.
	 *
	 * @param string $source A SOURCE_* value.
	 * @return string
	 */
	public static function source_label( $source ) {
		$labels = array(
			self::SOURCE_CONSTANT => __( 'a constant in wp-config.php', 'auto-mation' ),
			self::SOURCE_ENV      => __( 'a server environment variable', 'auto-mation' ),
			self::SOURCE_CONTENT  => __( 'wp-content/.env', 'auto-mation' ),
			self::SOURCE_PLUGIN   => __( ".env in this plugin's folder", 'auto-mation' ),
			self::SOURCE_OPTION   => __( 'this settings page', 'auto-mation' ),
		);
		return $labels[ $source ] ?? '';
	}

	/**
	 * Whether the value in use will be destroyed by the next plugin update.
	 *
	 * True only for the plugin-directory .env — the whole reason this class has
	 * more than one source.
	 *
	 * @param string $key Variable name.
	 * @return bool
	 */
	public static function is_fragile( $key ) {
		return self::SOURCE_PLUGIN === self::source( $key );
	}

	/**
	 * Store a secret in the database (or clear it when blank).
	 *
	 * @param string $key   Variable name.
	 * @param string $value Secret, or '' to remove it.
	 * @return void
	 */
	public static function set_option( $key, $value ) {
		$name  = self::option_name( $key );
		$value = trim( (string) $value );

		if ( '' === $value ) {
			delete_option( $name );
			return;
		}
		update_option( $name, $value, false );
	}

	/**
	 * Find a key, in order of durability.
	 *
	 * @param string $key Variable name.
	 * @return array{value:string,source:string}
	 */
	private static function resolve( $key ) {
		$key = (string) $key;

		// 1. wp-config.php constant.
		if ( defined( $key ) ) {
			$value = (string) constant( $key );
			if ( '' !== $value ) {
				return array( 'value' => $value, 'source' => self::SOURCE_CONSTANT );
			}
		}

		// 2. Real environment variable.
		$env = getenv( $key );
		if ( false !== $env && '' !== $env ) {
			return array( 'value' => (string) $env, 'source' => self::SOURCE_ENV );
		}

		// 3. wp-content/.env — above anything a plugin update deletes.
		if ( defined( 'WP_CONTENT_DIR' ) ) {
			$vars = self::load( trailingslashit( WP_CONTENT_DIR ) . '.env' );
			if ( isset( $vars[ $key ] ) && '' !== $vars[ $key ] ) {
				return array( 'value' => $vars[ $key ], 'source' => self::SOURCE_CONTENT );
			}
		}

		// 4. The plugin's own .env (dev convenience; wiped by every update).
		$vars = self::load( AMAW_DIR . '.env' );
		if ( isset( $vars[ $key ] ) && '' !== $vars[ $key ] ) {
			return array( 'value' => $vars[ $key ], 'source' => self::SOURCE_PLUGIN );
		}

		// 5. The database — the only option when there is no file access at all.
		$stored = (string) get_option( self::option_name( $key ), '' );
		if ( '' !== $stored ) {
			return array( 'value' => $stored, 'source' => self::SOURCE_OPTION );
		}

		return array( 'value' => '', 'source' => self::SOURCE_NONE );
	}

	/**
	 * Parse a .env file into an associative array, cached per path.
	 *
	 * Supports `KEY=value`, an optional `export ` prefix, `#` comments, and
	 * single/double quoted values. Intentionally tiny — no interpolation.
	 *
	 * @param string $path Absolute path to a .env file.
	 * @return array<string,string>
	 */
	private static function load( $path ) {
		if ( isset( self::$cache[ $path ] ) ) {
			return self::$cache[ $path ];
		}

		$vars = array();

		if ( ! is_readable( $path ) ) {
			self::$cache[ $path ] = $vars;
			return $vars;
		}

		$lines = file( $path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES );
		if ( false === $lines ) {
			self::$cache[ $path ] = $vars;
			return $vars;
		}

		foreach ( $lines as $line ) {
			$line = trim( $line );

			if ( '' === $line || str_starts_with( $line, '#' ) ) {
				continue;
			}

			if ( str_starts_with( $line, 'export ' ) ) {
				$line = substr( $line, strlen( 'export ' ) );
			}

			$pos = strpos( $line, '=' );
			if ( false === $pos ) {
				continue;
			}

			$name  = trim( substr( $line, 0, $pos ) );
			$value = trim( substr( $line, $pos + 1 ) );

			// Strip surrounding matching quotes.
			if ( strlen( $value ) >= 2 ) {
				$first = $value[0];
				$last  = $value[ strlen( $value ) - 1 ];
				if ( ( '"' === $first && '"' === $last ) || ( "'" === $first && "'" === $last ) ) {
					$value = substr( $value, 1, -1 );
				}
			}

			if ( '' !== $name ) {
				$vars[ $name ] = $value;
			}
		}

		self::$cache[ $path ] = $vars;
		return $vars;
	}
}
