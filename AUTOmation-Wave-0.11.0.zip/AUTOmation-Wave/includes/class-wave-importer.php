<?php
/**
 * Wave customer CSV importer (Dev Tools).
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Imports customers from a Wave (waveapps) customer-export CSV.
 *
 * Maps the Wave columns onto our model: customer identity + a notes stash for
 * fields we don't model (website, account #), an ordered set of contact methods
 * (call/text/email), and up to two locations (the main/billing address and the
 * ship-to address). New customers are created only when one of the same name
 * doesn't already exist (matched case-insensitively on the display name).
 *
 * This lives in the integrations layer because it consumes a Wave export, but it
 * makes no API calls — it only reads the CSV and writes our own tables.
 */
class AMAT_Wave_Importer {

	/**
	 * Import customers from a Wave CSV file.
	 *
	 * @param string $file_path Absolute path to the uploaded CSV.
	 * @return array{created:int,skipped:int,errors:string[]} Import summary.
	 */
	public static function import( $file_path ) {
		$result = array( 'created' => 0, 'skipped' => 0, 'errors' => array() );

		$handle = is_readable( $file_path ) ? fopen( $file_path, 'r' ) : false;
		if ( false === $handle ) {
			$result['errors'][] = __( 'Could not open the uploaded file.', 'auto-mation' );
			return $result;
		}

		$header = fgetcsv( $handle );
		if ( false === $header || array( null ) === $header ) {
			$result['errors'][] = __( 'The file appears to be empty.', 'auto-mation' );
			fclose( $handle );
			return $result;
		}

		// Normalize headers to lowercase keys; strip a UTF-8 BOM from the first.
		$header[0] = preg_replace( '/^\xEF\xBB\xBF/', '', (string) $header[0] );
		$columns   = array();
		foreach ( $header as $i => $name ) {
			$columns[ strtolower( trim( (string) $name ) ) ] = $i;
		}

		if ( ! isset( $columns['customer_name'] ) && ! isset( $columns['contact_first_name'] ) ) {
			$result['errors'][] = __( 'Unrecognized CSV — expected a Wave customer export (no customer_name column found).', 'auto-mation' );
			fclose( $handle );
			return $result;
		}

		// Names already on file (and added during this run) for dedupe-by-name.
		$existing = array();
		foreach ( AMAT_Customer_Model::all() as $c ) {
			$existing[ strtolower( trim( AMAT_Customer_Model::display_name( $c ) ) ) ] = true;
		}

		$line = 1; // header was line 1
		while ( false !== ( $row = fgetcsv( $handle ) ) ) {
			$line++;
			if ( array( null ) === $row ) {
				continue; // blank line
			}

			$get = static function ( $key ) use ( $row, $columns ) {
				if ( ! isset( $columns[ $key ] ) ) {
					return '';
				}
				$idx = $columns[ $key ];
				return isset( $row[ $idx ] ) ? trim( (string) $row[ $idx ] ) : '';
			};

			$customer_name = $get( 'customer_name' );
			$c_first       = $get( 'contact_first_name' );
			$c_last        = $get( 'contact_last_name' );

			// Name resolution:
			//  - With a contact name: contact_first/last become First/Last and the
			//    customer_name becomes the Display name.
			//  - Without one: split customer_name ("First Last") into First/Last and
			//    leave the Display name blank (falls back to "First Last").
			if ( '' !== $c_first || '' !== $c_last ) {
				$first   = $c_first;
				$last    = $c_last;
				$display = $customer_name;
			} else {
				list( $first, $last ) = self::split_name( $customer_name );
				$display              = '';
			}

			$effective = '' !== $customer_name ? $customer_name : trim( $first . ' ' . $last );
			if ( '' === $effective ) {
				/* translators: %d: CSV line number. */
				$result['errors'][] = sprintf( __( 'Line %d: skipped (no customer name).', 'auto-mation' ), $line );
				continue;
			}

			$dedupe_key = strtolower( $effective );
			if ( isset( $existing[ $dedupe_key ] ) ) {
				$result['skipped']++;
				continue;
			}

			$customer_id = self::create_customer( $first, $last, $display, $get );
			if ( ! $customer_id ) {
				/* translators: 1: CSV line number, 2: customer name. */
				$result['errors'][] = sprintf( __( 'Line %1$d: could not create "%2$s".', 'auto-mation' ), $line, $effective );
				continue;
			}

			self::import_contacts( $customer_id, $get );
			self::import_locations( $customer_id, $get );

			$existing[ $dedupe_key ] = true;
			$result['created']++;
		}

		fclose( $handle );
		return $result;
	}

	/**
	 * Create the customer record from already-resolved name parts.
	 *
	 * Website/account number are stashed in internal notes so they aren't
	 * silently dropped.
	 *
	 * @param string   $first   First name.
	 * @param string   $last    Last name.
	 * @param string   $display Display name (stored only when non-empty).
	 * @param callable $get     Column accessor.
	 * @return int|false New customer id, or false on failure.
	 */
	private static function create_customer( $first, $last, $display, callable $get ) {
		$note_parts = array();
		if ( '' !== $get( 'website' ) ) {
			$note_parts[] = __( 'Website: ', 'auto-mation' ) . $get( 'website' );
		}
		if ( '' !== $get( 'account_number' ) ) {
			$note_parts[] = __( 'Account #: ', 'auto-mation' ) . $get( 'account_number' );
		}

		return AMAT_Customer_Model::create(
			array(
				'first_name'   => $first,
				'last_name'    => $last,
				'display_name' => $display,
				'notes'        => implode( "\n", $note_parts ),
			)
		);
	}

	/**
	 * Split a "First Last" string into [first, last]: the first whitespace-run
	 * separates the first name from the remainder (so "Mary Jane Watson" → first
	 * "Mary", last "Jane Watson"). A single token yields an empty last name.
	 *
	 * @param string $name Full name.
	 * @return array{0:string,1:string}
	 */
	private static function split_name( $name ) {
		$name = trim( (string) $name );
		if ( '' === $name ) {
			return array( '', '' );
		}
		$parts = preg_split( '/\s+/', $name, 2 );
		return array( $parts[0], isset( $parts[1] ) ? $parts[1] : '' );
	}

	/**
	 * Build and store the customer's ordered contact methods from the row.
	 *
	 * Mobile is both callable and textable, so it seeds a call AND a text method;
	 * phone/toll-free add call methods; email adds an email method. Values are
	 * normalized via the type registry and de-duplicated per channel; anything
	 * that fails validation is skipped.
	 *
	 * @param int      $customer_id Customer id.
	 * @param callable $get         Column accessor.
	 * @return void
	 */
	private static function import_contacts( $customer_id, callable $get ) {
		// [type, raw] pairs in priority order (first = preferred contact).
		$candidates = array(
			array( 'call', $get( 'mobile' ) ),
			array( 'text', $get( 'mobile' ) ),
			array( 'call', $get( 'phone' ) ),
			array( 'call', $get( 'toll_free' ) ),
			array( 'email', $get( 'email' ) ),
		);

		$methods = array();
		$seen    = array(); // "type:value" guard against duplicates
		foreach ( $candidates as $pair ) {
			list( $type, $raw ) = $pair;
			if ( '' === $raw ) {
				continue;
			}
			$value = AMAT_Contact_Method_Types::validate( $type, $raw );
			if ( is_wp_error( $value ) ) {
				continue;
			}
			$key = $type . ':' . $value;
			if ( isset( $seen[ $key ] ) ) {
				continue;
			}
			$seen[ $key ] = true;
			$methods[]    = array( 'type' => $type, 'value' => $value );
		}

		if ( $methods ) {
			AMAT_Contact_Method_Model::replace_for_customer( $customer_id, $methods );
		}
	}

	/**
	 * Create the customer's location(s): the main/billing address and, when
	 * present and distinct, the ship-to address.
	 *
	 * The main address carries the primary + billing flags; if there is only a
	 * ship-to address, it takes those flags instead.
	 *
	 * @param int      $customer_id Customer id.
	 * @param callable $get         Column accessor.
	 * @return void
	 */
	private static function import_locations( $customer_id, callable $get ) {
		$has_main = ( '' !== $get( 'address_line_1' ) || '' !== $get( 'city' ) );
		$has_ship = ( '' !== $get( 'ship-to_address_line_1' ) || '' !== $get( 'ship-to_city' ) );

		if ( $has_main ) {
			AMAT_Location_Model::create(
				array(
					'customer_id' => $customer_id,
					'label'       => __( 'Billing', 'auto-mation' ),
					'is_primary'  => 1,
					'is_billing'  => 1,
					'is_active'   => 1,
					'street_1'    => $get( 'address_line_1' ),
					'street_2'    => $get( 'address_line_2' ),
					'city'        => $get( 'city' ),
					'state'       => self::normalize_state( $get( 'province/state' ) ),
					'zipcode'     => $get( 'postal_code/zip_code' ),
				)
			);
		}

		if ( $has_ship ) {
			AMAT_Location_Model::create(
				array(
					'customer_id' => $customer_id,
					'label'       => __( 'Shipping', 'auto-mation' ),
					'is_primary'  => $has_main ? 0 : 1,
					'is_billing'  => $has_main ? 0 : 1,
					'is_active'   => 1,
					'street_1'    => $get( 'ship-to_address_line_1' ),
					'street_2'    => $get( 'ship-to_address_line_2' ),
					'city'        => $get( 'ship-to_city' ),
					'state'       => self::normalize_state( $get( 'ship-to_province/state' ) ),
					'zipcode'     => $get( 'ship-to_postal_code/zip_code' ),
					'notes'       => $get( 'delivery_instructions' ),
				)
			);
		}
	}

	/**
	 * Normalize a state/province value to a 2-letter US code when possible.
	 *
	 * Accepts an existing code (any case) or a full state name; falls back to the
	 * raw value (uppercased if 2 chars) when it can't be mapped.
	 *
	 * @param string $raw Raw state value.
	 * @return string
	 */
	private static function normalize_state( $raw ) {
		$raw = trim( (string) $raw );
		if ( '' === $raw ) {
			return '';
		}
		if ( AMAT_Location_Model::is_valid_state( $raw ) ) {
			return strtoupper( $raw );
		}
		$map = self::state_name_map();
		$key = strtolower( $raw );
		return $map[ $key ] ?? $raw;
	}

	/**
	 * Lowercased US state/territory name => 2-letter code.
	 *
	 * @return array<string,string>
	 */
	private static function state_name_map() {
		return array(
			'alabama' => 'AL', 'alaska' => 'AK', 'arizona' => 'AZ', 'arkansas' => 'AR',
			'california' => 'CA', 'colorado' => 'CO', 'connecticut' => 'CT', 'delaware' => 'DE',
			'florida' => 'FL', 'georgia' => 'GA', 'hawaii' => 'HI', 'idaho' => 'ID',
			'illinois' => 'IL', 'indiana' => 'IN', 'iowa' => 'IA', 'kansas' => 'KS',
			'kentucky' => 'KY', 'louisiana' => 'LA', 'maine' => 'ME', 'maryland' => 'MD',
			'massachusetts' => 'MA', 'michigan' => 'MI', 'minnesota' => 'MN', 'mississippi' => 'MS',
			'missouri' => 'MO', 'montana' => 'MT', 'nebraska' => 'NE', 'nevada' => 'NV',
			'new hampshire' => 'NH', 'new jersey' => 'NJ', 'new mexico' => 'NM', 'new york' => 'NY',
			'north carolina' => 'NC', 'north dakota' => 'ND', 'ohio' => 'OH', 'oklahoma' => 'OK',
			'oregon' => 'OR', 'pennsylvania' => 'PA', 'rhode island' => 'RI', 'south carolina' => 'SC',
			'south dakota' => 'SD', 'tennessee' => 'TN', 'texas' => 'TX', 'utah' => 'UT',
			'vermont' => 'VT', 'virginia' => 'VA', 'washington' => 'WA', 'west virginia' => 'WV',
			'wisconsin' => 'WI', 'wyoming' => 'WY', 'district of columbia' => 'DC',
			'american samoa' => 'AS', 'guam' => 'GU', 'northern mariana islands' => 'MP',
			'puerto rico' => 'PR', 'virgin islands' => 'VI', 'u.s. virgin islands' => 'VI',
		);
	}
}
