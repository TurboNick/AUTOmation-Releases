<?php
/**
 * Bulk-link every unlinked customer to Wave, in throttled, resumable batches.
 *
 * The inverse of the Unlink tool: after first setup — or after switching the
 * target business — the whole customer book needs pushing to Wave one time. Doing
 * that by clicking Sync on each customer does not scale, and doing it in one
 * request would both time out and hammer an API whose rate limits are unpublished.
 *
 * How it is kept safe (core §11's requirements, which this closes out):
 *
 * - **Serial and delayed.** One customer at a time, with a pause between calls.
 *   Never concurrent — Wave publishes no limits, so the only defensible posture is
 *   conservative.
 * - **Batched in the background.** Each WP-Cron tick processes a small batch and
 *   schedules the next, so no single request runs long and the run survives a
 *   closed browser tab.
 * - **Backs off on 429.** A rate-limited reply pauses the run and reschedules it
 *   further out, doubling each time (honouring Retry-After if Wave sends one).
 *   The customer that hit the limit is NOT counted as failed — it is retried.
 * - **Resumable.** The work list is recomputed every batch from "active customers
 *   with no Wave link", so a success drops out by virtue of being linked. Stopping
 *   and starting again continues where it left off; nothing is pushed twice.
 * - **Adopts, never duplicates.** It calls the very same
 *   AMAT_Wave_Provider::sync_customer() the button uses, so match-and-adopt
 *   applies (see [[wave-no-delete-match-adopt]]): a customer already in Wave is
 *   linked to, not recreated. Ambiguous matches are left for the picker rather
 *   than guessed at — the same rule auto-sync follows.
 * - **Pinned to one business.** The target business is recorded when the run
 *   starts; if Settings is repointed mid-run the run stops instead of pushing the
 *   remainder into a different business.
 *
 * There is also a **preview**, which is nearly free (matching runs against the
 * cached customer list) and answers "what would this do?" without writing
 * anything — worth reading before a run against a real book.
 *
 * @package AUTOmation_Wave
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Throttled, resumable bulk customer push.
 */
class AMAT_Wave_Mass_Link {

	/**
	 * Option holding the run state (autoload false — it changes constantly).
	 *
	 * @var string
	 */
	const STATE_OPTION = 'amat_wave_masslink';

	/**
	 * Cron hook processing one batch. Reschedules itself until the run is done.
	 *
	 * @var string
	 */
	const BATCH_HOOK = 'amaw_masslink_batch';

	/**
	 * Log channel (core's AMAT_Log).
	 *
	 * @var string
	 */
	const CHANNEL = 'wave';

	/**
	 * Customers pushed per batch. Small on purpose: a batch runs inside one cron
	 * request, and a smaller batch means finer-grained resumption after a crash.
	 *
	 * @var int
	 */
	const BATCH_SIZE = 10;

	/**
	 * Pause between customers, in microseconds.
	 *
	 * Set from measurement, not guesswork: a 108-customer rehearsal at 0.4s ran at
	 * roughly 1.25 customers/second end to end and **was rate-limited twice** by
	 * Wave. 0.75s costs about a minute more on a book that size and left room under
	 * the limit. The backoff below is the safety net; this is the pace that tries
	 * not to need it.
	 *
	 * @var int
	 */
	const REQUEST_DELAY_US = 750000;

	/**
	 * Seconds between batches in normal running.
	 *
	 * @var int
	 */
	const BATCH_INTERVAL = 10;

	/**
	 * First backoff step after a 429, in seconds. Doubles per consecutive hit.
	 *
	 * @var int
	 */
	const BASE_BACKOFF = 60;

	/**
	 * Ceiling on the backoff, in seconds.
	 *
	 * @var int
	 */
	const MAX_BACKOFF = 900;

	/**
	 * Most ids kept in the failed/ambiguous lists. Beyond this only the count is
	 * tracked — the state is an option, not a table, and a pathological run must
	 * not grow it without bound.
	 *
	 * @var int
	 */
	const MAX_TRACKED_IDS = 200;

	/**
	 * Register the batch cron callback. Must run in every context: cron requests
	 * are not is_admin(), and the event would otherwise fire with no listener.
	 *
	 * @return void
	 */
	public function register() {
		add_action( self::BATCH_HOOK, array( $this, 'run_batch' ) );
	}

	/* --------------------------------------------------------------------- */
	/* State                                                                 */
	/* --------------------------------------------------------------------- */

	/**
	 * A fresh, empty state.
	 *
	 * @return array<string,mixed>
	 */
	public static function blank_state() {
		return array(
			'status'     => 'idle',
			'business'   => '',
			'total'      => 0,
			'processed'  => 0,
			'created'    => 0,
			'adopted'    => 0,
			'updated'    => 0,
			'ambiguous'  => array(),
			'failed'     => array(),
			'skipped'    => 0,
			'backoff'    => 0,
			'last_error' => '',
			'started_at' => '',
			'updated_at' => '',
		);
	}

	/**
	 * The current run state, always shaped like blank_state().
	 *
	 * @return array<string,mixed>
	 */
	public static function state() {
		$stored = get_option( self::STATE_OPTION, array() );
		return is_array( $stored ) ? array_merge( self::blank_state(), $stored ) : self::blank_state();
	}

	/**
	 * Whether a run is in progress (including one waiting out a backoff).
	 *
	 * @return bool
	 */
	public static function is_running() {
		return in_array( self::state()['status'], array( 'running', 'backoff' ), true );
	}

	/**
	 * Persist the state, stamping the update time.
	 *
	 * @param array<string,mixed> $state State to write.
	 * @return void
	 */
	private static function save( array $state ) {
		$state['updated_at'] = current_time( 'mysql' );
		update_option( self::STATE_OPTION, $state, false );
	}

	/* --------------------------------------------------------------------- */
	/* Work list + preview                                                   */
	/* --------------------------------------------------------------------- */

	/**
	 * Active customers with no Wave link, oldest first — the run's work list.
	 *
	 * Disabled customers are deliberately excluded: a disabled customer is one the
	 * owner has taken out of circulation, and creating it in Wave would resurrect
	 * it there. Recomputed on every batch, which is what makes the run resumable.
	 *
	 * @param int[] $exclude Local customer ids to skip (already tried this run).
	 * @return int[]
	 */
	public static function work_list( array $exclude = array() ) {
		$out = array();

		foreach ( AMAT_Customer_Model::all( array( 'is_active' => 1 ), array( 'orderby' => 'id', 'order' => 'ASC' ) ) as $customer ) {
			$id = (int) $customer['id'];
			if ( in_array( $id, $exclude, true ) ) {
				continue;
			}
			if ( '' === AMAT_Wave_Client::customer_ref( $id ) ) {
				$out[] = $id;
			}
		}

		return $out;
	}

	/**
	 * What a run would do, without doing any of it.
	 *
	 * Matching reads the cached Wave customer list, so this costs one fetch at
	 * most however many customers are pending — cheap enough to run before every
	 * real run, and the only way to see the ambiguous cases in advance.
	 *
	 * @return array{total:int,adopt:int,create:int,ambiguous:int,ambiguous_names:string[]}|WP_Error
	 */
	public function preview() {
		$wave = new AMAT_Wave_Client();
		if ( ! $wave->is_configured() ) {
			return new WP_Error( 'amat_wave_no_token', __( 'Wave is not configured. Add WAVE_API_TOKEN to .env first.', 'auto-mation' ) );
		}

		$customers = $wave->get_customers();
		if ( is_wp_error( $customers ) ) {
			return $customers;
		}

		$provider = new AMAT_Wave_Provider();
		$out      = array( 'total' => 0, 'adopt' => 0, 'create' => 0, 'ambiguous' => 0, 'ambiguous_names' => array() );

		foreach ( self::work_list() as $id ) {
			$customer = AMAT_Customer_Model::find( $id );
			if ( ! $customer ) {
				continue;
			}
			++$out['total'];

			$match = $wave->match_customer( $provider->payload( $customer ), AMAT_Wave_Client::claimed_customer_refs( $id ) );
			if ( is_wp_error( $match ) ) {
				return $match;
			}

			if ( 'unique' === $match['status'] ) {
				++$out['adopt'];
			} elseif ( 'ambiguous' === $match['status'] ) {
				++$out['ambiguous'];
				if ( count( $out['ambiguous_names'] ) < 20 ) {
					$out['ambiguous_names'][] = AMAT_Customer_Model::display_name( $customer );
				}
			} else {
				++$out['create'];
			}
		}

		return $out;
	}

	/* --------------------------------------------------------------------- */
	/* Run control                                                           */
	/* --------------------------------------------------------------------- */

	/**
	 * Begin a run: record the target business + work size and schedule batch one.
	 *
	 * @return array{status:string,message:string}
	 */
	public function start() {
		$wave = new AMAT_Wave_Client();
		if ( ! $wave->is_configured() ) {
			return array( 'status' => 'error', 'message' => __( 'Wave is not configured. Add WAVE_API_TOKEN to .env first.', 'auto-mation' ) );
		}
		if ( self::is_running() ) {
			return array( 'status' => 'error', 'message' => __( 'A mass-link run is already in progress.', 'auto-mation' ) );
		}

		$business = $wave->get_business_id();
		if ( is_wp_error( $business ) ) {
			return array( 'status' => 'error', 'message' => $business->get_error_message() );
		}

		$pending = self::work_list();
		if ( empty( $pending ) ) {
			return array( 'status' => 'error', 'message' => __( 'Every active customer is already linked to Wave — nothing to do.', 'auto-mation' ) );
		}

		$state               = self::blank_state();
		$state['status']     = 'running';
		$state['business']   = (string) $business;
		$state['total']      = count( $pending );
		$state['started_at'] = current_time( 'mysql' );
		self::save( $state );

		AMAT_Log::info(
			self::CHANNEL,
			__( 'Mass-link to Wave started.', 'auto-mation' ),
			array( 'context' => array( 'customers' => count( $pending ), 'business' => (string) $business ) )
		);

		self::schedule_next( 5 );

		/* translators: %d: number of customers queued. */
		return array( 'status' => 'success', 'message' => sprintf( _n( 'Mass-link started for %d customer.', 'Mass-link started for %d customers.', count( $pending ), 'auto-mation' ), count( $pending ) ) );
	}

	/**
	 * Stop a run in progress. What has been linked stays linked — the run is
	 * resumable, so this is a pause the owner can restart, not a rollback.
	 *
	 * @return array{status:string,message:string}
	 */
	public function stop() {
		$state = self::state();
		self::unschedule();

		if ( ! in_array( $state['status'], array( 'running', 'backoff' ), true ) ) {
			return array( 'status' => 'error', 'message' => __( 'No mass-link run is in progress.', 'auto-mation' ) );
		}

		$state['status'] = 'stopped';
		self::save( $state );

		AMAT_Log::info(
			self::CHANNEL,
			__( 'Mass-link to Wave stopped by the owner.', 'auto-mation' ),
			array( 'context' => array( 'processed' => (int) $state['processed'], 'total' => (int) $state['total'] ) )
		);

		return array( 'status' => 'success', 'message' => __( 'Mass-link stopped. Anything already linked stays linked; starting again resumes where it left off.', 'auto-mation' ) );
	}

	/**
	 * Clear the run state entirely (the "dismiss the finished report" action).
	 *
	 * @return void
	 */
	public function reset() {
		self::unschedule();
		delete_option( self::STATE_OPTION );
	}

	/* --------------------------------------------------------------------- */
	/* The batch                                                             */
	/* --------------------------------------------------------------------- */

	/**
	 * Process one batch, then schedule the next (or finish).
	 *
	 * Returns the state it saved, so the tests and a scripted run can drive it
	 * directly instead of waiting on WP-Cron.
	 *
	 * @return array<string,mixed> The state after this batch.
	 */
	public function run_batch() {
		$state = self::state();

		if ( ! in_array( $state['status'], array( 'running', 'backoff' ), true ) ) {
			return $state; // Stopped or finished between scheduling and firing.
		}

		$wave = new AMAT_Wave_Client();
		if ( ! $wave->is_configured() ) {
			return $this->halt( $state, __( 'Wave is no longer configured; the mass-link stopped.', 'auto-mation' ) );
		}

		// Pinned business: if Settings was repointed mid-run, stop rather than push
		// the remainder of the book into a different business.
		$business = $wave->get_business_id();
		if ( is_wp_error( $business ) || (string) $business !== (string) $state['business'] ) {
			return $this->halt( $state, __( 'The Wave target business changed during the run, so the mass-link stopped. Start it again to push the rest to the new business.', 'auto-mation' ) );
		}

		// Anything already tried and parked this run is not work any more.
		$tried   = array_merge( (array) $state['failed'], (array) $state['ambiguous'] );
		$pending = self::work_list( $tried );

		if ( empty( $pending ) ) {
			return $this->finish( $state );
		}

		$state['status'] = 'running';
		$provider        = new AMAT_Wave_Provider();
		$done            = 0;

		foreach ( $pending as $id ) {
			if ( $done >= self::BATCH_SIZE ) {
				break;
			}

			$result = $provider->sync_customer( $id );
			$status = (string) ( $result['status'] ?? 'error' );

			// Rate limited: back off and retry this same customer later. Deliberately
			// not counted as processed or failed — nothing about it was wrong.
			if ( ! empty( $result['rate_limited'] ) ) {
				return $this->back_off( $state, (int) ( $result['retry_after'] ?? 0 ) );
			}

			++$state['processed'];
			++$done;

			switch ( $status ) {
				case 'success':
					$action = (string) ( $result['action'] ?? '' );
					if ( 'created' === $action ) {
						++$state['created'];
					} elseif ( 'adopted' === $action ) {
						++$state['adopted'];
					} else {
						++$state['updated'];
					}
					$state['backoff'] = 0; // A clean call clears the backoff ladder.
					break;

				case 'ambiguous':
					// Several possible Wave matches. Never guessed at in bulk — park it
					// for the customer-detail picker, exactly as auto-sync does.
					self::track( $state['ambiguous'], $id );
					break;

				case 'skipped':
					++$state['skipped'];
					break;

				default:
					self::track( $state['failed'], $id );
					$state['last_error'] = (string) ( $result['message'] ?? '' );
					AMAT_Log::error(
						self::CHANNEL,
						/* translators: %s: error message. */
						sprintf( __( 'Mass-link could not sync this customer: %s', 'auto-mation' ), (string) ( $result['message'] ?? '' ) ),
						array( 'entity_type' => 'customer', 'entity_id' => $id )
					);
					break;
			}

			usleep( self::REQUEST_DELAY_US );
		}

		// More to do? Book the next batch. Otherwise the run is complete.
		$remaining = self::work_list( array_merge( (array) $state['failed'], (array) $state['ambiguous'] ) );
		if ( empty( $remaining ) ) {
			return $this->finish( $state );
		}

		self::save( $state );
		self::schedule_next( self::BATCH_INTERVAL );
		return $state;
	}

	/**
	 * Pause on a rate limit and reschedule further out (doubling each hit).
	 *
	 * @param array<string,mixed> $state       Current state.
	 * @param int                 $retry_after Seconds Wave asked for, 0 if none.
	 * @return array<string,mixed>
	 */
	private function back_off( array $state, $retry_after = 0 ) {
		$previous = (int) $state['backoff'];
		$next     = $previous > 0 ? $previous * 2 : self::BASE_BACKOFF;
		$next     = min( self::MAX_BACKOFF, max( $next, (int) $retry_after ) );

		$state['status']     = 'backoff';
		$state['backoff']    = $next;
		$state['last_error'] = __( 'Wave rate-limited the sync; waiting before continuing.', 'auto-mation' );
		self::save( $state );

		AMAT_Log::warning(
			self::CHANNEL,
			__( 'Wave rate-limited the mass-link; backing off.', 'auto-mation' ),
			array( 'context' => array( 'wait_seconds' => $next, 'processed' => (int) $state['processed'], 'total' => (int) $state['total'] ) )
		);

		self::schedule_next( $next );
		return $state;
	}

	/**
	 * Mark the run complete and report it.
	 *
	 * @param array<string,mixed> $state Current state.
	 * @return array<string,mixed>
	 */
	private function finish( array $state ) {
		$state['status'] = 'done';
		self::unschedule();
		self::save( $state );

		AMAT_Log::info(
			self::CHANNEL,
			__( 'Mass-link to Wave finished.', 'auto-mation' ),
			array(
				'context' => array(
					'processed' => (int) $state['processed'],
					'created'   => (int) $state['created'],
					'adopted'   => (int) $state['adopted'],
					'updated'   => (int) $state['updated'],
					'ambiguous' => count( (array) $state['ambiguous'] ),
					'failed'    => count( (array) $state['failed'] ),
				),
			)
		);

		return $state;
	}

	/**
	 * Stop the run for a reason that isn't the owner's doing.
	 *
	 * @param array<string,mixed> $state   Current state.
	 * @param string              $message Why.
	 * @return array<string,mixed>
	 */
	private function halt( array $state, $message ) {
		$state['status']     = 'stopped';
		$state['last_error'] = $message;
		self::unschedule();
		self::save( $state );

		AMAT_Log::warning( self::CHANNEL, $message, array( 'context' => array( 'processed' => (int) $state['processed'] ) ) );
		return $state;
	}

	/**
	 * Append an id to a tracked list, capped so the option cannot grow unbounded.
	 *
	 * @param array<int,int> $list List to append to (by reference).
	 * @param int            $id   Customer id.
	 * @return void
	 */
	private static function track( array &$list, $id ) {
		if ( count( $list ) < self::MAX_TRACKED_IDS && ! in_array( (int) $id, $list, true ) ) {
			$list[] = (int) $id;
		}
	}

	/* --------------------------------------------------------------------- */
	/* Cron scheduling                                                       */
	/* --------------------------------------------------------------------- */

	/**
	 * Schedule the next batch, replacing any already booked.
	 *
	 * @param int $delay Seconds from now.
	 * @return void
	 */
	private static function schedule_next( $delay ) {
		self::unschedule();
		wp_schedule_single_event( time() + max( 1, (int) $delay ), self::BATCH_HOOK );
	}

	/**
	 * Cancel any pending batch.
	 *
	 * @return void
	 */
	public static function unschedule() {
		wp_clear_scheduled_hook( self::BATCH_HOOK );
	}
}
