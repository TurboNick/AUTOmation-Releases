<?php
/**
 * Wave provider: wires the Wave integration into AUTOmation's extension points.
 *
 * Core fires neutral hooks (e.g. `amat_customer_detail_actions`); this class is
 * the only thing that knows those hooks mean "render Wave UI". It owns all the
 * Wave-specific admin UI + POST handlers and stores links via the generic
 * external_refs API — so the whole integration can later move to a separate
 * companion plugin with no change to core. Admin-only.
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers the Wave integration's hook listeners and handles its POSTs.
 */
class AMAT_Wave_Provider {

	const SYNC_POST_ACTION   = 'sync_customer_wave';
	const SYNC_NONCE         = 'amat_sync_customer_wave';
	const LINK_POST_ACTION   = 'link_customer_wave';
	const LINK_NONCE         = 'amat_link_customer_wave';
	const UNLINK_POST_ACTION = 'unlink_customer_wave';
	const UNLINK_NONCE       = 'amat_unlink_customer_wave';

	/**
	 * This integration's own admin page slug (a "Wave" submenu under AUTOmation).
	 *
	 * @var string
	 */
	const PAGE_SLUG = 'amat-wave';

	/**
	 * Hook suffix of the Wave admin page, for scoping the asset enqueue.
	 *
	 * @var string
	 */
	private $page_hook = '';

	/**
	 * Transient prefix holding ambiguous-match candidates for the current user
	 * between the sync POST and the customer detail that renders the picker.
	 *
	 * @var string
	 */
	const CANDIDATES_TRANSIENT = 'amat_wave_candidates_';

	/**
	 * Hook the provider into core's extension points.
	 *
	 * @return void
	 */
	public function register() {
		add_action( 'admin_init', array( $this, 'maybe_process' ) );
		add_action( 'amat_customer_detail_actions', array( $this, 'render_customer_actions' ) );

		// Estimate/invoice push lives in its own class — this one is already the
		// customer sync + the whole settings page.
		( new AMAT_Wave_Documents() )->register();

		// This integration's own "Wave" submenu under the AUTOmation menu (each
		// integration gets its own page). Priority 20 so it lands after core's items.
		add_action( 'admin_menu', array( $this, 'add_menu' ), 20 );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );

		// Wave settings form handlers (posted to admin-post.php).
		add_action( 'admin_post_amat_save_wave_business', array( $this, 'handle_save_wave_business' ) );
		add_action( 'admin_post_amat_save_wave_products', array( $this, 'handle_save_wave_products' ) );
		add_action( 'admin_post_amat_save_wave_estimate', array( $this, 'handle_save_wave_estimate' ) );
		add_action( 'admin_post_amat_save_wave_sync', array( $this, 'handle_save_wave_sync' ) );
		add_action( 'admin_post_amat_unlink_wave', array( $this, 'handle_unlink_wave' ) );
		add_action( 'admin_post_amat_masslink_wave', array( $this, 'handle_masslink_wave' ) );
		add_action( 'admin_post_amat_import_wave', array( $this, 'handle_import_wave' ) );
	}

	/**
	 * Intercept the provider's own POST actions on admin_init (before output).
	 *
	 * @return void
	 */
	public function maybe_process() {
		if ( isset( $_POST['amat_action'] ) && self::SYNC_POST_ACTION === $_POST['amat_action'] ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce checked in process_wave_sync().
			$this->process_wave_sync();
			return;
		}
		if ( isset( $_POST['amat_action'] ) && self::LINK_POST_ACTION === $_POST['amat_action'] ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce checked in process_wave_link().
			$this->process_wave_link();
			return;
		}
		if ( isset( $_POST['amat_action'] ) && self::UNLINK_POST_ACTION === $_POST['amat_action'] ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce checked in process_wave_unlink().
			$this->process_wave_unlink();
		}
	}

	/* --------------------------------------------------------------------- */
	/* Customer detail: sync UI (rendered via amat_customer_detail_actions)  */
	/* --------------------------------------------------------------------- */

	/**
	 * Render the Wave sync block on a customer's detail view.
	 *
	 * @param array<string,mixed> $customer Customer row.
	 * @return void
	 */
	public function render_customer_actions( array $customer ) {
		$id         = (int) $customer['id'];
		$wave_id    = AMAT_Wave_Client::customer_ref( $id );
		$configured = ( new AMAT_Wave_Client() )->is_configured();
		?>
		<h2><?php esc_html_e( 'Wave', 'auto-mation' ); ?></h2>
		<table class="amat-detail-table">
			<tbody>
				<tr>
					<th><?php esc_html_e( 'Sync status', 'auto-mation' ); ?></th>
					<td>
						<?php if ( '' !== $wave_id ) : ?>
							<?php esc_html_e( 'Synced ✓', 'auto-mation' ); ?>
							<span class="description">
								<?php
								/* translators: %s: Wave customer ID. */
								printf( esc_html__( 'Wave ID: %s', 'auto-mation' ), esc_html( $wave_id ) );
								?>
							</span>
						<?php else : ?>
							<span class="description"><?php esc_html_e( 'Not synced to Wave yet.', 'auto-mation' ); ?></span>
						<?php endif; ?>
					</td>
				</tr>
			</tbody>
		</table>

		<?php
		if ( ! $configured ) {
			echo '<p class="description">' . esc_html__( 'Wave is not configured — add WAVE_API_TOKEN to .env to enable syncing.', 'auto-mation' ) . '</p>';
			return;
		}

		// Ambiguous match: let the owner pick which existing Wave customer to adopt
		// (or create a new one) rather than risk a duplicate against years of history.
		$candidates = $this->take_candidates( $id );
		if ( ! empty( $candidates ) ) {
			$this->candidate_picker( $id, $candidates );
			return;
		}
		?>
		<form method="post" class="amat-inline-form">
			<?php wp_nonce_field( self::SYNC_NONCE ); ?>
			<input type="hidden" name="amat_action" value="<?php echo esc_attr( self::SYNC_POST_ACTION ); ?>" />
			<input type="hidden" name="id" value="<?php echo esc_attr( $id ); ?>" />
			<button type="submit" class="button amat-btn-primary">
				<?php echo '' !== $wave_id ? esc_html__( 'Re-sync to Wave', 'auto-mation' ) : esc_html__( 'Sync to Wave', 'auto-mation' ); ?>
			</button>
		</form>
		<?php if ( '' !== $wave_id ) : ?>
			<form method="post" class="amat-inline-form">
				<?php wp_nonce_field( self::UNLINK_NONCE ); ?>
				<input type="hidden" name="amat_action" value="<?php echo esc_attr( self::UNLINK_POST_ACTION ); ?>" />
				<input type="hidden" name="id" value="<?php echo esc_attr( $id ); ?>" />
				<button type="submit" class="button amat-btn-disable"><?php esc_html_e( 'Unlink from Wave', 'auto-mation' ); ?></button>
			</form>
			<p class="description"><?php esc_html_e( 'Unlink clears this customer\'s stored Wave ID locally (nothing is deleted in Wave). The next sync re-matches or creates fresh — use it to fix a wrong link or duplicate.', 'auto-mation' ); ?></p>
		<?php else : ?>
			<p class="description"><?php esc_html_e( 'Syncing first looks for an existing Wave customer with a matching email, phone, or name and links to it — only creating a new one if there is no strong match.', 'auto-mation' ); ?></p>
		<?php endif; ?>
		<?php
	}

	/**
	 * Clear this customer's stored Wave link (per-customer unlink). Local only —
	 * nothing is deleted in Wave; the next sync re-matches or creates fresh.
	 *
	 * @return void
	 */
	private function process_wave_unlink() {
		check_admin_referer( self::UNLINK_NONCE );
		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'auto-mation' ) );
		}

		$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		if ( $id ) {
			AMAT_External_Ref_Model::forget( 'wave', 'customer', $id );
		}
		$this->flash( array( 'status' => 'success', 'message' => __( 'Unlinked this customer from Wave.', 'auto-mation' ) ) );
		wp_safe_redirect( $this->customer_url( $id ) );
		exit;
	}

	/**
	 * Render the "pick which existing Wave customer to link" UI after an ambiguous
	 * match (radio list + an escape hatch to create a new Wave customer instead).
	 *
	 * @param int                            $id         Local customer id.
	 * @param array<int,array<string,mixed>> $candidates Wave match candidates.
	 * @return void
	 */
	private function candidate_picker( $id, array $candidates ) {
		?>
		<form method="post" class="amat-wave-candidates">
			<?php wp_nonce_field( self::LINK_NONCE ); ?>
			<input type="hidden" name="amat_action" value="<?php echo esc_attr( self::LINK_POST_ACTION ); ?>" />
			<input type="hidden" name="id" value="<?php echo esc_attr( (int) $id ); ?>" />
			<p><strong><?php esc_html_e( 'Possible existing Wave customers:', 'auto-mation' ); ?></strong></p>
			<ul class="amat-wave-candidate-list">
				<?php foreach ( $candidates as $i => $c ) : ?>
					<?php
					$cid     = (string) ( $c['id'] ?? '' );
					$cname   = (string) ( $c['name'] ?? '' );
					$cemail  = (string) ( $c['email'] ?? '' );
					$cphone  = (string) ( $c['phone'] ?? '' );
					$creason = $this->match_reason_label( (string) ( $c['reason'] ?? '' ) );
					$contact = trim( implode( ' · ', array_filter( array( $cemail, $cphone ) ) ) );
					?>
					<li>
						<label>
							<input type="radio" name="wave_match_id" value="<?php echo esc_attr( $cid ); ?>" <?php checked( 0, (int) $i ); ?> />
							<strong><?php echo esc_html( '' !== $cname ? $cname : $cid ); ?></strong>
							<?php if ( '' !== $contact ) : ?><span class="description"><?php echo esc_html( $contact ); ?></span><?php endif; ?>
							<span class="amat-badge">
								<?php
								/* translators: %s: what matched (email, phone, or name). */
								printf( esc_html__( 'matched %s', 'auto-mation' ), esc_html( $creason ) );
								?>
							</span>
						</label>
					</li>
				<?php endforeach; ?>
			</ul>
			<?php submit_button( __( 'Link selected customer', 'auto-mation' ), 'primary', 'submit', false ); ?>
		</form>

		<form method="post" class="amat-inline-form">
			<?php wp_nonce_field( self::SYNC_NONCE ); ?>
			<input type="hidden" name="amat_action" value="<?php echo esc_attr( self::SYNC_POST_ACTION ); ?>" />
			<input type="hidden" name="id" value="<?php echo esc_attr( (int) $id ); ?>" />
			<input type="hidden" name="force_create" value="1" />
			<?php submit_button( __( 'None of these — create new in Wave', 'auto-mation' ), 'secondary', 'submit', false ); ?>
		</form>
		<?php
	}

	/* --------------------------------------------------------------------- */
	/* POST handlers                                                         */
	/* --------------------------------------------------------------------- */

	/**
	 * Push one customer to Wave (create if new, patch if already linked). Adopts an
	 * existing Wave customer by email/phone/name rather than duplicating; an
	 * ambiguous match defers to a picker shown on the customer detail.
	 *
	 * @return void
	 */
	private function process_wave_sync() {
		check_admin_referer( self::SYNC_NONCE );
		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'auto-mation' ) );
		}

		$id       = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		$result   = $this->sync_customer( $id, ! empty( $_POST['force_create'] ) );
		$redirect = $this->customer_url( $id );

		// An ambiguous match isn't a failure — stash the candidates so the customer
		// detail can render the picker, and prompt the owner to choose.
		if ( 'ambiguous' === $result['status'] ) {
			$this->set_candidates( $id, $result['candidates'] );
			$this->flash( array( 'status' => 'error', 'message' => $result['message'] ) );
			wp_safe_redirect( $redirect );
			exit;
		}

		$this->flash(
			array(
				'status'  => 'success' === $result['status'] ? 'success' : 'error',
				'message' => $result['message'],
			)
		);
		wp_safe_redirect( $redirect );
		exit;
	}

	/**
	 * Push one customer to Wave (create if new, patch if already linked), adopting
	 * an existing Wave customer by email/phone/name rather than duplicating. Pure of
	 * the request lifecycle (no nonce/redirect/flash/exit) so the button handler,
	 * auto-sync and the retry cron can all call it.
	 *
	 * Returns one of:
	 *   - status 'success'   → created/updated/adopted; message describes which.
	 *   - status 'ambiguous' → several possible Wave matches; 'candidates' carries
	 *                          them for the picker. The owner must decide — auto-sync
	 *                          cannot, and deliberately does not guess (no duplicates
	 *                          against years of Wave history).
	 *   - status 'error'     → a Wave API failure; 'retryable' is true.
	 *   - status 'skipped'   → a precondition (not configured); not retryable.
	 *
	 * @param int  $id           Customer id.
	 * @param bool $force_create Skip the match step and create a fresh Wave customer.
	 * @return array{status:string,message:string,retryable?:bool,candidates?:array<int,array<string,mixed>>}
	 */
	public function sync_customer( $id, $force_create = false ) {
		$id       = (int) $id;
		$customer = $id ? AMAT_Customer_Model::find( $id ) : null;

		if ( ! $customer ) {
			return array( 'status' => 'error', 'message' => __( 'Customer not found.', 'auto-mation' ), 'retryable' => false );
		}

		$wave = new AMAT_Wave_Client();
		if ( ! $wave->is_configured() ) {
			return array( 'status' => 'skipped', 'message' => __( 'Wave is not configured. Add WAVE_API_TOKEN to .env first.', 'auto-mation' ), 'retryable' => false );
		}

		$payload  = $this->payload( $customer );
		$existing = AMAT_Wave_Client::customer_ref( $id );

		// Already linked → patch that record in place.
		if ( '' !== $existing ) {
			$result = $wave->update_customer( $existing, $payload );
			if ( is_wp_error( $result ) ) {
				/* translators: %s: Wave error message. */
				return $this->error_result( sprintf( __( 'Wave sync failed: %s', 'auto-mation' ), $result->get_error_message() ), $result );
			}
			// Re-affirm the link so a previously 'failed' ref reads 'synced' again.
			AMAT_Wave_Client::set_customer_ref( $id, $existing );
			return array( 'status' => 'success', 'action' => 'updated', 'message' => __( 'Customer updated in Wave.', 'auto-mation' ) );
		}

		// Unlinked. Unless "create new anyway" was chosen, look for an existing Wave
		// customer to adopt — never create a duplicate against years of history.
		if ( ! $force_create ) {
			// Never offer a Wave customer another local record already owns.
			$match = $wave->match_customer( $payload, AMAT_Wave_Client::claimed_customer_refs( $id ) );
			if ( is_wp_error( $match ) ) {
				/* translators: %s: Wave error message. */
				return $this->error_result( sprintf( __( 'Could not check Wave for existing customers: %s. Nothing was changed — try again.', 'auto-mation' ), $match->get_error_message() ), $match );
			}

			if ( 'unique' === $match['status'] ) {
				$wave_id = (string) $match['match'];
				$patch   = $wave->update_customer( $wave_id, $payload );
				if ( is_wp_error( $patch ) ) {
					/* translators: %s: Wave error message. */
					return $this->error_result( sprintf( __( 'Wave sync failed: %s', 'auto-mation' ), $patch->get_error_message() ), $patch );
				}
				AMAT_Wave_Client::set_customer_ref( $id, $wave_id );
				return array(
					'status'  => 'success',
					'action'  => 'adopted',
					/* translators: %s: what matched (email, phone, or name). */
					'message' => sprintf( __( 'Linked to an existing Wave customer (matched on %s) and updated it.', 'auto-mation' ), $this->match_reason_label( $match['reason'] ) ),
				);
			}

			if ( 'ambiguous' === $match['status'] ) {
				return array(
					'status'     => 'ambiguous',
					'message'    => __( 'Found more than one possible match in Wave. Pick the right customer to link, or create a new one.', 'auto-mation' ),
					'candidates' => $match['candidates'],
				);
			}
		}

		// No match (or the owner chose to create new anyway) → create fresh.
		$result = $wave->create_customer( $payload );
		if ( is_wp_error( $result ) ) {
			/* translators: %s: Wave error message. */
			return $this->error_result( sprintf( __( 'Wave sync failed: %s', 'auto-mation' ), $result->get_error_message() ), $result );
		}
		if ( is_string( $result ) && '' !== $result ) {
			AMAT_Wave_Client::set_customer_ref( $id, $result );
		}
		return array( 'status' => 'success', 'action' => 'created', 'message' => __( 'Customer created in Wave.', 'auto-mation' ) );
	}

	/**
	 * Shape a retryable error result, carrying the HTTP status through.
	 *
	 * The status is what lets a caller tell "Wave is rate-limiting us" from "that
	 * mutation was wrong" — the mass-link pauses on the former and records the
	 * latter. Flattening the WP_Error to a message string (as this used to) threw
	 * that away.
	 *
	 * @param string $message Human-readable message.
	 * @param mixed  $error   The WP_Error behind it.
	 * @return array{status:string,message:string,retryable:bool,error_code:string,http_status:int,rate_limited:bool,retry_after:int}
	 */
	private function error_result( $message, $error ) {
		return array(
			'status'       => 'error',
			'message'      => $message,
			'retryable'    => true,
			'error_code'   => is_wp_error( $error ) ? (string) $error->get_error_code() : '',
			'http_status'  => AMAT_Wave_Client::http_status( $error ),
			// A flag, not a status comparison: Wave signals a rate limit through the
			// message as well as (instead of) a 429 — see is_rate_limited().
			'rate_limited' => AMAT_Wave_Client::is_rate_limited( $error ),
			'retry_after'  => AMAT_Wave_Client::retry_after( $error ),
		);
	}

	/**
	 * Adopt a specific existing Wave customer the owner picked: store its ID + patch.
	 *
	 * @return void
	 */
	private function process_wave_link() {
		check_admin_referer( self::LINK_NONCE );
		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'auto-mation' ) );
		}

		$id       = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		$wave_id  = isset( $_POST['wave_match_id'] ) ? sanitize_text_field( wp_unslash( $_POST['wave_match_id'] ) ) : '';
		$customer = $id ? AMAT_Customer_Model::find( $id ) : null;
		$redirect = $this->customer_url( $id );

		$fail = function ( $message ) use ( $redirect ) {
			$this->flash( array( 'status' => 'error', 'message' => $message ) );
			wp_safe_redirect( $redirect );
			exit;
		};

		if ( ! $customer ) {
			$fail( __( 'Customer not found.', 'auto-mation' ) );
		}
		if ( '' === $wave_id ) {
			$fail( __( 'Choose a Wave customer to link.', 'auto-mation' ) );
		}

		$wave = new AMAT_Wave_Client();
		if ( ! $wave->is_configured() ) {
			$fail( __( 'Wave is not configured. Add WAVE_API_TOKEN to .env first.', 'auto-mation' ) );
		}

		$patch = $wave->update_customer( $wave_id, $this->payload( $customer ) );
		if ( is_wp_error( $patch ) ) {
			/* translators: %s: Wave error message. */
			$fail( sprintf( __( 'Could not link to that Wave customer: %s', 'auto-mation' ), $patch->get_error_message() ) );
		}

		AMAT_Wave_Client::set_customer_ref( $id, $wave_id );
		$this->flash( array( 'status' => 'success', 'message' => __( 'Linked to the chosen Wave customer and updated it.', 'auto-mation' ) ) );
		wp_safe_redirect( $redirect );
		exit;
	}

	/* --------------------------------------------------------------------- */
	/* Helpers                                                               */
	/* --------------------------------------------------------------------- */

	/**
	 * Assemble the brand-neutral payload pushed to Wave for a customer: computed
	 * display name, first email/text/call contact methods, billing address. The
	 * contact first/last name is sent only when the display name is a custom value
	 * (so Wave does not show the name twice on documents); empty otherwise so a
	 * re-sync clears a stale contact name.
	 *
	 * Public because the mass-link preview needs to ask "what would this match on
	 * in Wave?" without pushing anything.
	 *
	 * @param array<string,mixed> $customer Customer row.
	 * @return array<string,mixed>
	 */
	public function payload( array $customer ) {
		$id = (int) ( $customer['id'] ?? 0 );

		$has_custom_name = '' !== trim( (string) ( $customer['display_name'] ?? '' ) );
		$payload         = array(
			'name'      => AMAT_Customer_Model::display_name( $customer ),
			'firstName' => $has_custom_name ? (string) ( $customer['first_name'] ?? '' ) : '',
			'lastName'  => $has_custom_name ? (string) ( $customer['last_name'] ?? '' ) : '',
		);

		// Map our contact methods onto Wave's email/phone/mobile (first of each wins).
		// Wave has no "both" field, so a text-primary number (TXT/Call) → mobile and
		// a call-primary number (Call/TXT, Call Only) → phone.
		foreach ( AMAT_Contact_Method_Model::for_customer( $id ) as $method ) {
			$type  = (string) ( $method['type'] ?? '' );
			$value = (string) ( $method['value'] ?? '' );
			if ( 'email' === $type && empty( $payload['email'] ) ) {
				$payload['email'] = $value;
			} elseif ( 'text_call' === $type && empty( $payload['mobile'] ) ) {
				$payload['mobile'] = AMAT_Contact_Method_Types::format( $type, $value );
			} elseif ( in_array( $type, array( 'call_text', 'call_only' ), true ) && empty( $payload['phone'] ) ) {
				$payload['phone'] = AMAT_Contact_Method_Types::format( $type, $value );
			}
		}

		$billing = AMAT_Location_Model::billing_for_customer( $id );
		if ( $billing ) {
			$payload['address'] = array(
				'line1'  => (string) ( $billing['street_1'] ?? '' ),
				'line2'  => (string) ( $billing['street_2'] ?? '' ),
				'city'   => (string) ( $billing['city'] ?? '' ),
				'state'  => (string) ( $billing['state'] ?? '' ),
				'postal' => (string) ( $billing['zipcode'] ?? '' ),
			);
		}

		return $payload;
	}

	/**
	 * Human label for what a Wave match keyed on. Accepts a comma-joined list of
	 * field keys (e.g. "email,phone") and renders "email & phone".
	 *
	 * @param string $reason One or more of 'email'/'phone'/'name', comma-joined.
	 * @return string
	 */
	private function match_reason_label( $reason ) {
		$map   = array(
			'email' => __( 'email', 'auto-mation' ),
			'phone' => __( 'phone', 'auto-mation' ),
			'name'  => __( 'name', 'auto-mation' ),
		);
		$parts = array();
		foreach ( explode( ',', (string) $reason ) as $key ) {
			$key = trim( $key );
			if ( '' !== $key ) {
				$parts[] = $map[ $key ] ?? $key;
			}
		}
		return $parts ? implode( __( ' & ', 'auto-mation' ), $parts ) : __( 'name', 'auto-mation' );
	}

	/**
	 * URL of a customer's detail view.
	 *
	 * @param int $id Customer id.
	 * @return string
	 */
	private function customer_url( $id ) {
		return add_query_arg(
			array( 'page' => AMAT_Customers_Page::PAGE_SLUG, 'action' => 'view', 'id' => (int) $id ),
			admin_url( 'admin.php' )
		);
	}

	/**
	 * Flash a one-shot notice onto the customer detail page (same transient shape
	 * AMAT_Admin_Page::take_flash() reads).
	 *
	 * @param array{status:string,message:string} $payload Notice.
	 * @return void
	 */
	private function flash( array $payload ) {
		set_transient( 'amat_flash_' . AMAT_Customers_Page::PAGE_SLUG . '_' . get_current_user_id(), $payload, MINUTE_IN_SECONDS );
	}

	/**
	 * Stash ambiguous-match candidates for the current user + customer.
	 *
	 * @param int                            $customer_id Customer id.
	 * @param array<int,array<string,mixed>> $candidates  Candidate rows.
	 * @return void
	 */
	private function set_candidates( $customer_id, array $candidates ) {
		set_transient(
			self::CANDIDATES_TRANSIENT . get_current_user_id(),
			array( 'customer_id' => (int) $customer_id, 'list' => $candidates ),
			MINUTE_IN_SECONDS
		);
	}

	/**
	 * Read + clear the stashed candidates, but only for the given customer.
	 *
	 * @param int $customer_id Customer id.
	 * @return array<int,array<string,mixed>>
	 */
	private function take_candidates( $customer_id ) {
		$key    = self::CANDIDATES_TRANSIENT . get_current_user_id();
		$stored = get_transient( $key );
		delete_transient( $key );
		if ( is_array( $stored ) && (int) ( $stored['customer_id'] ?? 0 ) === (int) $customer_id && is_array( $stored['list'] ?? null ) ) {
			return $stored['list'];
		}
		return array();
	}

	/* --------------------------------------------------------------------- */
	/* Wave admin page (its own submenu under the AUTOmation menu)           */
	/* --------------------------------------------------------------------- */

	/**
	 * Register the "Wave" submenu under the AUTOmation menu.
	 *
	 * @return void
	 */
	public function add_menu() {
		// page_title stays "Wave"; the menu label is indented (↳) to read as a child
		// of Settings, which it sits directly beneath (registered after core's menu).
		$this->page_hook = (string) add_submenu_page(
			AMAT_Admin::MENU_SLUG,
			__( 'Wave', 'auto-mation' ),
			__( '↳ Wave', 'auto-mation' ),
			AMAT_Admin::CAPABILITY,
			self::PAGE_SLUG,
			array( $this, 'render_settings_page' )
		);
	}

	/**
	 * Enqueue core's admin stylesheet on the Wave page (it isn't one of core's
	 * own page hooks, so core won't enqueue there). No JS is needed here.
	 *
	 * @param string $hook Current admin page hook suffix.
	 * @return void
	 */
	public function enqueue_assets( $hook ) {
		if ( '' === $this->page_hook || $hook !== $this->page_hook ) {
			return;
		}
		wp_enqueue_style( 'amat-admin', AMAT_PLUGIN_URL . 'assets/admin.css', array(), AMAT_VERSION );
	}

	/**
	 * Render the Wave settings page: connection/token status plus the business,
	 * product, estimate, unlink, and CSV-import controls.
	 *
	 * @return void
	 */
	public function render_settings_page() {
		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'auto-mation' ) );
		}

		$has_token = '' !== AMAT_Env::get( 'WAVE_API_TOKEN' );
		$notice    = $this->take_settings_notice();
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Wave (waveapps)', 'auto-mation' ); ?></h1>

			<?php if ( $notice ) : ?>
				<div class="notice notice-<?php echo esc_attr( $notice['type'] ); ?> is-dismissible"><p><?php echo esc_html( $notice['message'] ); ?></p></div>
			<?php endif; ?>

			<p>
				<?php esc_html_e( 'The Wave Full Access Token is read from a WAVE_API_TOKEN constant in wp-config.php, a server environment variable, or — on a development machine only — a git-ignored .env in this plugin\'s folder. It is never stored in the database.', 'auto-mation' ); ?>
			</p>
			<p>
				<strong><?php esc_html_e( 'Token status:', 'auto-mation' ); ?></strong>
				<?php
				echo $has_token
					? esc_html__( 'Detected ✓', 'auto-mation' )
					: esc_html__( 'Not configured — add define( \'WAVE_API_TOKEN\', \'…\' ); to wp-config.php.', 'auto-mation' );
				?>
			</p>

			<?php
			// A token coming from the plugin's own .env is one update away from being
			// deleted. Say so here rather than letting it fail silently later, which
			// is exactly how the 2026-08-17 outage presented (it looked like Wave was
			// down, not like a missing file).
			if ( $has_token && ! defined( 'WAVE_API_TOKEN' ) && false === getenv( 'WAVE_API_TOKEN' ) ) :
				?>
				<div class="notice notice-warning inline">
					<p>
						<strong><?php esc_html_e( 'This token will be lost on the next plugin update.', 'auto-mation' ); ?></strong>
						<?php esc_html_e( 'It is coming from a .env file inside this plugin\'s folder, and a WordPress update replaces that whole folder. On a live site, move it to wp-config.php: define( \'WAVE_API_TOKEN\', \'your-token\' );', 'auto-mation' ); ?>
					</p>
				</div>
				<?php
			endif;
			?>
			<?php
			$this->render_wave_sync_mode();
			$this->render_wave_business( $has_token );
			$this->render_wave_products( $has_token );
			$this->render_wave_estimate_settings();
			$this->render_wave_mass_link( $has_token );
			$this->render_wave_unlink();
			$this->render_wave_import();
			?>
		</div>
		<?php
	}

	/**
	 * Redirect to the Wave page and exit (after a Wave settings POST), where this
	 * provider's sections + the settings notice are shown.
	 *
	 * @return void
	 */
	private function redirect_to_settings() {
		wp_safe_redirect( add_query_arg( array( 'page' => self::PAGE_SLUG ), admin_url( 'admin.php' ) ) );
		exit;
	}

	/**
	 * Stash a one-shot notice for the current user, read by the Wave page.
	 *
	 * @param string $type    'success' or 'error'.
	 * @param string $message Notice text.
	 * @return void
	 */
	private function set_settings_notice( $type, $message ) {
		set_transient(
			'amaw_notice_' . get_current_user_id(),
			array( 'type' => ( 'error' === $type ? 'error' : 'success' ), 'message' => $message ),
			MINUTE_IN_SECONDS
		);
	}

	/**
	 * Read and clear this integration's one-shot notice, if any.
	 *
	 * @return array{type:string,message:string}|null
	 */
	private function take_settings_notice() {
		$key     = 'amaw_notice_' . get_current_user_id();
		$payload = get_transient( $key );
		if ( false === $payload ) {
			return null;
		}
		delete_transient( $key );
		return is_array( $payload ) ? $payload : null;
	}

	/* --------------------------------------------------------------------- */
	/* Wave business picker (Settings)                                       */
	/* --------------------------------------------------------------------- */

	/**
	 * Render the Wave business picker: which business on the token's account the
	 * plugin syncs to. Without an explicit choice the client auto-picks the first
	 * business, which is wrong on a multi-business account — this makes the target
	 * a deliberate, visible choice. No-op when no token is configured.
	 *
	 * @param bool $has_token Whether a Wave token is present.
	 * @return void
	 */
	private function render_wave_business( $has_token ) {
		if ( ! $has_token ) {
			return;
		}

		$wave       = new AMAT_Wave_Client();
		$chosen     = (string) get_option( AMAT_Wave_Client::BUSINESS_ID_OPTION, '' );
		$businesses = $wave->get_businesses();
		?>
		<h3><?php esc_html_e( 'Business', 'auto-mation' ); ?></h3>

		<?php if ( is_wp_error( $businesses ) ) : ?>
			<p class="amat-danger-text">
				<?php
				/* translators: %s: Wave error message. */
				printf( esc_html__( 'Could not load businesses from Wave: %s', 'auto-mation' ), esc_html( $businesses->get_error_message() ) );
				?>
			</p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'amat_save_wave_business' ); ?>
				<input type="hidden" name="action" value="amat_save_wave_business" />
				<?php submit_button( __( 'Retry', 'auto-mation' ), 'secondary', 'refresh_businesses', false ); ?>
			</form>
		<?php elseif ( empty( $businesses ) ) : ?>
			<p class="description"><?php esc_html_e( 'No businesses found on this Wave account.', 'auto-mation' ); ?></p>
		<?php else : ?>
			<?php
			// Resolve the active target for the status line: the explicit choice,
			// or the first business when auto-picking.
			$active_id   = '' !== $chosen ? $chosen : $businesses[0]['id'];
			$active_name = '';
			foreach ( $businesses as $business ) {
				if ( $business['id'] === $active_id ) {
					$active_name = $business['name'];
					break;
				}
			}
			?>
			<p>
				<strong><?php esc_html_e( 'Currently syncing to:', 'auto-mation' ); ?></strong>
				<?php echo esc_html( '' !== $active_name ? $active_name : $active_id ); ?>
				<?php if ( '' === $chosen ) : ?>
					<span class="description"><?php esc_html_e( '(auto-selected first business — choose one below to be sure)', 'auto-mation' ); ?></span>
				<?php endif; ?>
			</p>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'amat_save_wave_business' ); ?>
				<input type="hidden" name="action" value="amat_save_wave_business" />
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="amat-wave-business"><?php esc_html_e( 'Sync to business', 'auto-mation' ); ?></label></th>
						<td>
							<select name="wave_business_id" id="amat-wave-business">
								<option value="" <?php selected( '', $chosen ); ?>><?php esc_html_e( '— Auto (first business) —', 'auto-mation' ); ?></option>
								<?php foreach ( $businesses as $business ) : ?>
									<option value="<?php echo esc_attr( $business['id'] ); ?>" <?php selected( $business['id'], $chosen ); ?>>
										<?php echo esc_html( $business['name'] ); ?>
									</option>
								<?php endforeach; ?>
							</select>
							<p class="description"><?php esc_html_e( 'Customers and (later) estimates/invoices sync to this business.', 'auto-mation' ); ?></p>
						</td>
					</tr>
				</table>
				<?php submit_button( __( 'Save business', 'auto-mation' ), 'primary', 'submit', false ); ?>
				<?php submit_button( __( 'Refresh list from Wave', 'auto-mation' ), 'secondary', 'refresh_businesses', false ); ?>
			</form>
		<?php endif; ?>
		<?php
	}

	/**
	 * Save the chosen Wave business (or refresh the cached list).
	 *
	 * @return void
	 */
	public function handle_save_wave_business() {
		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'auto-mation' ) );
		}
		check_admin_referer( 'amat_save_wave_business' );

		$wave = new AMAT_Wave_Client();

		// The "Refresh list" / "Retry" button just drops the cache and refetches.
		if ( isset( $_POST['refresh_businesses'] ) ) {
			$wave->clear_business_cache();
			$wave->get_businesses( true );
			$this->set_settings_notice( 'success', __( 'Business list refreshed from Wave.', 'auto-mation' ) );
			$this->redirect_to_settings();
		}

		$chosen = isset( $_POST['wave_business_id'] ) ? sanitize_text_field( wp_unslash( $_POST['wave_business_id'] ) ) : '';

		// Validate a non-empty choice against the account's actual businesses.
		if ( '' !== $chosen ) {
			$list  = $wave->get_businesses();
			$valid = false;
			if ( ! is_wp_error( $list ) ) {
				foreach ( $list as $business ) {
					if ( $business['id'] === $chosen ) {
						$valid = true;
						break;
					}
				}
			}
			if ( ! $valid ) {
				$this->set_settings_notice( 'error', __( 'That business was not found on your Wave account.', 'auto-mation' ) );
				$this->redirect_to_settings();
			}
		}

		update_option( AMAT_Wave_Client::BUSINESS_ID_OPTION, $chosen, false );
		$wave->clear_business_cache();

		if ( '' === $chosen ) {
			$this->set_settings_notice( 'success', __( 'Reverted to auto-selecting the first business.', 'auto-mation' ) );
			$this->redirect_to_settings();
		}

		$name = $wave->get_business_name( $chosen );
		$this->set_settings_notice(
			'success',
			'' !== $name
				/* translators: %s: business name. */
				? sprintf( __( 'Now syncing to "%s".', 'auto-mation' ), $name )
				: __( 'Wave business saved.', 'auto-mation' )
		);
		$this->redirect_to_settings();
	}

	/* --------------------------------------------------------------------- */
	/* Sync mode (Manual / Automatic)                                        */
	/* --------------------------------------------------------------------- */

	/**
	 * Render the sync-mode chooser: whether Wave pushes fire only on a button
	 * click (Manual, the default) or also automatically when a record is saved
	 * (Automatic), which additionally retries failed pushes on a schedule. Purely
	 * local (no Wave API call), so it shows regardless of token state.
	 *
	 * @return void
	 */
	private function render_wave_sync_mode() {
		$mode = AMAT_Wave_Client::sync_mode();
		?>
		<h3><?php esc_html_e( 'Sync mode', 'auto-mation' ); ?></h3>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<?php wp_nonce_field( 'amat_save_wave_sync' ); ?>
			<input type="hidden" name="action" value="amat_save_wave_sync" />
			<fieldset>
				<label style="display:block; margin-bottom:.4em;">
					<input type="radio" name="wave_sync_mode" value="<?php echo esc_attr( AMAT_Wave_Client::SYNC_MODE_MANUAL ); ?>" <?php checked( AMAT_Wave_Client::SYNC_MODE_MANUAL, $mode ); ?> />
					<strong><?php esc_html_e( 'Manual', 'auto-mation' ); ?></strong>
					<span class="description"><?php esc_html_e( 'Nothing syncs on its own — push customers, estimates and invoices with the Sync/Push buttons. (Default.)', 'auto-mation' ); ?></span>
				</label>
				<label style="display:block;">
					<input type="radio" name="wave_sync_mode" value="<?php echo esc_attr( AMAT_Wave_Client::SYNC_MODE_AUTO ); ?>" <?php checked( AMAT_Wave_Client::SYNC_MODE_AUTO, $mode ); ?> />
					<strong><?php esc_html_e( 'Automatic', 'auto-mation' ); ?></strong>
					<span class="description"><?php esc_html_e( 'Also push a record to Wave shortly after it is saved, and retry any failed push hourly. The buttons still work too.', 'auto-mation' ); ?></span>
				</label>
			</fieldset>
			<p class="description">
				<?php esc_html_e( 'Automatic pushes happen in the background just after a save (not during it), so a slow or failing Wave call never blocks your work. A customer with several possible Wave matches is left for you to resolve by hand — automatic sync never guesses which existing Wave customer to link.', 'auto-mation' ); ?>
			</p>
			<?php submit_button( __( 'Save sync mode', 'auto-mation' ), 'primary', 'submit', false ); ?>
		</form>
		<?php
	}

	/**
	 * Save the sync mode (manual/auto). Any unrecognized value falls back to manual.
	 *
	 * @return void
	 */
	public function handle_save_wave_sync() {
		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'auto-mation' ) );
		}
		check_admin_referer( 'amat_save_wave_sync' );

		$mode = isset( $_POST['wave_sync_mode'] ) ? sanitize_key( wp_unslash( $_POST['wave_sync_mode'] ) ) : '';
		$mode = ( AMAT_Wave_Client::SYNC_MODE_AUTO === $mode ) ? AMAT_Wave_Client::SYNC_MODE_AUTO : AMAT_Wave_Client::SYNC_MODE_MANUAL;

		update_option( AMAT_Wave_Client::SYNC_MODE_OPTION, $mode, false );

		$this->set_settings_notice(
			'success',
			AMAT_Wave_Client::SYNC_MODE_AUTO === $mode
				? __( 'Sync mode set to Automatic — records will push to Wave shortly after they are saved.', 'auto-mation' )
				: __( 'Sync mode set to Manual — use the Sync/Push buttons to send to Wave.', 'auto-mation' )
		);
		$this->redirect_to_settings();
	}

	/* --------------------------------------------------------------------- */
	/* Wave estimate settings                                                */
	/* --------------------------------------------------------------------- */

	/**
	 * Render the estimate settings: how many days out a new estimate's "valid
	 * until" date is set. Purely local (no Wave API call), so it shows regardless
	 * of token state.
	 *
	 * @return void
	 */
	private function render_wave_estimate_settings() {
		$days = AMAT_Wave_Client::estimate_expiry_days();
		?>
		<h3><?php esc_html_e( 'Estimates', 'auto-mation' ); ?></h3>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<?php wp_nonce_field( 'amat_save_wave_estimate' ); ?>
			<input type="hidden" name="action" value="amat_save_wave_estimate" />
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="amat-wave-estimate-expiry"><?php esc_html_e( 'Estimate valid for', 'auto-mation' ); ?></label></th>
					<td>
						<input type="number" name="estimate_expiry_days" id="amat-wave-estimate-expiry" class="small-text" min="1" max="365" step="1" value="<?php echo esc_attr( $days ); ?>" />
						<?php esc_html_e( 'days', 'auto-mation' ); ?>
						<p class="description"><?php esc_html_e( 'A new estimate\'s "valid until" date is set this many days after it is created (1–365). Default 30.', 'auto-mation' ); ?></p>
					</td>
				</tr>
			</table>
			<?php submit_button( __( 'Save estimate settings', 'auto-mation' ), 'primary', 'submit', false ); ?>
		</form>
		<?php
	}

	/**
	 * Save the estimate validity window (days), clamped to 1–365.
	 *
	 * @return void
	 */
	public function handle_save_wave_estimate() {
		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'auto-mation' ) );
		}
		check_admin_referer( 'amat_save_wave_estimate' );

		$days = isset( $_POST['estimate_expiry_days'] ) ? absint( wp_unslash( $_POST['estimate_expiry_days'] ) ) : 0;
		if ( $days < 1 ) {
			$days = AMAT_Wave_Client::DEFAULT_ESTIMATE_EXPIRY_DAYS;
		}
		$days = min( $days, 365 );

		update_option( AMAT_Wave_Client::ESTIMATE_EXPIRY_DAYS_OPTION, $days, false );

		$this->set_settings_notice(
			'success',
			/* translators: %d: number of days. */
			sprintf( _n( 'Estimates now valid for %d day.', 'Estimates now valid for %d days.', $days, 'auto-mation' ), $days )
		);
		$this->redirect_to_settings();
	}

	/* --------------------------------------------------------------------- */
	/* Wave parent-product pickers (Settings)                                */
	/* --------------------------------------------------------------------- */

	/**
	 * Render the Wave parent-product pickers: the existing Wave products that
	 * service lines and part lines reference on estimates/invoices. AUTOmation does
	 * not create per-item products — each line books to the chosen parent product
	 * with the item's name as the line description. No-op when no token is set.
	 *
	 * @param bool $has_token Whether a Wave token is present.
	 * @return void
	 */
	private function render_wave_products( $has_token ) {
		if ( ! $has_token ) {
			return;
		}

		$wave         = new AMAT_Wave_Client();
		$svc_chosen   = (string) get_option( AMAT_Wave_Client::SERVICE_PRODUCT_OPTION, '' );
		$parts_chosen = (string) get_option( AMAT_Wave_Client::PARTS_PRODUCT_OPTION, '' );
		$products     = $wave->get_products();
		?>
		<h3><?php esc_html_e( 'Estimate line products', 'auto-mation' ); ?></h3>
		<p class="description"><?php esc_html_e( 'Services and parts are not created as products in Wave. Pick the existing Wave product each kind of line should book to — the AUTOmation item name becomes the line description.', 'auto-mation' ); ?></p>

		<?php if ( is_wp_error( $products ) ) : ?>
			<p class="amat-danger-text">
				<?php
				/* translators: %s: Wave error message. */
				printf( esc_html__( 'Could not load products from Wave: %s', 'auto-mation' ), esc_html( $products->get_error_message() ) );
				?>
			</p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'amat_save_wave_products' ); ?>
				<input type="hidden" name="action" value="amat_save_wave_products" />
				<?php submit_button( __( 'Retry', 'auto-mation' ), 'secondary', 'refresh_products', false ); ?>
			</form>
		<?php elseif ( empty( $products ) ) : ?>
			<p class="description"><?php esc_html_e( 'No products found on this Wave business. Create the products you want to use (e.g. "Labor", "Parts") in Wave first, then refresh.', 'auto-mation' ); ?></p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'amat_save_wave_products' ); ?>
				<input type="hidden" name="action" value="amat_save_wave_products" />
				<?php submit_button( __( 'Refresh list from Wave', 'auto-mation' ), 'secondary', 'refresh_products', false ); ?>
			</form>
		<?php else : ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'amat_save_wave_products' ); ?>
				<input type="hidden" name="action" value="amat_save_wave_products" />
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="amat-wave-service-product"><?php esc_html_e( 'Services book to', 'auto-mation' ); ?></label></th>
						<td>
							<select name="wave_service_product_id" id="amat-wave-service-product">
								<option value=""><?php esc_html_e( '— Not set —', 'auto-mation' ); ?></option>
								<?php foreach ( $products as $product ) : ?>
									<option value="<?php echo esc_attr( $product['id'] ); ?>" <?php selected( $product['id'], $svc_chosen ); ?>>
										<?php echo esc_html( $product['name'] ); ?>
									</option>
								<?php endforeach; ?>
							</select>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="amat-wave-parts-product"><?php esc_html_e( 'Parts book to', 'auto-mation' ); ?></label></th>
						<td>
							<select name="wave_parts_product_id" id="amat-wave-parts-product">
								<option value=""><?php esc_html_e( '— Not set —', 'auto-mation' ); ?></option>
								<?php foreach ( $products as $product ) : ?>
									<option value="<?php echo esc_attr( $product['id'] ); ?>" <?php selected( $product['id'], $parts_chosen ); ?>>
										<?php echo esc_html( $product['name'] ); ?>
									</option>
								<?php endforeach; ?>
							</select>
						</td>
					</tr>
				</table>
				<?php submit_button( __( 'Save products', 'auto-mation' ), 'primary', 'submit', false ); ?>
				<?php submit_button( __( 'Refresh list from Wave', 'auto-mation' ), 'secondary', 'refresh_products', false ); ?>
			</form>
		<?php endif; ?>
		<?php
	}

	/**
	 * Save the chosen Wave parent products (or refresh the cached product list).
	 *
	 * @return void
	 */
	public function handle_save_wave_products() {
		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'auto-mation' ) );
		}
		check_admin_referer( 'amat_save_wave_products' );

		$wave = new AMAT_Wave_Client();

		// The "Refresh list" / "Retry" button just refetches the product list.
		if ( isset( $_POST['refresh_products'] ) ) {
			$wave->get_products( true );
			$this->set_settings_notice( 'success', __( 'Product list refreshed from Wave.', 'auto-mation' ) );
			$this->redirect_to_settings();
		}

		$svc   = isset( $_POST['wave_service_product_id'] ) ? sanitize_text_field( wp_unslash( $_POST['wave_service_product_id'] ) ) : '';
		$parts = isset( $_POST['wave_parts_product_id'] ) ? sanitize_text_field( wp_unslash( $_POST['wave_parts_product_id'] ) ) : '';

		// Validate any non-empty choice against the business's actual products.
		$list  = $wave->get_products();
		$valid = static function ( $id ) use ( $list ) {
			if ( '' === $id ) {
				return true;
			}
			if ( is_wp_error( $list ) ) {
				return false;
			}
			foreach ( $list as $product ) {
				if ( $product['id'] === $id ) {
					return true;
				}
			}
			return false;
		};

		if ( ! $valid( $svc ) || ! $valid( $parts ) ) {
			$this->set_settings_notice( 'error', __( 'One of those products was not found on your Wave business. Try refreshing the list.', 'auto-mation' ) );
			$this->redirect_to_settings();
		}

		update_option( AMAT_Wave_Client::SERVICE_PRODUCT_OPTION, $svc, false );
		update_option( AMAT_Wave_Client::PARTS_PRODUCT_OPTION, $parts, false );

		$this->set_settings_notice( 'success', __( 'Estimate line products saved.', 'auto-mation' ) );
		$this->redirect_to_settings();
	}

	/**
	 * Count the stored Wave links per column, plus a total.
	 *
	 * Iterates the central link registry so new Wave-ID columns are counted as
	 * soon as they're registered. Column/table names come from trusted constants,
	 * never user input.
	 *
	 * @return array{total:int,by:array<string,int>}
	 */
	private function wave_link_counts() {
		global $wpdb;

		// Customer links live in the generic external_refs store; the legacy job
		// estimate/invoice columns are still counted until that path is retired.
		$customers = AMAT_Wave_Client::linked_customer_count();
		$out       = array( 'total' => $customers, 'by' => array( 'customers' => $customers ) );

		foreach ( AMAT_Wave_Client::legacy_link_columns() as $table => $columns ) {
			$full = $wpdb->prefix . 'amat_' . $table;
			foreach ( $columns as $column ) {
				// Identifiers are from a trusted hardcoded registry, not user input.
				$count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$full} WHERE {$column} IS NOT NULL AND {$column} <> ''" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery
				$out['by'][ $column ] = $count;
				$out['total']        += $count;
			}
		}
		return $out;
	}

	/**
	 * Render the "Mass-link customers to Wave" tool: push every unlinked active
	 * customer in throttled background batches. The inverse of Unlink.
	 *
	 * Deliberately names the target business in the confirmation, because the one
	 * genuinely dangerous mistake here is running a whole-book push against the
	 * wrong business.
	 *
	 * @param bool $has_token Whether a Wave token is configured.
	 * @return void
	 */
	private function render_wave_mass_link( $has_token ) {
		?>
		<h3><?php esc_html_e( 'Mass-link customers to Wave', 'auto-mation' ); ?></h3>
		<p class="description">
			<?php esc_html_e( 'Pushes every active customer that has no Wave link yet, a few at a time in the background. Existing Wave customers are matched and adopted rather than duplicated; anyone with several possible matches is left for you to link by hand on their customer page. Safe to stop and restart — it resumes where it left off.', 'auto-mation' ); ?>
		</p>
		<?php
		if ( ! $has_token ) {
			echo '<p class="description">' . esc_html__( 'Add WAVE_API_TOKEN to .env first.', 'auto-mation' ) . '</p>';
			return;
		}

		$state    = AMAT_Wave_Mass_Link::state();
		$pending  = count( AMAT_Wave_Mass_Link::work_list() );
		$running  = AMAT_Wave_Mass_Link::is_running();
		$business = $this->current_business_name();

		if ( $running || in_array( $state['status'], array( 'done', 'stopped' ), true ) ) {
			$total     = max( 1, (int) $state['total'] );
			$processed = (int) $state['processed'];
			?>
			<table class="amat-detail-table">
				<tbody>
					<tr>
						<th><?php esc_html_e( 'Run status', 'auto-mation' ); ?></th>
						<td>
							<?php
							$labels = array(
								'running' => __( 'Running', 'auto-mation' ),
								'backoff' => __( 'Paused — Wave rate-limited us; waiting before continuing', 'auto-mation' ),
								'done'    => __( 'Finished', 'auto-mation' ),
								'stopped' => __( 'Stopped', 'auto-mation' ),
							);
							echo esc_html( $labels[ $state['status'] ] ?? $state['status'] );
							?>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Progress', 'auto-mation' ); ?></th>
						<td>
							<?php
							/* translators: 1: processed count, 2: total count, 3: percentage. */
							echo esc_html( sprintf( __( '%1$d of %2$d (%3$d%%)', 'auto-mation' ), $processed, (int) $state['total'], (int) round( $processed / $total * 100 ) ) );
							?>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Outcome so far', 'auto-mation' ); ?></th>
						<td>
							<?php
							echo esc_html(
								sprintf(
									/* translators: 1: adopted, 2: created, 3: updated, 4: needing a manual pick, 5: failed. */
									__( '%1$d linked to an existing Wave customer, %2$d created, %3$d updated, %4$d need you to choose, %5$d failed', 'auto-mation' ),
									(int) $state['adopted'],
									(int) $state['created'],
									(int) $state['updated'],
									count( (array) $state['ambiguous'] ),
									count( (array) $state['failed'] )
								)
							);
							?>
						</td>
					</tr>
					<?php if ( '' !== (string) $state['last_error'] ) : ?>
						<tr>
							<th><?php esc_html_e( 'Last problem', 'auto-mation' ); ?></th>
							<td><?php echo esc_html( (string) $state['last_error'] ); ?></td>
						</tr>
					<?php endif; ?>
				</tbody>
			</table>

			<?php if ( ! empty( $state['ambiguous'] ) ) : ?>
				<p class="description">
					<?php esc_html_e( 'Customers needing a manual link:', 'auto-mation' ); ?>
					<?php
					$names = array();
					foreach ( (array) $state['ambiguous'] as $ambiguous_id ) {
						$row = AMAT_Customer_Model::find( (int) $ambiguous_id );
						if ( $row ) {
							$names[] = '<a href="' . esc_url( $this->customer_url( (int) $ambiguous_id ) ) . '">' . esc_html( AMAT_Customer_Model::display_name( $row ) ) . '</a>';
						}
					}
					echo wp_kses( implode( ', ', $names ), array( 'a' => array( 'href' => array() ) ) );
					?>
				</p>
			<?php endif; ?>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'amat_masslink_wave' ); ?>
				<input type="hidden" name="action" value="amat_masslink_wave" />
				<?php if ( $running ) : ?>
					<input type="hidden" name="mode" value="stop" />
					<?php submit_button( __( 'Stop the run', 'auto-mation' ), 'secondary', 'submit', false ); ?>
					<p class="description"><?php esc_html_e( 'Batches run in the background via WP-Cron, so progress advances as the site receives traffic. Reload this page to refresh the numbers.', 'auto-mation' ); ?></p>
				<?php else : ?>
					<input type="hidden" name="mode" value="reset" />
					<?php submit_button( __( 'Clear this report', 'auto-mation' ), 'secondary', 'submit', false ); ?>
				<?php endif; ?>
			</form>
			<?php
		}

		if ( $running ) {
			return;
		}
		?>

		<p>
			<strong><?php esc_html_e( 'Waiting to be linked:', 'auto-mation' ); ?></strong>
			<?php
			/* translators: %d: number of unlinked active customers. */
			echo esc_html( sprintf( _n( '%d customer', '%d customers', $pending, 'auto-mation' ), $pending ) );
			?>
		</p>

		<?php if ( 0 === $pending ) : ?>
			<p class="description"><?php esc_html_e( 'Every active customer is already linked to Wave.', 'auto-mation' ); ?></p>
			<?php return; ?>
		<?php endif; ?>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<?php wp_nonce_field( 'amat_masslink_wave' ); ?>
			<input type="hidden" name="action" value="amat_masslink_wave" />
			<input type="hidden" name="mode" value="preview" />
			<?php submit_button( __( 'Preview (changes nothing)', 'auto-mation' ), 'secondary', 'submit', false ); ?>
		</form>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<?php wp_nonce_field( 'amat_masslink_wave' ); ?>
			<input type="hidden" name="action" value="amat_masslink_wave" />
			<input type="hidden" name="mode" value="start" />
			<p>
				<label>
					<input type="checkbox" name="confirm_masslink" value="1" />
					<?php
					echo esc_html(
						sprintf(
							/* translators: 1: number of customers, 2: Wave business name. */
							__( 'Push %1$d customers to the Wave business "%2$s".', 'auto-mation' ),
							$pending,
							'' !== $business ? $business : __( '(unknown)', 'auto-mation' )
						)
					);
					?>
				</label>
			</p>
			<?php submit_button( __( 'Start mass-link', 'auto-mation' ), 'primary', 'submit', false ); ?>
		</form>
		<?php
	}

	/**
	 * The display name of the business a sync would currently target, or ''.
	 *
	 * @return string
	 */
	private function current_business_name() {
		$wave   = new AMAT_Wave_Client();
		$target = $wave->get_business_id();
		if ( is_wp_error( $target ) ) {
			return '';
		}

		$businesses = $wave->get_businesses();
		if ( is_wp_error( $businesses ) ) {
			return '';
		}

		foreach ( (array) $businesses as $business ) {
			if ( (string) $business['id'] === (string) $target ) {
				return (string) $business['name'];
			}
		}
		return '';
	}

	/**
	 * Handle the mass-link POST: preview, start, stop or clear.
	 *
	 * @return void
	 */
	public function handle_masslink_wave() {
		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'auto-mation' ) );
		}
		check_admin_referer( 'amat_masslink_wave' );

		$mode      = isset( $_POST['mode'] ) ? sanitize_key( wp_unslash( $_POST['mode'] ) ) : '';
		$mass_link = new AMAT_Wave_Mass_Link();

		switch ( $mode ) {
			case 'preview':
				$preview = $mass_link->preview();
				if ( is_wp_error( $preview ) ) {
					$this->set_settings_notice( 'error', $preview->get_error_message() );
					break;
				}
				$message = sprintf(
					/* translators: 1: total pending, 2: would adopt, 3: would create, 4: ambiguous. */
					__( 'Preview: of %1$d unlinked customers, %2$d would link to an existing Wave customer, %3$d would be created new, and %4$d need you to choose between several matches. Nothing was changed.', 'auto-mation' ),
					(int) $preview['total'],
					(int) $preview['adopt'],
					(int) $preview['create'],
					(int) $preview['ambiguous']
				);
				if ( ! empty( $preview['ambiguous_names'] ) ) {
					/* translators: %s: comma-separated customer names. */
					$message .= ' ' . sprintf( __( 'Needing a choice: %s.', 'auto-mation' ), implode( ', ', $preview['ambiguous_names'] ) );
				}
				$this->set_settings_notice( 'info', $message );
				break;

			case 'start':
				if ( empty( $_POST['confirm_masslink'] ) ) {
					$this->set_settings_notice( 'error', __( 'Please tick the confirmation box — it names the Wave business the customers will be pushed to.', 'auto-mation' ) );
					break;
				}
				$result = $mass_link->start();
				$this->set_settings_notice( 'success' === $result['status'] ? 'success' : 'error', $result['message'] );
				break;

			case 'stop':
				$result = $mass_link->stop();
				$this->set_settings_notice( 'success' === $result['status'] ? 'success' : 'error', $result['message'] );
				break;

			case 'reset':
				$mass_link->reset();
				$this->set_settings_notice( 'success', __( 'Mass-link report cleared.', 'auto-mation' ) );
				break;

			default:
				$this->set_settings_notice( 'error', __( 'Unknown mass-link action.', 'auto-mation' ) );
		}

		$this->redirect_to_settings();
	}

	/**
	 * Render the "Unlink from Wave" tool: clear every stored Wave reference ID
	 * (customer links now; estimate/invoice links once those features land) from
	 * AUTOmation. Local-only — it never deletes anything in Wave. Use after
	 * switching the target business so the next sync re-creates records there
	 * instead of patching the old business's copies.
	 *
	 * @return void
	 */
	private function render_wave_unlink() {
		$counts = $this->wave_link_counts();
		?>
		<h3><?php esc_html_e( 'Unlink from Wave', 'auto-mation' ); ?></h3>
		<p class="description">
			<?php esc_html_e( 'Clears the Wave IDs stored in AUTOmation (customer links, and later estimate/invoice links). It does NOT delete anything in Wave. Use this after changing the target business so the next sync re-creates records in the new business instead of updating the old one.', 'auto-mation' ); ?>
		</p>

		<?php if ( 0 === $counts['total'] ) : ?>
			<p class="description"><?php esc_html_e( 'No Wave links are stored.', 'auto-mation' ); ?></p>
		<?php else : ?>
			<p>
				<strong><?php esc_html_e( 'Currently linked:', 'auto-mation' ); ?></strong>
				<?php
				/* translators: %d: number of customers linked to Wave. */
				echo esc_html( sprintf( _n( '%d customer', '%d customers', (int) $counts['by']['customers'], 'auto-mation' ), (int) $counts['by']['customers'] ) );
				$jobs_links = (int) ( $counts['by']['wave_estimate_id'] ?? 0 ) + (int) ( $counts['by']['wave_invoice_id'] ?? 0 );
				if ( $jobs_links > 0 ) {
					/* translators: %d: number of estimate/invoice links on jobs. */
					echo ', ' . esc_html( sprintf( _n( '%d job estimate/invoice link', '%d job estimate/invoice links', $jobs_links, 'auto-mation' ), $jobs_links ) );
				}
				?>.
			</p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="amat-unlink-wave-form">
				<?php wp_nonce_field( 'amat_unlink_wave' ); ?>
				<input type="hidden" name="action" value="amat_unlink_wave" />
				<p>
					<label>
						<input type="checkbox" name="confirm_unlink" value="1" />
						<?php esc_html_e( 'I understand this clears all stored Wave links (the next sync will re-create those records in Wave).', 'auto-mation' ); ?>
					</label>
				</p>
				<?php submit_button( __( 'Unlink all from Wave', 'auto-mation' ), 'delete', 'submit', false ); ?>
			</form>
		<?php endif; ?>
		<?php
	}

	/**
	 * Handle the "Unlink from Wave" POST: clear every registered Wave-ID column.
	 *
	 * @return void
	 */
	public function handle_unlink_wave() {
		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'auto-mation' ) );
		}
		check_admin_referer( 'amat_unlink_wave' );

		if ( empty( $_POST['confirm_unlink'] ) ) {
			$this->set_settings_notice( 'error', __( 'Please tick the confirmation box before unlinking.', 'auto-mation' ) );
			$this->redirect_to_settings();
		}

		global $wpdb;
		// Clear the customer links (external_refs) + the legacy job columns.
		$cleared = AMAT_External_Ref_Model::clear_for_provider( AMAT_Wave_Client::PROVIDER );
		foreach ( AMAT_Wave_Client::legacy_link_columns() as $table => $columns ) {
			$full = $wpdb->prefix . 'amat_' . $table;
			foreach ( $columns as $column ) {
				// Identifiers are from a trusted hardcoded registry, not user input.
				$affected = $wpdb->query( "UPDATE {$full} SET {$column} = '' WHERE {$column} IS NOT NULL AND {$column} <> ''" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery
				if ( is_numeric( $affected ) ) {
					$cleared += (int) $affected;
				}
			}
		}

		/* translators: %d: number of Wave links cleared. */
		$this->set_settings_notice( 'success', sprintf( _n( 'Cleared %d Wave link.', 'Cleared %d Wave links.', $cleared, 'auto-mation' ), $cleared ) );
		$this->redirect_to_settings();
	}

	/**
	 * Render the "Import Wave customers (CSV)" tool under Settings → Wave. A
	 * one-time seeding helper that creates local customers from a Wave export.
	 *
	 * @return void
	 */
	private function render_wave_import() {
		?>
		<h3><?php esc_html_e( 'Import Wave customers (CSV)', 'auto-mation' ); ?></h3>
		<p class="description"><?php esc_html_e( 'Upload a Wave (waveapps) customer-export CSV. New customers are created with their contact methods and addresses; customers whose name already exists are skipped.', 'auto-mation' ); ?></p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data">
			<?php wp_nonce_field( 'amat_import_wave' ); ?>
			<input type="hidden" name="action" value="amat_import_wave" />
			<input type="file" name="amat_csv" accept=".csv,text/csv" required />
			<?php submit_button( __( 'Import customers', 'auto-mation' ), 'secondary', 'submit', false ); ?>
		</form>
		<?php
	}

	/**
	 * Handle the Wave customer CSV import.
	 *
	 * @return void
	 */
	public function handle_import_wave() {
		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'auto-mation' ) );
		}
		check_admin_referer( 'amat_import_wave' );

		if ( empty( $_FILES['amat_csv']['tmp_name'] ) || ! is_uploaded_file( $_FILES['amat_csv']['tmp_name'] ) ) {
			$this->set_settings_notice( 'error', __( 'No file was uploaded.', 'auto-mation' ) );
			$this->redirect_to_settings();
		}
		if ( ! empty( $_FILES['amat_csv']['error'] ) ) {
			$this->set_settings_notice( 'error', __( 'The file upload failed. Please try again.', 'auto-mation' ) );
			$this->redirect_to_settings();
		}

		// Accept only a .csv by extension (Wave exports plain CSV).
		$name = isset( $_FILES['amat_csv']['name'] ) ? sanitize_file_name( wp_unslash( $_FILES['amat_csv']['name'] ) ) : '';
		if ( 'csv' !== strtolower( (string) pathinfo( $name, PATHINFO_EXTENSION ) ) ) {
			$this->set_settings_notice( 'error', __( 'Please upload a .csv file.', 'auto-mation' ) );
			$this->redirect_to_settings();
		}

		// Use the raw server-generated temp path: it is not user input, and
		// unslashing/sanitizing it would mangle a Windows path (C:\...\php1A2B.tmp).
		$tmp     = $_FILES['amat_csv']['tmp_name']; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- guarded by is_uploaded_file() above; sanitizing breaks the path.
		$summary = AMAT_Wave_Importer::import( $tmp );

		/* translators: 1: created count, 2: skipped count. */
		$message = sprintf(
			__( 'Import complete: %1$d created, %2$d skipped (already existed).', 'auto-mation' ),
			(int) $summary['created'],
			(int) $summary['skipped']
		);

		$type = 'success';
		if ( ! empty( $summary['errors'] ) ) {
			$shown    = array_slice( $summary['errors'], 0, 5 );
			$extra    = count( $summary['errors'] ) - count( $shown );
			$message .= ' ' . sprintf(
				/* translators: %d: number of errors. */
				_n( '%d issue:', '%d issues:', count( $summary['errors'] ), 'auto-mation' ),
				count( $summary['errors'] )
			) . ' ' . implode( ' ', $shown );
			if ( $extra > 0 ) {
				/* translators: %d: number of further issues not shown. */
				$message .= ' ' . sprintf( __( '(+%d more)', 'auto-mation' ), $extra );
			}
			$type = ( 0 === (int) $summary['created'] ) ? 'error' : 'success';
		}

		$this->set_settings_notice( $type, $message );
		$this->redirect_to_settings();
	}
}
