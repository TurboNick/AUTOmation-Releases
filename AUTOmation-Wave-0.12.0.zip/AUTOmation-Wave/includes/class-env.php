<?php
/**
 * Minimal secret reader for the Wave integration.
 *
 * ⚠ **Do not keep the production token in this plugin's `.env`.** A WordPress
 * plugin update deletes the entire plugin directory before unpacking the new zip,
 * and package.ps1 excludes `.env` from the archive on purpose (a token inside a
 * distributable file is a leak that travels). Both behaviours are correct; the
 * consequence is that a secret stored inside the plugin folder cannot survive an
 * update. It didn't: the first self-hosted update wiped it and Wave sync stopped
 * (core §10, 2026-08-17).
 *
 * The production answer is a **constant in `wp-config.php`**:
 *
 *     define( 'WAVE_API_TOKEN', 'your-token-here' );
 *
 * That is WordPress's own convention for credentials — the database password and
 * auth salts already live there. It sits outside the plugin, outside the database
 * and outside every backup this plugin can take, and it survives updates, plugin
 * deletion and re-installation. Because wp-config.php is executed rather than
 * served, its contents are never exposed over HTTP the way a `.env` can be.
 *
 * Resolution order:
 *
 *   1. A PHP constant of the same name (wp-config.php) — production.
 *   2. A real environment variable — for hosts that inject them.
 *   3. `.env` in this plugin's folder — **the local development machine only**.
 *      Kept because that is how Local is set up; it is the fragile one.
 *
 * Deliberately *not* supported: storing the token in the database, and reading a
 * `.env` from `wp-content/` (a dotfile there is inside the web root and many
 * servers will serve it as plain text). Both were considered and rejected.
 *
 * @package AUTOmation_Wave
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Reads secrets from a constant, the environment, or the plugin's .env file.
 */
class AMAT_Env {

	/**
	 * Parsed key => value pairs from the .env file. Null until first load.
	 *
	 * @var array<string,string>|null
	 */
	private static $cache = null;

	/**
	 * Get a value by key, falling back to a default.
	 *
	 * @param string $key     Variable name, e.g. 'WAVE_API_TOKEN'.
	 * @param string $default Value returned when the key is absent/empty.
	 * @return string
	 */
	public static function get( $key, $default = '' ) {
		$key = (string) $key;

		// 1. wp-config.php constant — the production route.
		if ( defined( $key ) ) {
			$value = (string) constant( $key );
			if ( '' !== $value ) {
				return $value;
			}
		}

		// 2. A real environment variable.
		$env = getenv( $key );
		if ( false !== $env && '' !== $env ) {
			return (string) $env;
		}

		// 3. The plugin's own .env — development only; an update destroys it.
		if ( null === self::$cache ) {
			self::$cache = self::load();
		}
		if ( isset( self::$cache[ $key ] ) && '' !== self::$cache[ $key ] ) {
			return self::$cache[ $key ];
		}

		return $default;
	}

	/**
	 * Parse the .env file in the plugin root into an associative array.
	 *
	 * Supports `KEY=value`, optional `export ` prefix, `#` comments, and
	 * single/double quoted values. Intentionally tiny — no interpolation.
	 *
	 * @return array<string,string>
	 */
	private static function load() {
		$path = AMAW_DIR . '.env';
		$vars = array();

		if ( ! is_readable( $path ) ) {
			return $vars;
		}

		$lines = file( $path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES );
		if ( false === $lines ) {
			return $vars;
		}

		foreach ( $lines as $line ) {
			$line = trim( $line );

			if ( '' === $line || str_starts_with( $line, '#' ) ) {
				continue;
			}

			if ( str_starts_with( $line, 'export ' ) ) {
				$line = substr( $line, strlen( 'export ' ) );
			}

			$pos = strpos( $line, '=' );
			if ( false === $pos ) {
				continue;
			}

			$key   = trim( substr( $line, 0, $pos ) );
			$value = trim( substr( $line, $pos + 1 ) );

			// Strip surrounding matching quotes.
			if ( strlen( $value ) >= 2 ) {
				$first = $value[0];
				$last  = $value[ strlen( $value ) - 1 ];
				if ( ( '"' === $first && '"' === $last ) || ( "'" === $first && "'" === $last ) ) {
					$value = substr( $value, 1, -1 );
				}
			}

			if ( '' !== $key ) {
				$vars[ $key ] = $value;
			}
		}

		return $vars;
	}
}
