<?php
/**
 * The business's branded email layout (Nick, 2026-10-06 for the welcomes;
 * opened up to companions 2026-10-09, when he asked for the estimate email to
 * "match the account/technician emails we've already created").
 *
 * One layout: the business's header (a theme's logo through
 * `amat_email_logo_url`, else the site icon, else the name) over a red line, a
 * greeting, an introduction, optional fact lines, an optional list, a lead line,
 * a red button, small notes, a sign-off and the footer. Each caller brings its
 * own words; this class decides how they look, so a caller can't break the look.
 *
 * @package AUTOmation
 */

defined( 'ABSPATH' ) || exit;

/**
 * Renders the branded email.
 */
class AMAT_Branded_Email {

	/**
	 * The business's name, as customers know it (Settings -> My Business), else
	 * the site title.
	 *
	 * @return string
	 */
	public static function business_name() {
		$name = trim( (string) get_option( AMAT_Admin::BUSINESS_NAME_OPTION, '' ) );
		return '' !== $name ? $name : (string) get_bloginfo( 'name' );
	}

	/**
	 * The email's HTML. Everything given is plain text and is escaped here.
	 *
	 * @param array<string,mixed> $words first (their first name; blank says "Hi,"),
	 *                                   intro (the opening paragraph),
	 *                                   facts (short lines shown in a box, e.g.
	 *                                   "Estimate #12 · 2015 Ford F-150"),
	 *                                   items (a bulleted list),
	 *                                   lead (a line just before the button),
	 *                                   button + url (the button; left out without a url),
	 *                                   notes (small grey lines under the button; a
	 *                                   string or a list), closing (the sign-off).
	 * @return string
	 */
	public static function html( array $words ) {
		$name  = self::business_name();
		$first = trim( (string) ( $words['first'] ?? '' ) );
		$logo  = (string) apply_filters( 'amat_email_logo_url', get_site_icon_url( 192 ) );

		$head = '' !== $logo
			? '<img src="' . esc_url( $logo ) . '" alt="' . esc_attr( $name ) . '" width="72" height="72" style="display:block;border:0;" />'
			: '<span style="font-size:22px;font-weight:700;color:#ffffff;">' . esc_html( $name ) . '</span>';

		$facts = '';
		foreach ( self::lines( $words['facts'] ?? array() ) as $i => $fact ) {
			$facts .= '<p style="margin:' . ( $i ? '4px' : '0' ) . ' 0 0;' . ( $i ? '' : 'font-weight:700;' ) . '">' . esc_html( $fact ) . '</p>';
		}
		$list = '';
		foreach ( self::lines( $words['items'] ?? array() ) as $item ) {
			$list .= '<li style="margin:0 0 8px;">' . esc_html( $item ) . '</li>';
		}
		$notes = '';
		foreach ( self::lines( $words['notes'] ?? array() ) as $note ) {
			$notes .= '<p style="margin:0 0 8px;color:#5c5f66;font-size:14px;">' . esc_html( $note ) . '</p>';
		}
		$intro   = trim( (string) ( $words['intro'] ?? '' ) );
		$lead    = trim( (string) ( $words['lead'] ?? '' ) );
		$url     = trim( (string) ( $words['url'] ?? '' ) );
		$button  = trim( (string) ( $words['button'] ?? '' ) );
		$closing = trim( (string) ( $words['closing'] ?? '' ) );

		return '<!doctype html><html><body style="margin:0;padding:0;background:#f4f4f5;font-family:Arial,Helvetica,sans-serif;color:#141416;">'
			. '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f4f4f5;padding:24px 0;"><tr><td align="center">'
			. '<table role="presentation" width="560" cellpadding="0" cellspacing="0" style="max-width:560px;width:100%;background:#ffffff;border-radius:10px;overflow:hidden;">'
			. '<tr><td style="background:#141416;padding:20px 28px;border-bottom:3px solid #a51419;">' . $head . '</td></tr>'
			. '<tr><td style="padding:28px;font-size:16px;line-height:1.55;">'
			/* translators: %s: their first name. */
			. '<p style="margin:0 0 14px;font-size:20px;font-weight:700;">' . esc_html( '' !== $first ? sprintf( __( 'Hi %s,', 'auto-mation' ), $first ) : __( 'Hi,', 'auto-mation' ) ) . '</p>'
			. ( '' !== $intro ? '<p style="margin:0 0 14px;">' . esc_html( $intro ) . '</p>' : '' )
			. ( '' !== $facts ? '<div style="margin:0 0 20px;padding:12px 16px;background:#f4f4f5;border-left:3px solid #a51419;border-radius:6px;font-size:15px;">' . $facts . '</div>' : '' )
			. ( '' !== $list ? '<ul style="margin:0 0 20px;padding-left:20px;">' . $list . '</ul>' : '' )
			. ( '' !== $lead ? '<p style="margin:0 0 22px;">' . esc_html( $lead ) . '</p>' : '' )
			. ( '' !== $url && '' !== $button ? '<p style="margin:0 0 24px;"><a href="' . esc_url( $url ) . '" style="display:inline-block;background:#a51419;color:#ffffff;text-decoration:none;font-weight:700;padding:12px 22px;border-radius:8px;">' . esc_html( $button ) . '</a></p>' : '' )
			. $notes
			. ( '' !== $closing ? '<p style="margin:16px 0 0;">' . esc_html( $closing ) . '</p>' : '' )
			. '</td></tr>'
			. '<tr><td style="padding:16px 28px;background:#f4f4f5;color:#5c5f66;font-size:12px;">' . esc_html( $name ) . ' &middot; <a href="' . esc_url( home_url( '/' ) ) . '" style="color:#5c5f66;">' . esc_html( (string) wp_parse_url( home_url(), PHP_URL_HOST ) ) . '</a></td></tr>'
			. '</table></td></tr></table></body></html>';
	}

	/**
	 * A string or a list, as non-blank lines.
	 *
	 * @param mixed $value String or array of strings.
	 * @return string[]
	 */
	private static function lines( $value ) {
		$out = array();
		foreach ( (array) $value as $line ) {
			$line = trim( (string) $line );
			if ( '' !== $line ) {
				$out[] = $line;
			}
		}
		return $out;
	}
}
