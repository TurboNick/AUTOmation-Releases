<?php
/**
 * Job proposal model.
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Times offered to a customer while a job is in Plan > Scheduling (DB v20).
 *
 * They sit on the calendar as tentative blocks so a slot is not double-booked
 * while the customer decides. Accepting one makes it the job's appointment and
 * clears the rest; closing the job withdraws them all.
 */
class AMAT_Job_Proposal_Model extends AMAT_Base_Model {

	/**
	 * {@inheritDoc}
	 */
	protected static function table_slug() {
		return 'job_proposals';
	}

	/**
	 * {@inheritDoc}
	 */
	protected static function schema() {
		return array(
			'job_id'   => 'int',
			'start_at' => 'datetime',
			'end_at'   => 'datetime',
		);
	}

	/**
	 * A job's proposals, earliest first.
	 *
	 * @param int $job_id Job id.
	 * @return array<int,array<string,mixed>>
	 */
	public static function for_job( $job_id ) {
		return self::all( array( 'job_id' => absint( $job_id ) ), array( 'orderby' => 'start_at', 'order' => 'ASC' ) );
	}

	/**
	 * Remove every proposal a job has.
	 *
	 * @param int $job_id Job id.
	 * @return void
	 */
	public static function clear_for_job( $job_id ) {
		global $wpdb;
		$wpdb->delete( self::table(), array( 'job_id' => absint( $job_id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	}
}
