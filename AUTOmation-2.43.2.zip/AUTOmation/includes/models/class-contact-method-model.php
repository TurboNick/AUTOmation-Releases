<?php
/**
 * Contact method model.
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Data access for the contact_methods table.
 *
 * A contact method belongs to one customer. Each row is a single channel
 * (email/call/text/…) with a stored value and a sort_order that sets priority
 * (lower = higher priority), replacing the old preferred_contact_method.
 * Validation/formatting live in AMAT_Contact_Method_Types.
 */
class AMAT_Contact_Method_Model extends AMAT_Base_Model {

	/**
	 * {@inheritDoc}
	 */
	protected static function table_slug() {
		return 'contact_methods';
	}

	/**
	 * {@inheritDoc}
	 */
	protected static function schema() {
		return array(
			'customer_id' => 'int',
			'type'        => 'text',
			'value'       => 'text',
			'sort_order'  => 'int',
			// Consent to automated texts (DB v24): when, and the exact wording.
			'sms_consent_at'   => 'datetime',
			'sms_consent_text' => 'textarea',
		);
	}

	/**
	 * All contact methods for a customer, in priority order.
	 *
	 * @param int $customer_id Customer id.
	 * @return array<int,array<string,mixed>>
	 */
	public static function for_customer( $customer_id ) {
		return self::all(
			array( 'customer_id' => absint( $customer_id ) ),
			array( 'orderby' => 'sort_order', 'order' => 'ASC' )
		);
	}

	/**
	 * The customer's top-priority contact method, or null.
	 *
	 * @param int $customer_id Customer id.
	 * @return array<string,mixed>|null
	 */
	public static function primary_for_customer( $customer_id ) {
		$rows = self::for_customer( $customer_id );
		return $rows[0] ?? null;
	}

	/**
	 * Replace all of a customer's contact methods with the given ordered set.
	 *
	 * Simplest correct strategy for the repeater UI: delete the customer's
	 * existing methods and re-insert the submitted ones in order. Caller is
	 * responsible for validating/normalizing each value first.
	 *
	 * A number's consent to texts survives this: it belongs to the NUMBER, so a
	 * value still present keeps the consent it had (whatever its type or place
	 * now), and a changed number has none - it never agreed to anything. A method
	 * may also bring its own (sms_consent_at, sms_consent_text), as a new request
	 * does.
	 *
	 * @param int   $customer_id Customer id.
	 * @param array<int,array{type:string,value:string,sms_consent_at?:string,sms_consent_text?:string}> $methods Ordered methods.
	 * @return void
	 */
	public static function replace_for_customer( $customer_id, array $methods ) {
		global $wpdb;

		$customer_id = absint( $customer_id );
		$consent     = array();
		foreach ( self::for_customer( $customer_id ) as $old ) {
			if ( ! empty( $old['sms_consent_at'] ) ) {
				$consent[ (string) $old['value'] ] = array( $old['sms_consent_at'], (string) $old['sms_consent_text'] );
			}
		}
		$wpdb->delete( static::table(), array( 'customer_id' => $customer_id ) );

		$order = 0;
		foreach ( $methods as $method ) {
			$row = array(
				'customer_id' => $customer_id,
				'type'        => $method['type'],
				'value'       => $method['value'],
				'sort_order'  => $order++,
			);
			if ( ! empty( $method['sms_consent_at'] ) ) {
				$row['sms_consent_at']   = $method['sms_consent_at'];
				$row['sms_consent_text'] = (string) ( $method['sms_consent_text'] ?? '' );
			} elseif ( isset( $consent[ (string) $method['value'] ] ) ) {
				list( $row['sms_consent_at'], $row['sms_consent_text'] ) = $consent[ (string) $method['value'] ];
			}
			self::create( $row );
		}
	}
}
