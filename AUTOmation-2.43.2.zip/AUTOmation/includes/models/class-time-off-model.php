<?php
/**
 * A technician's time off (DB v22).
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Rows of tech_time_off: a user, when they are away (start inclusive, end
 * exclusive), and a note for the owner. Written through AMAT_Technicians, which
 * checks the user is a technician and turns whole days into midnight-to-midnight.
 */
class AMAT_Time_Off_Model extends AMAT_Base_Model {

	/**
	 * Table slug.
	 *
	 * @return string
	 */
	protected static function table_slug() {
		return 'tech_time_off';
	}

	/**
	 * Columns and their types.
	 *
	 * @return array<string,string>
	 */
	protected static function schema() {
		return array(
			'user_id'  => 'int',
			'start_at' => 'datetime',
			'end_at'   => 'datetime',
			'note'     => 'text',
		);
	}

	/**
	 * A technician's time off, earliest first; with a range, only what overlaps it.
	 *
	 * @param int    $user_id The technician.
	 * @param string $from    'Y-m-d H:i:s' or '' (no lower bound).
	 * @param string $to      'Y-m-d H:i:s' or '' (no upper bound).
	 * @return array<int,array<string,mixed>>
	 */
	public static function for_user( $user_id, $from = '', $to = '' ) {
		global $wpdb;
		$table = self::table();
		$sql   = "SELECT * FROM {$table} WHERE user_id = %d";
		$args  = array( (int) $user_id );
		if ( '' !== $from ) {
			$sql   .= ' AND end_at > %s';
			$args[] = $from;
		}
		if ( '' !== $to ) {
			$sql   .= ' AND start_at < %s';
			$args[] = $to;
		}
		return $wpdb->get_results( $wpdb->prepare( $sql . ' ORDER BY start_at ASC', $args ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- the table name is ours; values are prepared.
	}
}
