<?php
/**
 * Vehicle model.
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Data access for the vehicles table.
 *
 * A vehicle belongs to one customer and has many jobs and service records.
 * Most spec fields are auto-populated from the NHTSA vPIC VIN decode
 * (see AMAT_Vin_Decoder and §7 of CLAUDE.md); license_plate/color/color_code
 * are entered manually.
 */
class AMAT_Vehicle_Model extends AMAT_Base_Model {

	/**
	 * {@inheritDoc}
	 */
	protected static function table_slug() {
		return 'vehicles';
	}

	/**
	 * {@inheritDoc}
	 */
	protected static function schema() {
		return array(
			'customer_id'         => 'int',
			'is_active'           => 'bool',
			'vin'                 => 'text',
			'year'                => 'int',
			'make'                => 'text',
			'model'               => 'text',
			'trim'                => 'text',
			'series'              => 'text',
			'body_type'           => 'text',
			'engine_displacement' => 'text',
			'engine_cylinders'    => 'text',
			'fuel_type_primary'   => 'text',
			'fuel_type_secondary' => 'text',
			'drive_type'          => 'text',
			'transmission_type'   => 'text',
			'transmission_speeds' => 'text',
			'license_plate'       => 'text',
			'plate_state'         => 'text', // two-letter state the plate is from (DB v26)
			'color'               => 'text',
			'color_code'          => 'text',
			'warnings'            => 'textarea',
			'notes'               => 'textarea',
		);
	}

	/**
	 * Create a vehicle from typed "Year Make Model" text. A leading all-digits
	 * token is the year; the next is the make; the rest is the model. A
	 * non-numeric first token means no year.
	 *
	 * @param int    $customer_id Owning customer id.
	 * @param string $text        E.g. "2015 Ford F-150".
	 * @param array  $extra       More columns (e.g. a VIN).
	 * @return int New vehicle id, or 0.
	 */
	public static function create_from_text( $customer_id, $text, array $extra = array() ) {
		$ymm = self::parse_text( $text );
		if ( '' === $ymm['year'] . $ymm['make'] . $ymm['model'] && empty( $extra ) ) {
			return 0;
		}
		$data = array_merge(
			array(
				'customer_id' => (int) $customer_id,
				'make'        => $ymm['make'],
				'model'       => $ymm['model'],
				'is_active'   => 1,
			),
			$extra
		);
		if ( '' !== $ymm['year'] ) {
			$data['year'] = $ymm['year'];
		}
		return (int) self::create( $data );
	}

	/**
	 * Split a typed "Year Make Model" line, saving nothing: a leading all-digits
	 * token is the year, the next the make, the rest the model.
	 *
	 * @param string $text E.g. "2015 Ford F-150".
	 * @return array{year:string,make:string,model:string}
	 */
	public static function parse_text( $text ) {
		$parts = preg_split( '/\s+/', trim( (string) $text ), -1, PREG_SPLIT_NO_EMPTY );
		$year  = ( $parts && ctype_digit( $parts[0] ) ) ? (string) array_shift( $parts ) : '';
		return array(
			'year'  => $year,
			'make'  => $parts ? (string) array_shift( $parts ) : '',
			'model' => $parts ? implode( ' ', $parts ) : '',
		);
	}

	/**
	 * A vehicle as the one line a customer types it: "2015 Ford F-150" ('' when
	 * nothing is known; no year shown for 0).
	 *
	 * @param array<string,mixed> $vehicle Vehicle row.
	 * @return string
	 */
	public static function text_of( array $vehicle ) {
		$year = (string) ( $vehicle['year'] ?? '' );
		return trim( implode( ' ', array_filter( array( '0' === $year ? '' : $year, (string) ( $vehicle['make'] ?? '' ), (string) ( $vehicle['model'] ?? '' ) ), static fn( $p ) => '' !== trim( $p ) ) ) );
	}

	/**
	 * All vehicles belonging to a customer.
	 *
	 * @param int $customer_id Customer id.
	 * @return array<int,array<string,mixed>>
	 */
	public static function for_customer( $customer_id ) {
		return self::all(
			array( 'customer_id' => absint( $customer_id ) ),
			array( 'orderby' => 'make', 'order' => 'ASC' )
		);
	}

	/**
	 * Search vehicles by make, model, VIN, plate, or year.
	 *
	 * @param string $term Raw search term.
	 * @return array<int,array<string,mixed>>
	 */
	public static function search( $term ) {
		global $wpdb;

		$term = trim( (string) $term );
		if ( '' === $term ) {
			return self::all( array(), array( 'orderby' => 'make', 'order' => 'ASC' ) );
		}

		$table = static::table();
		$like  = '%' . $wpdb->esc_like( $term ) . '%';
		$sql   = $wpdb->prepare(
			"SELECT * FROM {$table}
			 WHERE make LIKE %s OR model LIKE %s OR vin LIKE %s OR license_plate LIKE %s OR year LIKE %s
			 ORDER BY make ASC, model ASC",
			$like,
			$like,
			$like,
			$like,
			$like
		);

		return $wpdb->get_results( $sql, ARRAY_A ) ?: array();
	}

	/**
	 * A short label for a vehicle row, e.g. "2019 Toyota Camry".
	 *
	 * @param array<string,mixed> $vehicle Vehicle row.
	 * @return string
	 */
	public static function label( array $vehicle ) {
		$parts = array_filter(
			array(
				(string) ( $vehicle['year'] ?? '' ),
				(string) ( $vehicle['make'] ?? '' ),
				(string) ( $vehicle['model'] ?? '' ),
			),
			static fn( $p ) => '' !== trim( $p )
		);
		$label = trim( implode( ' ', $parts ) );
		return '' !== $label ? $label : __( '(unspecified vehicle)', 'auto-mation' );
	}

	/**
	 * The plate with its state, as it is read: "ABC 123 (IN)"; '' with no plate.
	 *
	 * @param array<string,mixed> $vehicle Vehicle row.
	 * @return string
	 */
	public static function plate_label( array $vehicle ) {
		$plate = trim( (string) ( $vehicle['license_plate'] ?? '' ) );
		$state = trim( (string) ( $vehicle['plate_state'] ?? '' ) );
		if ( '' === $plate ) {
			return '';
		}
		return '' !== $state ? $plate . ' (' . $state . ')' : $plate;
	}
}
