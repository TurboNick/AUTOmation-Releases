<?php
/**
 * Technicians: who works the jobs, when, and when they are away.
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Several technicians use the site and each job has one (Nick, 2026-10-01).
 *
 * A technician is a WordPress user: one with the Technician role, or any login
 * - the owner's admin one, say - marked as a technician. Each has weekly hours
 * (user meta), which default to the business's and never reach outside them,
 * and time off (AMAT_Time_Off_Model). AMAT_Availability counts them: a half-day
 * is offered while a tech is free to take it.
 *
 * What a technician may see and do when logged in is AMAT_Access (phase 2):
 * the role carries AMAT_Access::CAP, and the owner sets each tech's permissions.
 */
class AMAT_Technicians {

	/**
	 * The technician role.
	 *
	 * @var string
	 */
	const ROLE = 'amat_technician';

	/**
	 * User meta marking any other login (the owner's) as a technician.
	 *
	 * @var string
	 */
	const META_TECH = 'amat_is_tech';

	/**
	 * User meta holding a technician's weekly hours.
	 *
	 * @var string
	 */
	const META_HOURS = 'amat_tech_hours';

	/**
	 * Ensure the role exists. Called from activation and the upgrade routine.
	 *
	 * The name is stored untranslated, as WordPress's own roles are (it
	 * translates them on display): the upgrade can run before `init`, where
	 * translating loads the text domain too early.
	 *
	 * @return void
	 */
	public static function add_role() {
		$role = get_role( self::ROLE );
		if ( null === $role ) {
			add_role( self::ROLE, 'Technician', array( 'read' => true, AMAT_Access::CAP => true ) );
		} elseif ( ! $role->has_cap( AMAT_Access::CAP ) ) {
			$role->add_cap( AMAT_Access::CAP ); // a role made in phase 1, before techs could work
		}
	}

	/* --------------------------------------------------------------------- */
	/* Who                                                                   */
	/* --------------------------------------------------------------------- */

	/**
	 * Whether a user is a technician.
	 *
	 * @param int $user_id User id.
	 * @return bool
	 */
	public static function is_tech( $user_id ) {
		$user = get_userdata( (int) $user_id );
		return $user && ( in_array( self::ROLE, (array) $user->roles, true ) || '1' === (string) get_user_meta( $user->ID, self::META_TECH, true ) );
	}

	/**
	 * Every technician's id, by name.
	 *
	 * @return int[]
	 */
	public static function ids() {
		$users = array();
		foreach ( get_users( array( 'role' => self::ROLE ) ) as $u ) {
			$users[ $u->ID ] = $u->display_name;
		}
		foreach ( get_users( array( 'meta_key' => self::META_TECH, 'meta_value' => '1' ) ) as $u ) { // phpcs:ignore WordPress.DB.SlowDBQuery -- a handful of users.
			$users[ $u->ID ] = $u->display_name;
		}
		natcasesort( $users );
		return array_map( 'intval', array_keys( $users ) );
	}

	/**
	 * A technician's name, or '' for none.
	 *
	 * @param int $user_id User id (0 = unassigned).
	 * @return string
	 */
	public static function name( $user_id ) {
		$user = (int) $user_id ? get_userdata( (int) $user_id ) : false;
		return $user ? (string) $user->display_name : '';
	}

	/**
	 * A new technician: a login with the Technician role. Emails them a link to
	 * set their password unless told not to.
	 *
	 * @param string $first  First name.
	 * @param string $last   Last name.
	 * @param string $email  Email - their login.
	 * @param bool   $notify Send the "set your password" email.
	 * @return int|WP_Error The new user's id.
	 */
	public static function create( $first, $last, $email, $notify = true ) {
		$first = trim( sanitize_text_field( (string) $first ) );
		$last  = trim( sanitize_text_field( (string) $last ) );
		$email = trim( sanitize_email( (string) $email ) );
		if ( '' === $first ) {
			return new WP_Error( 'amat_tech_name', __( 'A technician needs a first name.', 'auto-mation' ) );
		}
		if ( ! is_email( $email ) ) {
			return new WP_Error( 'amat_tech_email', __( 'A technician needs an email address - it becomes their login.', 'auto-mation' ) );
		}
		if ( email_exists( $email ) ) {
			return new WP_Error( 'amat_tech_taken', __( 'That email already belongs to a login. To make an existing login a technician, use "Mark as a technician".', 'auto-mation' ) );
		}

		$login = sanitize_user( strtolower( $email ), true );
		$base  = $login;
		for ( $n = 2; username_exists( $login ); $n++ ) {
			$login = $base . $n;
		}
		$id = wp_insert_user(
			array(
				'user_login'   => $login,
				'user_email'   => $email,
				'user_pass'    => wp_generate_password( 24 ),
				'role'         => self::ROLE,
				'first_name'   => $first,
				'last_name'    => $last,
				'display_name' => trim( $first . ' ' . $last ),
			)
		);
		if ( is_wp_error( $id ) ) {
			return $id;
		}
		if ( $notify ) {
			self::send_welcome( (int) $id, $first );
		}
		/* translators: %s: the technician's name. */
		AMAT_Log::info( 'core', sprintf( __( 'Technician added: %s.', 'auto-mation' ), trim( $first . ' ' . $last ) ) );
		return (int) $id;
	}

	/**
	 * A new technician's welcome to the team, with a button to choose their
	 * password - the customer welcome's layout, their own words (Nick,
	 * 2026-10-06: "they are after all joining the team"). The wording is Claude's
	 * draft, on Nick's checklist for approval.
	 *
	 * @param int    $user_id Their login.
	 * @param string $first   Their first name.
	 * @return void
	 */
	private static function send_welcome( $user_id, $first ) {
		$name = AMAT_Welcome_Email::business_name();
		AMAT_Welcome_Email::send(
			$user_id,
			array(
				/* translators: %s: the business name. */
				'subject' => sprintf( __( 'Welcome to the team at %s', 'auto-mation' ), $name ),
				'first'   => $first,
				/* translators: %s: the business name. */
				'intro'   => sprintf( __( 'Welcome to the team at %s - we are glad to have you! You now have a login to our job system, where you can:', 'auto-mation' ), $name ),
				'items'   => array(
					__( 'See your jobs - the customer, the vehicle, and what they told us is wrong.', 'auto-mation' ),
					__( "Write up your findings and the work as you go, on each job's page.", 'auto-mation' ),
					__( 'Check your schedule and time off on your calendar.', 'auto-mation' ),
				),
				'expired' => __( 'The link works once, for a limited time - if it has expired, use "Lost your password?" on the login page.', 'auto-mation' ),
				'closing' => __( 'Glad to have you aboard - see you in the shop.', 'auto-mation' ),
			)
		);
	}

	/**
	 * Make an existing login a technician (the owner's own, typically).
	 *
	 * @param int $user_id User id.
	 * @return void
	 */
	public static function mark( $user_id ) {
		update_user_meta( (int) $user_id, self::META_TECH, '1' );
	}

	/**
	 * Stop a user being a technician. Their open jobs go back to unassigned (each
	 * logged); closed ones keep their name - that is who did the work.
	 *
	 * @param int $user_id User id.
	 * @return int How many open jobs were unassigned.
	 */
	public static function remove( $user_id ) {
		$user_id = (int) $user_id;
		$name    = self::name( $user_id );
		delete_user_meta( $user_id, self::META_TECH );
		$user = get_userdata( $user_id );
		if ( $user && in_array( self::ROLE, (array) $user->roles, true ) ) {
			$user->remove_role( self::ROLE );
		}

		$freed = 0;
		foreach ( AMAT_Job_Model::all( array( 'technician_id' => $user_id ) ) as $job ) {
			if ( '' !== (string) $job['closed_reason'] ) {
				continue;
			}
			AMAT_Job_Model::update( (int) $job['id'], array( 'technician_id' => 0 ) );
			/* translators: %s: the technician's name. */
			AMAT_Log::info( 'core', sprintf( __( 'Unassigned: %s is no longer a technician.', 'auto-mation' ), $name ), array( 'entity_type' => 'job', 'entity_id' => (int) $job['id'] ) );
			++$freed;
		}
		return $freed;
	}

	/* --------------------------------------------------------------------- */
	/* When                                                                  */
	/* --------------------------------------------------------------------- */

	/**
	 * A technician's weekly hours: their own, or the business's until set.
	 *
	 * @param int $user_id User id.
	 * @return array<string,array{open:string,close:string}>
	 */
	public static function hours( $user_id ) {
		$own = get_user_meta( (int) $user_id, self::META_HOURS, true );
		return is_array( $own ) && $own ? $own : AMAT_Availability::settings()['hours'];
	}

	/**
	 * Store a technician's weekly hours (cleaned as the business's are).
	 *
	 * @param int                 $user_id User id.
	 * @param array<string,mixed> $raw     By weekday key.
	 * @return array<string,array{open:string,close:string}> What was stored.
	 */
	public static function save_hours( $user_id, array $raw ) {
		$hours = AMAT_Availability::clean_hours( $raw );
		update_user_meta( (int) $user_id, self::META_HOURS, $hours );
		return $hours;
	}

	/**
	 * When a technician works on a day: their hours inside the business's, or
	 * null when either is closed or they do not overlap.
	 *
	 * @param int    $user_id User id.
	 * @param string $date    Y-m-d.
	 * @return array{0:DateTimeImmutable,1:DateTimeImmutable}|null
	 */
	public static function day_window( $user_id, $date ) {
		$day = DateTimeImmutable::createFromFormat( '!Y-m-d', (string) $date );
		if ( ! $day ) {
			return null;
		}
		$key      = strtolower( $day->format( 'D' ) );
		$business = AMAT_Availability::settings()['hours'][ $key ] ?? array( 'open' => '', 'close' => '' );
		$own      = self::hours( $user_id )[ $key ] ?? array( 'open' => '', 'close' => '' );
		if ( '' === $business['open'] || '' === $own['open'] ) {
			return null;
		}
		$open  = max( $business['open'], $own['open'] );
		$close = min( $business['close'], $own['close'] );
		if ( $open >= $close ) {
			return null;
		}
		return array( new DateTimeImmutable( "{$date} {$open}" ), new DateTimeImmutable( "{$date} {$close}" ) );
	}

	/**
	 * Record time off. A bare date is the whole day; from one date to another is
	 * every day between, inclusive.
	 *
	 * @param int    $user_id A technician.
	 * @param string $start   'Y-m-d', or 'Y-m-d H:i'.
	 * @param string $end     'Y-m-d' (inclusive), 'Y-m-d H:i' (exclusive), or '' (the start's day).
	 * @param string $note    Why, for the owner.
	 * @return int|WP_Error The new row's id.
	 */
	public static function add_time_off( $user_id, $start, $end, $note = '' ) {
		if ( ! self::is_tech( $user_id ) ) {
			return new WP_Error( 'amat_tech_unknown', __( 'That is not a technician.', 'auto-mation' ) );
		}
		$from = self::moment( $start, false );
		$to   = self::moment( '' === trim( (string) $end ) ? $start : $end, true );
		if ( ! $from || ! $to ) {
			return new WP_Error( 'amat_off_when', __( 'Time off needs a date it starts and ends.', 'auto-mation' ) );
		}
		if ( $to <= $from ) {
			return new WP_Error( 'amat_off_order', __( 'Time off cannot end before it starts.', 'auto-mation' ) );
		}
		return (int) AMAT_Time_Off_Model::create(
			array(
				'user_id'  => (int) $user_id,
				'start_at' => $from->format( 'Y-m-d H:i:s' ),
				'end_at'   => $to->format( 'Y-m-d H:i:s' ),
				'note'     => sanitize_text_field( (string) $note ),
			)
		);
	}

	/**
	 * A date or date-time as a moment. A bare date is its midnight - or, as the
	 * end of a range, the next midnight, so the day is included.
	 *
	 * @param string $value 'Y-m-d' or a date-time AMAT_Job_Workflow::parse_when() reads.
	 * @param bool   $end   Whether it ends a range.
	 * @return DateTimeImmutable|null
	 */
	private static function moment( $value, $end ) {
		$value = trim( (string) $value );
		$day   = DateTimeImmutable::createFromFormat( '!Y-m-d', $value );
		if ( $day && $day->format( 'Y-m-d' ) === $value ) {
			return $end ? $day->modify( '+1 day' ) : $day;
		}
		return AMAT_Job_Workflow::parse_when( $value );
	}

	/**
	 * Whether a technician is off at any point in a stretch of time.
	 *
	 * @param int               $user_id User id.
	 * @param DateTimeImmutable $from    Start.
	 * @param DateTimeImmutable $to      End (exclusive).
	 * @return bool
	 */
	public static function is_off( $user_id, DateTimeImmutable $from, DateTimeImmutable $to ) {
		return (bool) AMAT_Time_Off_Model::for_user( (int) $user_id, $from->format( 'Y-m-d H:i:s' ), $to->format( 'Y-m-d H:i:s' ) );
	}

	/**
	 * Why a technician cannot take a stretch of time: other jobs of theirs in it,
	 * time off, or it lies outside their hours. Warnings for the owner - an
	 * assignment is never refused for them.
	 *
	 * @param int               $user_id The technician.
	 * @param DateTimeImmutable $from    Start.
	 * @param DateTimeImmutable $to      End (exclusive).
	 * @param int               $exclude A job to leave out (the one being assigned).
	 * @return string[]
	 */
	public static function conflicts( $user_id, DateTimeImmutable $from, DateTimeImmutable $to, $exclude = 0 ) {
		$name     = self::name( $user_id );
		$warnings = array();
		foreach ( AMAT_Job_Workflow::busy_intervals() as $b ) {
			if ( (int) $user_id === $b['tech'] && (int) $exclude !== $b['job'] && $from < $b['end'] && $b['start'] < $to ) {
				$other = AMAT_Job_Model::find( $b['job'] );
				/* translators: 1: the technician, 2: the other job. */
				$warnings[] = sprintf( __( '%1$s already has %2$s then.', 'auto-mation' ), $name, $other ? AMAT_Job_Model::label( $other ) : '#' . $b['job'] );
			}
		}
		if ( self::is_off( $user_id, $from, $to ) ) {
			/* translators: %s: the technician. */
			$warnings[] = sprintf( __( '%s is off then.', 'auto-mation' ), $name );
		}
		$window = self::day_window( $user_id, $from->format( 'Y-m-d' ) );
		if ( ! $window || $from < $window[0] || ( $from->format( 'Y-m-d' ) === $to->format( 'Y-m-d' ) && $to > $window[1] ) ) {
			/* translators: %s: the technician. */
			$warnings[] = sprintf( __( 'That is outside %s\'s hours.', 'auto-mation' ), $name );
		}
		return $warnings;
	}
}
