<?php
/**
 * Jobs > Technicians: who the techs are, their hours, and their time off.
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The list of technicians (add one, mark your own login as one, remove one)
 * and each technician's page: their weekly hours, and a calendar of their time
 * off and assigned jobs - drag across days to add time off, tap it to remove.
 *
 * Owner-only (AMAT_Admin::CAPABILITY) in phase 1. Forms post to admin-post.php
 * and flash their result back through the page's transient, as the other pages
 * do; the calendar talks to admin-ajax.php.
 */
class AMAT_Technicians_Page {

	/**
	 * The page slug.
	 *
	 * @var string
	 */
	const PAGE_SLUG = 'amat-technicians';

	/**
	 * Nonce for the calendar's requests.
	 *
	 * @var string
	 */
	const NONCE = 'amat_tech_calendar';

	/**
	 * Hook the form handlers and the calendar's AJAX.
	 *
	 * @return void
	 */
	public static function register() {
		foreach ( array( 'add', 'mark', 'remove', 'hours', 'perms' ) as $what ) {
			add_action( 'admin_post_amat_tech_' . $what, array( __CLASS__, 'handle_' . $what ) );
		}
		add_action( 'wp_ajax_amat_tech_events', array( __CLASS__, 'ajax_events' ) );
		add_action( 'wp_ajax_amat_tech_add_off', array( __CLASS__, 'ajax_add_off' ) );
		add_action( 'wp_ajax_amat_tech_remove_off', array( __CLASS__, 'ajax_remove_off' ) );
	}

	/**
	 * The page's address.
	 *
	 * @param array<string,mixed> $args Query args.
	 * @return string
	 */
	public static function url( array $args = array() ) {
		return add_query_arg( array_merge( array( 'page' => self::PAGE_SLUG ), $args ), admin_url( 'admin.php' ) );
	}

	/* --------------------------------------------------------------------- */
	/* Pages                                                                 */
	/* --------------------------------------------------------------------- */

	/**
	 * The list, or one technician's page (?tech=).
	 *
	 * @return void
	 */
	public function render() {
		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'auto-mation' ) );
		}
		$tech = isset( $_GET['tech'] ) ? absint( $_GET['tech'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- view routing.
		echo '<div class="wrap amat-wrap amat-techs">';
		if ( $tech && AMAT_Technicians::is_tech( $tech ) ) {
			$this->render_tech( $tech );
		} else {
			$this->render_list();
		}
		echo '</div>';
	}

	/**
	 * The list of technicians.
	 *
	 * @return void
	 */
	private function render_list() {
		echo '<h1>' . esc_html__( 'Technicians', 'auto-mation' ) . '</h1>';
		self::notice();
		echo '<p class="description">' . esc_html__( 'Each job has one technician. Customers are offered a half-day while at least one tech is free to take it; you choose who when you book it.', 'auto-mation' ) . '</p>';

		$ids = AMAT_Technicians::ids();
		if ( $ids ) {
			echo '<table class="widefat striped amat-tech-list"><thead><tr><th>' . esc_html__( 'Technician', 'auto-mation' ) . '</th><th>' . esc_html__( 'Open jobs', 'auto-mation' ) . '</th><th>' . esc_html__( 'Next time off', 'auto-mation' ) . '</th><th></th></tr></thead><tbody>';
			$now = current_time( 'mysql' );
			foreach ( $ids as $id ) {
				$open = count( array_filter( AMAT_Job_Model::all( array( 'technician_id' => $id ) ), static fn( $j ) => '' === (string) $j['closed_reason'] ) );
				$off  = AMAT_Time_Off_Model::for_user( $id, $now );
				echo '<tr><td><a href="' . esc_url( self::url( array( 'tech' => $id ) ) ) . '"><strong>' . esc_html( AMAT_Technicians::name( $id ) ) . '</strong></a></td>'
					. '<td>' . esc_html( (string) $open ) . '</td>'
					. '<td>' . esc_html( $off ? self::describe_off( $off[0] ) : '—' ) . '</td><td>';
				self::form( 'amat_tech_remove', array( 'tech' => $id ), __( 'Remove', 'auto-mation' ), 'button button-small amat-btn-disable', __( 'Stop this person being a technician? Their open jobs go back to unassigned.', 'auto-mation' ) );
				echo '</td></tr>';
			}
			echo '</tbody></table>';
		} else {
			echo '<p>' . esc_html__( 'No technicians yet - online booking works from the business hours alone until there are.', 'auto-mation' ) . '</p>';
		}

		if ( ! AMAT_Technicians::is_tech( get_current_user_id() ) ) {
			echo '<p>';
			self::form( 'amat_tech_mark', array(), __( 'I work jobs too - make me a technician', 'auto-mation' ), 'button' );
			echo '</p>';
		}

		echo '<h2>' . esc_html__( 'Add a technician', 'auto-mation' ) . '</h2>'
			. '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="amat-tech-add">'
			. wp_nonce_field( 'amat_tech_add', '_wpnonce', true, false )
			. '<input type="hidden" name="action" value="amat_tech_add" />'
			. '<p><label for="amat-tech-first">' . esc_html__( 'First name', 'auto-mation' ) . '</label><br /><input type="text" name="first_name" id="amat-tech-first" required /></p>'
			. '<p><label for="amat-tech-last">' . esc_html__( 'Last name', 'auto-mation' ) . '</label><br /><input type="text" name="last_name" id="amat-tech-last" /></p>'
			. '<p><label for="amat-tech-email">' . esc_html__( 'Email (their login)', 'auto-mation' ) . '</label><br /><input type="email" name="email" id="amat-tech-email" required /></p>'
			. '<p class="description">' . esc_html__( 'They are emailed a link to set their password. Until technician access is built, logging in shows them nothing of the business.', 'auto-mation' ) . '</p>'
			. '<p><button type="submit" class="button button-primary">' . esc_html__( 'Add technician', 'auto-mation' ) . '</button></p></form>';
	}

	/**
	 * One technician: their calendar and their weekly hours.
	 *
	 * @param int $tech User id.
	 * @return void
	 */
	private function render_tech( $tech ) {
		echo '<p><a href="' . esc_url( self::url() ) . '">' . esc_html__( '← All technicians', 'auto-mation' ) . '</a></p>'
			. '<h1>' . esc_html( AMAT_Technicians::name( $tech ) ) . '</h1>';
		self::notice();

		echo '<h2>' . esc_html__( 'Calendar', 'auto-mation' ) . '</h2>'
			. '<p class="description">' . esc_html__( 'Drag across days (or press and hold on a phone) to add time off; tap time off to remove it. Their jobs are shown too.', 'auto-mation' ) . '</p>'
			. '<div id="amat-tech-notice" aria-live="polite"></div>'
			. '<div id="amat-tech-calendar" data-tech="' . esc_attr( (string) $tech ) . '"></div>';

		$hours = AMAT_Technicians::hours( $tech );
		$names = array(
			'mon' => __( 'Monday', 'auto-mation' ),
			'tue' => __( 'Tuesday', 'auto-mation' ),
			'wed' => __( 'Wednesday', 'auto-mation' ),
			'thu' => __( 'Thursday', 'auto-mation' ),
			'fri' => __( 'Friday', 'auto-mation' ),
			'sat' => __( 'Saturday', 'auto-mation' ),
			'sun' => __( 'Sunday', 'auto-mation' ),
		);
		echo '<h2>' . esc_html__( 'Weekly hours', 'auto-mation' ) . '</h2>'
			. '<p class="description">' . esc_html__( 'When they work. Only the part inside the business hours (Settings → Scheduling) is offered to customers. Leave a day blank for a day off.', 'auto-mation' ) . '</p>'
			. '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">'
			. wp_nonce_field( 'amat_tech_hours', '_wpnonce', true, false )
			. '<input type="hidden" name="action" value="amat_tech_hours" />'
			. '<input type="hidden" name="tech" value="' . esc_attr( (string) $tech ) . '" />'
			. '<table class="form-table amat-sched-hours" role="presentation">';
		foreach ( $names as $key => $label ) {
			echo '<tr><th scope="row">' . esc_html( $label ) . '</th><td>'
				/* translators: %s: weekday. */
				. '<input type="time" step="900" name="hours[' . esc_attr( $key ) . '][open]" value="' . esc_attr( $hours[ $key ]['open'] ?? '' ) . '" aria-label="' . esc_attr( sprintf( __( '%s starts', 'auto-mation' ), $label ) ) . '" /> <span aria-hidden="true">–</span> '
				/* translators: %s: weekday. */
				. '<input type="time" step="900" name="hours[' . esc_attr( $key ) . '][close]" value="' . esc_attr( $hours[ $key ]['close'] ?? '' ) . '" aria-label="' . esc_attr( sprintf( __( '%s ends', 'auto-mation' ), $label ) ) . '" /></td></tr>';
		}
		echo '</table><p><button type="submit" class="button button-primary">' . esc_html__( 'Save hours', 'auto-mation' ) . '</button></p></form>';

		// What they may do when logged in (AMAT_Access). Not for the owner's own
		// login - the owner can do everything.
		if ( AMAT_Access::is_owner( $tech ) ) {
			return;
		}
		echo '<h2>' . esc_html__( 'Permissions', 'auto-mation' ) . '</h2>'
			. '<p class="description">' . esc_html__( 'A technician always works the jobs assigned to them - estimates and invoices included - and never reaches your settings or customer lists. These add to that.', 'auto-mation' ) . '</p>'
			. '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="amat-tech-perms">'
			. wp_nonce_field( 'amat_tech_perms', '_wpnonce', true, false )
			. '<input type="hidden" name="action" value="amat_tech_perms" />'
			. '<input type="hidden" name="tech" value="' . esc_attr( (string) $tech ) . '" />';
		foreach ( array_keys( AMAT_Access::PERMS ) as $key ) {
			$on = 'hide_contacts' === $key ? ! AMAT_Access::sees_contacts( $tech ) : AMAT_Access::perm( $key, $tech );
			echo '<p><label><input type="checkbox" name="perms[]" value="' . esc_attr( $key ) . '"' . checked( $on, true, false ) . ' /> ' . esc_html( AMAT_Access::label( $key ) ) . '</label></p>';
		}
		echo '<p><button type="submit" class="button button-primary">' . esc_html__( 'Save permissions', 'auto-mation' ) . '</button></p></form>';
	}

	/**
	 * A small form posting one action.
	 *
	 * @param string               $action  The admin-post action (also the nonce).
	 * @param array<string,scalar> $hidden  Hidden fields.
	 * @param string               $label   Button label.
	 * @param string               $class   Button classes.
	 * @param string               $confirm A question to confirm first, or ''.
	 * @return void
	 */
	private static function form( $action, array $hidden, $label, $class, $confirm = '' ) {
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="amat-inline-form">'
			. wp_nonce_field( $action, '_wpnonce', true, false )
			. '<input type="hidden" name="action" value="' . esc_attr( $action ) . '" />';
		foreach ( $hidden as $name => $value ) {
			echo '<input type="hidden" name="' . esc_attr( $name ) . '" value="' . esc_attr( (string) $value ) . '" />';
		}
		echo '<button type="submit" class="' . esc_attr( $class ) . '"' . ( '' !== $confirm ? ' onclick="return confirm(\'' . esc_js( $confirm ) . '\');"' : '' ) . '>' . esc_html( $label ) . '</button></form>';
	}

	/**
	 * "Mar 4" / "Mar 4 – Mar 6" for a time-off row.
	 *
	 * @param array<string,mixed> $row A tech_time_off row.
	 * @return string
	 */
	private static function describe_off( array $row ) {
		$from = new DateTimeImmutable( (string) $row['start_at'] );
		$to   = new DateTimeImmutable( (string) $row['end_at'] );
		$last = '00:00' === $to->format( 'H:i' ) ? $to->modify( '-1 day' ) : $to;
		return $from->format( 'Y-m-d' ) === $last->format( 'Y-m-d' ) ? $from->format( 'M j' ) : $from->format( 'M j' ) . ' – ' . $last->format( 'M j' );
	}

	/* --------------------------------------------------------------------- */
	/* Notices                                                               */
	/* --------------------------------------------------------------------- */

	/**
	 * Show (and clear) the result of the last form.
	 *
	 * @return void
	 */
	private static function notice() {
		$key   = 'amat_flash_' . self::PAGE_SLUG . '_' . get_current_user_id();
		$flash = get_transient( $key );
		if ( is_array( $flash ) && isset( $flash['message'] ) ) {
			delete_transient( $key );
			echo '<div class="notice notice-' . ( 'error' === $flash['status'] ? 'error' : 'success' ) . ' is-dismissible"><p>' . esc_html( $flash['message'] ) . '</p></div>';
		}
	}

	/**
	 * Flash a result and go back.
	 *
	 * @param string $status  'success' or 'error'.
	 * @param string $message What happened.
	 * @param int    $tech    The technician's page to return to, or 0 for the list.
	 * @return void
	 */
	private static function back( $status, $message, $tech = 0 ) {
		set_transient( 'amat_flash_' . self::PAGE_SLUG . '_' . get_current_user_id(), array( 'status' => $status, 'message' => $message ), MINUTE_IN_SECONDS );
		wp_safe_redirect( self::url( $tech ? array( 'tech' => (int) $tech ) : array() ) );
		exit;
	}

	/**
	 * The owner, with a valid nonce for this action - or stop.
	 *
	 * @param string $action The nonce action.
	 * @return void
	 */
	private static function guard( $action ) {
		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'auto-mation' ) );
		}
		check_admin_referer( $action );
	}

	/* --------------------------------------------------------------------- */
	/* Form handlers                                                         */
	/* --------------------------------------------------------------------- */

	/**
	 * Add a technician.
	 *
	 * @return void
	 */
	public static function handle_add() {
		self::guard( 'amat_tech_add' );
		$id = AMAT_Technicians::create(
			wp_unslash( $_POST['first_name'] ?? '' ), // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized in create().
			wp_unslash( $_POST['last_name'] ?? '' ), // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- as above.
			wp_unslash( $_POST['email'] ?? '' ) // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- as above.
		);
		if ( is_wp_error( $id ) ) {
			self::back( 'error', $id->get_error_message() );
		}
		/* translators: %s: the technician's name. */
		self::back( 'success', sprintf( __( '%s is a technician - they have been emailed a link to set a password. Set their hours below.', 'auto-mation' ), AMAT_Technicians::name( $id ) ), $id );
	}

	/**
	 * Make the owner's own login a technician.
	 *
	 * @return void
	 */
	public static function handle_mark() {
		self::guard( 'amat_tech_mark' );
		AMAT_Technicians::mark( get_current_user_id() );
		self::back( 'success', __( 'You are a technician too - jobs can be assigned to you.', 'auto-mation' ), get_current_user_id() );
	}

	/**
	 * Stop someone being a technician.
	 *
	 * @return void
	 */
	public static function handle_remove() {
		self::guard( 'amat_tech_remove' );
		$tech  = absint( $_POST['tech'] ?? 0 );
		$name  = AMAT_Technicians::name( $tech );
		$freed = AMAT_Technicians::remove( $tech );
		/* translators: 1: the person, 2: how many open jobs went back to unassigned. */
		self::back( 'success', sprintf( _n( '%1$s is no longer a technician; %2$d open job went back to unassigned.', '%1$s is no longer a technician; %2$d open jobs went back to unassigned.', $freed, 'auto-mation' ), $name, $freed ) );
	}

	/**
	 * Save a technician's weekly hours.
	 *
	 * @return void
	 */
	public static function handle_hours() {
		self::guard( 'amat_tech_hours' );
		$tech = absint( $_POST['tech'] ?? 0 );
		if ( ! AMAT_Technicians::is_tech( $tech ) ) {
			self::back( 'error', __( 'That is not a technician.', 'auto-mation' ) );
		}
		AMAT_Technicians::save_hours( $tech, isset( $_POST['hours'] ) && is_array( $_POST['hours'] ) ? map_deep( wp_unslash( $_POST['hours'] ), 'sanitize_text_field' ) : array() );
		self::back( 'success', __( 'Hours saved.', 'auto-mation' ), $tech );
	}

	/**
	 * Save a technician's permissions.
	 *
	 * @return void
	 */
	public static function handle_perms() {
		self::guard( 'amat_tech_perms' );
		$tech = absint( $_POST['tech'] ?? 0 );
		if ( ! AMAT_Technicians::is_tech( $tech ) ) {
			self::back( 'error', __( 'That is not a technician.', 'auto-mation' ) );
		}
		$on = isset( $_POST['perms'] ) && is_array( $_POST['perms'] ) ? array_map( 'sanitize_key', wp_unslash( $_POST['perms'] ) ) : array();
		AMAT_Access::set_perms( $tech, $on );
		/* translators: %s: the technician. */
		AMAT_Log::info( 'core', sprintf( __( 'Permissions changed for %s.', 'auto-mation' ), AMAT_Technicians::name( $tech ) ), array( 'permissions' => $on ) );
		self::back( 'success', __( 'Permissions saved.', 'auto-mation' ), $tech );
	}

	/* --------------------------------------------------------------------- */
	/* The calendar (AJAX)                                                   */
	/* --------------------------------------------------------------------- */

	/**
	 * The owner, with the calendar's nonce - or a JSON refusal.
	 *
	 * @return void
	 */
	private static function ajax_guard() {
		if ( ! check_ajax_referer( self::NONCE, 'nonce', false ) || ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			wp_send_json_error( array( 'message' => __( 'You are not allowed to do that.', 'auto-mation' ) ), 403 );
		}
	}

	/**
	 * A technician's time off and assigned jobs between two dates.
	 *
	 * @return void
	 */
	public static function ajax_events() {
		self::ajax_guard();
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- ajax_guard() checked it.
		$tech = absint( $_POST['tech'] ?? 0 );
		$from = substr( sanitize_text_field( wp_unslash( $_POST['start'] ?? '' ) ), 0, 10 );
		$to   = substr( sanitize_text_field( wp_unslash( $_POST['end'] ?? '' ) ), 0, 10 );
		// phpcs:enable
		wp_send_json_success( self::events( $tech, $from, $to ) );
	}

	/**
	 * The calendar's events for one technician.
	 *
	 * @param int    $tech The technician.
	 * @param string $from Y-m-d.
	 * @param string $to   Y-m-d (exclusive).
	 * @return array<int,array<string,mixed>>
	 */
	public static function events( $tech, $from, $to ) {
		$out = array();
		foreach ( AMAT_Time_Off_Model::for_user( $tech, $from . ' 00:00:00', $to . ' 00:00:00' ) as $off ) {
			$whole = '00:00:00' === substr( (string) $off['start_at'], 11 ) && '00:00:00' === substr( (string) $off['end_at'], 11 );
			$out[] = array(
				'id'            => 'off-' . (int) $off['id'],
				'title'         => '' !== (string) $off['note'] ? (string) $off['note'] : __( 'Off', 'auto-mation' ),
				'start'         => $whole ? substr( (string) $off['start_at'], 0, 10 ) : str_replace( ' ', 'T', (string) $off['start_at'] ),
				'end'           => $whole ? substr( (string) $off['end_at'], 0, 10 ) : str_replace( ' ', 'T', (string) $off['end_at'] ),
				'allDay'        => $whole,
				'classNames'    => array( 'amat-tech-off' ),
				'extendedProps' => array( 'off' => (int) $off['id'] ),
			);
		}
		foreach ( AMAT_Job_Model::all( array( 'technician_id' => (int) $tech ) ) as $job ) {
			if ( ! in_array( (string) $job['closed_reason'], array( '', 'paid' ), true ) || ! AMAT_Job_Model::scheduled_days( $job, $from, $to ) ) {
				continue;
			}
			$event               = AMAT_Job_Calendar::event( $job );
			$event['editable']   = false;
			$event['classNames'] = array_merge( (array) $event['classNames'], array( 'amat-tech-job' ) );
			$out[]               = $event;
		}
		return $out;
	}

	/**
	 * Add time off from a calendar selection.
	 *
	 * @return void
	 */
	public static function ajax_add_off() {
		self::ajax_guard();
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- ajax_guard() checked it.
		$id = AMAT_Technicians::add_time_off(
			absint( $_POST['tech'] ?? 0 ),
			sanitize_text_field( wp_unslash( $_POST['start'] ?? '' ) ),
			sanitize_text_field( wp_unslash( $_POST['end'] ?? '' ) ),
			sanitize_text_field( wp_unslash( $_POST['note'] ?? '' ) )
		);
		// phpcs:enable
		if ( is_wp_error( $id ) ) {
			wp_send_json_error( array( 'message' => $id->get_error_message() ) );
		}
		wp_send_json_success( array( 'id' => $id ) );
	}

	/**
	 * Remove a stretch of time off.
	 *
	 * @return void
	 */
	public static function ajax_remove_off() {
		self::ajax_guard();
		$id = absint( $_POST['id'] ?? 0 ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- ajax_guard() checked it.
		if ( ! $id || ! AMAT_Time_Off_Model::find( $id ) ) {
			wp_send_json_error( array( 'message' => __( 'That time off is already gone.', 'auto-mation' ) ) );
		}
		AMAT_Time_Off_Model::delete( $id );
		wp_send_json_success();
	}

	/* --------------------------------------------------------------------- */
	/* Assets                                                                */
	/* --------------------------------------------------------------------- */

	/**
	 * FullCalendar and the technician calendar, on a technician's page only.
	 *
	 * @return void
	 */
	public static function enqueue() {
		$tech = isset( $_GET['tech'] ) ? absint( $_GET['tech'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- view routing.
		if ( ! $tech ) {
			return;
		}
		wp_enqueue_script( 'amat-fullcalendar', AMAT_PLUGIN_URL . 'assets/fullcalendar/fullcalendar.min.js', array(), '6.1.15', true );
		wp_enqueue_script( 'amat-tech-calendar', AMAT_PLUGIN_URL . 'assets/tech-calendar.js', array( 'amat-fullcalendar' ), AMAT_VERSION, true );

		// Their working hours, for the calendar to shade: hours inside the business's.
		$business = array();
		foreach ( AMAT_Availability::DAYS as $n => $key ) {
			$date   = ( new DateTimeImmutable( 'monday this week' ) )->modify( '+' . $n . ' days' )->format( 'Y-m-d' );
			$window = AMAT_Technicians::day_window( $tech, $date );
			if ( $window ) {
				$business[] = array( 'daysOfWeek' => array( ( $n + 1 ) % 7 ), 'startTime' => $window[0]->format( 'H:i' ), 'endTime' => $window[1]->format( 'H:i' ) );
			}
		}
		wp_localize_script(
			'amat-tech-calendar',
			'amatTechCalendar',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( self::NONCE ),
				'tech'    => $tech,
				'now'     => current_time( 'Y-m-d\TH:i:s' ),
				'hours'   => $business,
				'i18n'    => array(
					'today'    => __( 'Today', 'auto-mation' ),
					'month'    => __( 'Month', 'auto-mation' ),
					'week'     => __( 'Week', 'auto-mation' ),
					'day'      => __( 'Day', 'auto-mation' ),
					'notePrompt' => __( 'Time off - a note for yourself (optional):', 'auto-mation' ),
					/* translators: %s: the dates. */
					'removeOff' => __( 'Remove this time off (%s)?', 'auto-mation' ),
					'added'    => __( 'Time off added.', 'auto-mation' ),
					'removed'  => __( 'Time off removed.', 'auto-mation' ),
					'failed'   => __( 'Could not reach the server. Nothing was changed.', 'auto-mation' ),
				),
			)
		);
	}
}
