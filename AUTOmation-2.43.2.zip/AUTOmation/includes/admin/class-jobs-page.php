<?php
/**
 * Jobs admin page: a month calendar (default) and a status-filterable grid of
 * all jobs, plus the add/edit form. Jobs tie a customer + vehicle + location +
 * work + status together.
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Renders the Jobs board and calendar, the job screen, and the Add job form.
 *
 * Two list views share a toolbar (Add job + Board/Calendar toggle):
 *  - Board (default): a column per workflow stage.
 *  - Calendar: FullCalendar, fed by AMAT_Job_Calendar, with drag to reschedule
 *    and proposed times drawn as tentative blocks.
 *
 * The job screen is also where a job is edited: its Edit button (`action=edit`)
 * turns the screen's fields into inputs in place, and each estimate/invoice
 * expands from its row into its editing card. There is no separate edit form.
 *
 * A new job's customer is chosen with an AJAX search (not a dropdown). When a
 * job is added from a customer (`return_customer`) or edited, the customer is
 * fixed instead. Vehicle/location options are scoped to the customer.
 *
 * Security pattern per §5 (nonce, capability, sanitize in, escape out).
 */
class AMAT_Jobs_Page extends AMAT_Admin_Page {

	const NONCE_ACTION = 'amat_save_job';
	const PAGE_SLUG    = 'amat-jobs';
	const POST_ACTION  = 'save_job';
	const CUST_NONCE   = 'amat_job_customer';
	const DOC_NONCE    = 'amat_job_doc';
	const FLOW_NONCE   = 'amat_job_flow';

	/**
	 * Whether the job on screen is one the viewer may see but not work - an
	 * unassigned job, to a technician (AMAT_Access). No Edit, no flow buttons.
	 *
	 * @var bool
	 */
	private $read_only = false;

	/**
	 * Jobs have no soft-delete, but opt into the Dev Tools per-record delete.
	 *
	 * @return string
	 */
	protected static function deletable_model() {
		return 'AMAT_Job_Model';
	}

	/**
	 * Cascade a job hard-delete to its parts orders and service records (Dev Tools
	 * delete). The job's linked draft estimate is left in place (it is a
	 * customer-owned financial document, deletable on its own).
	 *
	 * @param int $id Deleted job id.
	 * @return void
	 */
	protected function after_delete( $id ) {
		global $wpdb;
		$wpdb->delete( $wpdb->prefix . 'amat_parts_orders', array( 'job_id' => (int) $id ) );
		$wpdb->delete( $wpdb->prefix . 'amat_service_records', array( 'job_id' => (int) $id ) );
		AMAT_Job_Proposal_Model::clear_for_job( (int) $id );
	}

	/**
	 * Render the page: show any flashed notice, then route to a view or form.
	 *
	 * Views: the Board (default — a column per workflow stage) and the Calendar.
	 * The old Grid was retired with the job status (DB v20); a `view=grid` link
	 * lands on the Board.
	 *
	 * @return void
	 */
	public function render() {
		// The owner, and technicians (AMAT_Access decides which jobs).
		if ( ! AMAT_Access::can_work() ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'auto-mation' ) );
		}

		$flash  = $this->take_flash();
		$action = isset( $_GET['action'] ) ? sanitize_key( wp_unslash( $_GET['action'] ) ) : '';

		if ( 'view' === $action ) {
			$id  = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0;
			$job = $id ? AMAT_Job_Model::find( $id ) : null;
			if ( ! $job ) {
				$this->render_board( array( 'status' => 'error', 'message' => __( 'Job not found.', 'auto-mation' ) ) );
				return;
			}
			if ( ! AMAT_Access::can_view_job( $job ) ) {
				wp_die( esc_html__( 'That job is not yours.', 'auto-mation' ) );
			}
			if ( AMAT_Access::can_edit_job( $job ) ) {
				$this->render_view( $job, $flash );
				return;
			}

			// Seen, not worked: an unassigned job a technician may take. No Edit, no
			// workflow buttons, every form disabled - but "Take this job", and with
			// the permission "Customer picked this", which take it for them.
			$this->read_only = true;
			ob_start();
			$this->render_view( $job, $flash );
			$html = (string) ob_get_clean();
			$html = preg_replace( '#<button type="submit"(?![^>]*amat-keep)#', '<button type="submit" disabled', $html );
			$take = '<div class="notice notice-info inline amat-take"><p>' . esc_html__( 'This job has no technician yet.', 'auto-mation' ) . ' '
				. '<form method="post" class="amat-inline-form">' . wp_nonce_field( self::FLOW_NONCE, '_wpnonce', true, false )
				. '<input type="hidden" name="amat_action" value="job_flow_take" />'
				. '<input type="hidden" name="job_id" value="' . esc_attr( (string) (int) $job['id'] ) . '" />'
				. '<button type="submit" class="button button-primary amat-keep">' . esc_html__( 'Take this job', 'auto-mation' ) . '</button></form></p></div>';
			$at   = strpos( $html, '</h1>' );
			echo false === $at ? $take . $html : substr( $html, 0, $at + 5 ) . $take . substr( $html, $at + 5 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from escaped parts.
			return;
		}

		if ( 'new' === $action && ! AMAT_Access::is_owner() ) {
			wp_die( esc_html__( 'Only the owner adds jobs.', 'auto-mation' ) );
		}

		// Two kinds of flash land on a form. The job form's own validation error
		// carries the typed values back, and the fields are rebuilt from them.
		// Everything else carries only a status and a message, and is SHOWN above
		// the job as it is. (Handling only the first kind once dropped every
		// success and crashed on a document error - 2026-09-22.)
		$typed = ( $flash && 'error' === $flash['status'] && isset( $flash['data'] ) && is_array( $flash['data'] ) ) ? $flash['data'] : null;

		if ( 'new' === $action ) {
			$this->render_form( $typed ? $typed : array(), $flash );
			return;
		}

		if ( 'edit' === $action ) {
			// There is no separate edit screen: editing is the job screen itself, one
			// stage at a time, its fields turned into inputs in place (2026-09-30).
			$id  = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0;
			$job = $id ? AMAT_Job_Model::find( $id ) : null;
			if ( ! $job ) {
				$this->render_board( array( 'status' => 'error', 'message' => __( 'Job not found.', 'auto-mation' ) ) );
				return;
			}
			if ( ! AMAT_Access::can_edit_job( $job ) ) {
				wp_die( esc_html__( 'That job is not yours to edit.', 'auto-mation' ) );
			}
			// Which stage: the one a rejected save came from, else the one asked for,
			// else the job's current stage.
			$asked = isset( $_GET['stage'] ) ? sanitize_key( wp_unslash( $_GET['stage'] ) ) : '';
			$stage = (string) ( $typed['edit_stage'] ?? $asked );
			if ( ! isset( AMAT_Job_Workflow::stages()[ $stage ] ) ) {
				$current = AMAT_Job_Workflow::stage( $job );
				$stage   = isset( AMAT_Job_Workflow::stages()[ $current ] ) ? $current : 'info';
			}
			$this->render_view( $job, $flash, $stage, $typed ? $typed : array() );
			return;
		}

		$view = isset( $_GET['view'] ) ? sanitize_key( wp_unslash( $_GET['view'] ) ) : 'board';
		if ( 'calendar' === $view ) {
			$this->render_calendar( $flash );
		} else {
			$this->render_board( $flash );
		}
	}

	/* --------------------------------------------------------------------- */
	/* Shared pieces                                                         */
	/* --------------------------------------------------------------------- */

	/**
	 * Echo the page heading, the Add job button, and the Board/Calendar toggle.
	 *
	 * @param string $active 'board' or 'calendar'.
	 * @return void
	 */
	private function toolbar( $active ) {
		$add_url   = $this->list_url( array( 'action' => 'new' ) );
		$board_url = $this->list_url();
		$cal_url   = $this->list_url( array( 'view' => 'calendar' ) );
		?>
		<h1 class="wp-heading-inline"><?php esc_html_e( 'Jobs', 'auto-mation' ); ?></h1>
		<hr class="wp-header-end" />
		<div class="amat-list-bar">
			<?php if ( AMAT_Access::is_owner() ) : ?>
				<a href="<?php echo esc_url( $add_url ); ?>" class="button amat-btn-primary amat-add-inline"><?php esc_html_e( 'Add job', 'auto-mation' ); ?></a>
			<?php endif; ?>
			<span class="amat-view-toggle">
				<a href="<?php echo esc_url( $board_url ); ?>" class="button <?php echo 'board' === $active ? 'amat-btn-primary' : ''; ?>"><?php esc_html_e( 'Board', 'auto-mation' ); ?></a>
				<a href="<?php echo esc_url( $cal_url ); ?>" class="button <?php echo 'calendar' === $active ? 'amat-btn-primary' : ''; ?>"><?php esc_html_e( 'Calendar', 'auto-mation' ); ?></a>
			</span>
		</div>
		<?php
	}

	/**
	 * Echo a flash notice (success, warning or error).
	 *
	 * @param array<string,mixed>|null $flash Flash payload.
	 * @return void
	 */
	private function notice( $flash ) {
		if ( ! $flash || empty( $flash['message'] ) ) {
			return;
		}
		$type = in_array( $flash['status'] ?? '', array( 'success', 'warning', 'error' ), true ) ? $flash['status'] : 'success';
		echo '<div class="notice notice-' . esc_attr( $type ) . ' is-dismissible"><p>' . esc_html( (string) $flash['message'] ) . '</p></div>';
	}

	/**
	 * The job's customer display name.
	 *
	 * @param array<string,mixed> $job Job row.
	 * @return string
	 */
	private static function who( array $job ) {
		$owner = ! empty( $job['customer_id'] ) ? AMAT_Customer_Model::find( (int) $job['customer_id'] ) : null;
		return $owner ? AMAT_Customer_Model::display_name( $owner ) : __( '(no customer)', 'auto-mation' );
	}

	/**
	 * The job's vehicle label, or ''.
	 *
	 * @param array<string,mixed> $job Job row.
	 * @return string
	 */
	private static function vehicle_label( array $job ) {
		$vehicle = ! empty( $job['vehicle_id'] ) ? AMAT_Vehicle_Model::find( (int) $job['vehicle_id'] ) : null;
		return $vehicle ? AMAT_Vehicle_Model::label( $vehicle ) : '';
	}

	/**
	 * A job's step (or close reason) as a pill in its stage colour.
	 *
	 * @param array<string,mixed> $job Job row.
	 * @return string Escaped HTML.
	 */
	public static function step_pill( array $job ) {
		$stage = AMAT_Job_Workflow::stage( $job );
		$label = 'closed' === $stage
			/* translators: %s: why the job closed. */
			? sprintf( __( 'Closed — %s', 'auto-mation' ), AMAT_Job_Workflow::close_reasons()[ (string) $job['closed_reason'] ] ?? '' )
			: AMAT_Job_Workflow::step_label( (string) $job['step'] );
		return '<span class="amat-stage-pill amat-stage-' . esc_attr( $stage ) . '">' . esc_html( $label ) . '</span>';
	}

	/**
	 * A job's flags (Appointment passed, Hold with its reason, Standby) as pills.
	 *
	 * @param array<string,mixed> $job Job row.
	 * @return string Escaped HTML.
	 */
	private static function flag_pills( array $job ) {
		$out    = '';
		$review = (string) ( $job['review_reason'] ?? '' );
		if ( '' !== $review ) {
			$out .= '<span class="amat-flag amat-flag-review" title="' . esc_attr( $review ) . '">' . esc_html__( 'Needs review', 'auto-mation' ) . '</span>';
		}
		if ( AMAT_Job_Workflow::appointment_passed( $job ) ) {
			$out .= '<span title="' . esc_attr__( 'The appointment is over but the job is still being planned. Move it on if the work was done.', 'auto-mation' ) . '" class="amat-flag amat-flag-passed">' . esc_html__( 'Appointment passed', 'auto-mation' ) . '</span>';
		}
		if ( ! empty( $job['on_hold'] ) ) {
			$out .= '<span class="amat-flag amat-flag-hold">' . esc_html( self::hold_text( $job ) ) . '</span>';
		}
		if ( ! empty( $job['standby'] ) ) {
			$out .= '<span class="amat-flag amat-flag-standby"' . ( '' !== (string) $job['hold_reason'] ? ' title="' . esc_attr( (string) $job['hold_reason'] ) . '"' : '' ) . '>' . esc_html__( 'Standby', 'auto-mation' ) . '</span>';
		}
		return $out;
	}

	/**
	 * "On hold: Starter on backorder · est. Oct 2".
	 *
	 * @param array<string,mixed> $job Job row.
	 * @return string Plain text.
	 */
	private static function hold_text( array $job ) {
		/* translators: %s: why the job is on hold. */
		$text  = sprintf( __( 'On hold: %s', 'auto-mation' ), (string) $job['hold_reason'] );
		$until = substr( (string) ( $job['hold_until'] ?? '' ), 0, 10 );
		if ( '' !== $until && '0000-00-00' !== $until ) {
			/* translators: %s: the estimated date, e.g. "Oct 2". */
			$text .= ' · ' . sprintf( __( 'est. %s', 'auto-mation' ), AMAT_Job_Workflow::short_date( $until ) );
		}
		return $text;
	}

	/**
	 * Announce invoices whose due date the job moved, as an owner save - so a
	 * provider's automatic sync carries the new date across (and Wave's payment
	 * reminders follow it). Fired from the admin paths that moved them, never
	 * from the models (§3).
	 *
	 * @param int[] $ids Invoice ids.
	 * @return void
	 */
	public static function announce_invoices( array $ids ) {
		foreach ( array_unique( array_map( 'intval', $ids ) ) as $id ) {
			/** This action is documented in includes/admin/class-jobs-page.php (fire_doc_saved). */
			do_action( 'amat_after_invoice_save', $id, false );
		}
	}

	/**
	 * The appointment as "Thu Oct 8, 9:00 AM–11:00 AM" (or just the date(s) for
	 * an all-day job), or ''.
	 *
	 * @param array<string,mixed> $job Job row.
	 * @return string
	 */
	private static function appointment( array $job ) {
		$start = AMAT_Job_Workflow::parse_when( (string) ( $job['scheduled_start'] ?? '' ) );
		if ( ! $start ) {
			return '';
		}
		$end = AMAT_Job_Workflow::parse_when( (string) ( $job['scheduled_end'] ?? '' ) );
		if ( '00:00' === $start->format( 'H:i' ) && ( ! $end || '00:00' === $end->format( 'H:i' ) ) ) {
			$text = $start->format( 'D M j' );
			if ( $end && $end->format( 'Y-m-d' ) !== $start->format( 'Y-m-d' ) ) {
				$text .= ' – ' . $end->format( 'D M j' );
			}
			return $text;
		}
		return AMAT_Job_Workflow::describe_slot( $start, $end );
	}

	/**
	 * Approved total: the sum of the job's accepted and approved estimates.
	 *
	 * @param array<int,array<string,mixed>> $estimates The job's estimates.
	 * @return float
	 */
	private static function approved_total( array $estimates ) {
		$sum = 0.0;
		foreach ( $estimates as $est ) {
			if ( AMAT_Estimate_Model::is_go_ahead( $est ) ) {
				$sum += (float) AMAT_Estimate_Model::total( (int) $est['id'] );
			}
		}
		return $sum;
	}

	/**
	 * What is still owed across the job's (non-void) invoices, and whether it has
	 * any invoice at all.
	 *
	 * @param int $job_id Job id.
	 * @return array{0:bool,1:float} [has_invoice, balance].
	 */
	private static function balance( $job_id ) {
		$has = false;
		$due = 0.0;
		foreach ( AMAT_Invoice_Model::all( array( 'job_id' => (int) $job_id ) ) as $inv ) {
			if ( 'void' === $inv['status'] ) {
				continue;
			}
			$has  = true;
			$due += (float) AMAT_Invoice_Model::total( (int) $inv['id'] ) - (float) ( $inv['amount_paid'] ?? 0 );
		}
		return array( $has, $due );
	}

	/* --------------------------------------------------------------------- */
	/* Board                                                                 */
	/* --------------------------------------------------------------------- */

	/**
	 * The one line a card shows: what matters at the job's step.
	 *
	 * @param array<string,mixed> $job Job row.
	 * @return string Plain text.
	 */
	private static function card_line( array $job ) {
		$stage = AMAT_Job_Workflow::stage( $job );
		$step  = (string) $job['step'];
		$id    = (int) $job['id'];

		if ( 'closed' === $stage ) {
			return self::appointment( $job );
		}
		if ( 'approval' === $step ) {
			$pending = array_values(
				array_filter(
					AMAT_Estimate_Model::all( array( 'job_id' => $id ), array( 'orderby' => 'id', 'order' => 'DESC' ) ),
					static function ( $e ) {
						return in_array( $e['status'], array( 'sent', 'viewed' ), true );
					}
				)
			);
			if ( $pending ) {
				return sprintf(
					/* translators: 1: estimate number, 2: its total. */
					__( 'Estimate #%1$d · %2$s — waiting on the customer', 'auto-mation' ),
					(int) $pending[0]['id'],
					AMAT_Money::format_amount( AMAT_Estimate_Model::total( (int) $pending[0]['id'] ) )
				);
			}
		}
		$when = self::appointment( $job );
		if ( in_array( $stage, array( 'plan', 'job' ), true ) && '' !== $when ) {
			return $when;
		}
		if ( 'scheduling' === $step ) {
			$n = count( AMAT_Job_Proposal_Model::for_job( $id ) );
			/* translators: %d: number of proposed times. */
			return $n ? sprintf( _n( '%d time proposed — waiting on the customer', '%d times proposed — waiting on the customer', $n, 'auto-mation' ), $n ) : __( 'Needs a time', 'auto-mation' );
		}
		if ( in_array( $step, array( 'deposit', 'ordering' ), true ) ) {
			$approved = self::approved_total( AMAT_Estimate_Model::all( array( 'job_id' => $id ) ) );
			/* translators: %s: approved total. */
			return $approved > 0 ? sprintf( __( 'Approved %s', 'auto-mation' ), AMAT_Money::format_amount( $approved ) ) : '';
		}
		if ( 'pay' === $stage ) {
			list( $has, $due ) = self::balance( $id );
			if ( ! $has ) {
				return __( 'No invoice yet', 'auto-mation' );
			}
			/* translators: %s: amount still owed. */
			return $due > 0.004 ? sprintf( __( 'Balance %s', 'auto-mation' ), AMAT_Money::format_amount( $due ) ) : __( 'Paid — receipt to send', 'auto-mation' );
		}
		$complaint = trim( (string) ( $job['complaint'] ?? '' ) );
		return '' !== $complaint ? $complaint : ( 'info' === $stage ? __( 'No complaint recorded yet', 'auto-mation' ) : '' );
	}

	/**
	 * The Jobs board: a column per stage (Info, Plan, Job, Pay), plus Closed on
	 * request. On a phone the columns become tabs (admin.js initJobBoard).
	 *
	 * @param array<string,mixed>|null $flash Flash payload.
	 * @return void
	 */
	private function render_board( $flash = null ) {
		$show_closed = ! empty( $_GET['show_closed'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only view toggle.
		$columns     = AMAT_Job_Workflow::stages();
		if ( $show_closed ) {
			$columns['closed'] = AMAT_Job_Workflow::stage_label( 'closed' );
		}

		$by_stage = array_fill_keys( array_keys( $columns ), array() );
		foreach ( AMAT_Access::visible_jobs( AMAT_Job_Model::all() ) as $job ) {
			$stage = AMAT_Job_Workflow::stage( $job );
			if ( isset( $by_stage[ $stage ] ) ) {
				$by_stage[ $stage ][] = $job;
			}
		}
		foreach ( $by_stage as $stage => $jobs ) {
			// Furthest along first, then by appointment.
			usort(
				$jobs,
				static function ( $a, $b ) {
					$pa = AMAT_Job_Workflow::position( (string) $a['step'] );
					$pb = AMAT_Job_Workflow::position( (string) $b['step'] );
					if ( $pa !== $pb ) {
						return $pb <=> $pa;
					}
					return strcmp( (string) $a['scheduled_start'], (string) $b['scheduled_start'] );
				}
			);
			$by_stage[ $stage ] = $jobs;
		}

		// On a phone, open on the busiest of Plan and Job (where the day's work is).
		$first_tab = count( $by_stage['job'] ) ? 'job' : 'plan';
		$toggle    = $show_closed ? $this->list_url() : $this->list_url( array( 'show_closed' => '1' ) );
		?>
		<div class="wrap amat-jobs-board">
			<?php $this->toolbar( 'board' ); ?>
			<?php $this->notice( $flash ); ?>

			<div class="amat-board-bar">
				<label class="screen-reader-text" for="amat-board-search"><?php esc_html_e( 'Search jobs', 'auto-mation' ); ?></label>
				<input type="search" id="amat-board-search" class="regular-text" placeholder="<?php esc_attr_e( 'Search jobs, customers, vehicles', 'auto-mation' ); ?>" />
				<a href="<?php echo esc_url( $toggle ); ?>" class="button"><?php echo $show_closed ? esc_html__( 'Hide closed', 'auto-mation' ) : esc_html__( 'Show closed', 'auto-mation' ); ?></a>
			</div>

			<div class="amat-board-tabs" role="tablist" aria-label="<?php esc_attr_e( 'Stages', 'auto-mation' ); ?>">
				<?php foreach ( $columns as $stage => $label ) : ?>
					<button type="button" class="amat-board-tab<?php echo $stage === $first_tab ? ' is-on' : ''; ?>" role="tab" data-tab="<?php echo esc_attr( $stage ); ?>" aria-selected="<?php echo $stage === $first_tab ? 'true' : 'false'; ?>">
						<?php echo esc_html( $label ); ?> <span class="amat-board-count"><?php echo (int) count( $by_stage[ $stage ] ); ?></span>
					</button>
				<?php endforeach; ?>
			</div>

			<div class="amat-board amat-board-cols-<?php echo (int) count( $columns ); ?>">
				<?php foreach ( $columns as $stage => $label ) : ?>
					<section class="amat-board-col<?php echo $stage === $first_tab ? ' is-on' : ''; ?>" data-stage="<?php echo esc_attr( $stage ); ?>" aria-label="<?php echo esc_attr( $label ); ?>">
						<h2 class="amat-board-col-head"><?php echo esc_html( $label ); ?> <span class="amat-board-count"><?php echo (int) count( $by_stage[ $stage ] ); ?></span></h2>
						<?php if ( empty( $by_stage[ $stage ] ) ) : ?>
							<p class="amat-board-empty"><?php esc_html_e( 'Nothing here.', 'auto-mation' ); ?></p>
						<?php endif; ?>
						<?php foreach ( $by_stage[ $stage ] as $job ) : ?>
							<?php
							$who     = self::who( $job );
							$vehicle = self::vehicle_label( $job );
							$title   = AMAT_Job_Model::label( $job, $who );
							$line    = self::card_line( $job );
							$search  = strtolower( $title . ' ' . $who . ' ' . $vehicle );
							?>
							<a class="amat-card" href="<?php echo esc_url( $this->list_url( array( 'action' => 'view', 'id' => (int) $job['id'] ) ) ); ?>" data-search="<?php echo esc_attr( $search ); ?>">
								<span class="amat-card-title"><?php echo esc_html( $title ); ?></span>
								<span class="amat-card-who"><?php echo esc_html( $who . ( '' !== $vehicle ? ' · ' . $vehicle : '' ) ); ?></span>
								<span class="amat-card-step"><?php echo self::step_pill( $job ) . self::flag_pills( $job ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped internally. ?></span>
								<?php if ( '' !== $line ) : ?>
									<span class="amat-card-line"><?php echo esc_html( $line ); ?></span>
								<?php endif; ?>
							</a>
						<?php endforeach; ?>
					</section>
				<?php endforeach; ?>
			</div>
			<p class="amat-board-nomatch description" hidden><?php esc_html_e( 'No jobs match your search.', 'auto-mation' ); ?></p>
		</div>
		<?php
	}

	/* --------------------------------------------------------------------- */
	/* Calendar view                                                         */
	/* --------------------------------------------------------------------- */

	/**
	 * Render the Jobs calendar: the mount points FullCalendar fills (month/week/
	 * day/list, drag to reschedule, a day's jobs listed below, proposed times as
	 * tentative blocks), then the jobs waiting for a slot and the times already
	 * offered to them — what matters while scheduling (Nick, 2026-10-01).
	 *
	 * @param array<string,mixed>|null $flash Flash payload.
	 * @return void
	 */
	private function render_calendar( $flash = null ) {
		$waiting = array_values(
			array_filter(
				AMAT_Access::visible_jobs( AMAT_Job_Model::all() ),
				static function ( $job ) {
					return 'scheduling' === $job['step'] && '' === (string) $job['closed_reason'] && ! AMAT_Job_Model::scheduled_days( $job );
				}
			)
		);
		?>
		<div class="wrap">
			<?php $this->toolbar( 'calendar' ); ?>
			<?php $this->notice( $flash ); ?>

			<div id="amat-cal-notice" class="amat-cal-notice" aria-live="polite"></div>
			<div id="amat-job-calendar" class="amat-job-calendar"></div>
			<noscript><p class="description"><?php esc_html_e( 'The calendar needs JavaScript. The Board lists every job without it.', 'auto-mation' ); ?></p></noscript>
			<div id="amat-cal-detail" class="amat-cal-detail"><p class="description"><?php esc_html_e( 'Tap a day to list its jobs here.', 'auto-mation' ); ?></p></div>

			<h2><?php esc_html_e( 'Waiting for a slot', 'auto-mation' ); ?></h2>
			<?php if ( empty( $waiting ) ) : ?>
				<p class="description"><?php esc_html_e( 'No jobs are waiting to be scheduled.', 'auto-mation' ); ?></p>
			<?php else : ?>
				<p class="description"><?php esc_html_e( 'Jobs at the Scheduling step with no appointment yet. Times already offered show on the calendar as striped blocks.', 'auto-mation' ); ?></p>
				<ul class="amat-waiting-list">
					<?php foreach ( $waiting as $job ) : ?>
						<?php
						$vehicle   = self::vehicle_label( $job );
						$proposals = AMAT_Job_Proposal_Model::for_job( (int) $job['id'] );
						?>
						<li>
							<a href="<?php echo esc_url( $this->list_url( array( 'action' => 'view', 'id' => (int) $job['id'] ) ) ); ?>"><?php echo esc_html( AMAT_Job_Model::label( $job, self::who( $job ) ) ); ?></a>
							<?php if ( '' !== $vehicle ) : ?> — <?php echo esc_html( $vehicle ); ?><?php endif; ?>
							<?php echo self::flag_pills( $job ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped internally. ?>
							<?php if ( $proposals ) : ?>
								<span class="amat-waiting-proposed">
									<?php
									echo esc_html(
										sprintf(
											/* translators: %s: list of proposed times. */
											__( 'Proposed: %s', 'auto-mation' ),
											implode(
												'; ',
												array_map(
													static function ( $p ) {
														return AMAT_Job_Workflow::describe_slot( AMAT_Job_Workflow::parse_when( (string) $p['start_at'] ), AMAT_Job_Workflow::parse_when( (string) $p['end_at'] ) );
													},
													$proposals
												)
											)
										)
									);
									?>
								</span>
							<?php else : ?>
								<span class="amat-waiting-proposed description"><?php esc_html_e( 'No times proposed yet', 'auto-mation' ); ?></span>
							<?php endif; ?>
						</li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
		</div>
		<?php
	}

	/* --------------------------------------------------------------------- */
	/* Job screen                                                            */
	/* --------------------------------------------------------------------- */

	/**
	 * A small POST form for one workflow action on this job.
	 *
	 * @param int                 $job_id  Job id.
	 * @param string              $action  job_flow_* action.
	 * @param string              $label   Button text.
	 * @param string              $class   Button classes.
	 * @param array<string,mixed> $hidden  Extra hidden fields.
	 * @return string Escaped HTML.
	 */
	private function flow_button( $job_id, $action, $label, $class = 'button', array $hidden = array() ) {
		if ( $this->read_only ) {
			return ''; // a job the viewer may see but not work (AMAT_Access)
		}
		$html  = '<form method="post" class="amat-inline-form">';
		$html .= wp_nonce_field( self::FLOW_NONCE, '_wpnonce', true, false );
		$html .= '<input type="hidden" name="amat_action" value="' . esc_attr( $action ) . '" />';
		$html .= '<input type="hidden" name="job_id" value="' . esc_attr( (string) (int) $job_id ) . '" />';
		foreach ( $hidden as $name => $value ) {
			$html .= '<input type="hidden" name="' . esc_attr( $name ) . '" value="' . esc_attr( (string) $value ) . '" />';
		}
		$html .= '<button type="submit" class="' . esc_attr( $class ) . '">' . esc_html( $label ) . '</button></form>';
		return $html;
	}

	/**
	 * Echo one step's block inside a stage section, marked when it is current.
	 *
	 * @param array<string,mixed> $job     Job row.
	 * @param string              $step    Step slug.
	 * @param string              $content Escaped HTML body.
	 * @return void
	 */
	private function step_block( array $job, $step, $content ) {
		$here = '' === (string) $job['closed_reason'] && $step === $job['step'];
		?>
		<div class="amat-step<?php echo $here ? ' is-now' : ''; ?>">
			<h3><?php echo esc_html( AMAT_Job_Workflow::step_label( $step ) ); ?><?php if ( $here ) : ?> <span class="amat-step-here"><?php esc_html_e( 'current step', 'auto-mation' ); ?></span><?php endif; ?></h3>
			<?php echo $content; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built escaped by the caller. ?>
		</div>
		<?php
	}

	/**
	 * Label/value rows (values escaped here; pass pre-escaped HTML as array(html)).
	 *
	 * @param array<int,array{0:string,1:mixed}> $rows Rows.
	 * @return string Escaped HTML.
	 */
	private static function kv( array $rows ) {
		$html = '<dl class="amat-kv">';
		foreach ( array_filter( $rows ) as $row ) { // a null row is one left out
			$value = $row[1];
			if ( is_array( $value ) ) {
				$shown = (string) $value[0];
			} else {
				$shown = '' === trim( (string) $value ) ? '—' : nl2br( esc_html( (string) $value ) );
			}
			$html .= '<dt>' . esc_html( $row[0] ) . '</dt><dd>' . $shown . '</dd>';
		}
		return $html . '</dl>';
	}

	/**
	 * The job screen: where the job is (stage bar + step), its one next action,
	 * closing, and a section per stage with the job's detail.
	 *
	 * Editing is one stage at a time (Nick, 2026-09-30): each stage's header
	 * has an Edit button (`action=edit&stage=info`), and that stage's fields turn
	 * into inputs in place. Those inputs belong to the stage's own form through
	 * the HTML `form` attribute - the <form> element itself sits at the foot of
	 * the section - so the estimate/invoice cards, forms of their own, still open
	 * in place: nothing nests.
	 *
	 * @param array<string,mixed>      $job        Job row.
	 * @param array<string,mixed>|null $flash      Flash payload.
	 * @param string                   $edit_stage Stage being edited, or ''.
	 * @param array<string,mixed>      $typed      What was typed, after a rejected save.
	 * @return void
	 */
	private function render_view( array $job, $flash = null, $edit_stage = '', array $typed = array() ) {
		$id        = (int) $job['id'];
		$stage     = AMAT_Job_Workflow::stage( $job );
		$step      = (string) $job['step'];
		$closed    = 'closed' === $stage;
		$cur_stage = AMAT_Job_Workflow::stage_of_step( $step );
		$owner     = $job['customer_id'] ? AMAT_Customer_Model::find( (int) $job['customer_id'] ) : null;
		$who       = self::who( $job );
		$vehicle   = $job['vehicle_id'] ? AMAT_Vehicle_Model::find( (int) $job['vehicle_id'] ) : null;
		$location  = $job['location_id'] ? AMAT_Location_Model::find( (int) $job['location_id'] ) : null;
		// A technician with contacts hidden never gets them into the page at all.
		$methods   = ( $owner && AMAT_Access::sees_contacts() ) ? AMAT_Contact_Method_Model::for_customer( (int) $job['customer_id'] ) : array();
		$estimates = AMAT_Estimate_Model::all( array( 'job_id' => $id ), array( 'orderby' => 'id', 'order' => 'ASC' ) );
		$invoices  = AMAT_Invoice_Model::all( array( 'job_id' => $id ), array( 'orderby' => 'id', 'order' => 'ASC' ) );
		$proposals = AMAT_Job_Proposal_Model::for_job( $id );
		$when      = self::appointment( $job );
		$open      = isset( $_GET['open'] ) ? sanitize_key( wp_unslash( $_GET['open'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only: which card to show open.

		$return_customer = isset( $_GET['return_customer'] ) ? absint( $_GET['return_customer'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only nav context.
		$back_url        = $return_customer
			? add_query_arg( array( 'page' => AMAT_Customers_Page::PAGE_SLUG, 'action' => 'view', 'id' => $return_customer ), admin_url( 'admin.php' ) )
			: $this->list_url();
		$back_label      = $return_customer ? __( '← Back to customer', 'auto-mation' ) : __( '← All jobs', 'auto-mation' );
		$stage_keys      = array_keys( AMAT_Job_Workflow::stages() );
		$cur_index       = array_search( $cur_stage, $stage_keys, true );

		$this->section_ctx = array(
			'job_id'          => $id,
			'cur_stage'       => $cur_stage,
			'closed'          => $closed,
			'edit_stage'      => $edit_stage,
			'return_customer' => $return_customer,
		);
		// The value a field shows: what was typed (after a rejected save), else what is stored.
		$val = static function ( $key, $stored ) use ( $typed ) {
			return array_key_exists( $key, $typed ) ? (string) $typed[ $key ] : (string) $stored;
		};
		?>
		<div class="wrap amat-detail amat-job-screen<?php echo '' !== $edit_stage ? ' is-editing' : ''; ?>">
			<p class="amat-back"><a href="<?php echo esc_url( $back_url ); ?>"><?php echo esc_html( $back_label ); ?></a></p>
			<h1><?php echo esc_html( AMAT_Job_Model::label( $job, $owner ? $who : __( 'Job', 'auto-mation' ) ) ); ?></h1>
			<p class="amat-job-sub"><?php echo esc_html( implode( ' · ', array_filter( array( $who, $vehicle ? AMAT_Vehicle_Model::label( $vehicle ) : '', $when ) ) ) ); ?></p>
			<hr class="wp-header-end" />
			<?php $this->notice( $flash ); ?>

			<p class="amat-job-flags"><?php echo self::step_pill( $job ) . self::flag_pills( $job ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped internally. ?></p>
			<?php if ( '' !== (string) ( $job['review_reason'] ?? '' ) ) : ?>
				<div class="notice notice-warning inline amat-review-note">
					<p><strong><?php esc_html_e( 'Needs review:', 'auto-mation' ); ?></strong> <?php echo esc_html( (string) $job['review_reason'] ); ?>
						<span class="description"><?php esc_html_e( 'The job stays in Info until this is cleared. The customer does not see it.', 'auto-mation' ); ?></span></p>
					<?php echo $this->flow_button( $id, 'job_flow_reviewed', __( 'Mark reviewed', 'auto-mation' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped internally. ?>
				</div>
			<?php endif; ?>

			<div class="amat-stages" aria-label="<?php esc_attr_e( 'Stages', 'auto-mation' ); ?>">
				<?php foreach ( AMAT_Job_Workflow::stages() as $key => $label ) : ?>
					<?php
					$i   = array_search( $key, $stage_keys, true );
					$cls = 'amat-stage amat-stage-' . $key;
					if ( $closed || $i < $cur_index ) {
						$cls .= ' is-done';
					} elseif ( $i === $cur_index ) {
						$cls .= ' is-now';
					}
					?>
					<div class="<?php echo esc_attr( $cls ); ?>"><b><?php echo esc_html( $label ); ?></b><span><?php echo ( ! $closed && $i === $cur_index ) ? esc_html( AMAT_Job_Workflow::step_label( $step ) ) : ''; ?></span></div>
				<?php endforeach; ?>
			</div>

			<div class="amat-job-actions">
				<?php if ( ! $closed ) : ?>
					<?php echo $this->flow_button( $id, 'job_flow_advance', ( AMAT_Job_Workflow::step_actions()[ $step ] ?? __( 'Done', 'auto-mation' ) ) . ' ✓', 'button button-primary' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped internally. ?>

					<form method="post" class="amat-inline-form">
						<?php wp_nonce_field( self::FLOW_NONCE ); ?>
						<input type="hidden" name="amat_action" value="job_flow_set_step" />
						<input type="hidden" name="job_id" value="<?php echo esc_attr( (string) $id ); ?>" />
						<label class="screen-reader-text" for="amat-set-step"><?php esc_html_e( 'Set the step by hand', 'auto-mation' ); ?></label>
						<select name="step" id="amat-set-step">
							<?php foreach ( AMAT_Job_Workflow::stages() as $skey => $slabel ) : ?>
								<optgroup label="<?php echo esc_attr( $slabel ); ?>">
									<?php foreach ( AMAT_Job_Workflow::steps() as $k => $l ) : ?>
										<?php if ( AMAT_Job_Workflow::stage_of_step( $k ) === $skey ) : ?>
											<option value="<?php echo esc_attr( $k ); ?>" <?php selected( $k, $step ); ?>><?php echo esc_html( $l ); ?></option>
										<?php endif; ?>
									<?php endforeach; ?>
								</optgroup>
							<?php endforeach; ?>
						</select>
						<button type="submit" class="button"><?php esc_html_e( 'Set step', 'auto-mation' ); ?></button>
					</form>

					<?php // Hold and Standby are set in the Plan stage's Scheduling step (Nick, 2026-09-30). ?>
					<details class="amat-pop">
						<summary class="button amat-btn-disable"><?php esc_html_e( 'Close job…', 'auto-mation' ); ?></summary>
						<form method="post" class="amat-pop-body">
							<?php wp_nonce_field( self::FLOW_NONCE ); ?>
							<input type="hidden" name="amat_action" value="job_flow_close" />
							<input type="hidden" name="job_id" value="<?php echo esc_attr( (string) $id ); ?>" />
							<fieldset>
								<legend><?php esc_html_e( 'Close because', 'auto-mation' ); ?></legend>
								<?php foreach ( AMAT_Job_Workflow::close_reasons() as $rkey => $rlabel ) : ?>
									<label><input type="radio" name="close_reason" value="<?php echo esc_attr( $rkey ); ?>" /> <?php echo esc_html( $rlabel ); ?></label>
								<?php endforeach; ?>
							</fieldset>
							<button type="submit" class="button amat-btn-disable"><?php esc_html_e( 'Close job', 'auto-mation' ); ?></button>
						</form>
					</details>
				<?php else : ?>
					<?php echo $this->flow_button( $id, 'job_flow_reopen', __( 'Reopen', 'auto-mation' ), 'button button-primary' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<?php endif; ?>

				<?php echo $this->flow_button( $id, 'job_flow_related', __( 'Create related job', 'auto-mation' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<?php echo $this->delete_button( self::POST_ACTION, self::NONCE_ACTION, $id, $this->list_url() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built with esc_* internally. ?>
			</div>

			<?php
			// ---- Info ------------------------------------------------------
			$cust_id = (int) $job['customer_id'];
			$this->open_section( 'info' );
			if ( 'info' === $edit_stage ) {
				$this->step_block( $job, 'customer', self::in_stage_form( $this->info_customer_fields( $job, $owner, $methods, $location, $typed ) ) );
				$this->step_block( $job, 'vehicle', self::in_stage_form( $this->info_vehicle_fields( $job, $vehicle, $typed ) ) );
			} else {
				$contact = '';
				foreach ( $methods as $m ) {
					$m_type   = (string) ( $m['type'] ?? '' );
					$m_show   = AMAT_Contact_Method_Types::format( $m_type, (string) ( $m['value'] ?? '' ) );
					$m_href   = AMAT_Contact_Method_Types::href( $m_type, (string) ( $m['value'] ?? '' ) );
					$contact .= '<span class="amat-contact-label">' . esc_html( AMAT_Contact_Method_Types::label( $m_type ) ) . ':</span> '
						. ( $m_href ? '<a href="' . esc_url( $m_href ) . '">' . esc_html( $m_show ) . '</a>' : esc_html( $m_show ) ) . '<br />';
				}
				$customer_link = $owner
					? ( AMAT_Access::is_owner()
						? '<a href="' . esc_url( add_query_arg( array( 'page' => AMAT_Customers_Page::PAGE_SLUG, 'action' => 'view', 'id' => (int) $owner['id'] ), admin_url( 'admin.php' ) ) ) . '">' . esc_html( $who ) . '</a>'
						: esc_html( $who ) ) // the customer screens are the owner's
					: '—';
				$loc_text = $location ? trim( trim( (string) $location['label'] ) . ' ' . AMAT_Location_Model::one_line( $location ) ) : '';
				$vin      = $vehicle ? trim( (string) ( $vehicle['vin'] ?? '' ) ) : '';
				ob_start();
				$this->render_vin_copy( $vin );
				$vin_html = (string) ob_get_clean();

				// The optional fields show only when filled (Nick, 2026-10-06: the
				// job screen shows every field of the job's records).
				$filled = static function ( $label, $value ) {
					return '' !== trim( (string) $value ) ? array( $label, (string) $value ) : null;
				};
				$this->step_block(
					$job,
					'customer',
					self::kv(
						array_merge(
							$this->related_rows( $job ),
							array( array( __( 'Customer', 'auto-mation' ), array( $customer_link ) ) ),
							AMAT_Access::sees_contacts() ? array( array( __( 'Contact', 'auto-mation' ), array( '' !== $contact ? $contact : '—' ) ) ) : array(),
							array(
								$filled( __( 'Customer notes (internal)', 'auto-mation' ), $owner['notes'] ?? '' ),
								array( __( 'Location', 'auto-mation' ), $loc_text ),
								$filled( __( 'Access code', 'auto-mation' ), $location['code'] ?? '' ),
								$filled( __( 'Location notes', 'auto-mation' ), $location['notes'] ?? '' ),
							)
						)
					)
				);
				$this->step_block(
					$job,
					'vehicle',
					self::kv(
						array(
							array( __( 'Vehicle', 'auto-mation' ), $vehicle ? AMAT_Vehicle_Model::label( $vehicle ) : '' ),
							array( __( 'VIN', 'auto-mation' ), array( '' !== $vin ? $vin_html : '—' ) ),
							array( __( 'Plate', 'auto-mation' ), $vehicle ? AMAT_Vehicle_Model::plate_label( $vehicle ) : '' ),
							array( __( 'Color', 'auto-mation' ), $vehicle ? (string) $vehicle['color'] : '' ),
							$filled( __( 'Color code', 'auto-mation' ), $vehicle['color_code'] ?? '' ),
							'' !== trim( (string) ( $vehicle['warnings'] ?? '' ) ) ? array( __( 'Warnings', 'auto-mation' ), array( '<span class="amat-veh-warnings">' . nl2br( esc_html( (string) $vehicle['warnings'] ) ) . '</span>' ) ) : null,
							$filled( __( 'Vehicle notes', 'auto-mation' ), $vehicle['notes'] ?? '' ),
							array( __( 'Complaint', 'auto-mation' ), (string) $job['complaint'] ),
						)
					)
				);
			}
			$this->close_section( 'info' );

			// ---- Plan ------------------------------------------------------
			$editing_plan = 'plan' === $edit_stage;
			$est_html     = $this->doc_table( 'estimate', $estimates, $id, $open, $editing_plan );
			if ( $estimates ) {
				$est_html .= '<p class="amat-approved">' . esc_html__( 'Approved total', 'auto-mation' ) . ' <b>' . esc_html( AMAT_Money::format_amount( self::approved_total( $estimates ) ) ) . '</b> <span class="description">' . esc_html__( 'the sum of the accepted and approved estimates', 'auto-mation' ) . '</span></p>';
			}

			$this->open_section( 'plan' );
			$this->step_block(
				$job,
				'research',
				self::kv( array( array( __( 'Notes', 'auto-mation' ), $editing_plan ? array( self::in_stage_form( self::textarea( 'research', 'amat-job-research', $val( 'research', $job['research'] ), __( 'Labor time, difficulty, parts availability.', 'auto-mation' ) ) ) ) : (string) $job['research'] ) ) )
			);
			$this->step_block( $job, 'estimate', $est_html );
			$this->step_block( $job, 'approval', '<p class="description">' . esc_html__( 'Recorded on each estimate: accepted by the customer, or approved by you. The go-ahead moves the job on to the deposit.', 'auto-mation' ) . '</p>' );
			$this->step_block( $job, 'deposit', '<p class="description">' . esc_html__( 'Take the deposit, or tap on if none is needed.', 'auto-mation' ) . '</p>' );
			$this->step_block( $job, 'ordering', '<p class="description">' . esc_html__( 'Order the parts the approved estimates need.', 'auto-mation' ) . '</p>' );
			$sched = $this->scheduling_block( $editing_plan ? array_merge( $job, array_intersect_key( $typed, array_flip( array( 'scheduled_start', 'scheduled_end' ) ) ) ) : $job, $proposals, $when, $editing_plan );
			$this->step_block( $job, 'scheduling', $editing_plan ? self::in_stage_form( $sched ) : $sched );
			$this->close_section( 'plan' );

			// ---- Job -------------------------------------------------------
			$editing_job = 'job' === $edit_stage;
			$mileage_raw = $val( 'mileage', $job['mileage'] ?? '' );
			$mileage     = '' !== $mileage_raw ? number_format_i18n( (int) $mileage_raw ) : '';
			$this->open_section( 'job' );
			$this->step_block(
				$job,
				'vehicle_info',
				self::kv(
					array(
						array(
							__( 'Odometer', 'auto-mation' ),
							$editing_job
								? array( self::in_stage_form( '<input name="mileage" id="amat-job-mileage" type="number" min="0" step="1" inputmode="numeric" value="' . esc_attr( '' !== $mileage_raw ? (string) (int) $mileage_raw : '' ) . '" aria-label="' . esc_attr__( 'Odometer', 'auto-mation' ) . '" />' ) )
								: $mileage,
						),
						array( __( 'Existing damage', 'auto-mation' ), $editing_job ? array( self::in_stage_form( self::textarea( 'damage', 'amat-job-damage', $val( 'damage', $job['damage'] ), __( 'Anything already damaged when you arrived.', 'auto-mation' ) ) ) ) : (string) $job['damage'] ),
					)
				)
			);
			$this->step_block( $job, 'reproduce', '' );
			$this->step_block( $job, 'diagnostic', '<p class="description">' . esc_html__( 'Anything beyond what was approved becomes a new estimate on this job, for the customer to approve.', 'auto-mation' ) . '</p>' );
			$this->step_block( $job, 'repair', '' );
			$this->step_block( $job, 'inspect', '' );
			echo self::kv( array( array( __( 'Notes (Internal)', 'auto-mation' ), $editing_job ? array( self::in_stage_form( self::textarea( 'description', 'amat-job-description', $val( 'description', $job['description'] ), __( 'For your eyes only — never shown to the customer. Anything the customer should read goes in the notes on an estimate or invoice.', 'auto-mation' ), 4 ) ) ) : (string) $job['description'] ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped internally.
			$this->close_section( 'job' );

			// ---- Pay -------------------------------------------------------
			$this->open_section( 'pay' );
			$this->step_block( $job, 'invoice', $this->doc_table( 'invoice', $invoices, $id, $open, 'pay' === $edit_stage ) );
			$this->step_block( $job, 'receipt', '<p class="description">' . esc_html__( 'Send the receipt once the balance is paid; the job then closes.', 'auto-mation' ) . '</p>' );
			$this->close_section( 'pay' );

			// ---- History ---------------------------------------------------
			$history = AMAT_Log_Model::for_entity( 'job', $id, 100 );
			?>
			<details class="amat-job-section">
				<summary><?php esc_html_e( 'History', 'auto-mation' ); ?> <span class="amat-section-steps"><?php esc_html_e( 'every step change, hold and proposal', 'auto-mation' ); ?></span></summary>
				<div class="amat-job-section-body">
					<?php if ( empty( $history ) ) : ?>
						<p class="description"><?php esc_html_e( 'Nothing recorded yet.', 'auto-mation' ); ?></p>
					<?php else : ?>
						<ol class="amat-history">
							<?php foreach ( $history as $h ) : ?>
								<li><span class="amat-history-when"><?php echo esc_html( $this->dt_display( (string) $h['created_at'] ) ); ?></span> <?php echo esc_html( (string) $h['message'] ); ?></li>
							<?php endforeach; ?>
						</ol>
					<?php endif; ?>
				</div>
			</details>

			<?php
			/**
			 * Let a provider integration add actions to the job detail. Core ships
			 * no default (estimate→provider sync lives on the native estimate).
			 *
			 * @param array<string,mixed>      $job   Job row.
			 * @param array<string,mixed>|null $owner Owning customer row.
			 */
			if ( '' === $edit_stage ) {
				do_action( 'amat_job_detail_actions', $job, $owner );
			}
			?>
		</div>
		<?php
	}

	/**
	 * The jobs this one is related to: the one it follows on from ("Create
	 * related job") and any that follow on from it, each linked when this user
	 * may open it.
	 *
	 * @param array<string,mixed> $job Job row.
	 * @return array<int,array{0:string,1:array<int,string>}> kv() rows.
	 */
	private function related_rows( array $job ) {
		$link = function ( array $other ) {
			$owner = AMAT_Customer_Model::find( (int) $other['customer_id'] );
			$label = esc_html( AMAT_Job_Model::label( $other, $owner ? AMAT_Customer_Model::display_name( $owner ) : '' ) );
			return AMAT_Access::can_view_job( $other )
				? '<a href="' . esc_url( $this->list_url( array( 'action' => 'view', 'id' => (int) $other['id'] ) ) ) . '">' . $label . '</a>'
				: $label;
		};
		$rows   = array();
		$before = (int) ( $job['related_job_id'] ?? 0 ) ? AMAT_Job_Model::find( (int) $job['related_job_id'] ) : null;
		if ( $before ) {
			$rows[] = array( __( 'Follows on from', 'auto-mation' ), array( $link( $before ) ) );
		}
		$after = AMAT_Job_Model::all( array( 'related_job_id' => (int) $job['id'] ) );
		if ( $after ) {
			$rows[] = array( __( 'Followed by', 'auto-mation' ), array( implode( '<br />', array_map( $link, $after ) ) ) );
		}
		return $rows;
	}

	/**
	 * The customer's own decision on an estimate, from the portal: who, when, the
	 * total and, for a decline, their reason ('' when they have not decided
	 * there).
	 *
	 * @param array<string,mixed> $doc Estimate row.
	 * @return string Escaped HTML.
	 */
	private static function decision_note( array $doc ) {
		if ( '' === (string) ( $doc['decision_at'] ?? '' ) || ! in_array( (string) $doc['status'], array( 'accepted', 'declined' ), true ) ) {
			return '';
		}
		$user = get_userdata( (int) $doc['decision_by'] );
		$who  = $user ? $user->display_name : __( 'the customer', 'auto-mation' );
		$when = mysql2date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (string) $doc['decision_at'] );
		$text = 'accepted' === $doc['status']
			/* translators: 1: who, 2: when, 3: the total accepted. */
			? sprintf( __( 'Accepted by %1$s in the portal, %2$s, for %3$s.', 'auto-mation' ), $who, $when, AMAT_Money::format_amount( $doc['decision_total'] ) )
			/* translators: 1: who, 2: when. */
			: sprintf( __( 'Declined by %1$s in the portal, %2$s.', 'auto-mation' ), $who, $when );
		$why  = trim( (string) ( $doc['decline_reason'] ?? '' ) );
		return '<p class="amat-doc-decision amat-doc-decision-' . esc_attr( (string) $doc['status'] ) . '">' . esc_html( $text )
			. ( 'declined' === $doc['status'] && '' !== $why ? ' <span class="amat-doc-decision-why">' . esc_html( sprintf( /* translators: %s: their reason. */ __( 'Their reason: %s', 'auto-mation' ), $why ) ) . '</span>' : '' )
			. '</p>';
	}

	/**
	 * The id of the one stage form. Each field of the stage being edited carries
	 * `form="amat-stage-form"`; the <form> element itself sits at the foot of the
	 * section, so the document cards (forms of their own) never nest inside it.
	 *
	 * @var string
	 */
	const STAGE_FORM = 'amat-stage-form';

	/**
	 * What the section helpers need to know about the screen being drawn.
	 *
	 * @var array{job_id:int,cur_stage:string,closed:bool,edit_stage:string,return_customer:int}
	 */
	private $section_ctx = array(
		'job_id'          => 0,
		'cur_stage'       => '',
		'closed'          => false,
		'edit_stage'      => '',
		'return_customer' => 0,
	);

	/**
	 * Tie every field in a block of HTML to the stage form.
	 *
	 * @param string $html Escaped HTML.
	 * @return string
	 */
	private static function in_stage_form( $html ) {
		return (string) preg_replace( '/<(input|select|textarea|button)\b(?![^>]*\bform=)/', '<$1 form="' . self::STAGE_FORM . '"', (string) $html );
	}

	/**
	 * URL of the job screen, in a stage's edit mode or not.
	 *
	 * @param string $stage Stage to edit, or '' for the plain screen.
	 * @return string
	 */
	private function screen_url( $stage = '' ) {
		$args = array( 'action' => '' === $stage ? 'view' : 'edit', 'id' => (int) $this->section_ctx['job_id'] );
		if ( '' !== $stage ) {
			$args['stage'] = $stage;
		}
		if ( $this->section_ctx['return_customer'] ) {
			$args['return_customer'] = (int) $this->section_ctx['return_customer'];
		}
		return $this->list_url( $args );
	}

	/**
	 * Open a stage section: expanded when it is the job's current stage or the
	 * stage being edited. Its header carries its Edit button; while it is being
	 * edited, Save and Cancel sit at its top instead.
	 *
	 * @param string $stage Stage slug.
	 * @return void
	 */
	private function open_section( $stage ) {
		$ctx     = $this->section_ctx;
		$editing = $stage === $ctx['edit_stage'];
		$steps   = array();
		foreach ( AMAT_Job_Workflow::steps() as $k => $l ) {
			if ( AMAT_Job_Workflow::stage_of_step( $k ) === $stage ) {
				$steps[] = $l;
			}
		}
		$label = AMAT_Job_Workflow::stage_label( $stage );
		echo '<details class="amat-job-section amat-job-section-' . esc_attr( $stage ) . ( $editing ? ' is-editing' : '' ) . '"' . ( $editing || ( ! $ctx['closed'] && $stage === $ctx['cur_stage'] ) ? ' open' : '' ) . '>'
			. '<summary>' . esc_html( $label ) . ' <span class="amat-section-steps">' . esc_html( implode( ' · ', $steps ) ) . '</span>'
			. ( $editing || $this->read_only ? '' : '<a href="' . esc_url( $this->screen_url( $stage ) ) . '" class="button button-small amat-stage-edit-btn"'
				/* translators: %s: the stage, e.g. "Info". */
				. ' aria-label="' . esc_attr( sprintf( __( 'Edit %s', 'auto-mation' ), $label ) ) . '">' . esc_html__( 'Edit', 'auto-mation' ) . '</a>' )
			. '</summary><div class="amat-job-section-body">';
		if ( $editing ) {
			echo $this->stage_edit_bar(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped internally.
		}
	}

	/**
	 * Close a stage section. The stage being edited ends with its form.
	 *
	 * @param string $stage Stage slug.
	 * @return void
	 */
	private function close_section( $stage ) {
		if ( $stage === $this->section_ctx['edit_stage'] ) {
			echo '<form method="post" id="' . esc_attr( self::STAGE_FORM ) . '" class="amat-stage-form">' // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped piece by piece.
				. wp_nonce_field( self::NONCE_ACTION, '_wpnonce', true, false )
				. '<input type="hidden" name="amat_action" value="' . esc_attr( self::POST_ACTION ) . '" />'
				. '<input type="hidden" name="job_id" value="' . esc_attr( (string) (int) $this->section_ctx['job_id'] ) . '" />'
				. '<input type="hidden" name="stage" value="' . esc_attr( $stage ) . '" />'
				. ( $this->section_ctx['return_customer'] ? '<input type="hidden" name="return_customer" value="' . esc_attr( (string) (int) $this->section_ctx['return_customer'] ) . '" />' : '' )
				. $this->stage_edit_bar()
				. '</form>';
		}
		echo '</div></details>';
	}

	/**
	 * Save / Cancel for the stage being edited.
	 *
	 * @return string Escaped HTML.
	 */
	private function stage_edit_bar() {
		return '<div class="amat-stage-edit-bar">'
			. '<button type="submit" form="' . esc_attr( self::STAGE_FORM ) . '" class="button button-primary">' . esc_html__( 'Save', 'auto-mation' ) . '</button> '
			. '<a href="' . esc_url( $this->screen_url() ) . '" class="button amat-stage-cancel">' . esc_html__( 'Cancel', 'auto-mation' ) . '</a>'
			. '</div>';
	}

	/**
	 * The Info stage's Customer step, as inputs: the job's name, the customer's
	 * names and contact methods, and the location (pick one, add one, edit its
	 * address). These edit the customer's own records (Nick, 2026-09-30).
	 *
	 * @param array<string,mixed>            $job      Job row.
	 * @param array<string,mixed>|null       $owner    Customer row.
	 * @param array<int,array<string,mixed>> $methods  Their contact methods.
	 * @param array<string,mixed>|null       $location The job's location.
	 * @param array<string,mixed>            $typed    What was typed, after a rejected save.
	 * @return string Escaped HTML (not yet tied to the stage form).
	 */
	private function info_customer_fields( array $job, $owner, array $methods, $location, array $typed ) {
		$v       = static function ( $key, $stored ) use ( $typed ) {
			return array_key_exists( $key, $typed ) ? (string) $typed[ $key ] : (string) $stored;
		};
		$display = $v( 'display_name', $owner['display_name'] ?? '' );
		$custom  = '' !== trim( $display );
		$rows    = '';
		foreach ( ( array_key_exists( 'methods', $typed ) ? (array) $typed['methods'] : $methods ) as $m ) {
			$type  = (string) ( $m['type'] ?? '' );
			$value = (string) ( $m['value'] ?? '' );
			$rows .= AMAT_Customers_Page::cm_row_html( $type, AMAT_Contact_Method_Types::is_valid_type( $type ) ? AMAT_Contact_Method_Types::format( $type, $value ) : $value );
		}
		if ( '' === $rows ) {
			$rows = AMAT_Customers_Page::cm_row_html( '', '' );
		}

		// The location's address fields show the location the job points at (or
		// what was typed); admin.js refills them when another one is picked.
		$loc_id = $v( 'location_id', $job['location_id'] );
		if ( $location && (string) (int) $location['id'] === $loc_id ) {
			$loc = $location;
		} else {
			$loc = ( ctype_digit( $loc_id ) && (int) $loc_id ) ? AMAT_Location_Model::find( (int) $loc_id ) : null;
		}
		$addr = '';
		foreach ( array(
			'label'    => __( 'Label (e.g. Home, Work)', 'auto-mation' ),
			'street_1' => __( 'Street', 'auto-mation' ),
			'street_2' => __( 'Street, line 2', 'auto-mation' ),
			'city'     => __( 'City', 'auto-mation' ),
			'state'    => __( 'State', 'auto-mation' ),
			'zipcode'  => __( 'ZIP', 'auto-mation' ),
			'code'     => __( 'Gate or access code', 'auto-mation' ),
		) as $field => $placeholder ) {
			$addr .= '<input type="text" name="loc_' . esc_attr( $field ) . '" id="amat-loc-' . esc_attr( $field ) . '" class="amat-loc-' . esc_attr( $field ) . ( 'state' === $field ? ' amat-state-input' : '' ) . '" value="' . esc_attr( $v( 'loc_' . $field, $loc[ $field ] ?? '' ) ) . '" placeholder="' . esc_attr( $placeholder ) . '" aria-label="' . esc_attr( $placeholder ) . '"' . ( 'state' === $field ? ' maxlength="2"' : '' ) . ( 'zipcode' === $field ? ' maxlength="10" inputmode="numeric" data-zip' : '' ) . ' />';
		}

		$addr .= '<textarea name="loc_notes" id="amat-loc-notes" class="large-text amat-loc-notes" rows="2" placeholder="' . esc_attr__( 'Location notes', 'auto-mation' ) . '" aria-label="' . esc_attr__( 'Location notes', 'auto-mation' ) . '">' . esc_textarea( $v( 'loc_notes', $loc['notes'] ?? '' ) ) . '</textarea>';

		$contact_row = array(
			__( 'Contact', 'auto-mation' ),
			array(
				'<div id="amat-cm-rows">' . $rows . '</div>' . AMAT_Customers_Page::cm_row_html( '', '', true )
				. '<p><button type="button" class="button" id="amat-cm-add">' . esc_html__( 'Add contact method', 'auto-mation' ) . '</button></p>'
				. '<p class="description">' . esc_html__( 'Drag to reorder — the top method is the preferred way to reach the customer.', 'auto-mation' ) . '</p>',
			),
		);

		return self::kv(
			array(
				array( __( 'Job name', 'auto-mation' ), array( '<input type="text" name="name" id="amat-job-name" maxlength="255" value="' . esc_attr( $v( 'name', $job['name'] ) ) . '" placeholder="' . esc_attr( $owner ? AMAT_Customer_Model::display_name( $owner ) : '' ) . '" aria-label="' . esc_attr__( 'Job name', 'auto-mation' ) . '" />' ) ),
				array(
					__( 'Name', 'auto-mation' ),
					array(
						'<span class="amat-name-edit"><input type="text" name="first_name" id="amat-first" maxlength="100" value="' . esc_attr( $v( 'first_name', $owner['first_name'] ?? '' ) ) . '" placeholder="' . esc_attr__( 'First', 'auto-mation' ) . '" aria-label="' . esc_attr__( 'First name', 'auto-mation' ) . '" required />'
						. '<input type="text" name="last_name" id="amat-last" maxlength="100" value="' . esc_attr( $v( 'last_name', $owner['last_name'] ?? '' ) ) . '" placeholder="' . esc_attr__( 'Last', 'auto-mation' ) . '" aria-label="' . esc_attr__( 'Last name', 'auto-mation' ) . '" /></span>',
					),
				),
				array(
					__( 'Display name', 'auto-mation' ),
					array( '<input type="text" name="display_name" id="amat-display" maxlength="191" class="' . ( $custom ? '' : 'amat-input-auto' ) . '" value="' . esc_attr( $display ) . '" data-custom="' . ( $custom ? '1' : '0' ) . '" aria-label="' . esc_attr__( 'Display name', 'auto-mation' ) . '" /> <span id="amat-display-auto" class="amat-auto-tag"' . ( $custom ? ' style="display:none;"' : '' ) . '>' . esc_html__( '(Auto)', 'auto-mation' ) . '</span>' ),
				),
				// Hidden contacts: no rows to read or edit (and the save leaves them be).
				AMAT_Access::sees_contacts() ? $contact_row : null,
				array( __( 'Customer notes (internal)', 'auto-mation' ), array( self::textarea( 'customer_notes', 'amat-customer-notes', $v( 'customer_notes', $owner['notes'] ?? '' ), __( 'About the customer, for you and your techs - never shown to them.', 'auto-mation' ) ) ) ),
				array(
					__( 'Location', 'auto-mation' ),
					array(
						$this->location_select( (int) $job['customer_id'], 'new' === $loc_id ? 'new' : (int) $loc_id, true )
						. '<span class="amat-loc-edit">' . $addr . '</span>'
						. '<p class="description">' . esc_html__( 'Edits this location for every job that uses it. Choose "+ New location" to add one.', 'auto-mation' ) . '</p>',
					),
				),
			)
		);
	}

	/**
	 * The Info stage's Vehicle step, as inputs: pick or add the vehicle, then
	 * its VIN, Plate and Color (they edit the vehicle's own record), and the
	 * complaint.
	 *
	 * @param array<string,mixed>      $job     Job row.
	 * @param array<string,mixed>|null $vehicle The job's vehicle.
	 * @param array<string,mixed>      $typed   What was typed, after a rejected save.
	 * @return string Escaped HTML (not yet tied to the stage form).
	 */
	private function info_vehicle_fields( array $job, $vehicle, array $typed ) {
		$v = static function ( $key, $stored ) use ( $typed ) {
			return array_key_exists( $key, $typed ) ? (string) $typed[ $key ] : (string) $stored;
		};
		return self::kv(
			array(
				array( __( 'Vehicle', 'auto-mation' ), array( $this->vehicle_picker( (int) $job['customer_id'], (int) $v( 'vehicle_id', $job['vehicle_id'] ), false ) ) ),
				array(
					__( 'VIN', 'auto-mation' ),
					array(
						'<span class="amat-vin-edit"><input type="text" name="vin" id="amat-veh-vin" maxlength="17" autocomplete="off" value="' . esc_attr( $v( 'vin', $vehicle['vin'] ?? '' ) ) . '" aria-label="' . esc_attr__( 'VIN', 'auto-mation' ) . '" />'
						. ' <button type="button" class="button" id="amat-veh-decode" data-year="' . esc_attr( (string) ( $vehicle['year'] ?? '' ) ) . '">' . esc_html__( 'Decode VIN', 'auto-mation' ) . '</button></span>'
						. '<div id="amat-veh-decode-status" class="amat-vin-status" aria-live="polite"></div>'
						. '<p class="description">' . esc_html__( 'A changed VIN is decoded when you save, and its year, make, model and specs stored.', 'auto-mation' ) . '</p>',
					),
				),
				array( __( 'Plate', 'auto-mation' ), array( '<input type="text" name="license_plate" id="amat-veh-plate" maxlength="20" value="' . esc_attr( $v( 'license_plate', $vehicle['license_plate'] ?? '' ) ) . '" aria-label="' . esc_attr__( 'Plate', 'auto-mation' ) . '" />' ) ),
				array( __( 'Plate state', 'auto-mation' ), array( '<input type="text" name="plate_state" id="amat-veh-plate-state" class="small-text amat-state-input" maxlength="2" value="' . esc_attr( $v( 'plate_state', $vehicle['plate_state'] ?? '' ) ) . '" aria-label="' . esc_attr__( 'Plate state', 'auto-mation' ) . '" placeholder="IN" />' ) ),
				array( __( 'Color', 'auto-mation' ), array( '<input type="text" name="color" id="amat-veh-color" maxlength="50" value="' . esc_attr( $v( 'color', $vehicle['color'] ?? '' ) ) . '" aria-label="' . esc_attr__( 'Color', 'auto-mation' ) . '" />' ) ),
				array( __( 'Color code', 'auto-mation' ), array( '<input type="text" name="color_code" id="amat-veh-color-code" maxlength="20" value="' . esc_attr( $v( 'color_code', $vehicle['color_code'] ?? '' ) ) . '" aria-label="' . esc_attr__( 'Color code', 'auto-mation' ) . '" />' ) ),
				array( __( 'Warnings', 'auto-mation' ), array( self::textarea( 'warnings', 'amat-veh-warnings', $v( 'warnings', $vehicle['warnings'] ?? '' ), __( 'Anything every tech must know before touching it.', 'auto-mation' ) ) ) ),
				array( __( 'Vehicle notes', 'auto-mation' ), array( self::textarea( 'vehicle_notes', 'amat-veh-notes', $v( 'vehicle_notes', $vehicle['notes'] ?? '' ) ) ) ),
				array( __( 'Complaint', 'auto-mation' ), array( self::textarea( 'complaint', 'amat-job-complaint', $v( 'complaint', $job['complaint'] ), __( 'What the customer says is wrong, in their words.', 'auto-mation' ) ) ) ),
			)
		);
	}

	/**
	 * The Scheduling step: the appointment, the flags, the proposed times (with
	 * "Customer picked this" and "Withdraw"), and the form to offer another.
	 *
	 * @param array<string,mixed>            $job       Job row.
	 * @param array<int,array<string,mixed>> $proposals The job's proposals.
	 * @param string                         $when      Appointment text.
	 * @param bool                           $editing   Edit mode: the appointment as
	 *                                                  inputs, proposals set aside.
	 * @return string Escaped HTML.
	 */
	private function scheduling_block( array $job, array $proposals, $when, $editing = false ) {
		// (The Technician row and accept_form() are technicians phase 1, 2026-10-01.)
		$id = (int) $job['id'];
		if ( $editing ) {
			ob_start();
			echo '<span class="amat-appt-edit"><span class="amat-appt-part">' . esc_html__( 'Start', 'auto-mation' ) . ' ';
			$this->datetime_fields( 'scheduled_start', 'amat-job-start', $job['scheduled_start'] ?? '' );
			echo '</span><span class="amat-appt-part">' . esc_html__( 'End', 'auto-mation' ) . ' ';
			$this->datetime_fields( 'scheduled_end', 'amat-job-end', $job['scheduled_end'] ?? '' );
			echo '</span></span>';
			$appt = (string) ob_get_clean();
		}
		$tech = (int) ( $job['technician_id'] ?? 0 );
		if ( ! $editing ) {
			$actions = $this->appointment_buttons( $job );
			$appt    = '' !== $actions
				? esc_html( $when ) . ' <span class="amat-appt-actions">' . $actions . '</span>'
				: ( '' !== $when ? esc_html( $when ) : esc_html__( 'Not booked yet', 'auto-mation' ) );
		}
		$html = self::kv(
			array(
				array( __( 'Appointment', 'auto-mation' ), array( $appt ) ),
				array( __( 'Technician', 'auto-mation' ), $editing && AMAT_Access::is_owner() ? array( self::tech_select( 'amat-job-tech', $tech ) ) : ( $tech ? AMAT_Technicians::name( $tech ) : __( 'Unassigned', 'auto-mation' ) ) ),
				array( __( 'Hold / Standby', 'auto-mation' ), $editing ? array( self::flag_fields( $job ) ) : self::flag_summary( $job ) ),
			)
		);
		if ( $editing || '' !== (string) $job['closed_reason'] ) {
			return $html;
		}

		$html .= '<h4>' . esc_html__( 'Proposed times', 'auto-mation' ) . '</h4>';
		if ( $proposals ) {
			$html .= '<ul class="amat-proposals">';
			foreach ( $proposals as $p ) {
				$slot  = AMAT_Job_Workflow::describe_slot( AMAT_Job_Workflow::parse_when( (string) $p['start_at'] ), AMAT_Job_Workflow::parse_when( (string) $p['end_at'] ) );
				$html .= '<li><span class="amat-proposal-slot">' . esc_html( $slot ) . '</span> '
					. $this->accept_form( $job, $p )
					. $this->flow_button( $id, 'job_flow_proposal_remove', __( 'Withdraw', 'auto-mation' ), 'button button-small', array( 'proposal_id' => (int) $p['id'] ) )
					. '</li>';
			}
			$html .= '</ul>';
		} else {
			$html .= '<p class="description">' . esc_html__( 'None yet. Times you offer show on the calendar as striped blocks, so they are not double-booked while the customer decides.', 'auto-mation' ) . '</p>';
		}

		$html .= '<form method="post" class="amat-propose-form">'
			. wp_nonce_field( self::FLOW_NONCE, '_wpnonce', true, false )
			. '<input type="hidden" name="amat_action" value="job_flow_propose" />'
			. '<input type="hidden" name="job_id" value="' . esc_attr( (string) $id ) . '" />'
			. '<label for="amat-propose-date">' . esc_html__( 'Offer', 'auto-mation' ) . '</label> '
			. '<input type="date" name="proposal_date" id="amat-propose-date" required /> '
			. '<input type="time" name="proposal_start" id="amat-propose-start" step="900" required aria-label="' . esc_attr__( 'Start time', 'auto-mation' ) . '" /> '
			. '<span aria-hidden="true">–</span> '
			. '<input type="time" name="proposal_end" id="amat-propose-end" step="900" aria-label="' . esc_attr__( 'End time', 'auto-mation' ) . '" /> '
			. '<button type="submit" class="button">' . esc_html__( 'Propose time', 'auto-mation' ) . '</button>'
			. '</form>';
		return $html;
	}

	/**
	 * A provider's buttons beside a booked appointment - e.g. "Send to customer",
	 * to send or re-send the booking confirmation (Nick, 2026-10-09). Only on an
	 * open job with an appointment, and only for someone who may work the job
	 * (flow_button() renders nothing for a read-only viewer). Each is a flow form
	 * posting `job_flow_appointment` with the provider's slug in `amat_then`, so
	 * core owns the nonce, the permission and the redirect, and the provider acts
	 * in `amat_job_appointment_action`. Escaped HTML, or ''.
	 *
	 * @param array<string,mixed> $job Job row.
	 * @return string
	 */
	private function appointment_buttons( array $job ) {
		if ( '' !== (string) $job['closed_reason'] || ! AMAT_Job_Workflow::parse_when( (string) ( $job['scheduled_start'] ?? '' ) ) ) {
			return '';
		}
		/**
		 * Buttons beside a booked appointment on the job screen.
		 *
		 * Return `[ 'action' => 'your_slug', 'label' => '…', 'class' => 'button' ]`
		 * entries. Pressing one posts back to core, which checks the nonce and that
		 * the user may work this job, then hands off to `amat_job_appointment_action`.
		 * Shown only on an open job with an appointment, outside edit mode.
		 *
		 * @param array<int,array<string,string>> $buttons Buttons so far.
		 * @param array<string,mixed>             $job     The job.
		 */
		$buttons = (array) apply_filters( 'amat_job_appointment_buttons', array(), $job );
		$html    = '';
		foreach ( $buttons as $b ) {
			$slug = sanitize_key( (string) ( $b['action'] ?? '' ) );
			if ( '' === $slug || '' === (string) ( $b['label'] ?? '' ) ) {
				continue;
			}
			$html .= $this->flow_button( (int) $job['id'], 'job_flow_appointment', (string) $b['label'], 'button button-small ' . (string) ( $b['class'] ?? '' ), array( 'amat_then' => $slug ) );
		}
		return $html;
	}

	/**
	 * A choice of technician: Unassigned, then each tech. With a time given, a
	 * tech who is off, booked or outside their hours then says so beside their
	 * name. Escaped HTML.
	 *
	 * @param string                 $id       The select's id.
	 * @param int                    $selected The chosen tech (0 = unassigned).
	 * @param DateTimeImmutable|null $from     The time in question, if any.
	 * @param DateTimeImmutable|null $to       Its end.
	 * @param int                    $job_id   The job, left out of "booked".
	 * @return string
	 */
	private static function tech_select( $id, $selected, $from = null, $to = null, $job_id = 0 ) {
		$html = '<select name="technician_id" id="' . esc_attr( $id ) . '"><option value="0">' . esc_html__( 'Unassigned', 'auto-mation' ) . '</option>';
		foreach ( AMAT_Technicians::ids() as $tech ) {
			$label = AMAT_Technicians::name( $tech );
			if ( $from && $to && AMAT_Technicians::conflicts( $tech, $from, $to, $job_id ) ) {
				$label .= ' — ' . __( 'not free then', 'auto-mation' );
			}
			$html .= '<option value="' . esc_attr( (string) $tech ) . '"' . selected( $selected, $tech, false ) . '>' . esc_html( $label ) . '</option>';
		}
		return $html . '</select>';
	}

	/**
	 * "Customer picked this" for one proposed time, with the technician to give
	 * the job: the job's own, or else the first tech free then. Escaped HTML.
	 *
	 * @param array<string,mixed> $job      The job.
	 * @param array<string,mixed> $proposal The proposed time.
	 * @return string
	 */
	private function accept_form( array $job, array $proposal ) {
		$id = (int) $job['id'];
		if ( ! AMAT_Access::perm( 'confirm' ) ) {
			return ''; // the owner, or a technician given the permission
		}
		if ( ! AMAT_Access::is_owner() ) {
			// A technician confirming takes the job for themselves: no one to choose.
			return '<form method="post" class="amat-inline-form">'
				. wp_nonce_field( self::FLOW_NONCE, '_wpnonce', true, false )
				. '<input type="hidden" name="amat_action" value="job_flow_proposal_accept" />'
				. '<input type="hidden" name="job_id" value="' . esc_attr( (string) $id ) . '" />'
				. '<input type="hidden" name="proposal_id" value="' . esc_attr( (string) (int) $proposal['id'] ) . '" />'
				. '<button type="submit" class="button button-small button-primary amat-keep">' . esc_html__( 'Customer picked this', 'auto-mation' ) . '</button></form>';
		}
		$techs = AMAT_Technicians::ids();
		if ( ! $techs ) {
			return $this->flow_button( $id, 'job_flow_proposal_accept', __( 'Customer picked this', 'auto-mation' ), 'button button-small button-primary', array( 'proposal_id' => (int) $proposal['id'] ) );
		}
		$from   = AMAT_Job_Workflow::parse_when( (string) $proposal['start_at'] );
		$to     = AMAT_Job_Workflow::parse_when( (string) $proposal['end_at'] );
		$to     = $to ? $to : ( $from ? $from->modify( '+1 hour' ) : null );
		$chosen = (int) $job['technician_id'];
		if ( ! $chosen && $from && $to ) {
			foreach ( $techs as $tech ) {
				if ( ! AMAT_Technicians::conflicts( $tech, $from, $to, $id ) ) {
					$chosen = $tech;
					break;
				}
			}
		}
		return '<form method="post" class="amat-inline-form amat-accept-form">'
			. wp_nonce_field( self::FLOW_NONCE, '_wpnonce', true, false )
			. '<input type="hidden" name="amat_action" value="job_flow_proposal_accept" />'
			. '<input type="hidden" name="job_id" value="' . esc_attr( (string) $id ) . '" />'
			. '<input type="hidden" name="proposal_id" value="' . esc_attr( (string) (int) $proposal['id'] ) . '" />'
			. '<label class="screen-reader-text" for="amat-accept-tech-' . (int) $proposal['id'] . '">' . esc_html__( 'Technician', 'auto-mation' ) . '</label>'
			. self::tech_select( 'amat-accept-tech-' . (int) $proposal['id'], $chosen, $from, $to, $id ) . ' '
			. '<button type="submit" class="button button-small button-primary">' . esc_html__( 'Customer picked this', 'auto-mation' ) . '</button></form>';
	}

	/**
	 * The job's flag as a line of text, for the Scheduling step.
	 *
	 * @param array<string,mixed> $job Job row.
	 * @return string Plain text.
	 */
	private static function flag_summary( array $job ) {
		if ( ! empty( $job['on_hold'] ) ) {
			return self::hold_text( $job );
		}
		if ( ! empty( $job['standby'] ) ) {
			return '' !== (string) $job['hold_reason']
				/* translators: %s: the standby reason. */
				? sprintf( __( 'Standby: %s', 'auto-mation' ), (string) $job['hold_reason'] )
				: __( 'Standby — would take an earlier slot', 'auto-mation' );
		}
		return __( 'Neither', 'auto-mation' );
	}

	/**
	 * Edit mode's Hold / Standby: one or the other (or neither), a Reason shown
	 * for either, and an Estimated date shown for Hold (Nick, 2026-09-30). The
	 * fields are revealed by initJobFlag() in admin.js; the server renders them
	 * hidden to match the saved state.
	 *
	 * @param array<string,mixed> $job Job row.
	 * @return string Escaped HTML.
	 */
	private static function flag_fields( array $job ) {
		$flag  = ! empty( $job['on_hold'] ) ? 'hold' : ( ! empty( $job['standby'] ) ? 'standby' : '' );
		$until = substr( (string) ( $job['hold_until'] ?? '' ), 0, 10 );
		$until = '0000-00-00' === $until ? '' : $until;
		$html  = '<span class="amat-flag-edit">';
		foreach ( array( '' => __( 'Neither', 'auto-mation' ), 'hold' => __( 'On hold', 'auto-mation' ), 'standby' => __( 'Standby', 'auto-mation' ) ) as $value => $label ) {
			$html .= '<label class="amat-flag-choice"><input type="radio" name="flag" value="' . esc_attr( $value ) . '"' . checked( $flag, $value, false ) . ' /> ' . esc_html( $label ) . '</label>';
		}
		$html .= '</span>'
			. '<span class="amat-flag-reason"' . ( '' === $flag ? ' hidden' : '' ) . '><label for="amat-flag-reason">' . esc_html__( 'Reason', 'auto-mation' ) . '</label> '
			. '<input type="text" name="flag_reason" id="amat-flag-reason" maxlength="191" value="' . esc_attr( (string) $job['hold_reason'] ) . '" placeholder="' . esc_attr__( 'e.g. parts backordered; can come in on short notice', 'auto-mation' ) . '" />'
			. ' <span class="description">' . esc_html__( 'The customer sees this reason.', 'auto-mation' ) . '</span></span>'
			. '<span class="amat-flag-until"' . ( 'hold' === $flag ? '' : ' hidden' ) . '><label for="amat-hold-until">' . esc_html__( 'Estimated date', 'auto-mation' ) . '</label> '
			. '<input type="date" name="hold_until" id="amat-hold-until" value="' . esc_attr( $until ) . '" />'
			. '<span class="description">' . esc_html__( 'Moves the invoice due date to 30 days after it.', 'auto-mation' ) . '</span></span>';
		return $html;
	}

	/**
	 * Echo a VIN with a copy-to-clipboard button (for 3rd-party parts lookups).
	 * Shown on the job view + edit screens when the vehicle has a VIN.
	 *
	 * @param string $vin The vehicle VIN.
	 * @return void
	 */
	private function render_vin_copy( $vin ) {
		$vin = trim( (string) $vin );
		if ( '' === $vin ) {
			return;
		}
		?>
		<span class="amat-vin-display">
			<code class="amat-vin-value"><?php echo esc_html( $vin ); ?></code>
			<button type="button" class="button-link amat-copy-btn" data-copy="<?php echo esc_attr( $vin ); ?>" title="<?php esc_attr_e( 'Copy VIN', 'auto-mation' ); ?>" aria-label="<?php esc_attr_e( 'Copy VIN', 'auto-mation' ); ?>"><span class="dashicons dashicons-clipboard"></span></button>
		</span>
		<?php
	}

	/* --------------------------------------------------------------------- */
	/* Add job form, and the fields the job screen's Edit mode shares       */
	/* --------------------------------------------------------------------- */

	/**
	 * Render the Add job form. (Editing an existing job happens on its job
	 * screen, in place - see render_view().)
	 *
	 * The owning customer is locked when the job is started from a customer
	 * (`return_customer`); otherwise it is chosen with an AJAX search. Vehicle /
	 * location options are server-rendered when the customer is known (locked, or
	 * repopulated after a validation error) and loaded via AJAX on a pick.
	 *
	 * @param array<string,mixed>      $data  Submitted values (after a rejected save), or empty.
	 * @param array<string,mixed>|null $flash Flash payload.
	 * @return void
	 */
	private function render_form( array $data, $flash = null ) {
		$cust_id = (int) ( $data['customer_id'] ?? 0 );

		$return_customer = isset( $data['return_customer'] )
			? absint( $data['return_customer'] )
			: ( isset( $_GET['return_customer'] ) ? absint( $_GET['return_customer'] ) : 0 ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only nav context; the save itself is nonce-checked.
		if ( ! $cust_id && $return_customer ) {
			$cust_id = $return_customer;
		}

		// Customer is fixed when arriving from a customer.
		$locked = $return_customer > 0;
		$owner  = $cust_id ? AMAT_Customer_Model::find( $cust_id ) : null;

		if ( $locked && ! $owner ) {
			$this->render_board( array( 'status' => 'error', 'message' => __( 'That customer no longer exists.', 'auto-mation' ) ) );
			return;
		}

		$cancel_url = $return_customer
			? add_query_arg( array( 'page' => AMAT_Customers_Page::PAGE_SLUG, 'action' => 'view', 'id' => $return_customer ), admin_url( 'admin.php' ) )
			: $this->list_url();

		$veh_id = (int) ( $data['vehicle_id'] ?? 0 );
		$loc_id = (int) ( $data['location_id'] ?? 0 );

		// Default a new job's location to the customer's primary, if known.
		if ( ! $loc_id && $cust_id ) {
			$primary = AMAT_Location_Model::primary_for_customer( $cust_id );
			if ( $primary ) {
				$loc_id = (int) $primary['id'];
			}
		}
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Add job', 'auto-mation' ); ?></h1>
			<?php $this->notice( $flash ); ?>

			<form method="post">
				<?php wp_nonce_field( self::NONCE_ACTION ); ?>
				<input type="hidden" name="amat_action" value="save_job" />
				<input type="hidden" name="job_id" value="0" />
				<?php if ( $return_customer ) : ?>
					<input type="hidden" name="return_customer" value="<?php echo esc_attr( $return_customer ); ?>" />
				<?php endif; ?>

				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="amat-job-name"><?php esc_html_e( 'Name', 'auto-mation' ); ?></label></th>
						<td>
							<input name="name" id="amat-job-name" type="text" class="regular-text" maxlength="255" value="<?php echo esc_attr( (string) ( $data['name'] ?? '' ) ); ?>" />
							<p class="description"><?php esc_html_e( 'Optional label shown wherever this job appears (calendar, lists). Defaults to the customer name when blank.', 'auto-mation' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row">
							<?php if ( $locked ) : ?>
								<?php esc_html_e( 'Customer', 'auto-mation' ); ?>
							<?php else : ?>
								<label for="amat-job-customer-search"><?php esc_html_e( 'Customer', 'auto-mation' ); ?></label>
							<?php endif; ?>
						</th>
						<td>
							<?php if ( $locked ) : ?>
								<strong><?php echo esc_html( AMAT_Customer_Model::display_name( $owner ) ); ?></strong>
								<input type="hidden" name="customer_id" value="<?php echo esc_attr( $cust_id ); ?>" />
							<?php else : ?>
								<div class="amat-search-wrap">
									<input type="search" id="amat-job-customer-search" name="customer_search" class="regular-text" autocomplete="off" placeholder="<?php esc_attr_e( 'Search customers, or type a name to add a new one…', 'auto-mation' ); ?>" value="<?php echo esc_attr( $owner ? AMAT_Customer_Model::display_name( $owner ) : '' ); ?>" />
									<span id="amat-job-customer-new" class="amat-new-tag" style="display:none;"><?php esc_html_e( '(NEW)', 'auto-mation' ); ?></span>
									<div id="amat-job-customer-results" class="amat-search-results"></div>
								</div>
								<input type="hidden" name="customer_id" id="amat-job-customer-id" value="<?php echo esc_attr( $cust_id ); ?>" />
								<p class="description"><?php esc_html_e( 'Pick an existing customer, or just type a name (e.g. “Jane Doe”) to add a new customer for follow-up.', 'auto-mation' ); ?></p>
							<?php endif; ?>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="amat-job-vehicle-search"><?php esc_html_e( 'Vehicle', 'auto-mation' ); ?></label></th>
						<td><?php echo $this->vehicle_picker( $cust_id, $veh_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped internally. ?></td>
					</tr>
					<tr>
						<th scope="row"><label for="amat-job-location"><?php esc_html_e( 'Location', 'auto-mation' ); ?></label></th>
						<td><?php echo $this->location_select( $cust_id, $loc_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped internally. ?></td>
					</tr>
					<tr>
						<th scope="row"><label for="amat-job-complaint"><?php esc_html_e( 'Complaint', 'auto-mation' ); ?></label></th>
						<td><?php echo self::textarea( 'complaint', 'amat-job-complaint', (string) ( $data['complaint'] ?? '' ), __( 'What the customer says is wrong, in their words.', 'auto-mation' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped internally. ?></td>
					</tr>
					<tr>
						<th scope="row"><label for="amat-job-research"><?php esc_html_e( 'Research', 'auto-mation' ); ?></label></th>
						<td><?php echo self::textarea( 'research', 'amat-job-research', (string) ( $data['research'] ?? '' ), __( 'Labor time, difficulty, parts availability.', 'auto-mation' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped internally. ?></td>
					</tr>
					<tr>
						<th scope="row"><label for="amat-job-start-date"><?php esc_html_e( 'Scheduled start', 'auto-mation' ); ?></label></th>
						<td><?php $this->datetime_fields( 'scheduled_start', 'amat-job-start', $data['scheduled_start'] ?? '' ); ?></td>
					</tr>
					<tr>
						<th scope="row"><label for="amat-job-end-date"><?php esc_html_e( 'Scheduled end', 'auto-mation' ); ?></label></th>
						<td><?php $this->datetime_fields( 'scheduled_end', 'amat-job-end', $data['scheduled_end'] ?? '' ); ?></td>
					</tr>
					<tr>
						<th scope="row"><label for="amat-job-mileage"><?php esc_html_e( 'Mileage', 'auto-mation' ); ?></label></th>
						<td>
							<?php $mileage_val = ( null !== ( $data['mileage'] ?? null ) && '' !== (string) $data['mileage'] ) ? (int) $data['mileage'] : ''; ?>
							<input name="mileage" id="amat-job-mileage" type="number" class="regular-text" min="0" step="1" inputmode="numeric" value="<?php echo esc_attr( $mileage_val ); ?>" />
							<p class="description"><?php esc_html_e( 'Odometer reading at this job (optional). Recorded for your records and the customer portal.', 'auto-mation' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="amat-job-damage"><?php esc_html_e( 'Existing damage', 'auto-mation' ); ?></label></th>
						<td><?php echo self::textarea( 'damage', 'amat-job-damage', (string) ( $data['damage'] ?? '' ), __( 'Anything already damaged when you arrived.', 'auto-mation' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped internally. ?></td>
					</tr>
					<tr>
						<th scope="row"><label for="amat-job-description"><?php esc_html_e( 'Notes (Internal)', 'auto-mation' ); ?></label></th>
						<td><?php echo self::textarea( 'description', 'amat-job-description', (string) ( $data['description'] ?? '' ), __( 'Optional notes specific to this job, for your eyes only — never shown to the customer, on a document or in the portal. Anything the customer should read goes in the notes on an estimate or invoice.', 'auto-mation' ), 4 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped internally. ?></td>
					</tr>
				</table>
				<p class="description"><?php esc_html_e( 'Estimates and invoices are added on the job screen once the job exists.', 'auto-mation' ); ?></p>

				<?php submit_button( __( 'Add job', 'auto-mation' ) ); ?>
				<a href="<?php echo esc_url( $cancel_url ); ?>" class="button amat-btn-secondary"><?php esc_html_e( 'Cancel', 'auto-mation' ); ?></a>
			</form>
		</div>
		<?php
	}

	/**
	 * A textarea with its hint, as HTML (the add form and the job screen's Edit
	 * mode share it).
	 *
	 * @param string $name  Field name.
	 * @param string $id    Element id.
	 * @param string $value Current value.
	 * @param string $hint  Help text under it.
	 * @param int    $rows  Rows.
	 * @return string Escaped HTML.
	 */
	private static function textarea( $name, $id, $value, $hint = '', $rows = 2 ) {
		return '<textarea name="' . esc_attr( $name ) . '" id="' . esc_attr( $id ) . '" class="large-text" rows="' . (int) $rows . '">' . esc_textarea( (string) $value ) . '</textarea>'
			. ( '' !== $hint ? '<p class="description">' . esc_html( $hint ) . '</p>' : '' );
	}

	/**
	 * The vehicle picker: a type-to-search over the customer's vehicles that can
	 * also add one (typed "Year Make Model", or by VIN), plus the picked
	 * vehicle's VIN with a copy button. Driven by initJobVehicleSearch() and
	 * initJobVinDecode() in admin.js, which find it by its ids.
	 *
	 * @param int  $cust_id Owning customer id (0 = not chosen yet).
	 * @param int  $veh_id  Selected vehicle id.
	 * @param bool $full    With the add-by-VIN box and the VIN display. The Info
	 *                      stage leaves both out: it has its own VIN field, which
	 *                      admin.js refills (with Plate and Color) on a pick.
	 * @return string Escaped HTML.
	 */
	private function vehicle_picker( $cust_id, $veh_id, $full = true ) {
		$choices = $cust_id ? self::vehicle_choices( $cust_id, $veh_id ) : array();
		$label   = '';
		$cur_vin = '';
		foreach ( $choices as $vc ) {
			if ( (int) $vc['id'] === (int) $veh_id ) {
				$label   = (string) $vc['label'];
				$cur_vin = (string) $vc['vin'];
				break;
			}
		}
		ob_start();
		?>
		<div class="amat-search-wrap" id="amat-job-vehicle-wrap" data-vehicles="<?php echo esc_attr( (string) wp_json_encode( $choices ) ); ?>">
			<input type="search" id="amat-job-vehicle-search" name="vehicle_search" class="regular-text" autocomplete="off" aria-label="<?php esc_attr_e( 'Vehicle', 'auto-mation' ); ?>" placeholder="<?php esc_attr_e( 'Search a vehicle, or type Year Make Model to add one…', 'auto-mation' ); ?>" value="<?php echo esc_attr( $label ); ?>" />
			<span id="amat-job-vehicle-new" class="amat-new-tag" style="display:none;"><?php esc_html_e( '(NEW)', 'auto-mation' ); ?></span>
			<div id="amat-job-vehicle-results" class="amat-search-results"></div>
		</div>
		<input type="hidden" name="vehicle_id" id="amat-job-vehicle-id" value="<?php echo esc_attr( (string) (int) $veh_id ); ?>" />
		<p class="description"><?php esc_html_e( 'Pick an existing vehicle, or type Year Make Model (e.g. 2015 Ford F-150) to add a new one for this customer.', 'auto-mation' ); ?></p>
		<?php if ( $full ) : ?>
		<details class="amat-vin-quickadd">
			<summary><?php esc_html_e( 'Add a new vehicle by VIN', 'auto-mation' ); ?></summary>
			<div class="amat-vin-quickadd-body">
				<input type="text" name="new_vehicle_vin" id="amat-job-vin" maxlength="17" autocomplete="off" placeholder="<?php esc_attr_e( 'VIN', 'auto-mation' ); ?>" />
				<input type="number" name="new_vehicle_year" id="amat-job-vin-year" min="1981" max="2100" placeholder="<?php esc_attr_e( 'Year', 'auto-mation' ); ?>" />
				<button type="button" class="button" id="amat-job-vin-decode"><?php esc_html_e( 'Decode VIN', 'auto-mation' ); ?></button>
				<div id="amat-job-vin-status" class="amat-vin-status"></div>
				<p class="description"><?php esc_html_e( 'Live NHTSA lookup. Enter the VIN (and Year for accuracy), then Decode — the full spec is stored when the job is saved.', 'auto-mation' ); ?></p>
			</div>
		</details>
		<div id="amat-job-vin-display"><?php $this->render_vin_copy( $cur_vin ); ?></div>
		<?php endif; ?>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * The Location dropdown: the customer's locations, then the business's shops.
	 *
	 * @param int        $cust_id   Owning customer id (0 = not chosen yet).
	 * @param int|string $loc_id    Selected location id, or 'new'.
	 * @param bool       $allow_new Offer "+ New location" and carry each
	 *                              location's address, so the Info stage can
	 *                              add one or edit the picked one (admin.js
	 *                              refills the address fields on a change).
	 * @return string Escaped HTML.
	 */
	private function location_select( $cust_id, $loc_id, $allow_new = false ) {
		$loc_opts  = $cust_id ? self::location_options( $cust_id, (int) $loc_id ) : array();
		$shop_opts = self::business_location_options( (int) $loc_id );
		$data      = '';
		if ( $allow_new ) {
			$addresses = array();
			foreach ( array_keys( $loc_opts + $shop_opts ) as $lid ) {
				$row = AMAT_Location_Model::find( (int) $lid );
				if ( $row ) {
					$addresses[ $lid ] = array(
						'label'    => (string) $row['label'],
						'street_1' => (string) $row['street_1'],
						'street_2' => (string) $row['street_2'],
						'city'     => (string) $row['city'],
						'state'    => (string) $row['state'],
						'zipcode'  => (string) $row['zipcode'],
						'code'     => (string) $row['code'],
						'notes'    => (string) $row['notes'],
						'shop'     => AMAT_Location_Model::BUSINESS_OWNER_ID === (int) $row['customer_id'],
					);
				}
			}
			$data = ' data-locations="' . esc_attr( (string) wp_json_encode( (object) $addresses ) ) . '"';
		}
		$html = '<select name="location_id" id="amat-job-location" aria-label="' . esc_attr__( 'Location', 'auto-mation' ) . '"' . $data . '>'
			. '<option value="0">' . esc_html__( '— None —', 'auto-mation' ) . '</option>';
		foreach ( array( array( __( 'Customer locations', 'auto-mation' ), 'amat-loc-customer', $loc_opts ), array( __( 'Your shops', 'auto-mation' ), 'amat-loc-shops', $shop_opts ) ) as $group ) {
			if ( ! $group[2] ) {
				continue;
			}
			$html .= '<optgroup label="' . esc_attr( $group[0] ) . '" class="' . esc_attr( $group[1] ) . '">';
			foreach ( $group[2] as $opt_id => $opt_label ) {
				$html .= '<option value="' . esc_attr( (string) $opt_id ) . '"' . selected( (string) $opt_id, (string) $loc_id, false ) . '>' . esc_html( $opt_label ) . '</option>';
			}
			$html .= '</optgroup>';
		}
		if ( $allow_new ) {
			$html .= '<option value="new"' . selected( 'new', (string) $loc_id, false ) . '>' . esc_html__( '+ New location', 'auto-mation' ) . '</option>';
		}
		return $html . '</select>';
	}

	/* --------------------------------------------------------------------- */
	/* Estimates / invoices on the job screen                                */
	/* --------------------------------------------------------------------- */

	/**
	 * A job's estimates or invoices as a table whose rows expand, in place, into
	 * each document's editing card (Nick, 2026-09-30).
	 *
	 * Each card sits in a hidden row straight after its summary row; the toggle
	 * (or a tap on the row) reveals it. `?open=estimate-12` opens one on arrival,
	 * which is how every document action lands back where it was working. The
	 * cards open whatever stage is being edited: a stage's fields belong to its
	 * form by the `form` attribute, so nothing nests.
	 *
	 * "+ Add estimate" / "+ Add invoice" appear while its stage (Plan / Pay) is
	 * being edited, as a button of that stage's form: it saves what was typed,
	 * then adds the document and opens its card.
	 *
	 * @param string                         $type    'estimate' or 'invoice'.
	 * @param array<int,array<string,mixed>> $docs    The job's documents of that type.
	 * @param int                            $job_id  Job id.
	 * @param string                         $open    Which card to show open ('estimate-12').
	 * @param bool                           $can_add Whether its stage is being edited.
	 * @return string Escaped HTML.
	 */
	private function doc_table( $type, array $docs, $job_id, $open = '', $can_add = false ) {
		$is_estimate = 'estimate' === $type;
		$heads       = $is_estimate
			? array( __( 'Estimate', 'auto-mation' ), __( 'State', 'auto-mation' ), __( 'Total', 'auto-mation' ), __( 'Date', 'auto-mation' ) )
			: array( __( 'Invoice', 'auto-mation' ), __( 'State', 'auto-mation' ), __( 'Total', 'auto-mation' ), __( 'Paid', 'auto-mation' ), __( 'Balance', 'auto-mation' ) );
		$html        = '';

		if ( $docs ) {
			$html .= '<div class="amat-table-scroll"><table class="widefat amat-mini-table amat-doc-table"><thead><tr>';
			foreach ( $heads as $i => $head ) {
				$html .= '<th' . ( $i >= 2 ? ' class="num"' : '' ) . '>' . esc_html( $head ) . '</th>';
			}
			$html .= '<th class="amat-doc-toggle-col"><span class="screen-reader-text">' . esc_html__( 'Edit', 'auto-mation' ) . '</span></th></tr></thead><tbody>';

			foreach ( $docs as $doc ) {
				$did   = (int) $doc['id'];
				$key   = $type . '-' . $did;
				$here  = $key === $open;
				$url   = add_query_arg( array( 'page' => $is_estimate ? AMAT_Estimates_Page::PAGE_SLUG : AMAT_Invoices_Page::PAGE_SLUG, 'action' => 'view', 'id' => $did ), admin_url( 'admin.php' ) );
				$total = (float) ( $is_estimate ? AMAT_Estimate_Model::total( $did ) : AMAT_Invoice_Model::total( $did ) );
				$label = $is_estimate ? AMAT_Estimates_Page::label( $doc ) : AMAT_Invoices_Page::label( $doc );
				$state = $is_estimate ? AMAT_Estimate_Model::status_label( $doc['status'] ) : AMAT_Invoice_Model::status_label( $doc['status'] );

				$html .= '<tr class="amat-doc-row' . ( $here ? ' is-open' : '' ) . '"><td><a href="' . esc_url( $url ) . '">' . esc_html( $label ) . '</a></td>'
					. '<td><span class="amat-status amat-status-' . esc_attr( $doc['status'] ) . '">' . esc_html( $state ) . '</span></td>'
					. '<td class="num">' . esc_html( AMAT_Money::format_amount( $total ) ) . '</td>';
				if ( $is_estimate ) {
					$html .= '<td>' . esc_html( (string) $doc['issue_date'] ) . '</td>';
				} else {
					$paid  = (float) ( $doc['amount_paid'] ?? 0 );
					$html .= '<td class="num">' . esc_html( AMAT_Money::format_amount( $paid ) ) . '</td>'
						. '<td class="num">' . esc_html( AMAT_Money::format_amount( 'void' === $doc['status'] ? 0 : $total - $paid ) ) . '</td>';
				}
				$html .= '<td class="amat-doc-toggle-col"><button type="button" class="button-link amat-doc-toggle" aria-expanded="' . ( $here ? 'true' : 'false' ) . '" aria-controls="amat-doc-' . esc_attr( $key ) . '"'
					/* translators: %s: the document, e.g. "Estimate #12". */
					. ' aria-label="' . esc_attr( sprintf( __( 'Edit %s', 'auto-mation' ), $label ) ) . '"><span class="dashicons dashicons-arrow-right-alt2" aria-hidden="true"></span></button></td></tr>';

				ob_start();
				$this->render_doc_subform( $type, $doc, (int) $job_id );
				$html .= '<tr id="amat-doc-' . esc_attr( $key ) . '" class="amat-doc-edit-row"' . ( $here ? '' : ' hidden' ) . '><td colspan="' . ( count( $heads ) + 1 ) . '">' . ob_get_clean() . '</td></tr>';
			}
			$html .= '</tbody></table></div>';
		} else {
			$html .= '<p class="description">' . ( $is_estimate ? esc_html__( 'No estimates yet.', 'auto-mation' ) : esc_html__( 'No invoice yet. Convert an approved estimate, or add one.', 'auto-mation' ) ) . '</p>';
		}

		if ( $can_add ) {
			$html .= '<p class="amat-doc-add">' . self::in_stage_form(
				'<button type="submit" name="then_add" value="' . esc_attr( $type ) . '" class="button"'
				. ' title="' . esc_attr__( 'Saves your changes, then adds it', 'auto-mation' ) . '">'
				. ( $is_estimate ? esc_html__( '+ Add estimate', 'auto-mation' ) : esc_html__( '+ Add invoice', 'auto-mation' ) ) . '</button>'
			) . '</p>';
		}
		return $html;
	}

	/**
	 * One estimate/invoice sub-form within the job manager: header (number/status/
	 * total), an editable status + notes, the line-item repeater, and action
	 * buttons. Save / Convert / Delete are distinct submit buttons (only the
	 * clicked one's amat_action is posted).
	 *
	 * @param string              $type 'estimate' or 'invoice'.
	 * @param array<string,mixed> $doc  Estimate/invoice row.
	 * @param int                 $job_id Owning job id.
	 * @return void
	 */
	private function render_doc_subform( $type, array $doc, $job_id ) {
		$is_estimate = ( 'estimate' === $type );
		$id          = (int) $doc['id'];
		$items       = $is_estimate ? AMAT_Estimate_Item_Model::for_parent( $id ) : AMAT_Invoice_Item_Model::for_parent( $id );
		$total       = $is_estimate ? AMAT_Estimate_Model::total( $id ) : AMAT_Invoice_Model::total( $id );
		$label       = $is_estimate ? AMAT_Estimates_Page::label( $doc ) : AMAT_Invoices_Page::label( $doc );
		$statuses    = $is_estimate ? AMAT_Estimate_Model::statuses_labeled() : AMAT_Invoice_Model::statuses_labeled();
		$status      = (string) $doc['status'];
		$converted   = $is_estimate && AMAT_Invoice_Model::for_estimate( $id );
		$is_void     = ( 'void' === $status );
		$view_url    = add_query_arg(
			array( 'page' => ( $is_estimate ? AMAT_Estimates_Page::PAGE_SLUG : AMAT_Invoices_Page::PAGE_SLUG ), 'action' => 'view', 'id' => $id ),
			admin_url( 'admin.php' )
		);
		?>
		<div class="amat-doc-card<?php echo $is_void ? ' amat-doc-void' : ''; ?>">
			<form method="post" class="amat-doc-form">
				<?php wp_nonce_field( self::DOC_NONCE ); ?>
				<input type="hidden" name="job_id" value="<?php echo esc_attr( (int) $job_id ); ?>" />
				<input type="hidden" name="doc_id" value="<?php echo esc_attr( $id ); ?>" />
				<?php // Which kind of document this card is. The Save/Convert/Delete buttons carry it in their action value; a provider button carries only its own slug, so the type has to be on the form. ?>
				<input type="hidden" name="doc_type" value="<?php echo esc_attr( $type ); ?>" />

				<div class="amat-doc-card-head">
					<strong><a href="<?php echo esc_url( $view_url ); ?>"><?php echo esc_html( $label ); ?></a></strong>
					<span class="amat-status amat-status-<?php echo esc_attr( $status ); ?>"><?php echo esc_html( $statuses[ $status ] ?? $status ); ?></span>
					<span class="amat-doc-total"><?php echo esc_html( AMAT_Money::format_amount( $total ) ); ?></span>
					<?php if ( $converted ) : ?><span class="description"><?php esc_html_e( '(converted)', 'auto-mation' ); ?></span><?php endif; ?>
				</div>
				<?php echo $is_estimate ? self::decision_note( $doc ) : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside. ?>

				<label class="amat-doc-status">
					<?php esc_html_e( 'Status', 'auto-mation' ); ?>
					<select name="status">
						<?php foreach ( $statuses as $slug => $slabel ) : ?>
							<?php
							if ( $is_estimate && 'approved' === $slug && 'approved' !== $status && ! AMAT_Access::perm( 'approve' ) ) {
								continue; // approving is the owner's, or a technician's with the permission
							}
							?>
							<option value="<?php echo esc_attr( $slug ); ?>" <?php selected( $slug, $status ); ?>><?php echo esc_html( $slabel ); ?></option>
						<?php endforeach; ?>
					</select>
				</label>

				<?php AMAT_Estimates_Page::render_items_field( $items ); ?>

				<label class="amat-doc-notes">
					<?php esc_html_e( 'Notes (shown to the customer)', 'auto-mation' ); ?>
					<textarea name="notes" class="large-text" rows="2"><?php echo esc_textarea( (string) ( $doc['notes'] ?? '' ) ); ?></textarea>
				</label>
				<p class="description amat-doc-notes-hint"><?php esc_html_e( 'These notes appear on the document the customer receives. Keep internal remarks on the job instead.', 'auto-mation' ); ?></p>

				<p class="amat-doc-actions">
					<button type="submit" name="amat_action" value="<?php echo esc_attr( $is_estimate ? 'job_estimate_save' : 'job_invoice_save' ); ?>" class="button amat-btn-primary"><?php esc_html_e( 'Save', 'auto-mation' ); ?></button>
					<?php if ( $is_estimate && ! $converted ) : ?>
						<button type="submit" name="amat_action" value="job_estimate_convert" class="button"><?php esc_html_e( 'Convert to invoice', 'auto-mation' ); ?></button>
					<?php endif; ?>
					<?php
					/**
					 * Buttons a provider plugin adds to this document's action row.
					 *
					 * They live INSIDE the card's form, so the values the owner has just
					 * typed — status, notes, line items — are in the POST. Core saves the
					 * document exactly as its own Save button would, and only then hands
					 * off to the provider via `amat_job_document_saved_action`. That is
					 * the whole point: pushing a document that is not what is on screen
					 * is the bug this replaced (2026-09-22).
					 *
					 * Each entry: [ 'action' => 'a_slug', 'label' => 'Save & push', 'class' => 'button' ].
					 * The slug is opaque to core — it is the provider's own name for what
					 * it will do, echoed back to it after the save.
					 *
					 * @param array<int,array<string,string>> $buttons Provider buttons.
					 * @param string                          $type    'estimate' or 'invoice'.
					 * @param array<string,mixed>             $doc     The document row.
					 * @param int                             $job_id  Owning job id.
					 */
					$provider_buttons = apply_filters( 'amat_job_document_buttons', array(), $type, $doc, (int) $job_id );
					foreach ( (array) $provider_buttons as $btn ) {
						$slug = isset( $btn['action'] ) ? sanitize_key( $btn['action'] ) : '';
						$text = isset( $btn['label'] ) ? (string) $btn['label'] : '';
						if ( '' === $slug || '' === $text ) {
							continue;
						}
						printf(
							'<button type="submit" name="amat_then" value="%1$s" class="%2$s">%3$s</button>',
							esc_attr( $slug ),
							esc_attr( isset( $btn['class'] ) ? (string) $btn['class'] : 'button' ),
							esc_html( $text )
						);
					}
					?>
					<?php if ( AMAT_Admin::delete_enabled() ) : ?>
						<button type="submit" name="amat_action" value="<?php echo esc_attr( $is_estimate ? 'job_estimate_delete' : 'job_invoice_delete' ); ?>" class="button amat-btn-disable amat-doc-delete"><?php esc_html_e( 'Delete', 'auto-mation' ); ?></button>
					<?php endif; ?>
				</p>
			</form>
			<?php
			/**
			 * Fires inside a job's estimate/invoice card, at its foot, so a provider
			 * can show that document's sync state without making the owner open the
			 * document itself.
			 *
			 * **Display only.** Fired outside the card's <form>, because a listener
			 * cannot nest a form of its own here — the browser discards the inner one.
			 * An *action* belongs on `amat_job_document_buttons` instead, which puts a
			 * submit button inside the card's form so core saves the typed values
			 * before handing off. Rendering a form here would push whatever was last
			 * saved rather than what is on screen; that was the 2026-09-22 bug.
			 *
			 * @param array<string,mixed> $doc    The estimate/invoice row.
			 * @param int                 $job_id The owning job id.
			 */
			if ( $is_estimate ) {
				do_action( 'amat_job_estimate_actions', $doc, (int) $job_id );
			} else {
				do_action( 'amat_job_invoice_actions', $doc, (int) $job_id );
			}
			?>
		</div>
		<?php
	}

	/**
	 * Active vehicles for a customer as id => label, always including the
	 * currently-selected one (even if disabled) so an existing job still shows it.
	 *
	 * @param int $cust_id  Customer id.
	 * @param int $selected Currently-selected vehicle id (0 = none).
	 * @return array<int,string>
	 */
	private static function vehicle_options( $cust_id, $selected = 0 ) {
		$opts = array();
		foreach ( self::vehicle_choices( $cust_id, $selected ) as $v ) {
			$opts[ $v['id'] ] = $v['label'];
		}
		return $opts;
	}

	/**
	 * The same vehicles as vehicle_options(), as a list carrying each vehicle's VIN
	 * so the job form's picker can show (and live-update) the VIN of whichever
	 * vehicle is selected. Feeds both the server-rendered `data-vehicles` payload
	 * and the AJAX customer-items response.
	 *
	 * @param int $cust_id  Customer id.
	 * @param int $selected Currently-selected vehicle id (0 = none).
	 * @return array<int,array<string,mixed>> List of { id, label, vin, plate, color }.
	 */
	private static function vehicle_choices( $cust_id, $selected = 0 ) {
		$out = array();
		foreach ( AMAT_Vehicle_Model::for_customer( $cust_id ) as $v ) {
			$vid = (int) $v['id'];
			if ( empty( $v['is_active'] ) && $vid !== (int) $selected ) {
				continue;
			}
			$label = AMAT_Vehicle_Model::label( $v );
			if ( empty( $v['is_active'] ) ) {
				$label .= ' ' . __( '(disabled)', 'auto-mation' );
			}
			$out[] = array(
				'id'    => $vid,
				'label' => $label,
				'vin'   => trim( (string) ( $v['vin'] ?? '' ) ),
				'plate' => (string) ( $v['license_plate'] ?? '' ),
				'state' => (string) ( $v['plate_state'] ?? '' ),
				'color' => (string) ( $v['color'] ?? '' ),
				'ccode' => (string) ( $v['color_code'] ?? '' ),
				'warn'  => (string) ( $v['warnings'] ?? '' ),
				'notes' => (string) ( $v['notes'] ?? '' ),
			);
		}
		return $out;
	}

	/**
	 * Active locations for a customer as id => label, always including the
	 * currently-selected one (even if disabled).
	 *
	 * @param int $cust_id  Customer id.
	 * @param int $selected Currently-selected location id (0 = none).
	 * @return array<int,string>
	 */
	private static function location_options( $cust_id, $selected = 0 ) {
		$opts = array();
		foreach ( AMAT_Location_Model::for_customer( $cust_id ) as $loc ) {
			$lid = (int) $loc['id'];
			if ( empty( $loc['is_active'] ) && $lid !== (int) $selected ) {
				continue;
			}
			$name         = '' !== $loc['label'] ? $loc['label'] : AMAT_Location_Model::one_line( $loc );
			$opts[ $lid ] = empty( $loc['is_active'] ) ? $name . ' ' . __( '(disabled)', 'auto-mation' ) : $name;
		}
		return $opts;
	}

	/**
	 * The business's own shops as id => label, for the job Location dropdown.
	 * Always includes the currently-selected shop (even if disabled) so an
	 * existing job still shows it. These appear after the customer's locations.
	 *
	 * @param int $selected Currently-selected location id (0 = none).
	 * @return array<int,string>
	 */
	private static function business_location_options( $selected = 0 ) {
		$opts = array();
		foreach ( AMAT_Location_Model::business_locations( true ) as $loc ) {
			$lid = (int) $loc['id'];
			if ( empty( $loc['is_active'] ) && $lid !== (int) $selected ) {
				continue;
			}
			$name         = '' !== $loc['label'] ? $loc['label'] : AMAT_Location_Model::one_line( $loc );
			$opts[ $lid ] = empty( $loc['is_active'] ) ? $name . ' ' . __( '(disabled)', 'auto-mation' ) : $name;
		}
		return $opts;
	}

	/**
	 * Echo a paired native date picker + 15-minute time dropdown for a stored
	 * datetime, posting as `{$base}_date` and `{$base}_time` (recombined on save).
	 * Replaces the bare datetime-local input so the time is chosen, not typed.
	 *
	 * @param string $base    Field base name, e.g. 'scheduled_start'.
	 * @param string $id_base Element id base, e.g. 'amat-job-start'.
	 * @param string $value   Stored datetime to prefill.
	 * @return void
	 */
	private function datetime_fields( $base, $id_base, $value ) {
		$date    = $this->dt_date_part( $value );
		$time    = $this->dt_time_part( $value );
		$options = $this->time_options();

		// Keep an off-grid existing time selectable (e.g. legacy 9:07 data).
		if ( '' !== $time && ! isset( $options[ $time ] ) ) {
			$dt              = date_create( '2000-01-01 ' . $time );
			$options         = array( $time => ( $dt ? $dt->format( 'g:i A' ) : $time ) ) + $options;
		}
		?>
		<span class="amat-dt-fields">
			<input type="date" name="<?php echo esc_attr( $base ); ?>_date" id="<?php echo esc_attr( $id_base ); ?>-date" value="<?php echo esc_attr( $date ); ?>" />
			<label class="screen-reader-text" for="<?php echo esc_attr( $id_base ); ?>-time"><?php esc_html_e( 'Time', 'auto-mation' ); ?></label>
			<select name="<?php echo esc_attr( $base ); ?>_time" id="<?php echo esc_attr( $id_base ); ?>-time">
				<?php foreach ( $options as $val => $label ) : ?>
					<option value="<?php echo esc_attr( $val ); ?>" <?php selected( $val, $time ); ?>><?php echo esc_html( $label ); ?></option>
				<?php endforeach; ?>
			</select>
		</span>
		<?php
	}

	/**
	 * Time-of-day options on a 15-minute grid as 'H:i' => 'g:i A', led by a
	 * blank "— Time —" choice (date-only allowed; defaults to midnight on save).
	 *
	 * @return array<string,string>
	 */
	private function time_options() {
		$opts = array( '' => __( '— Time —', 'auto-mation' ) );
		for ( $m = 0; $m < 24 * 60; $m += 15 ) {
			$hi          = sprintf( '%02d:%02d', intdiv( $m, 60 ), $m % 60 );
			$dt          = date_create( '2000-01-01 ' . $hi );
			$opts[ $hi ] = $dt ? $dt->format( 'g:i A' ) : $hi;
		}
		return $opts;
	}

	/**
	 * Combine a posted date ('Y-m-d') + time ('H:i') into a 'Y-m-d H:i' string
	 * for the model's datetime sanitizer, or '' when no valid date was given.
	 *
	 * @param string $date_raw Raw posted date.
	 * @param string $time_raw Raw posted time.
	 * @return string
	 */
	private function combine_datetime( $date_raw, $time_raw ) {
		$date = sanitize_text_field( wp_unslash( $date_raw ) );
		$time = sanitize_text_field( wp_unslash( $time_raw ) );
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) {
			return '';
		}
		if ( ! preg_match( '/^\d{1,2}:\d{2}$/', $time ) ) {
			$time = '00:00';
		}
		return $date . ' ' . $time;
	}

	/**
	 * Date portion ('Y-m-d') of a stored datetime, or '' when empty/zero.
	 *
	 * @param string $v Stored datetime.
	 * @return string
	 */
	private function dt_date_part( $v ) {
		$v = trim( (string) $v );
		if ( '' === $v || 0 === strpos( $v, '0000' ) ) {
			return '';
		}
		$dt = date_create( str_replace( 'T', ' ', $v ) );
		return $dt ? $dt->format( 'Y-m-d' ) : '';
	}

	/**
	 * Time portion ('H:i') of a stored datetime, or '' when empty/zero.
	 *
	 * @param string $v Stored datetime.
	 * @return string
	 */
	private function dt_time_part( $v ) {
		$v = trim( (string) $v );
		if ( '' === $v || 0 === strpos( $v, '0000' ) ) {
			return '';
		}
		$dt = date_create( str_replace( 'T', ' ', $v ) );
		return $dt ? $dt->format( 'H:i' ) : '';
	}

	/**
	 * Friendly display of a stored datetime, or an em dash when unset.
	 *
	 * @param string $v Stored datetime.
	 * @return string
	 */
	private function dt_display( $v ) {
		$v = trim( (string) $v );
		if ( '' === $v || 0 === strpos( $v, '0000' ) ) {
			return '—';
		}
		$dt = date_create( $v );
		return $dt ? $dt->format( 'M j, Y g:i A' ) : $v;
	}

	/**
	 * Time-of-day portion of a stored datetime (e.g. "9:30 AM"), or '' if unset.
	 *
	 * @param string $v Stored datetime.
	 * @return string
	 */
	private function dt_time( $v ) {
		$v = trim( (string) $v );
		if ( '' === $v || 0 === strpos( $v, '0000' ) ) {
			return '';
		}
		$dt = date_create( $v );
		return $dt ? $dt->format( 'g:i A' ) : '';
	}

	/* --------------------------------------------------------------------- */
	/* AJAX: customer search + dependent vehicle/location options            */
	/* --------------------------------------------------------------------- */

	/**
	 * AJAX: search customers for the job form's customer picker.
	 *
	 * Registered on wp_ajax_amat_job_search_customers. Returns up to 20 matches
	 * as { id, name }.
	 *
	 * @return void
	 */
	public static function ajax_search_customers() {
		check_ajax_referer( self::CUST_NONCE, 'nonce' );
		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			wp_send_json_error( array( 'message' => __( 'Not allowed.', 'auto-mation' ) ), 403 );
		}

		$term = isset( $_POST['term'] ) ? sanitize_text_field( wp_unslash( $_POST['term'] ) ) : '';
		// active_only: a disabled customer must not be pickable for a new job, nor
		// offered as a "referred by" (this endpoint feeds both pickers).
		$rows = AMAT_Customer_Model::search( $term, true );

		$out = array();
		foreach ( array_slice( $rows, 0, 20 ) as $c ) {
			$out[] = array( 'id' => (int) $c['id'], 'name' => AMAT_Customer_Model::display_name( $c ) );
		}
		wp_send_json_success( $out );
	}

	/**
	 * AJAX: a customer's active vehicles + locations for the job form.
	 *
	 * Registered on wp_ajax_amat_job_customer_items. Returns {vehicles, locations,
	 * primary} where vehicles/locations are [{id,label}] and primary is the
	 * customer's primary location id (0 if none).
	 *
	 * @return void
	 */
	public static function ajax_customer_items() {
		check_ajax_referer( self::CUST_NONCE, 'nonce' );
		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			wp_send_json_error( array( 'message' => __( 'Not allowed.', 'auto-mation' ) ), 403 );
		}

		$cust_id = isset( $_POST['customer_id'] ) ? absint( $_POST['customer_id'] ) : 0;

		$vehicles  = self::vehicle_choices( $cust_id );
		$locations = array();
		foreach ( self::location_options( $cust_id ) as $lid => $label ) {
			$locations[] = array( 'id' => $lid, 'label' => $label );
		}
		$shops = array();
		foreach ( self::business_location_options() as $lid => $label ) {
			$shops[] = array( 'id' => $lid, 'label' => $label );
		}
		$primary = $cust_id ? AMAT_Location_Model::primary_for_customer( $cust_id ) : null;

		wp_send_json_success(
			array(
				'vehicles'  => $vehicles,
				'locations' => $locations,
				'shops'     => $shops,
				'primary'   => $primary ? (int) $primary['id'] : 0,
			)
		);
	}

	/**
	 * Create a new customer from a typed name (quick add from the job form). One
	 * word → first name only; two+ words → first word is the first name, the rest
	 * is the last name.
	 *
	 * @param string $name Typed full name.
	 * @return int New customer id, or 0 on failure.
	 */
	private static function create_customer_from_name( $name ) {
		$parts = preg_split( '/\s+/', trim( (string) $name ), -1, PREG_SPLIT_NO_EMPTY );
		if ( empty( $parts ) ) {
			return 0;
		}
		$first = (string) array_shift( $parts );
		$last  = $parts ? implode( ' ', $parts ) : '';

		return (int) AMAT_Customer_Model::create(
			array(
				'first_name' => $first,
				'last_name'  => $last,
				'is_active'  => 1,
			)
		);
	}

	/**
	 * Create a new vehicle for a customer from typed "Year Make Model" text (quick
	 * add from the job form). A leading all-digits token is the year; the next is
	 * the make; the remainder is the model. A non-numeric first token means no year.
	 *
	 * @param int    $customer_id Owning customer id.
	 * @param string $text        Typed "Year Make Model" string.
	 * @return int New vehicle id, or 0 on failure.
	 */
	private static function create_vehicle_from_text( $customer_id, $text ) {
		return AMAT_Vehicle_Model::create_from_text( $customer_id, $text );
	}

	/**
	 * Create a new vehicle for a customer from a VIN (quick-add from the job form).
	 * Decodes the VIN live via vPIC server-side and stores every returned spec plus
	 * the VIN itself. The VIN is stored even if the decode fails (transport/API
	 * error), so a vehicle is still created. Returns 0 only on an empty VIN or a DB
	 * insert failure (the caller then falls back to the typed "Year Make Model").
	 *
	 * @param int    $customer_id Owning customer id.
	 * @param string $vin         Entered VIN.
	 * @param int    $year        Model year for decode accuracy (0 = unknown).
	 * @return int New vehicle id, or 0 on failure.
	 */
	private static function create_vehicle_from_vin( $customer_id, $vin, $year = 0 ) {
		$vin = strtoupper( preg_replace( '/[^A-Za-z0-9]/', '', (string) $vin ) );
		if ( '' === $vin ) {
			return 0;
		}

		$data = array(
			'customer_id' => (int) $customer_id,
			'vin'         => $vin,
			'is_active'   => 1,
		);

		$decoder = new AMAT_Vin_Decoder();
		$decoded = $decoder->decode( $vin, $year ?: null );
		if ( ! is_wp_error( $decoded ) ) {
			foreach ( $decoded as $column => $value ) {
				if ( '' !== $value ) {
					$data[ $column ] = $value;
				}
			}
		}

		return (int) AMAT_Vehicle_Model::create( $data );
	}

	/* --------------------------------------------------------------------- */
	/* Manager POST handlers (estimates/invoices on a job)                   */
	/* --------------------------------------------------------------------- */

	/**
	 * Intercept the job-document manager POSTs before the base PRG dispatch, then
	 * fall through to the normal job save. Each action redirects back to the job
	 * screen with a flash.
	 *
	 * @return void
	 */
	public function maybe_process() {
		$action = isset( $_POST['amat_action'] ) ? sanitize_key( wp_unslash( $_POST['amat_action'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce verified in each handler.

		// A provider button (see `amat_job_document_buttons`): save the document
		// first, exactly as our own Save does, then hand off. The provider never
		// sees a half-saved record, and never pushes a stale one.
		$then = isset( $_POST['amat_then'] ) ? sanitize_key( wp_unslash( $_POST['amat_then'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce verified in the handler.
		if ( '' !== $then && '' === $action ) {
			$type = isset( $_POST['doc_type'] ) ? sanitize_key( wp_unslash( $_POST['doc_type'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce verified in the handler.
			if ( in_array( $type, array( 'estimate', 'invoice' ), true ) ) {
				$this->process_doc_save( $type, $then );
				return;
			}
		}

		switch ( $action ) {
			case 'job_estimate_save':
			case 'job_invoice_save':
				$this->process_doc_save( 'job_estimate_save' === $action ? 'estimate' : 'invoice' );
				return;
			case 'job_estimate_convert':
				$this->process_doc_convert();
				return;
			case 'job_estimate_delete':
			case 'job_invoice_delete':
				$this->process_doc_delete( 'job_estimate_delete' === $action ? 'estimate' : 'invoice' );
				return;
		}
		if ( 0 === strpos( $action, 'job_flow_' ) ) {
			$this->process_flow( $action );
			return;
		}
		parent::maybe_process();
	}

	/**
	 * A workflow button on the job screen: next action, set step, hold, standby,
	 * close, reopen, proposed times, create related job. Every change goes
	 * through AMAT_Job_Workflow (so it is logged), then lands back on the job.
	 *
	 * @param string $action The job_flow_* action.
	 * @return void
	 */
	private function process_flow( $action ) {
		check_admin_referer( self::FLOW_NONCE );
		if ( ! AMAT_Access::can_work() ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'auto-mation' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- verified above.
		$job_id   = isset( $_POST['job_id'] ) ? absint( $_POST['job_id'] ) : 0;
		$pid      = isset( $_POST['proposal_id'] ) ? absint( $_POST['proposal_id'] ) : 0;
		$redirect = $this->list_url( array( 'action' => 'view', 'id' => $job_id ) );
		$notice   = array( 'status' => 'success', 'message' => __( 'Done.', 'auto-mation' ) );

		// Who may (AMAT_Access): taking a job and confirming a proposed time have
		// their own permissions; everything else is for the job's own technician.
		$job     = $job_id ? AMAT_Job_Model::find( $job_id ) : null;
		$allowed = $job && AMAT_Access::can_work();
		if ( $allowed && 'job_flow_take' === $action ) {
			$allowed = AMAT_Access::perm( 'unassigned' ) && 0 === (int) $job['technician_id'];
		} elseif ( $allowed && 'job_flow_proposal_accept' === $action ) {
			$proposal = AMAT_Job_Proposal_Model::find( $pid );
			$allowed  = AMAT_Access::perm( 'confirm' ) && AMAT_Access::can_view_job( $job ) && $proposal && (int) $proposal['job_id'] === $job_id;
		} elseif ( $allowed ) {
			$allowed = AMAT_Access::can_edit_job( $job );
		}
		if ( ! $allowed ) {
			$action = 'job_flow_refused'; // lands back on the job with the reason, like any refusal
		} elseif ( 'job_flow_proposal_accept' === $action && ! AMAT_Access::is_owner() ) {
			$_POST['technician_id'] = (string) get_current_user_id(); // confirming takes it, for themselves
		}

		switch ( $action ) {
			case 'job_flow_refused':
				$result = new WP_Error( 'amat_job_access', __( 'You are not allowed to do that.', 'auto-mation' ) );
				if ( ! $job || ! AMAT_Access::can_view_job( $job ) ) {
					$redirect = $this->list_url(); // not even theirs to look at
				}
				break;
			case 'job_flow_take':
				$result = AMAT_Job_Workflow::assign( $job_id, get_current_user_id() );
				if ( ! is_wp_error( $result ) ) {
					$notice['message'] = trim( __( 'The job is yours.', 'auto-mation' ) . ' ' . implode( ' ', $result['warnings'] ) );
				}
				break;
			case 'job_flow_advance':
				$result = AMAT_Job_Workflow::advance( $job_id );
				if ( ! is_wp_error( $result ) ) {
					$notice['message'] = '' !== (string) $result['closed_reason']
						? __( 'Receipt sent — the job is closed.', 'auto-mation' )
						/* translators: %s: the new step. */
						: sprintf( __( 'Now at %s.', 'auto-mation' ), AMAT_Job_Workflow::step_label( (string) $result['step'] ) );
				}
				break;
			case 'job_flow_reviewed':
				$was    = (string) $job['review_source'];
				$result = AMAT_Job_Workflow::set_review( $job_id, '', null ); // the owner clears any mark
				if ( ! is_wp_error( $result ) ) {
					$notice['message'] = __( 'Marked reviewed.', 'auto-mation' );
					// A request held as a possible duplicate, reviewed by the owner, is
					// a customer of its own: announce them now, so Wave syncs them.
					if ( AMAT_Portal::DUPLICATE === $was ) {
						/** This action is documented in includes/admin/class-customers-page.php */
						do_action( 'amat_after_customer_save', (int) $job['customer_id'], false );
					}
				}
				break;
			case 'job_flow_set_step':
				$result = AMAT_Job_Workflow::set_step( $job_id, sanitize_key( wp_unslash( $_POST['step'] ?? '' ) ) );
				if ( ! is_wp_error( $result ) ) {
					/* translators: %s: the step set. */
					$notice['message'] = sprintf( __( 'Step set to %s (logged as set by hand).', 'auto-mation' ), AMAT_Job_Workflow::step_label( (string) $result['step'] ) );
				}
				break;
			case 'job_flow_close':
				$result = AMAT_Job_Workflow::close( $job_id, sanitize_key( wp_unslash( $_POST['close_reason'] ?? '' ) ) );
				if ( ! is_wp_error( $result ) ) {
					/* translators: %s: why it closed. */
					$notice['message'] = sprintf( __( 'Closed — %s. It leaves the board; "Show closed" finds it.', 'auto-mation' ), AMAT_Job_Workflow::close_reasons()[ (string) $result['closed_reason'] ] );
				}
				break;
			case 'job_flow_reopen':
				$result            = AMAT_Job_Workflow::reopen( $job_id );
				$notice['message'] = __( 'Reopened.', 'auto-mation' );
				break;
			case 'job_flow_propose':
				$date   = sanitize_text_field( wp_unslash( $_POST['proposal_date'] ?? '' ) );
				$start  = sanitize_text_field( wp_unslash( $_POST['proposal_start'] ?? '' ) );
				$end    = sanitize_text_field( wp_unslash( $_POST['proposal_end'] ?? '' ) );
				$result = AMAT_Job_Workflow::propose( $job_id, $date . ' ' . $start, '' !== $end ? $date . ' ' . $end : '' );
				if ( ! is_wp_error( $result ) ) {
					$notice['message'] = __( 'Time proposed — it shows on the calendar until the customer decides.', 'auto-mation' );
					if ( ! empty( $result['conflicts'] ) ) {
						$notice = array(
							'status'  => 'warning',
							/* translators: %s: the clashes. */
							'message' => sprintf( __( 'Proposed — but it overlaps: %s.', 'auto-mation' ), implode( '; ', $result['conflicts'] ) ),
						);
					}
				}
				break;
			case 'job_flow_proposal_accept':
				$tech = isset( $_POST['technician_id'] ) ? absint( $_POST['technician_id'] ) : null;
				if ( $tech && ! AMAT_Technicians::is_tech( $tech ) ) {
					$result = new WP_Error( 'amat_job_tech', __( 'Only a technician can be assigned a job.', 'auto-mation' ) );
					break;
				}
				$result            = AMAT_Job_Workflow::accept_proposal( $pid );
				$notice['message'] = __( 'Booked — the other proposed times were cleared.', 'auto-mation' );
				if ( ! is_wp_error( $result ) ) {
					self::announce_invoices( AMAT_Job_Workflow::schedule_changed( (int) $result['id'] ) );
					if ( null !== $tech ) {
						$assigned = AMAT_Job_Workflow::assign( (int) $result['id'], $tech );
						if ( ! is_wp_error( $assigned ) && $assigned['warnings'] ) {
							$notice['message'] .= ' ' . implode( ' ', $assigned['warnings'] );
						}
					}
					$notice = self::announce_confirmed( (int) $result['id'], $notice );
				}
				break;
			case 'job_flow_appointment':
				$notice = $this->appointment_action( $job, sanitize_key( wp_unslash( $_POST['amat_then'] ?? '' ) ) );
				$result = $job;
				break;
			case 'job_flow_proposal_remove':
				$result            = AMAT_Job_Workflow::remove_proposal( $pid );
				$notice['message'] = __( 'Proposed time withdrawn.', 'auto-mation' );
				break;
			case 'job_flow_related':
				$result = $this->create_related_job( $job_id );
				if ( ! is_wp_error( $result ) ) {
					$redirect          = $this->list_url( array( 'action' => 'edit', 'id' => (int) $result ) );
					$notice['message'] = __( 'Related job created for the same customer and vehicle.', 'auto-mation' );
				}
				break;
			default:
				$result = new WP_Error( 'amat_job_flow', __( 'Unknown action.', 'auto-mation' ) );
		}
		// phpcs:enable

		if ( is_wp_error( $result ) ) {
			$notice = array( 'status' => 'error', 'message' => $result->get_error_message() );
		}
		$this->flash_to_destination( $notice, $redirect );
		wp_safe_redirect( $redirect );
		exit;
	}

	/**
	 * Announce an appointment confirmed from the customer's proposed times, and
	 * fold what the listeners report into the owner's notice.
	 *
	 * Fired here, on the admin path that confirms ("Customer picked this"), and
	 * never from the model or the workflow class - core's rule for lifecycle
	 * hooks: they mean "the owner did this". Moving a job on the calendar, typing
	 * a time, or proposing one fires nothing.
	 *
	 * @param int                  $job_id The job, now booked (and assigned).
	 * @param array<string,string> $notice The notice so far.
	 * @return array<string,string> The notice to flash.
	 */
	private static function announce_confirmed( $job_id, array $notice ) {
		/**
		 * Fires when an appointment is confirmed from one of the customer's
		 * proposed times. The job is booked, its other proposals cleared and its
		 * technician assigned by now. Core ships no listener; a messaging plugin
		 * tells the customer. A listener must never redirect, exit or throw.
		 *
		 * @param int $job_id The job.
		 */
		do_action( 'amat_appointment_confirmed', (int) $job_id );

		/**
		 * How the listeners to `amat_appointment_confirmed` got on, for the notice
		 * the owner reads after confirming: a list of
		 * `[ 'status' => 'success'|'error', 'message' => '…' ]`. Each message is
		 * added to core's "Booked"; an error turns the notice into a warning - the
		 * booking stands either way.
		 *
		 * @param array<int,array<string,string>> $notices Reports so far.
		 * @param int                             $job_id  The job.
		 */
		$reports = (array) apply_filters( 'amat_appointment_confirmed_notices', array(), (int) $job_id );
		foreach ( $reports as $report ) {
			$text = trim( (string) ( is_array( $report ) ? ( $report['message'] ?? '' ) : '' ) );
			if ( '' === $text ) {
				continue;
			}
			$notice['message'] .= ' ' . $text;
			if ( 'error' === ( $report['status'] ?? '' ) ) {
				$notice['status'] = 'warning';
			}
		}
		return $notice;
	}

	/**
	 * A provider's button beside the appointment was pressed (see
	 * appointment_buttons()): hand off, and return the notice to flash. Core has
	 * checked the nonce and that the user may work the job; the job must still be
	 * open and booked.
	 *
	 * @param array<string,mixed> $job  The job.
	 * @param string              $slug The provider's action slug.
	 * @return array<string,string>
	 */
	private function appointment_action( array $job, $slug ) {
		if ( '' !== (string) $job['closed_reason'] ) {
			return array( 'status' => 'error', 'message' => __( 'This job is closed.', 'auto-mation' ) );
		}
		if ( ! AMAT_Job_Workflow::parse_when( (string) $job['scheduled_start'] ) ) {
			return array( 'status' => 'error', 'message' => __( 'This job has no appointment yet.', 'auto-mation' ) );
		}
		/**
		 * A provider's button beside the appointment was used. Return a notice -
		 * `[ 'status' => 'success'|'error', 'message' => '…' ]` - or pass $notice
		 * through for a slug that is not yours. Core has verified the nonce and the
		 * permission and makes the redirect: a listener must not redirect or exit.
		 *
		 * @param array<string,string>|null $notice Notice so far, or null.
		 * @param string                    $action The provider's own slug.
		 * @param int                       $job_id The job.
		 */
		$handled = apply_filters( 'amat_job_appointment_action', null, (string) $slug, (int) $job['id'] );
		if ( ! is_array( $handled ) || empty( $handled['message'] ) ) {
			return array( 'status' => 'error', 'message' => __( 'Nothing handled that button.', 'auto-mation' ) );
		}
		return array(
			'status'  => 'error' === ( $handled['status'] ?? '' ) ? 'error' : 'success',
			'message' => (string) $handled['message'],
		);
	}

	/**
	 * Start a NEW job for the same customer and vehicle, linked back to this one
	 * (workflow.md: the loop is always a new job) — continued work, maintenance,
	 * or a warranty callback.
	 *
	 * @param int $job_id The job it follows on from.
	 * @return int|WP_Error The new job's id.
	 */
	private function create_related_job( $job_id ) {
		$job = AMAT_Job_Model::find( (int) $job_id );
		if ( ! $job ) {
			return new WP_Error( 'amat_job_missing', __( 'That job no longer exists.', 'auto-mation' ) );
		}
		$new = (int) AMAT_Job_Model::create(
			array(
				'customer_id'    => (int) $job['customer_id'],
				'vehicle_id'     => (int) $job['vehicle_id'],
				'location_id'    => (int) $job['location_id'],
				'step'           => AMAT_Job_Workflow::FIRST_STEP,
				'related_job_id' => (int) $job_id,
			)
		);
		if ( ! $new ) {
			return new WP_Error( 'amat_job_related', __( 'Could not create the related job.', 'auto-mation' ) );
		}
		AMAT_Job_Workflow::reconcile( $new );
		return $new;
	}

	/**
	 * Shared preamble for a document action: verify nonce + capability, load the
	 * job, and return the job screen's URL. wp_die on a bad nonce/cap.
	 *
	 * @return array{0:int,1:array<string,mixed>|null,2:string} [job_id, job, redirect].
	 */
	private function doc_action_context() {
		check_admin_referer( self::DOC_NONCE );
		$job_id = isset( $_POST['job_id'] ) ? absint( $_POST['job_id'] ) : 0;
		$job    = $job_id ? AMAT_Job_Model::find( $job_id ) : null;
		// The owner, or the job's own technician - money included (AMAT_Access).
		if ( ! AMAT_Access::can_work() || ( $job && ! AMAT_Access::can_edit_job( $job ) ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'auto-mation' ) );
		}
		$redirect = $this->doc_url( $job_id );
		return array( $job_id, $job, $redirect );
	}

	/**
	 * The job screen, with one document's card open and scrolled to - where a
	 * document action lands, so the owner is back where they were working.
	 *
	 * @param int    $job_id Job id.
	 * @param string $type   'estimate' or 'invoice' ('' = no card open).
	 * @param int    $doc_id Document id.
	 * @return string
	 */
	private function doc_url( $job_id, $type = '', $doc_id = 0 ) {
		$args = array( 'action' => 'view', 'id' => (int) $job_id );
		if ( '' === $type || ! $doc_id ) {
			return $this->list_url( $args );
		}
		$key = $type . '-' . (int) $doc_id;
		return $this->list_url( $args + array( 'open' => $key ) ) . '#amat-doc-' . $key;
	}

	/**
	 * Create a fresh draft estimate/invoice on a job (customer + vehicle inherited
	 * from it), firing the lifecycle hook as any owner save does.
	 *
	 * @param array<string,mixed> $job  Job row.
	 * @param string              $type 'estimate' or 'invoice'.
	 * @return int New document id, or 0.
	 */
	private function create_document( array $job, $type ) {
		$fields = array(
			'customer_id' => (int) $job['customer_id'],
			'job_id'      => (int) $job['id'],
			'vehicle_id'  => (int) $job['vehicle_id'],
			'status'      => 'draft',
			'issue_date'  => gmdate( 'Y-m-d', current_time( 'timestamp' ) ),
		);
		$new_id = 'estimate' === $type ? (int) AMAT_Estimate_Model::create( $fields ) : (int) AMAT_Invoice_Model::create( $fields );
		if ( $new_id ) {
			if ( 'invoice' === $type ) {
				// Before the save is announced, so a provider's first push carries it.
				AMAT_Job_Workflow::start_invoice_due( $new_id );
			}
			$this->fire_doc_saved( $type, $new_id, true );
		}
		return $new_id;
	}

	/**
	 * Save one estimate/invoice sub-form: status + notes + line items (customer +
	 * vehicle stay inherited from the job). Catalog "save" flags are resolved first.
	 *
	 * @param string $type 'estimate' or 'invoice'.
	 * @param string $then Provider action slug to hand off to once the save has
	 *                     landed, or '' for a plain Save. Opaque to core.
	 * @return void
	 */
	private function process_doc_save( $type, $then = '' ) {
		list( $job_id, $job, $redirect ) = $this->doc_action_context();
		$doc_id      = isset( $_POST['doc_id'] ) ? absint( $_POST['doc_id'] ) : 0;
		$is_estimate = ( 'estimate' === $type );
		$model       = $is_estimate ? 'AMAT_Estimate_Model' : 'AMAT_Invoice_Model';
		$item_model  = $is_estimate ? 'AMAT_Estimate_Item_Model' : 'AMAT_Invoice_Item_Model';

		$doc = $doc_id ? $model::find( $doc_id ) : null;
		if ( ! $job || ! $doc || (int) $doc['job_id'] !== $job_id ) {
			$this->flash_to_destination( array( 'status' => 'error', 'message' => __( 'That document is not on this job.', 'auto-mation' ) ), $redirect );
			wp_safe_redirect( $redirect );
			exit;
		}

		$redirect = $this->doc_url( $job_id, $type, $doc_id );
		$status   = isset( $_POST['status'] ) ? sanitize_key( wp_unslash( $_POST['status'] ) ) : 'draft';
		$statuses = $is_estimate ? AMAT_Estimate_Model::STATUSES : AMAT_Invoice_Model::STATUSES;

		// Approving on the customer's behalf (the either-or of the Approval step)
		// is the owner's, or a technician's given the permission.
		if ( $is_estimate && 'approved' === $status && 'approved' !== (string) $doc['status'] && ! AMAT_Access::perm( 'approve' ) ) {
			$this->flash_to_destination( array( 'status' => 'error', 'message' => __( 'You are not allowed to approve estimates. Nothing was saved.', 'auto-mation' ) ), $redirect );
			wp_safe_redirect( $redirect );
			exit;
		}
		$rows     = AMAT_Estimates_Page::persist_catalog_flags( AMAT_Estimates_Page::collect_item_rows() );

		$model::update(
			$doc_id,
			array(
				'customer_id' => (int) $job['customer_id'],
				'vehicle_id'  => (int) $job['vehicle_id'],
				'status'      => in_array( $status, $statuses, true ) ? $status : (string) $doc['status'],
				'notes'       => sanitize_textarea_field( wp_unslash( $_POST['notes'] ?? '' ) ),
			)
		);
		$item_model::replace_for_parent( $doc_id, $rows );

		// After the line items land, so a listener sees the finished document.
		$this->fire_doc_saved( $type, $doc_id, false );

		$notice = array( 'status' => 'success', 'message' => __( 'Saved.', 'auto-mation' ) );

		if ( '' !== $then ) {
			/**
			 * A provider button in this document's action row was used: the document
			 * is now saved, so act on it.
			 *
			 * Return a notice — `[ 'status' => 'success'|'error', 'message' => '…' ]` —
			 * to replace core's "Saved.", which is what the owner wants to read (the
			 * save is implied by the result). Return null to leave core's message, and
			 * ignore any slug that is not yours: every provider sees every slug.
			 *
			 * Core has already verified the nonce and the capability, and the redirect
			 * back to the job is core's to make — a listener must not redirect or exit.
			 *
			 * @param array<string,string>|null $notice Notice to flash, or null.
			 * @param string                    $action The provider's own action slug.
			 * @param string                    $type   'estimate' or 'invoice'.
			 * @param int                       $doc_id Document id.
			 * @param int                       $job_id Owning job id.
			 */
			$handled = apply_filters( 'amat_job_document_saved_action', null, $then, $type, (int) $doc_id, (int) $job_id );
			if ( is_array( $handled ) && ! empty( $handled['message'] ) ) {
				$notice = array(
					'status'  => ( 'error' === ( $handled['status'] ?? '' ) ) ? 'error' : 'success',
					'message' => (string) $handled['message'],
				);
			}
		}

		$this->flash_to_destination( $notice, $redirect );
		wp_safe_redirect( $redirect );
		exit;
	}

	/**
	 * Fire the lifecycle hook for a saved estimate/invoice.
	 *
	 * Fired from the save paths rather than from the models, deliberately: the
	 * models are also driven by migrations, importers and tests, where an
	 * outbound provider call would be wrong. These hooks mean "the owner saved
	 * this record" — which is what a provider's auto-sync mode is about.
	 *
	 * @param string $type   'estimate' or 'invoice'.
	 * @param int    $id     Document id.
	 * @param bool   $is_new Whether the record was just created.
	 * @return void
	 */
	private function fire_doc_saved( $type, $id, $is_new ) {
		// A document changes the facts the workflow moves on (an estimate sent or
		// given the go-ahead, an invoice paid). Forward only; never undoes a step.
		$doc = 'estimate' === $type ? AMAT_Estimate_Model::find( (int) $id ) : AMAT_Invoice_Model::find( (int) $id );
		if ( $doc && ! empty( $doc['job_id'] ) ) {
			AMAT_Job_Workflow::reconcile( (int) $doc['job_id'] );
		}

		if ( 'estimate' === $type ) {
			/**
			 * Fires after the owner saves an estimate from the job's document manager.
			 *
			 * Core ships no listener; a provider integration uses it for auto-sync.
			 *
			 * @param int  $id     Estimate id.
			 * @param bool $is_new Whether the record was just created.
			 */
			do_action( 'amat_after_estimate_save', (int) $id, (bool) $is_new );
			return;
		}

		/**
		 * Fires after the owner saves an invoice from the job's document manager.
		 *
		 * Core ships no listener; a provider integration uses it for auto-sync.
		 *
		 * @param int  $id     Invoice id.
		 * @param bool $is_new Whether the record was just created.
		 */
		do_action( 'amat_after_invoice_save', (int) $id, (bool) $is_new );
	}

	/**
	 * Convert one of the job's estimates into an invoice on the same job, then land
	 * back on the job screen with the new invoice open. Refuses a second convert.
	 *
	 * @return void
	 */
	private function process_doc_convert() {
		list( $job_id, $job, $redirect ) = $this->doc_action_context();
		$doc_id   = isset( $_POST['doc_id'] ) ? absint( $_POST['doc_id'] ) : 0;
		$estimate = $doc_id ? AMAT_Estimate_Model::find( $doc_id ) : null;

		if ( ! $job || ! $estimate || (int) $estimate['job_id'] !== $job_id ) {
			$this->flash_to_destination( array( 'status' => 'error', 'message' => __( 'That estimate is not on this job.', 'auto-mation' ) ), $redirect );
		} elseif ( AMAT_Invoice_Model::for_estimate( $doc_id ) ) {
			$this->flash_to_destination( array( 'status' => 'error', 'message' => __( 'This estimate was already converted to an invoice.', 'auto-mation' ) ), $redirect );
		} else {
			$new = AMAT_Invoice_Model::create_from_estimate( $estimate );
			if ( $new ) {
				AMAT_Job_Workflow::start_invoice_due( (int) $new );
				$this->fire_doc_saved( 'invoice', (int) $new, true );
				$redirect = $this->doc_url( $job_id, 'invoice', (int) $new );
			}
			$this->flash_to_destination(
				$new
					? array( 'status' => 'success', 'message' => __( 'Estimate converted to an invoice.', 'auto-mation' ) )
					: array( 'status' => 'error', 'message' => __( 'Could not convert the estimate.', 'auto-mation' ) ),
				$redirect
			);
		}
		wp_safe_redirect( $redirect );
		exit;
	}

	/**
	 * Permanently delete one of the job's estimates/invoices (and its line items),
	 * then land back on the job screen.
	 *
	 * A dev/testing escape hatch, not an everyday action: gated on the Dev Tools
	 * "record deletion" switch (server-side, not merely a hidden button) and
	 * confirm-gated in JS. The everyday way to cancel a document is the 'void'
	 * status, which keeps it on file.
	 *
	 * @param string $type 'estimate' or 'invoice'.
	 * @return void
	 */
	private function process_doc_delete( $type ) {
		list( $job_id, $job, $redirect ) = $this->doc_action_context();
		$doc_id      = isset( $_POST['doc_id'] ) ? absint( $_POST['doc_id'] ) : 0;
		$is_estimate = ( 'estimate' === $type );
		$model       = $is_estimate ? 'AMAT_Estimate_Model' : 'AMAT_Invoice_Model';
		$item_model  = $is_estimate ? 'AMAT_Estimate_Item_Model' : 'AMAT_Invoice_Item_Model';

		$doc = $doc_id ? $model::find( $doc_id ) : null;
		if ( ! AMAT_Admin::delete_enabled() ) {
			// Server-side gate, not just a hidden button: a permanent delete is
			// only ever available while the Dev Tools switch is on. Everyday
			// cancellation is the 'void' status, which keeps the record on file.
			$this->flash_to_destination(
				array(
					'status'  => 'error',
					'message' => __( 'Permanent deletion is turned off. Set the status to Void instead, or enable record deletion in Settings → Dev Tools.', 'auto-mation' ),
				),
				$redirect
			);
		} elseif ( ! $job || ! $doc || (int) $doc['job_id'] !== $job_id ) {
			$this->flash_to_destination( array( 'status' => 'error', 'message' => __( 'That document is not on this job.', 'auto-mation' ) ), $redirect );
		} else {
			$item_model::replace_for_parent( $doc_id, array() ); // drop line items first (no orphans)
			$model::delete( $doc_id );
			$this->flash_to_destination( array( 'status' => 'success', 'message' => __( 'Deleted.', 'auto-mation' ) ), $redirect );
		}
		wp_safe_redirect( $redirect );
		exit;
	}

	/* --------------------------------------------------------------------- */
	/* Save                                                                  */
	/* --------------------------------------------------------------------- */

	/**
	 * Validate and persist the submitted job: the Add job form (a new job), or
	 * one stage of an existing job's screen (Nick, 2026-09-30).
	 *
	 * Called from the base class on `admin_init` once it confirms this is the
	 * job save POST; always returns a result array (never null).
	 *
	 * @return array{status:string,message:string,data?:array,editing_id?:int}
	 */
	protected function save() {
		check_admin_referer( self::NONCE_ACTION );
		$refused = array( 'status' => 'error', 'message' => __( 'You are not allowed to save this job.', 'auto-mation' ), 'data' => array(), 'editing_id' => 0 );

		$id = isset( $_POST['job_id'] ) ? absint( $_POST['job_id'] ) : 0;
		if ( $id ) {
			// The owner, or the job's own technician (AMAT_Access).
			$existing = AMAT_Job_Model::find( $id );
			if ( ! $existing || ! AMAT_Access::can_edit_job( $existing ) ) {
				return $refused;
			}
			return $this->save_stage( $id, isset( $_POST['stage'] ) ? sanitize_key( wp_unslash( $_POST['stage'] ) ) : '' );
		}
		if ( ! AMAT_Access::is_owner() ) {
			return $refused; // only the owner adds jobs
		}
		$return_customer = isset( $_POST['return_customer'] ) ? absint( $_POST['return_customer'] ) : 0;

		// Resolve the customer: a picked existing one, else create a new customer
		// from a typed name (quick add for follow-up). Same for the vehicle.
		$cust_id = isset( $_POST['customer_id'] ) ? absint( $_POST['customer_id'] ) : 0;
		if ( ! $cust_id ) {
			$typed_name = sanitize_text_field( wp_unslash( $_POST['customer_search'] ?? '' ) );
			if ( '' !== trim( $typed_name ) ) {
				$cust_id = (int) self::create_customer_from_name( $typed_name );
			}
		}

		$data = array(
			'customer_id'     => $cust_id,
			'return_customer' => $return_customer,
			'name'            => sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) ),
			'vehicle_id'      => $cust_id ? $this->resolve_vehicle( $cust_id ) : 0,
			'location_id'     => isset( $_POST['location_id'] ) ? absint( $_POST['location_id'] ) : 0,
			'scheduled_start' => $this->combine_datetime( $_POST['scheduled_start_date'] ?? '', $_POST['scheduled_start_time'] ?? '' ),
			'scheduled_end'   => $this->combine_datetime( $_POST['scheduled_end_date'] ?? '', $_POST['scheduled_end_time'] ?? '' ),
			'complaint'       => sanitize_textarea_field( wp_unslash( $_POST['complaint'] ?? '' ) ),
			'research'        => sanitize_textarea_field( wp_unslash( $_POST['research'] ?? '' ) ),
			'damage'          => sanitize_textarea_field( wp_unslash( $_POST['damage'] ?? '' ) ),
			'description'     => sanitize_textarea_field( wp_unslash( $_POST['description'] ?? '' ) ),
			// Blank clears it (odometer is optional); the model's int sanitizer stores NULL.
			'mileage'         => ( isset( $_POST['mileage'] ) && '' !== trim( (string) $_POST['mileage'] ) ) ? absint( wp_unslash( $_POST['mileage'] ) ) : null,
		);

		if ( ! $data['customer_id'] ) {
			return array( 'status' => 'error', 'message' => __( 'Please choose a customer for this job.', 'auto-mation' ), 'data' => $data, 'editing_id' => 0 );
		}
		if ( self::ends_before_start( $data['scheduled_start'], $data['scheduled_end'] ) ) {
			return array( 'status' => 'error', 'message' => __( 'The end of the job is before its start. Check the scheduled dates and times.', 'auto-mation' ), 'data' => $data, 'editing_id' => 0 );
		}

		$id = AMAT_Job_Model::create( $data );
		if ( ! $id ) {
			return array( 'status' => 'error', 'message' => __( 'Could not save the job. Please try again.', 'auto-mation' ), 'data' => $data, 'editing_id' => 0 );
		}

		// A customer, a vehicle, booked dates: move the step on to match.
		AMAT_Job_Workflow::reconcile( (int) $id );

		$success = array( 'status' => 'success', 'message' => __( 'Job saved.', 'auto-mation' ) );
		if ( $return_customer ) {
			$success['redirect'] = add_query_arg(
				array( 'page' => AMAT_Customers_Page::PAGE_SLUG, 'action' => 'view', 'id' => $return_customer ),
				admin_url( 'admin.php' )
			);
		} else {
			// Land on the job screen - that is where the job lives, and where its
			// estimates and invoices are added.
			$success['redirect'] = $this->list_url( array( 'action' => 'view', 'id' => (int) $id ) );
		}
		return $success;
	}

	/**
	 * A job that ends before it starts is a typo, and an expensive one: it lands
	 * on the calendar as a single day and quietly misstates how long the work
	 * takes. Compared as timestamps, not strings: combine_datetime() tolerates a
	 * single-digit hour, and "9:00" sorts after "10:00" as text.
	 *
	 * @param string $start Stored start.
	 * @param string $end   Stored end.
	 * @return bool
	 */
	private static function ends_before_start( $start, $end ) {
		$start_ts = '' !== (string) $start ? strtotime( (string) $start ) : false;
		$end_ts   = '' !== (string) $end ? strtotime( (string) $end ) : false;
		return false !== $start_ts && false !== $end_ts && $end_ts < $start_ts;
	}

	/**
	 * The vehicle the form chose: a picked one, else a new one from a VIN typed
	 * into the quick-add box (live-decoded), else from a typed "Year Make Model".
	 *
	 * @param int $cust_id Owning customer.
	 * @return int Vehicle id, or 0.
	 */
	private function resolve_vehicle( $cust_id ) {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- verified by the caller.
		$veh_id = isset( $_POST['vehicle_id'] ) ? absint( $_POST['vehicle_id'] ) : 0;
		if ( $veh_id || ! $cust_id ) {
			return $veh_id;
		}
		$vin = isset( $_POST['new_vehicle_vin'] ) ? sanitize_text_field( wp_unslash( $_POST['new_vehicle_vin'] ) ) : '';
		if ( '' !== trim( $vin ) ) {
			$veh_id = (int) self::create_vehicle_from_vin( $cust_id, $vin, isset( $_POST['new_vehicle_year'] ) ? absint( $_POST['new_vehicle_year'] ) : 0 );
		}
		if ( ! $veh_id ) {
			$typed = sanitize_text_field( wp_unslash( $_POST['vehicle_search'] ?? '' ) );
			if ( '' !== trim( $typed ) ) {
				$veh_id = (int) self::create_vehicle_from_text( $cust_id, $typed );
			}
		}
		// phpcs:enable
		return $veh_id;
	}

	/**
	 * Save one stage of an existing job's screen. Only that stage's fields are
	 * written - another stage's are never blanked - and nothing at all is
	 * written unless the whole stage is valid.
	 *
	 *  - info: the job's name, complaint, vehicle and location; the customer's
	 *          names and contact methods; the location's address (or a new one);
	 *          the vehicle's VIN, Plate and Color. Announced as a customer save,
	 *          so a provider's copy follows.
	 *  - plan: research, the appointment, Hold / Standby (+ invoice due dates).
	 *  - job:  odometer, existing damage, internal notes.
	 *  - pay:  nothing of its own - "+ Add invoice".
	 *
	 * "+ Add estimate" / "+ Add invoice" (`then_add`) add the document once the
	 * stage is saved, and land on it open.
	 *
	 * @param int    $id    Job id.
	 * @param string $stage Stage slug.
	 * @return array{status:string,message:string,data?:array,editing_id?:int,redirect?:string}
	 */
	private function save_stage( $id, $stage ) {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- verified in save().
		$job = AMAT_Job_Model::find( (int) $id );
		if ( ! $job ) {
			return array( 'status' => 'error', 'message' => __( 'Job not found.', 'auto-mation' ), 'data' => array(), 'editing_id' => 0 );
		}
		if ( ! isset( AMAT_Job_Workflow::stages()[ $stage ] ) ) {
			return array( 'status' => 'error', 'message' => __( 'That part of the job could not be saved. Please try again.', 'auto-mation' ), 'data' => array(), 'editing_id' => $id );
		}
		$return_customer = isset( $_POST['return_customer'] ) ? absint( $_POST['return_customer'] ) : 0;
		$text            = static function ( $key ) {
			return sanitize_text_field( wp_unslash( $_POST[ $key ] ?? '' ) );
		};
		$area            = static function ( $key ) {
			return sanitize_textarea_field( wp_unslash( $_POST[ $key ] ?? '' ) );
		};
		// What was typed, so a rejected save can put it all back on the screen.
		$typed = array( 'edit_stage' => $stage );
		$fail  = static function ( $message ) use ( &$typed, $id ) {
			return array( 'status' => 'error', 'message' => $message, 'data' => $typed, 'editing_id' => $id );
		};

		$moved    = array();
		$warnings = array(); // said alongside "Saved." - e.g. the tech is off then
		switch ( $stage ) {
			case 'info':
				$cust_id = (int) $job['customer_id'];
				// Contacts hidden from this technician: whatever was posted for them is
				// ignored, and the customer's stay exactly as they are.
				$hidden = ! AMAT_Access::sees_contacts();
				list( $methods, $errors, $submitted ) = $hidden ? array( array(), array(), array() ) : AMAT_Customers_Page::parse_contact_methods();
				$loc_choice = $text( 'location_id' );
				$address    = array();
				foreach ( array( 'label', 'street_1', 'street_2', 'city', 'state', 'zipcode' ) as $field ) {
					$address[ $field ] = $text( 'loc_' . $field );
					$typed[ 'loc_' . $field ] = $address[ $field ];
				}
				// The fields added later (2026-10-06) are written only when posted, so
				// a form without them leaves them alone.
				$posted = static function ( $key ) {
					return isset( $_POST[ $key ] ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified in maybe_process().
				};
				if ( $posted( 'loc_code' ) ) {
					$address['code']   = $text( 'loc_code' );
					$typed['loc_code'] = $address['code'];
				}
				if ( $posted( 'loc_notes' ) ) {
					$address['notes']   = $area( 'loc_notes' );
					$typed['loc_notes'] = $address['notes'];
				}
				$address['state'] = strtoupper( trim( $address['state'] ) );
				$customer         = array(
					'first_name'   => $text( 'first_name' ),
					'last_name'    => $text( 'last_name' ),
					'display_name' => $text( 'display_name' ),
				);
				$cust_extra = array();
				if ( $posted( 'customer_notes' ) ) {
					$cust_extra['notes']     = $area( 'customer_notes' );
					$typed['customer_notes'] = $cust_extra['notes'];
				}
				$veh_extra = array();
				foreach ( array( 'color_code' => 'color_code', 'warnings' => 'warnings', 'vehicle_notes' => 'notes' ) as $key => $column ) {
					if ( $posted( $key ) ) {
						$veh_extra[ $column ] = 'color_code' === $key ? strtoupper( $text( $key ) ) : $area( $key );
						$typed[ $key ]        = $veh_extra[ $column ];
					}
				}
				$vin              = AMAT_Vin_Decoder::normalize( $text( 'vin' ) );
				$typed           += $customer + array(
					'name'          => $text( 'name' ),
					'complaint'     => $area( 'complaint' ),
					'methods'       => $submitted,
					'location_id'   => $loc_choice,
					'vehicle_id'    => (string) absint( $_POST['vehicle_id'] ?? 0 ),
					'vin'           => $vin,
					'license_plate' => $text( 'license_plate' ),
					'plate_state'   => $text( 'plate_state' ),
					'color'         => $text( 'color' ),
				);

				// Validate everything before writing anything.
				if ( '' === $customer['first_name'] ) {
					return $fail( __( 'A first name is required.', 'auto-mation' ) );
				}
				if ( $errors ) {
					return $fail( implode( ' ', $errors ) );
				}
				if ( '' !== $vin ) {
					$checked = AMAT_Vin_Decoder::validate( $vin );
					if ( is_wp_error( $checked ) ) {
						return $fail( $checked->get_error_message() );
					}
				}
				// No vehicle picked or typed: a VIN adds one (below); plate or colour
				// alone has nowhere to go - say so rather than drop it.
				$no_vehicle = ! absint( $_POST['vehicle_id'] ?? 0 ) && '' === trim( sanitize_text_field( wp_unslash( $_POST['vehicle_search'] ?? '' ) ) );
				if ( $no_vehicle && '' === $vin && ( '' !== $text( 'license_plate' ) || '' !== $text( 'color' ) ) ) {
					return $fail( __( 'Pick or add a vehicle first - or enter its VIN to add it.', 'auto-mation' ) );
				}
				$loc_id  = 'new' === $loc_choice ? 0 : absint( $loc_choice );
				$loc_row = $loc_id ? AMAT_Location_Model::find( $loc_id ) : null;
				$own_loc = $loc_row && (int) $loc_row['customer_id'] === $cust_id;
				if ( 'new' === $loc_choice || $own_loc ) {
					if ( 'new' === $loc_choice && '' === trim( $address['street_1'] ) ) {
						return $fail( __( 'Enter the new location\'s street.', 'auto-mation' ) );
					}
					if ( '' !== $address['state'] && ! AMAT_Location_Model::is_valid_state( $address['state'] ) ) {
						/* translators: %s: what was typed. */
						return $fail( sprintf( __( '"%s" is not a US state code. Use two letters, e.g. IN.', 'auto-mation' ), $address['state'] ) );
					}
					$zip = AMAT_Location_Model::normalize_zip( $address['zipcode'] );
					if ( is_wp_error( $zip ) ) {
						return $fail( $zip->get_error_message() );
					}
					$address['zipcode'] = $zip;
				}
				$plate_state = strtoupper( $text( 'plate_state' ) );
				if ( '' !== $plate_state && ! AMAT_Location_Model::is_valid_state( $plate_state ) ) {
					/* translators: %s: what was typed. */
					return $fail( sprintf( __( 'Plate state "%s" is not a US state code. Use two letters, e.g. IN.', 'auto-mation' ), $plate_state ) );
				}

				// The customer and their contact methods.
				AMAT_Customer_Model::update( $cust_id, $customer + $cust_extra );
				if ( ! $hidden ) {
					AMAT_Contact_Method_Model::replace_for_customer( $cust_id, $methods );
				}

				// The location: a new one, or the picked one's address.
				if ( 'new' === $loc_choice ) {
					$first  = ! array_filter( AMAT_Location_Model::for_customer( $cust_id ), static fn( $l ) => ! empty( $l['is_active'] ) );
					$loc_id = (int) AMAT_Location_Model::create(
						$address + array(
							'customer_id' => $cust_id,
							'is_active'   => 1,
							'is_primary'  => $first ? 1 : 0,
							'is_billing'  => $first ? 1 : 0,
						)
					);
				} elseif ( $own_loc ) {
					AMAT_Location_Model::update( $loc_id, $address );
				}

				// The vehicle: picked or added, then its VIN, Plate and Color. With none
				// picked or typed, the VIN adds it - or is the customer's vehicle that
				// already carries that VIN.
				$veh_id = $this->resolve_vehicle( $cust_id );
				if ( ! $veh_id && '' !== $vin ) {
					foreach ( AMAT_Vehicle_Model::for_customer( $cust_id ) as $owned ) {
						if ( ! empty( $owned['is_active'] ) && strtoupper( (string) $owned['vin'] ) === $vin ) {
							$veh_id = (int) $owned['id'];
							break;
						}
					}
					if ( ! $veh_id ) {
						$veh_id = (int) self::create_vehicle_from_vin( $cust_id, $vin );
					}
				}
				if ( $veh_id ) {
					$veh_fields = array(
						'vin'           => $vin,
						'license_plate' => strtoupper( $text( 'license_plate' ) ),
						'plate_state'   => $plate_state,
						'color'         => $text( 'color' ),
					) + $veh_extra;
					// A changed VIN is decoded here and its specs stored, as adding a
					// vehicle by VIN does. An unchanged VIN costs no network call, and a
					// failed decode still saves the VIN.
					$stored = AMAT_Vehicle_Model::find( $veh_id );
					if ( '' !== $vin && $stored && $vin !== (string) $stored['vin'] ) {
						$decoded = ( new AMAT_Vin_Decoder() )->decode( $vin, (int) $stored['year'] ?: null );
						if ( ! is_wp_error( $decoded ) ) {
							foreach ( $decoded as $column => $value ) {
								if ( '' !== (string) $value && ! isset( $veh_fields[ $column ] ) ) {
									$veh_fields[ $column ] = $value;
								}
							}
						}
					}
					AMAT_Vehicle_Model::update( $veh_id, $veh_fields );
				}

				AMAT_Job_Model::update(
					$id,
					array(
						'name'        => $text( 'name' ),
						'complaint'   => $area( 'complaint' ),
						'vehicle_id'  => $veh_id,
						'location_id' => $loc_id,
					)
				);

				/** This action is documented in includes/admin/class-customers-page.php */
				do_action( 'amat_after_customer_save', $cust_id, false );
				break;

			case 'plan':
				$fields = array();
				if ( isset( $_POST['research'] ) ) {
					$fields['research'] = $area( 'research' );
				}
				if ( isset( $_POST['scheduled_start_date'] ) ) {
					$fields['scheduled_start'] = $this->combine_datetime( $_POST['scheduled_start_date'] ?? '', $_POST['scheduled_start_time'] ?? '' );
					$fields['scheduled_end']   = $this->combine_datetime( $_POST['scheduled_end_date'] ?? '', $_POST['scheduled_end_time'] ?? '' );
				}
				$typed += $fields + array(
					'flag'        => $text( 'flag' ),
					'flag_reason' => $text( 'flag_reason' ),
					'hold_until'  => $text( 'hold_until' ),
				);
				if ( isset( $fields['scheduled_start'] ) && self::ends_before_start( $fields['scheduled_start'], $fields['scheduled_end'] ) ) {
					return $fail( __( 'The end of the job is before its start. Check the scheduled dates and times.', 'auto-mation' ) );
				}
				// The owner assigns; a technician's posted choice is ignored.
				$tech = ( isset( $_POST['technician_id'] ) && AMAT_Access::is_owner() ) ? absint( $_POST['technician_id'] ) : null;
				if ( $tech && ! AMAT_Technicians::is_tech( $tech ) ) {
					return $fail( __( 'Only a technician can be assigned a job.', 'auto-mation' ) );
				}
				if ( $fields ) {
					AMAT_Job_Model::update( $id, $fields );
				}
				// After the dates, so its warnings are about the new appointment.
				if ( null !== $tech ) {
					$assigned = AMAT_Job_Workflow::assign( $id, $tech );
					$warnings = is_wp_error( $assigned ) ? array() : $assigned['warnings'];
				}

				// Hold / Standby, then the appointment. The order matters: a job put on
				// hold keeps the hold's due date even if its dates changed in the same
				// save, while a hold cleared in a save that also moves the appointment
				// follows the new appointment.
				if ( isset( $_POST['flag'] ) ) {
					$flagged = AMAT_Job_Workflow::set_flag( $id, sanitize_key( wp_unslash( $_POST['flag'] ) ), $text( 'flag_reason' ), $text( 'hold_until' ) );
					if ( ! is_wp_error( $flagged ) ) {
						$moved = $flagged['invoices'];
					}
				}
				$after = AMAT_Job_Model::find( $id );
				if ( (string) $job['scheduled_start'] !== (string) $after['scheduled_start'] || (string) $job['scheduled_end'] !== (string) $after['scheduled_end'] ) {
					$moved = array_merge( $moved, AMAT_Job_Workflow::schedule_changed( $id ) );
				}
				break;

			case 'job':
				$fields = array();
				if ( isset( $_POST['mileage'] ) ) {
					// Blank clears it (odometer is optional); the model stores NULL.
					$fields['mileage'] = '' !== trim( (string) $_POST['mileage'] ) ? absint( wp_unslash( $_POST['mileage'] ) ) : null;
				}
				foreach ( array( 'damage', 'description' ) as $field ) {
					if ( isset( $_POST[ $field ] ) ) {
						$fields[ $field ] = $area( $field );
					}
				}
				if ( $fields ) {
					AMAT_Job_Model::update( $id, $fields );
				}
				break;
		}
		// phpcs:enable

		// A customer, a vehicle, booked dates: move the step on to match.
		// Forward only - it never undoes a step set by hand.
		AMAT_Job_Workflow::reconcile( $id );
		self::announce_invoices( $moved );

		$success  = array( 'status' => 'success', 'message' => trim( __( 'Saved.', 'auto-mation' ) . ' ' . implode( ' ', $warnings ) ) );
		$then_add = isset( $_POST['then_add'] ) ? sanitize_key( wp_unslash( $_POST['then_add'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified in save().
		if ( in_array( $then_add, array( 'estimate', 'invoice' ), true ) ) {
			$doc_id = $this->create_document( AMAT_Job_Model::find( $id ), $then_add );
			if ( $doc_id ) {
				$success['message']  = 'estimate' === $then_add ? __( 'Saved, and an estimate added.', 'auto-mation' ) : __( 'Saved, and an invoice added.', 'auto-mation' );
				$success['redirect'] = $this->doc_url( $id, $then_add, $doc_id );
				return $success;
			}
		}

		$args = array( 'action' => 'view', 'id' => $id );
		if ( $return_customer ) {
			$args['return_customer'] = $return_customer;
		}
		$success['redirect'] = $this->list_url( $args );
		return $success;
	}
}
