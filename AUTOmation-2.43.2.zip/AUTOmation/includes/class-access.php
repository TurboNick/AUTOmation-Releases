<?php
/**
 * Who may see and do what: the owner, and technicians (phase 2).
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The one place the access rules live (Nick, 2026-10-01).
 *
 *  - The OWNER - whoever holds AMAT_Admin::CAPABILITY (manage_options) - can do
 *    everything and has nothing hidden.
 *  - A TECHNICIAN holds CAP: they work the jobs assigned to them, estimates and
 *    invoices included, and reach none of the owner's screens. Per tech, the
 *    owner switches on any of PERMS.
 *
 * Every screen and handler asks here; never compare roles by hand. Hiding a
 * button is a courtesy - the refusal that matters is the server's.
 */
class AMAT_Access {

	/**
	 * The capability to work jobs: technicians have it, and the owner is granted
	 * it (grant_owner()).
	 *
	 * @var string
	 */
	const CAP = 'amat_work';

	/**
	 * Prefix of the user meta holding each per-tech permission ('1' = on).
	 *
	 * @var string
	 */
	const META_PREFIX = 'amat_perm_';

	/**
	 * The per-tech permissions, all off until the owner turns them on.
	 *
	 * @var array<string,string>
	 */
	const PERMS = array(
		'unassigned'    => 'See unassigned jobs, and take one',
		'confirm'       => 'Confirm a customer\'s proposed time (and take the job)',
		'approve'       => 'Approve an estimate on the customer\'s behalf',
		'hide_contacts' => 'Hide customers\' phone numbers and emails',
	);

	/**
	 * Hook the owner's grant. Called on every request.
	 *
	 * @return void
	 */
	public static function register() {
		add_filter( 'user_has_cap', array( __CLASS__, 'grant_owner' ), 10, 1 );
	}

	/**
	 * The owner can work jobs too: whoever can manage the site holds CAP.
	 *
	 * @param array<string,bool> $allcaps The user's capabilities.
	 * @return array<string,bool>
	 */
	public static function grant_owner( $allcaps ) {
		if ( ! empty( $allcaps[ AMAT_Admin::CAPABILITY ] ) ) {
			$allcaps[ self::CAP ] = true;
		}
		return $allcaps;
	}

	/**
	 * A permission's label, translated.
	 *
	 * @param string $key A PERMS key.
	 * @return string
	 */
	public static function label( $key ) {
		$labels = array(
			'unassigned'    => __( 'See unassigned jobs, and take one', 'auto-mation' ),
			'confirm'       => __( 'Confirm a customer\'s proposed time (and take the job)', 'auto-mation' ),
			'approve'       => __( 'Approve an estimate on the customer\'s behalf', 'auto-mation' ),
			'hide_contacts' => __( 'Hide customers\' phone numbers and emails', 'auto-mation' ),
		);
		return $labels[ $key ] ?? $key;
	}

	/**
	 * The current user, or the one given.
	 *
	 * @param int $user_id User id, or 0 for the current user.
	 * @return int
	 */
	private static function who( $user_id ) {
		return (int) $user_id ? (int) $user_id : get_current_user_id();
	}

	/**
	 * Whether a user is the owner.
	 *
	 * @param int $user_id User id, or 0 for the current user.
	 * @return bool
	 */
	public static function is_owner( $user_id = 0 ) {
		$user_id = self::who( $user_id );
		return $user_id && user_can( $user_id, AMAT_Admin::CAPABILITY );
	}

	/**
	 * Whether a user works jobs at all (a technician, or the owner).
	 *
	 * @param int $user_id User id, or 0 for the current user.
	 * @return bool
	 */
	public static function can_work( $user_id = 0 ) {
		$user_id = self::who( $user_id );
		return $user_id && user_can( $user_id, self::CAP );
	}

	/**
	 * Whether a per-tech permission is on. The owner has every permission, and
	 * never has contacts hidden.
	 *
	 * @param string $key     A PERMS key.
	 * @param int    $user_id User id, or 0 for the current user.
	 * @return bool
	 */
	public static function perm( $key, $user_id = 0 ) {
		$user_id = self::who( $user_id );
		if ( self::is_owner( $user_id ) ) {
			return 'hide_contacts' !== $key;
		}
		return isset( self::PERMS[ $key ] ) && '1' === (string) get_user_meta( $user_id, self::META_PREFIX . $key, true );
	}

	/**
	 * Set a technician's permissions: those named are on, the rest off.
	 *
	 * @param int      $user_id The technician.
	 * @param string[] $on      PERMS keys (unknown ones are ignored).
	 * @return void
	 */
	public static function set_perms( $user_id, array $on ) {
		foreach ( array_keys( self::PERMS ) as $key ) {
			if ( in_array( $key, $on, true ) ) {
				update_user_meta( (int) $user_id, self::META_PREFIX . $key, '1' );
			} else {
				delete_user_meta( (int) $user_id, self::META_PREFIX . $key );
			}
		}
	}

	/**
	 * Whether a user sees customers' phone numbers and emails.
	 *
	 * @param int $user_id User id, or 0 for the current user.
	 * @return bool
	 */
	public static function sees_contacts( $user_id = 0 ) {
		return ! self::perm( 'hide_contacts', $user_id );
	}

	/**
	 * Whether a user may see a job: the owner, its technician, or - with the
	 * permission - anyone who works jobs, while it is unassigned.
	 *
	 * @param array<string,mixed> $job     The job.
	 * @param int                 $user_id User id, or 0 for the current user.
	 * @return bool
	 */
	public static function can_view_job( array $job, $user_id = 0 ) {
		$user_id = self::who( $user_id );
		if ( self::is_owner( $user_id ) ) {
			return true;
		}
		if ( ! self::can_work( $user_id ) ) {
			return false;
		}
		$tech = (int) ( $job['technician_id'] ?? 0 );
		return $tech === $user_id || ( 0 === $tech && self::perm( 'unassigned', $user_id ) );
	}

	/**
	 * Whether a user may work a job: the owner, or its technician.
	 *
	 * @param array<string,mixed> $job     The job.
	 * @param int                 $user_id User id, or 0 for the current user.
	 * @return bool
	 */
	public static function can_edit_job( array $job, $user_id = 0 ) {
		$user_id = self::who( $user_id );
		return self::is_owner( $user_id ) || ( self::can_work( $user_id ) && (int) ( $job['technician_id'] ?? 0 ) === $user_id );
	}

	/**
	 * The jobs among these a user may see.
	 *
	 * @param array<int,array<string,mixed>> $jobs    Job rows.
	 * @param int                            $user_id User id, or 0 for the current user.
	 * @return array<int,array<string,mixed>>
	 */
	public static function visible_jobs( array $jobs, $user_id = 0 ) {
		if ( self::is_owner( $user_id ) ) {
			return $jobs;
		}
		return array_values( array_filter( $jobs, static fn( $job ) => self::can_view_job( $job, $user_id ) ) );
	}
}
