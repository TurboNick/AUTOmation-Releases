<?php
/**
 * The job workflow: Info -> Plan -> Job -> Pay.
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Where a job is in the work, and every way that changes (DB v20).
 *
 * Nick's workflow.md is the source: a job tracks its STEP, and its STAGE is
 * worked out from the step. Hold and Standby are flags on the job, not steps.
 * A job leaves the board by being CLOSED with a reason. This replaced the old
 * job `status` (requested/scheduled/standby/...).
 *
 * Steps move three ways, all through this class so each is logged:
 *  - advance()   — the job screen's next-action button;
 *  - set_step()  — by hand, logged as such;
 *  - reconcile() — automatically, from facts the system already holds (a
 *                  vehicle, an estimate sent or given the go-ahead, dates
 *                  booked, the invoice paid). It only ever moves a job
 *                  FORWARD: it can never undo a step set by hand, and an
 *                  estimate added during diagnosis does not pull a job back
 *                  out of the Job stage.
 */
class AMAT_Job_Workflow {

	/**
	 * The step a new job starts at.
	 */
	const FIRST_STEP = 'customer';

	/**
	 * Log channel.
	 */
	const LOG_CHANNEL = 'core';

	/**
	 * Every step, in order, with its stage (workflow.md).
	 *
	 * @var array<string,string>
	 */
	const STEP_STAGES = array(
		'customer'     => 'info',
		'vehicle'      => 'info',
		'research'     => 'plan',
		'estimate'     => 'plan',
		'approval'     => 'plan',
		'deposit'      => 'plan',
		'ordering'     => 'plan',
		'scheduling'   => 'plan',
		'vehicle_info' => 'job',
		'reproduce'    => 'job',
		'diagnostic'   => 'job',
		'repair'       => 'job',
		'inspect'      => 'job',
		'invoice'      => 'pay',
		'receipt'      => 'pay',
	);

	/* --------------------------------------------------------------------- */
	/* Vocabulary                                                            */
	/* --------------------------------------------------------------------- */

	/**
	 * The stages, in order, with their labels.
	 *
	 * @return array<string,string>
	 */
	public static function stages() {
		return array(
			'info' => __( 'Info', 'auto-mation' ),
			'plan' => __( 'Plan', 'auto-mation' ),
			'job'  => __( 'Job', 'auto-mation' ),
			'pay'  => __( 'Pay', 'auto-mation' ),
		);
	}

	/**
	 * Label for a stage slug (including 'closed').
	 *
	 * @param string $stage Stage slug.
	 * @return string
	 */
	public static function stage_label( $stage ) {
		if ( 'closed' === $stage ) {
			return __( 'Closed', 'auto-mation' );
		}
		$stages = self::stages();
		return $stages[ $stage ] ?? (string) $stage;
	}

	/**
	 * The steps, in order, with their labels.
	 *
	 * @return array<string,string>
	 */
	public static function steps() {
		return array(
			'customer'     => __( 'Customer', 'auto-mation' ),
			'vehicle'      => __( 'Vehicle', 'auto-mation' ),
			'research'     => __( 'Research', 'auto-mation' ),
			'estimate'     => __( 'Estimate', 'auto-mation' ),
			'approval'     => __( 'Approval', 'auto-mation' ),
			'deposit'      => __( 'Deposit', 'auto-mation' ),
			'ordering'     => __( 'Ordering', 'auto-mation' ),
			'scheduling'   => __( 'Scheduling', 'auto-mation' ),
			'vehicle_info' => __( 'Update vehicle info', 'auto-mation' ),
			'reproduce'    => __( 'Reproduce complaint', 'auto-mation' ),
			'diagnostic'   => __( 'Diagnostic', 'auto-mation' ),
			'repair'       => __( 'Repair / Service', 'auto-mation' ),
			'inspect'      => __( 'Inspect', 'auto-mation' ),
			'invoice'      => __( 'Invoice', 'auto-mation' ),
			'receipt'      => __( 'Receipt', 'auto-mation' ),
		);
	}

	/**
	 * What finishing each step is called — the job screen's next-action button.
	 *
	 * @return array<string,string>
	 */
	public static function step_actions() {
		return array(
			'customer'     => __( 'Customer confirmed', 'auto-mation' ),
			'vehicle'      => __( 'Vehicle & complaint recorded', 'auto-mation' ),
			'research'     => __( 'Research done', 'auto-mation' ),
			'estimate'     => __( 'Estimate sent', 'auto-mation' ),
			'approval'     => __( 'Approval received', 'auto-mation' ),
			'deposit'      => __( 'Deposit received / not needed', 'auto-mation' ),
			'ordering'     => __( 'Parts ordered / none needed', 'auto-mation' ),
			'scheduling'   => __( 'Start the job', 'auto-mation' ),
			'vehicle_info' => __( 'Odometer & damage recorded', 'auto-mation' ),
			'reproduce'    => __( 'Complaint reproduced', 'auto-mation' ),
			'diagnostic'   => __( 'Diagnosis done', 'auto-mation' ),
			'repair'       => __( 'Repair done', 'auto-mation' ),
			'inspect'      => __( 'Complaint verified resolved', 'auto-mation' ),
			'invoice'      => __( 'Final payment received', 'auto-mation' ),
			'receipt'      => __( 'Receipt sent — close the job', 'auto-mation' ),
		);
	}

	/**
	 * Why a job can be closed, with labels.
	 *
	 * @return array<string,string>
	 */
	public static function close_reasons() {
		return array(
			'paid'      => __( 'Paid', 'auto-mation' ),
			'cancelled' => __( 'Cancelled', 'auto-mation' ),
			'declined'  => __( 'Estimate declined', 'auto-mation' ),
			'no_show'   => __( 'No-show', 'auto-mation' ),
		);
	}

	/**
	 * Whether a slug is a step.
	 *
	 * @param string $step Candidate.
	 * @return bool
	 */
	public static function is_step( $step ) {
		return isset( self::STEP_STAGES[ (string) $step ] );
	}

	/**
	 * Label for a step slug.
	 *
	 * @param string $step Step slug.
	 * @return string
	 */
	public static function step_label( $step ) {
		$steps = self::steps();
		return $steps[ $step ] ?? (string) $step;
	}

	/**
	 * The stage a step belongs to.
	 *
	 * @param string $step Step slug.
	 * @return string
	 */
	public static function stage_of_step( $step ) {
		return self::STEP_STAGES[ (string) $step ] ?? 'info';
	}

	/**
	 * A job's stage: 'closed' once closed, else the stage of its step.
	 *
	 * @param array<string,mixed> $job Job row.
	 * @return string
	 */
	public static function stage( array $job ) {
		if ( '' !== (string) ( $job['closed_reason'] ?? '' ) ) {
			return 'closed';
		}
		return self::stage_of_step( (string) ( $job['step'] ?? self::FIRST_STEP ) );
	}

	/**
	 * Whether an open job is still in Info or Plan after its appointment's last
	 * day - almost always work that was done but never marked. Only flagged, never
	 * moved: a date arriving is not a fact on a record, so reconcile() leaves it
	 * to the owner (Nick, 2026-09-29).
	 *
	 * @param array<string,mixed> $job   Job row.
	 * @param string              $today Y-m-d; defaults to the site's own date.
	 * @return bool
	 */
	public static function appointment_passed( array $job, $today = '' ) {
		if ( '' !== (string) ( $job['closed_reason'] ?? '' ) || ! in_array( self::stage( $job ), array( 'info', 'plan' ), true ) ) {
			return false;
		}
		$last = self::parse_when( (string) ( $job['scheduled_end'] ?? '' ) ) ?: self::parse_when( (string) ( $job['scheduled_start'] ?? '' ) );
		if ( ! $last ) {
			return false;
		}
		$today = '' !== (string) $today ? (string) $today : current_time( 'Y-m-d' );
		return $last->format( 'Y-m-d' ) < $today;
	}

	/**
	 * The step after this one, or '' at the end.
	 *
	 * @param string $step Step slug.
	 * @return string
	 */
	public static function next_step( $step ) {
		$keys = array_keys( self::STEP_STAGES );
		$i    = array_search( (string) $step, $keys, true );
		return ( false !== $i && isset( $keys[ $i + 1 ] ) ) ? $keys[ $i + 1 ] : '';
	}

	/**
	 * Position of a step in the workflow (for "is it past").
	 *
	 * @param string $step Step slug.
	 * @return int
	 */
	public static function position( $step ) {
		$i = array_search( (string) $step, array_keys( self::STEP_STAGES ), true );
		return false === $i ? 0 : (int) $i;
	}

	/* --------------------------------------------------------------------- */
	/* Changes                                                               */
	/* --------------------------------------------------------------------- */

	/**
	 * Finish the current step: move to the next, or close the job as paid when
	 * the receipt is done.
	 *
	 * @param int $id Job id.
	 * @return array<string,mixed>|WP_Error The updated job.
	 */
	public static function advance( $id ) {
		$job = self::open_job( $id );
		if ( is_wp_error( $job ) ) {
			return $job;
		}
		$from = (string) $job['step'];
		$next = self::next_step( $from );
		if ( '' === $next ) {
			return self::close( $id, 'paid' );
		}
		AMAT_Job_Model::update( (int) $id, array( 'step' => $next ) );
		self::log(
			$id,
			sprintf(
				/* translators: 1: what was finished, 2: the new step. */
				__( '%1$s — now at %2$s.', 'auto-mation' ),
				self::step_actions()[ $from ] ?? self::step_label( $from ),
				self::step_label( $next )
			),
			array( 'from' => $from, 'to' => $next )
		);
		return AMAT_Job_Model::find( (int) $id );
	}

	/**
	 * Put a job at any step, by hand. Always logged as such.
	 *
	 * @param int    $id   Job id.
	 * @param string $step Step slug.
	 * @return array<string,mixed>|WP_Error
	 */
	public static function set_step( $id, $step ) {
		if ( ! self::is_step( $step ) ) {
			return new WP_Error( 'amat_job_step', __( 'That is not a step in the workflow.', 'auto-mation' ) );
		}
		$job = self::open_job( $id );
		if ( is_wp_error( $job ) ) {
			return $job;
		}
		$from = (string) $job['step'];
		AMAT_Job_Model::update( (int) $id, array( 'step' => $step ) );
		self::log(
			$id,
			sprintf(
				/* translators: 1: old step, 2: new step. */
				__( 'Step set by hand: %1$s → %2$s.', 'auto-mation' ),
				self::step_label( $from ),
				self::step_label( $step )
			),
			array( 'from' => $from, 'to' => $step, 'by_hand' => true )
		);
		return AMAT_Job_Model::find( (int) $id );
	}

	/**
	 * Put a job on hold, with a reason. The step does not change.
	 *
	 * @param int    $id     Job id.
	 * @param string $reason Why.
	 * @return array<string,mixed>|WP_Error
	 */
	public static function hold( $id, $reason ) {
		$job = self::open_job( $id );
		if ( is_wp_error( $job ) ) {
			return $job;
		}
		$reason = trim( (string) $reason );
		if ( '' === $reason ) {
			$reason = __( 'No reason given', 'auto-mation' );
		}
		AMAT_Job_Model::update( (int) $id, array( 'on_hold' => 1, 'standby' => 0, 'hold_reason' => $reason ) );
		/* translators: %s: the hold reason. */
		self::log( $id, sprintf( __( 'On hold: %s', 'auto-mation' ), $reason ) );
		return AMAT_Job_Model::find( (int) $id );
	}

	/**
	 * Take a job off hold.
	 *
	 * @param int $id Job id.
	 * @return array<string,mixed>|WP_Error
	 */
	public static function release_hold( $id ) {
		$job = AMAT_Job_Model::find( (int) $id );
		if ( ! $job ) {
			return self::missing();
		}
		AMAT_Job_Model::update( (int) $id, array( 'on_hold' => 0, 'hold_reason' => '', 'hold_until' => '' ) );
		self::log( $id, __( 'Hold cleared.', 'auto-mation' ) );
		return AMAT_Job_Model::find( (int) $id );
	}

	/**
	 * Mark (or clear) standby: the customer would take an earlier slot.
	 *
	 * @param int  $id Job id.
	 * @param bool $on Standby or not.
	 * @return array<string,mixed>|WP_Error
	 */
	public static function set_standby( $id, $on ) {
		$job = AMAT_Job_Model::find( (int) $id );
		if ( ! $job ) {
			return self::missing();
		}
		AMAT_Job_Model::update( (int) $id, $on ? array( 'standby' => 1, 'on_hold' => 0, 'hold_until' => '' ) : array( 'standby' => 0 ) );
		self::log( $id, $on ? __( 'Marked standby — would take an earlier slot.', 'auto-mation' ) : __( 'Standby cleared.', 'auto-mation' ) );
		return AMAT_Job_Model::find( (int) $id );
	}

	/**
	 * Set a job's flag - Hold, Standby, or neither (Nick, 2026-09-30).
	 *
	 * The two are one or the other: Hold is waiting on something out of our
	 * control, Standby is the customer waiting for a short-notice slot, like a
	 * flight. Either carries one Reason (the `hold_reason` column serves both);
	 * Hold also carries an estimated date, `hold_until`.
	 *
	 * Putting a job on hold, or changing its estimated date, moves the job's open
	 * invoices to fall due 30 days past that date (or from today, with none).
	 * Clearing a hold and Standby leave the due date alone.
	 *
	 * Logs only what changed; a save that changes nothing is silent.
	 *
	 * @param int    $id     Job id.
	 * @param string $flag   'hold', 'standby', or '' for neither.
	 * @param string $reason The reason (Hold or Standby).
	 * @param string $until  Hold's estimated date, Y-m-d, or ''.
	 * @return array{job:array<string,mixed>,invoices:int[]}|WP_Error Invoices whose due date moved.
	 */
	public static function set_flag( $id, $flag, $reason = '', $until = '' ) {
		$job = AMAT_Job_Model::find( (int) $id );
		if ( ! $job ) {
			return self::missing();
		}
		$flag   = in_array( $flag, array( 'hold', 'standby' ), true ) ? $flag : '';
		$reason = '' === $flag ? '' : trim( (string) $reason );
		$until  = 'hold' === $flag && self::parse_when( trim( (string) $until ) . ' 00:00' ) ? trim( (string) $until ) : '';

		$was_flag  = ! empty( $job['on_hold'] ) ? 'hold' : ( ! empty( $job['standby'] ) ? 'standby' : '' );
		$was_until = self::day_part( (string) ( $job['hold_until'] ?? '' ) );
		if ( $flag === $was_flag && $reason === (string) $job['hold_reason'] && $until === $was_until ) {
			return array( 'job' => $job, 'invoices' => array() );
		}

		AMAT_Job_Model::update(
			(int) $id,
			array(
				'on_hold'     => 'hold' === $flag ? 1 : 0,
				'standby'     => 'standby' === $flag ? 1 : 0,
				'hold_reason' => $reason,
				'hold_until'  => $until,
			)
		);

		if ( 'hold' === $flag ) {
			$text = '' !== $reason ? $reason : __( 'no reason given', 'auto-mation' );
			if ( '' !== $until ) {
				/* translators: 1: the reason, 2: the estimated date. */
				$text = sprintf( __( '%1$s (estimated %2$s)', 'auto-mation' ), $text, self::short_date( $until ) );
			}
			/* translators: %s: the reason and estimated date. */
			self::log( $id, sprintf( 'hold' === $was_flag ? __( 'Hold updated: %s', 'auto-mation' ) : __( 'On hold: %s', 'auto-mation' ), $text ) );
		} elseif ( 'standby' === $flag ) {
			/* translators: %s: the reason. */
			self::log( $id, '' !== $reason ? sprintf( __( 'Standby: %s', 'auto-mation' ), $reason ) : __( 'Marked standby — would take an earlier slot.', 'auto-mation' ) );
		} else {
			self::log( $id, 'hold' === $was_flag ? __( 'Hold cleared.', 'auto-mation' ) : __( 'Standby cleared.', 'auto-mation' ) );
		}

		$invoices = array();
		if ( 'hold' === $flag && ( 'hold' !== $was_flag || $until !== $was_until ) ) {
			$invoices = self::set_invoice_due( (int) $id, self::hold_due( $until ) );
		}
		return array( 'job' => AMAT_Job_Model::find( (int) $id ), 'invoices' => $invoices );
	}

	/* --------------------------------------------------------------------- */
	/* Invoice due dates (Nick, 2026-09-30)                                  */
	/* --------------------------------------------------------------------- */

	/**
	 * How long an invoice runs when nothing more specific sets its due date:
	 * when it starts on an unbooked job, and after a hold's estimated date.
	 *
	 * @var int
	 */
	const INVOICE_TERMS_DAYS = 30;

	/**
	 * The last day of a job's appointment (its end, else its start), Y-m-d, or ''.
	 *
	 * @param array<string,mixed> $job Job row.
	 * @return string
	 */
	public static function last_day( array $job ) {
		$end = self::day_part( (string) ( $job['scheduled_end'] ?? '' ) );
		return '' !== $end ? $end : self::day_part( (string) ( $job['scheduled_start'] ?? '' ) );
	}

	/**
	 * A hold's due date: 30 days past its estimated date, or from today.
	 *
	 * @param string $until Estimated date, Y-m-d, or ''.
	 * @return string Y-m-d.
	 */
	public static function hold_due( $until ) {
		$from = '' !== (string) $until ? (string) $until : current_time( 'Y-m-d' );
		return gmdate( 'Y-m-d', strtotime( $from . ' +' . self::INVOICE_TERMS_DAYS . ' days' ) );
	}

	/**
	 * The due date a new invoice on this job starts with: the hold's rule while on
	 * hold, the appointment's last day once one is booked, else 30 days out.
	 *
	 * @param array<string,mixed> $job   Job row.
	 * @param string              $issue The invoice's issue date, Y-m-d.
	 * @return string Y-m-d.
	 */
	public static function starting_due( array $job, $issue ) {
		if ( ! empty( $job['on_hold'] ) ) {
			return self::hold_due( self::day_part( (string) ( $job['hold_until'] ?? '' ) ) );
		}
		$last = self::last_day( $job );
		if ( '' !== $last ) {
			return $last;
		}
		return gmdate( 'Y-m-d', strtotime( $issue . ' +' . self::INVOICE_TERMS_DAYS . ' days' ) );
	}

	/**
	 * Give a just-created invoice its starting due date.
	 *
	 * @param int $invoice_id Invoice id.
	 * @return bool Whether the due date changed.
	 */
	public static function start_invoice_due( $invoice_id ) {
		$inv = AMAT_Invoice_Model::find( (int) $invoice_id );
		$job = $inv && ! empty( $inv['job_id'] ) ? AMAT_Job_Model::find( (int) $inv['job_id'] ) : null;
		if ( ! $job ) {
			return false;
		}
		$issue = self::day_part( (string) $inv['issue_date'] );
		return self::move_due( $inv, self::starting_due( $job, '' !== $issue ? $issue : current_time( 'Y-m-d' ) ) );
	}

	/**
	 * The appointment was booked or moved: open invoices fall due on its last
	 * day - unless the job is on hold, when the hold's rule stands.
	 *
	 * @param int $job_id Job id.
	 * @return int[] Invoices whose due date moved.
	 */
	public static function schedule_changed( $job_id ) {
		$job = AMAT_Job_Model::find( (int) $job_id );
		if ( ! $job || ! empty( $job['on_hold'] ) || '' === self::last_day( $job ) ) {
			return array();
		}
		return self::set_invoice_due( (int) $job_id, self::last_day( $job ) );
	}

	/**
	 * Move every open invoice on a job to a due date. Paid, overpaid and void
	 * invoices are never touched, and none falls due before it was issued (Wave
	 * refuses that too).
	 *
	 * @param int    $job_id Job id.
	 * @param string $date   Y-m-d.
	 * @return int[] Invoices whose due date moved.
	 */
	public static function set_invoice_due( $job_id, $date ) {
		$moved = array();
		foreach ( AMAT_Invoice_Model::all( array( 'job_id' => (int) $job_id ) ) as $inv ) {
			if ( self::move_due( $inv, $date ) ) {
				$moved[] = (int) $inv['id'];
			}
		}
		if ( $moved ) {
			/* translators: %s: the new due date. */
			self::log( $job_id, sprintf( __( 'Invoice due date moved to %s.', 'auto-mation' ), self::short_date( $date ) ), array( 'invoices' => $moved, 'due' => $date ) );
		}
		return $moved;
	}

	/**
	 * Set one invoice's due date, if it is open and the date actually changes.
	 *
	 * @param array<string,mixed> $inv  Invoice row.
	 * @param string              $date Y-m-d.
	 * @return bool
	 */
	private static function move_due( array $inv, $date ) {
		if ( in_array( (string) $inv['status'], array( 'paid', 'overpaid', 'void' ), true ) ) {
			return false;
		}
		$issue = self::day_part( (string) $inv['issue_date'] );
		if ( '' !== $issue && $date < $issue ) {
			$date = $issue;
		}
		if ( $date === self::day_part( (string) $inv['due_date'] ) ) {
			return false;
		}
		AMAT_Invoice_Model::update( (int) $inv['id'], array( 'due_date' => $date ) );
		return true;
	}

	/**
	 * The Y-m-d part of a stored date or datetime, or '' when unset.
	 *
	 * @param string $value Stored value.
	 * @return string
	 */
	private static function day_part( $value ) {
		$value = substr( trim( (string) $value ), 0, 10 );
		return preg_match( '/^\d{4}-\d{2}-\d{2}$/', $value ) && '0000-00-00' !== $value ? $value : '';
	}

	/**
	 * "Oct 2" for a Y-m-d.
	 *
	 * @param string $date Y-m-d.
	 * @return string
	 */
	public static function short_date( $date ) {
		$dt = self::parse_when( (string) $date . ' 00:00' );
		return $dt ? $dt->format( 'M j' ) : (string) $date;
	}

	/**
	 * Give a job to a technician (one per job), or back to unassigned with 0.
	 * Logged. A tech who is off, booked or outside their hours then is warned
	 * about, not refused - the owner decides.
	 *
	 * @param int $id   Job id.
	 * @param int $tech A technician's user id, or 0.
	 * @return array{warnings:string[]}|WP_Error
	 */
	public static function assign( $id, $tech ) {
		$job = AMAT_Job_Model::find( (int) $id );
		if ( ! $job ) {
			return new WP_Error( 'amat_job_missing', __( 'That job no longer exists.', 'auto-mation' ) );
		}
		$tech = (int) $tech;
		if ( $tech && ! AMAT_Technicians::is_tech( $tech ) ) {
			return new WP_Error( 'amat_job_tech', __( 'Only a technician can be assigned a job.', 'auto-mation' ) );
		}
		if ( (int) $job['technician_id'] === $tech ) {
			return array( 'warnings' => array() );
		}

		AMAT_Job_Model::update( (int) $id, array( 'technician_id' => $tech ) );
		self::log(
			(int) $id,
			$tech
				/* translators: %s: the technician. */
				? sprintf( __( 'Assigned to %s.', 'auto-mation' ), AMAT_Technicians::name( $tech ) )
				: __( 'Unassigned.', 'auto-mation' )
		);

		$warnings = array();
		$start    = self::parse_when( (string) $job['scheduled_start'] );
		if ( $tech && $start ) {
			list( $a, $b ) = self::interval( $start, self::parse_when( (string) $job['scheduled_end'] ) );
			$warnings      = AMAT_Technicians::conflicts( $tech, $a, $b, (int) $id );
		}
		return array( 'warnings' => $warnings );
	}

	/**
	 * Close a job with a reason. Its proposed times are withdrawn.
	 *
	 * @param int    $id     Job id.
	 * @param string $reason A close_reasons() key.
	 * @return array<string,mixed>|WP_Error
	 */
	public static function close( $id, $reason ) {
		if ( ! isset( self::close_reasons()[ $reason ] ) ) {
			return new WP_Error( 'amat_job_close', __( 'Choose why the job is closing.', 'auto-mation' ) );
		}
		$job = self::open_job( $id );
		if ( is_wp_error( $job ) ) {
			return $job;
		}
		AMAT_Job_Model::update( (int) $id, array( 'closed_reason' => $reason, 'closed_at' => current_time( 'mysql' ) ) );
		AMAT_Job_Proposal_Model::clear_for_job( (int) $id );
		/* translators: %s: why the job closed. */
		self::log( $id, sprintf( __( 'Closed — %s.', 'auto-mation' ), self::close_reasons()[ $reason ] ), array( 'reason' => $reason ) );
		return AMAT_Job_Model::find( (int) $id );
	}

	/**
	 * Reopen a closed job, at the step it closed on.
	 *
	 * @param int $id Job id.
	 * @return array<string,mixed>|WP_Error
	 */
	public static function reopen( $id ) {
		$job = AMAT_Job_Model::find( (int) $id );
		if ( ! $job ) {
			return self::missing();
		}
		AMAT_Job_Model::update( (int) $id, array( 'closed_reason' => '', 'closed_at' => '' ) );
		self::log( $id, __( 'Reopened.', 'auto-mation' ) );
		return AMAT_Job_Model::find( (int) $id );
	}

	/* --------------------------------------------------------------------- */
	/* Proposed times (Plan > Scheduling)                                    */
	/* --------------------------------------------------------------------- */

	/**
	 * Offer the customer a time. It goes on the calendar as a tentative block
	 * so the slot is not double-booked while they decide.
	 *
	 * Anything it overlaps — another job's appointment or another proposal — is
	 * returned as a warning, but the proposal is still saved: offering the same
	 * slot to two customers can be deliberate.
	 *
	 * @param int    $job_id Job id.
	 * @param string $start  'Y-m-d\TH:i' (a date-time input) or 'Y-m-d H:i[:s]'.
	 * @param string $end    Same, or '' for none.
	 * @return array{proposal:int,conflicts:array<int,string>}|WP_Error
	 */
	public static function propose( $job_id, $start, $end = '' ) {
		$job = self::open_job( $job_id );
		if ( is_wp_error( $job ) ) {
			return $job;
		}
		$from = self::parse_when( $start );
		$to   = '' === trim( (string) $end ) ? null : self::parse_when( $end );
		if ( ! $from || ( '' !== trim( (string) $end ) && ! $to ) ) {
			return new WP_Error( 'amat_proposal_date', __( 'Enter a start date and time for the proposed slot.', 'auto-mation' ) );
		}
		if ( $to && $to < $from ) {
			return new WP_Error( 'amat_proposal_order', __( 'The proposed slot ends before it starts.', 'auto-mation' ) );
		}

		$pid = (int) AMAT_Job_Proposal_Model::create(
			array(
				'job_id'   => (int) $job_id,
				'start_at' => $from->format( 'Y-m-d H:i:s' ),
				'end_at'   => $to ? $to->format( 'Y-m-d H:i:s' ) : '',
			)
		);
		/* translators: %s: the proposed slot. */
		self::log( $job_id, sprintf( __( 'Proposed %s to the customer.', 'auto-mation' ), self::describe_slot( $from, $to ) ) );

		return array(
			'proposal'  => $pid,
			'conflicts' => self::conflicts( $from, $to, (int) $job_id ),
		);
	}

	/**
	 * Withdraw one proposed time.
	 *
	 * @param int $proposal_id Proposal id.
	 * @return true|WP_Error
	 */
	public static function remove_proposal( $proposal_id ) {
		$p = AMAT_Job_Proposal_Model::find( (int) $proposal_id );
		if ( ! $p ) {
			return new WP_Error( 'amat_proposal_missing', __( 'That proposed time no longer exists.', 'auto-mation' ) );
		}
		AMAT_Job_Proposal_Model::delete( (int) $proposal_id );
		/* translators: %s: the withdrawn slot. */
		self::log( (int) $p['job_id'], sprintf( __( 'Withdrew the proposed time %s.', 'auto-mation' ), self::describe_slot( self::parse_when( $p['start_at'] ), self::parse_when( (string) $p['end_at'] ) ) ) );
		return true;
	}

	/**
	 * The customer picked this time: it becomes the appointment, and every other
	 * proposal for the job is cleared.
	 *
	 * @param int $proposal_id Proposal id.
	 * @return array<string,mixed>|WP_Error The updated job.
	 */
	public static function accept_proposal( $proposal_id ) {
		$p = AMAT_Job_Proposal_Model::find( (int) $proposal_id );
		if ( ! $p ) {
			return new WP_Error( 'amat_proposal_missing', __( 'That proposed time no longer exists.', 'auto-mation' ) );
		}
		$job_id = (int) $p['job_id'];
		$job    = self::open_job( $job_id );
		if ( is_wp_error( $job ) ) {
			return $job;
		}
		AMAT_Job_Model::update(
			$job_id,
			array(
				'scheduled_start' => (string) $p['start_at'],
				'scheduled_end'   => (string) $p['end_at'],
			)
		);
		AMAT_Job_Proposal_Model::clear_for_job( $job_id );
		/* translators: %s: the booked slot. */
		self::log( $job_id, sprintf( __( 'Customer picked %s — booked.', 'auto-mation' ), self::describe_slot( self::parse_when( $p['start_at'] ), self::parse_when( (string) $p['end_at'] ) ) ) );
		self::reconcile( $job_id );
		return AMAT_Job_Model::find( $job_id );
	}

	/**
	 * What a slot overlaps: other open jobs' appointments, and other jobs'
	 * proposals. A slot with no end counts as an hour; an all-day appointment
	 * covers its whole days. Slots that only touch end-to-start do not overlap.
	 *
	 * @param DateTimeImmutable      $from    Slot start.
	 * @param DateTimeImmutable|null $to      Slot end, or null.
	 * @param int                    $exclude Job to leave out (the one proposing).
	 * @return array<int,string> Readable descriptions of each clash.
	 */
	public static function conflicts( DateTimeImmutable $from, $to, $exclude = 0 ) {
		list( $a_start, $a_end ) = self::interval( $from, $to );
		$clashes = array();
		$names   = array();

		foreach ( AMAT_Job_Model::all() as $job ) {
			if ( (int) $job['id'] === (int) $exclude || '' !== (string) $job['closed_reason'] ) {
				continue;
			}
			$names[ (int) $job['id'] ] = $job;
			$s = self::parse_when( (string) $job['scheduled_start'] );
			if ( ! $s ) {
				continue;
			}
			list( $b_start, $b_end ) = self::interval( $s, self::parse_when( (string) $job['scheduled_end'] ) );
			if ( $a_start < $b_end && $b_start < $a_end ) {
				/* translators: 1: job name, 2: its booked slot. */
				$clashes[] = sprintf( __( '%1$s is booked %2$s', 'auto-mation' ), self::job_name( $job ), self::describe_slot( $s, self::parse_when( (string) $job['scheduled_end'] ) ) );
			}
		}

		foreach ( AMAT_Job_Proposal_Model::all() as $p ) {
			$jid = (int) $p['job_id'];
			if ( $jid === (int) $exclude || ! isset( $names[ $jid ] ) ) {
				continue; // Its own, or a closed/missing job's.
			}
			$s = self::parse_when( (string) $p['start_at'] );
			if ( ! $s ) {
				continue;
			}
			$e = self::parse_when( (string) $p['end_at'] );
			list( $b_start, $b_end ) = self::interval( $s, $e );
			if ( $a_start < $b_end && $b_start < $a_end ) {
				/* translators: 1: job name, 2: the slot offered to it. */
				$clashes[] = sprintf( __( '%1$s has %2$s proposed', 'auto-mation' ), self::job_name( $names[ $jid ] ), self::describe_slot( $s, $e ) );
			}
		}

		return $clashes;
	}

	/**
	 * Every time that is already spoken for: each open job's appointment and each
	 * proposed time on an open job, as half-open intervals - the same rules
	 * conflicts() warns by, for the portal's open slots (AMAT_Availability).
	 * Each carries the job's technician (DB v22); a proposed time has none yet -
	 * the owner assigns one when confirming it.
	 *
	 * @return array<int,array{job:int,tech:int,start:DateTimeImmutable,end:DateTimeImmutable}>
	 */
	public static function busy_intervals() {
		$busy = array();
		$open = array();
		foreach ( AMAT_Job_Model::all() as $job ) {
			if ( '' !== (string) $job['closed_reason'] ) {
				continue;
			}
			$open[ (int) $job['id'] ] = true;
			$s = self::parse_when( (string) $job['scheduled_start'] );
			if ( $s ) {
				list( $a, $b ) = self::interval( $s, self::parse_when( (string) $job['scheduled_end'] ) );
				$busy[]        = array( 'job' => (int) $job['id'], 'tech' => (int) $job['technician_id'], 'start' => $a, 'end' => $b );
			}
		}
		foreach ( AMAT_Job_Proposal_Model::all() as $p ) {
			$s = self::parse_when( (string) $p['start_at'] );
			if ( ! $s || ! isset( $open[ (int) $p['job_id'] ] ) ) {
				continue;
			}
			list( $a, $b ) = self::interval( $s, self::parse_when( (string) $p['end_at'] ) );
			$busy[]        = array( 'job' => (int) $p['job_id'], 'tech' => 0, 'start' => $a, 'end' => $b );
		}
		return $busy;
	}

	/**
	 * A slot as a half-open interval: no end = one hour; midnight-to-midnight
	 * (a date with no time) = the whole day(s).
	 *
	 * @param DateTimeImmutable      $start Start.
	 * @param DateTimeImmutable|null $end   End, or null.
	 * @return array{0:DateTimeImmutable,1:DateTimeImmutable}
	 */
	private static function interval( DateTimeImmutable $start, $end ) {
		$all_day = '00:00' === $start->format( 'H:i' ) && ( ! $end || '00:00' === $end->format( 'H:i' ) );
		if ( $all_day ) {
			$last = $end && $end > $start ? $end : $start;
			return array( $start, $last->modify( '+1 day' ) );
		}
		if ( ! $end || $end <= $start ) {
			return array( $start, $start->modify( '+1 hour' ) );
		}
		return array( $start, $end );
	}

	/**
	 * "Thu Oct 8, 9:00 AM–11:00 AM", for notices and the log.
	 *
	 * @param DateTimeImmutable|null $start Start.
	 * @param DateTimeImmutable|null $end   End.
	 * @return string
	 */
	public static function describe_slot( $start, $end ) {
		if ( ! $start ) {
			return '';
		}
		$text = $start->format( 'D M j, g:i A' );
		if ( $end ) {
			$text .= '–' . ( $end->format( 'Y-m-d' ) === $start->format( 'Y-m-d' ) ? $end->format( 'g:i A' ) : $end->format( 'D M j, g:i A' ) );
		}
		return $text;
	}

	/**
	 * A job's name for messages: its label, else its customer.
	 *
	 * @param array<string,mixed> $job Job row.
	 * @return string
	 */
	private static function job_name( array $job ) {
		$c = ! empty( $job['customer_id'] ) ? AMAT_Customer_Model::find( (int) $job['customer_id'] ) : null;
		return AMAT_Job_Model::label( $job, $c ? AMAT_Customer_Model::display_name( $c ) : __( 'A job', 'auto-mation' ) );
	}

	/**
	 * Read a date-time as typed or stored, strictly (Feb 30 is refused), or null.
	 *
	 * @param string $value 'Y-m-d\TH:i', 'Y-m-d H:i', or 'Y-m-d H:i:s'.
	 * @return DateTimeImmutable|null
	 */
	public static function parse_when( $value ) {
		$value = trim( (string) $value );
		if ( ! preg_match( '/^(\d{4}-\d{2}-\d{2})[T ](\d{2}:\d{2})(?::(\d{2}))?$/', $value, $m ) || 0 === strpos( $value, '0000' ) ) {
			return null;
		}
		$text = $m[1] . ' ' . $m[2] . ':' . ( isset( $m[3] ) ? $m[3] : '00' );
		$dt   = DateTimeImmutable::createFromFormat( '!Y-m-d H:i:s', $text );
		return ( $dt && $dt->format( 'Y-m-d H:i:s' ) === $text ) ? $dt : null;
	}

	/* --------------------------------------------------------------------- */
	/* Automatic: forward only, from facts                                   */
	/* --------------------------------------------------------------------- */

	/**
	 * The furthest step the facts about a job already prove it has reached.
	 *
	 *  - a customer            -> at least Vehicle
	 *  - a vehicle             -> at least Research
	 *  - an estimate           -> at least Estimate
	 *  - one sent or viewed    -> at least Approval
	 *  - one given the go-ahead (accepted or approved) -> at least Deposit
	 *  - dates booked          -> at least Scheduling
	 *  - every invoice paid    -> at least Receipt
	 *
	 * Void estimates and invoices count for nothing.
	 *
	 * @param array<string,mixed> $job Job row.
	 * @return string
	 */
	public static function floor_step( array $job ) {
		$floor = self::FIRST_STEP;
		$raise = static function ( $step ) use ( &$floor ) {
			if ( self::position( $step ) > self::position( $floor ) ) {
				$floor = $step;
			}
		};

		if ( ! empty( $job['customer_id'] ) ) {
			$raise( 'vehicle' );
		}
		if ( ! empty( $job['vehicle_id'] ) ) {
			$raise( 'research' );
		}

		$id = (int) ( $job['id'] ?? 0 );
		foreach ( $id ? AMAT_Estimate_Model::all( array( 'job_id' => $id ) ) : array() as $est ) {
			$status = (string) $est['status'];
			if ( 'void' === $status ) {
				continue;
			}
			$raise( 'estimate' );
			if ( in_array( $status, array( 'sent', 'viewed' ), true ) ) {
				$raise( 'approval' );
			}
			if ( AMAT_Estimate_Model::is_go_ahead( $status ) ) {
				$raise( 'deposit' );
			}
		}

		$start = trim( (string) ( $job['scheduled_start'] ?? '' ) );
		if ( '' !== $start && 0 !== strpos( $start, '0000' ) ) {
			$raise( 'scheduling' );
		}

		$invoices = $id ? array_filter(
			AMAT_Invoice_Model::all( array( 'job_id' => $id ) ),
			static function ( $inv ) {
				return 'void' !== $inv['status'];
			}
		) : array();
		if ( $invoices ) {
			$all_paid = true;
			foreach ( $invoices as $inv ) {
				if ( ! in_array( (string) $inv['status'], array( 'paid', 'overpaid' ), true ) ) {
					$all_paid = false;
				}
			}
			if ( $all_paid ) {
				$raise( 'receipt' );
			}
		}

		// A job that needs review moves on by itself no further than Info (Nick,
		// 2026-10-06: a website customer Wave hasn't confirmed stays in Info).
		if ( '' !== (string) ( $job['review_reason'] ?? '' ) && self::position( $floor ) > self::position( self::LAST_INFO_STEP ) ) {
			$floor = self::LAST_INFO_STEP;
		}

		return $floor;
	}

	/**
	 * The last step of Info - as far as a job that needs review moves by itself.
	 *
	 * @var string
	 */
	const LAST_INFO_STEP = 'vehicle';

	/**
	 * Mark a job as needing review, with an internal reason, or clear the mark.
	 * A reason belongs to its source (e.g. 'wave'): clearing with a source clears
	 * only that source's mark; clearing with null (the owner's "Mark reviewed")
	 * clears any. Once clear, the job is reconciled, so the facts carry it on.
	 * Logged only when something changes. Never shown to the customer.
	 *
	 * @param int         $id     Job id.
	 * @param string      $reason Why ('' = clear).
	 * @param string|null $source Who sets/clears it ('core', a provider slug), or null.
	 * @return array<string,mixed>|WP_Error The job as it now stands.
	 */
	public static function set_review( $id, $reason, $source = 'core' ) {
		$job = AMAT_Job_Model::find( (int) $id );
		if ( ! $job ) {
			return self::missing();
		}
		$reason = trim( (string) $reason );
		$had    = (string) ( $job['review_reason'] ?? '' );
		if ( '' === $reason ) {
			if ( '' === $had || ( null !== $source && (string) $job['review_source'] !== $source ) ) {
				return $job; // nothing to clear, or not this source's mark
			}
			AMAT_Job_Model::update( (int) $id, array( 'review_reason' => '', 'review_source' => '' ) );
			self::log( $id, __( 'Review cleared.', 'auto-mation' ), array( 'review' => '' ) );
			self::reconcile( $id );
			return AMAT_Job_Model::find( (int) $id );
		}
		$source = null === $source ? 'core' : sanitize_key( (string) $source );
		if ( $reason === $had && $source === (string) $job['review_source'] ) {
			return $job;
		}
		AMAT_Job_Model::update( (int) $id, array( 'review_reason' => $reason, 'review_source' => $source ) );
		/* translators: %s: why the job needs review. */
		self::log( $id, sprintf( __( 'Needs review: %s', 'auto-mation' ), $reason ), array( 'review' => $reason, 'source' => $source ) );
		return AMAT_Job_Model::find( (int) $id );
	}

	/**
	 * Move a job forward to what the facts prove, if it is behind. Never moves
	 * a job back, and leaves closed jobs alone.
	 *
	 * Called after anything that changes those facts: a job, estimate or
	 * invoice saved from the admin, and a provider's payment read-back.
	 *
	 * @param int $id Job id.
	 * @return string The new step, or '' when nothing changed.
	 */
	public static function reconcile( $id ) {
		$job = AMAT_Job_Model::find( (int) $id );
		if ( ! $job || '' !== (string) ( $job['closed_reason'] ?? '' ) ) {
			return '';
		}
		$current = self::is_step( (string) $job['step'] ) ? (string) $job['step'] : self::FIRST_STEP;
		$floor   = self::floor_step( $job );
		if ( self::position( $floor ) <= self::position( $current ) ) {
			return '';
		}
		AMAT_Job_Model::update( (int) $id, array( 'step' => $floor ) );
		self::log(
			$id,
			sprintf(
				/* translators: 1: old step, 2: new step. */
				__( 'Moved on automatically: %1$s → %2$s.', 'auto-mation' ),
				self::step_label( $current ),
				self::step_label( $floor )
			),
			array( 'from' => $current, 'to' => $floor, 'automatic' => true )
		);
		return $floor;
	}

	/* --------------------------------------------------------------------- */
	/* Helpers                                                               */
	/* --------------------------------------------------------------------- */

	/**
	 * A job that exists and is open, or the error explaining why not.
	 *
	 * @param int $id Job id.
	 * @return array<string,mixed>|WP_Error
	 */
	private static function open_job( $id ) {
		$job = AMAT_Job_Model::find( (int) $id );
		if ( ! $job ) {
			return self::missing();
		}
		if ( '' !== (string) ( $job['closed_reason'] ?? '' ) ) {
			return new WP_Error( 'amat_job_closed', __( 'This job is closed. Reopen it first.', 'auto-mation' ) );
		}
		return $job;
	}

	/**
	 * The "no such job" error.
	 *
	 * @return WP_Error
	 */
	private static function missing() {
		return new WP_Error( 'amat_job_missing', __( 'That job no longer exists.', 'auto-mation' ) );
	}

	/**
	 * Record a workflow change against the job (the job screen's History).
	 *
	 * @param int                 $id      Job id.
	 * @param string              $message What happened.
	 * @param array<string,mixed> $context Extra detail.
	 * @return void
	 */
	private static function log( $id, $message, array $context = array() ) {
		AMAT_Log::info(
			self::LOG_CHANNEL,
			$message,
			array(
				'entity_type' => 'job',
				'entity_id'   => (int) $id,
				'context'     => $context,
			)
		);
	}
}
