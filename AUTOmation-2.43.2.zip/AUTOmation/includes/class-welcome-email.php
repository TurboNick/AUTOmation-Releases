<?php
/**
 * The branded "welcome - choose a password" email, shared by the customer's
 * portal welcome and a new technician's (Nick, 2026-10-06). The layout is
 * AMAT_Branded_Email's (shared with Comms' estimate and invoice emails since
 * 2026-10-09): a greeting, an introduction, a list, a Set my password button,
 * the login and a sign-off. Each caller brings its own words.
 *
 * @package AUTOmation
 */

defined( 'ABSPATH' ) || exit;

/**
 * Sends the welcome email.
 */
class AMAT_Welcome_Email {

	/**
	 * The business's name, as customers know it (Settings -> My Business), else
	 * the site title.
	 *
	 * @return string
	 */
	public static function business_name() {
		return AMAT_Branded_Email::business_name();
	}

	/**
	 * Email a login its welcome. Falls back to WordPress's own set-password email
	 * if no reset key can be made, so they can at least get in.
	 *
	 * @param int                 $user_id The login.
	 * @param array<string,mixed> $words   subject, first (their first name), intro,
	 *                                     items (list of strings), expired (what to do
	 *                                     when the link has run out), closing.
	 * @param callable|null       $link_to Builds the set-password link from ( WP_User,
	 *                                     reset key ). A customer's opens the portal's
	 *                                     branded page (2026-10-13); without one - a
	 *                                     technician's, who works in wp-admin - it is
	 *                                     WordPress's own wp-login.php form.
	 * @return void
	 */
	public static function send( $user_id, array $words, $link_to = null ) {
		$user = get_userdata( (int) $user_id );
		if ( ! $user ) {
			return;
		}
		$key = get_password_reset_key( $user );
		if ( is_wp_error( $key ) ) {
			wp_new_user_notification( (int) $user_id, null, 'user' );
			return;
		}
		$link = is_callable( $link_to )
			? (string) call_user_func( $link_to, $user, $key )
			: network_site_url( 'wp-login.php?action=rp&key=' . $key . '&login=' . rawurlencode( $user->user_login ), 'login' );
		$html = AMAT_Branded_Email::html(
			array(
				'first'   => (string) ( $words['first'] ?? '' ),
				'intro'   => (string) ( $words['intro'] ?? '' ),
				'items'   => (array) ( $words['items'] ?? array() ),
				'lead'    => __( 'To get started, choose a password:', 'auto-mation' ),
				'button'  => __( 'Set my password', 'auto-mation' ),
				'url'     => $link,
				/* translators: %s: their login (their email address). */
				'notes'   => trim( sprintf( __( 'Your login is %s.', 'auto-mation' ), $user->user_login ) . ' ' . (string) ( $words['expired'] ?? '' ) ),
				'closing' => (string) ( $words['closing'] ?? '' ),
			)
		);

		wp_mail( $user->user_email, (string) ( $words['subject'] ?? '' ), $html, array( 'Content-Type: text/html; charset=UTF-8' ) );
	}
}
