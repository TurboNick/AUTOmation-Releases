<?php
/**
 * Scheduling availability: the owner's hours, and the open slots offered to
 * customers.
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * When a customer may ask for an appointment (CLAUDE.md §4: "weekly business
 * hours per weekday, a blackout/time-off date list, and a max-jobs-per-day
 * cap"), kept in one option, plus the open slots those settings leave.
 *
 * A slot is half a day (Nick, 2026-10-01: "Time slots should be a half day.
 * The customer can pick a preferred day and morning or afternoon."): the
 * morning runs from opening to midday, the afternoon from midday to closing, and
 * a day open on only one side of midday has only that half.
 *
 * A slot is open when its day is open and not blacked out, the day is under its
 * cap, it starts far enough ahead (the notice needed) and within the horizon,
 * and nothing already holds it: no open job's appointment and no proposed time
 * overlaps it (AMAT_Job_Workflow::busy_intervals() - the same rules the job
 * screen warns about double-booking by). A proposed time counts: while a
 * customer decides, the slot is theirs.
 *
 * Times are the site's wall clock, as everywhere else in the plugin.
 */
class AMAT_Availability {

	/**
	 * The option holding the settings.
	 *
	 * @var string
	 */
	const OPTION = 'amat_scheduling';

	/**
	 * Weekday keys, Monday first, as PHP's 'D' format lower-cased.
	 *
	 * @var string[]
	 */
	const DAYS = array( 'mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun' );

	/**
	 * The settings, with defaults filled in.
	 *
	 * @return array{hours:array<string,array{open:string,close:string}>,blackouts:string[],midday:string,lead_hours:int,max_per_day:int,horizon_days:int}
	 */
	public static function settings() {
		$stored = get_option( self::OPTION, null );
		if ( ! is_array( $stored ) ) {
			return self::defaults();
		}
		return array_merge( self::defaults(), $stored );
	}

	/**
	 * Monday to Friday, 8 to 5, split at noon; a day's notice; three jobs a day;
	 * a month ahead. A starting point - the owner sets the real ones.
	 *
	 * @return array<string,mixed>
	 */
	public static function defaults() {
		$hours = array();
		foreach ( self::DAYS as $day ) {
			$hours[ $day ] = in_array( $day, array( 'sat', 'sun' ), true )
				? array( 'open' => '', 'close' => '' )
				: array( 'open' => '08:00', 'close' => '17:00' );
		}
		return array(
			'hours'        => $hours,
			'blackouts'    => array(),
			'midday'       => '12:00',
			'lead_hours'   => 24,
			'max_per_day'  => 3,
			'horizon_days' => 30,
		);
	}

	/**
	 * Store the settings, cleaned up: a day whose times cannot be read, or that
	 * closes before it opens, is closed; blackouts keep only real dates, once
	 * each, in order; an unreadable midday is noon; the numbers are held to sane
	 * limits.
	 *
	 * @param array<string,mixed> $raw As posted (blackouts may be one date per line).
	 * @return array<string,mixed> What was stored.
	 */
	public static function save( array $raw ) {
		$hours = self::clean_hours( (array) ( $raw['hours'] ?? array() ) );

		$lines     = is_array( $raw['blackouts'] ?? null ) ? $raw['blackouts'] : preg_split( '/[\s,]+/', (string) ( $raw['blackouts'] ?? '' ) );
		$blackouts = array();
		foreach ( (array) $lines as $line ) {
			$line = trim( (string) $line );
			$dt   = DateTimeImmutable::createFromFormat( '!Y-m-d', $line );
			if ( $dt && $dt->format( 'Y-m-d' ) === $line ) {
				$blackouts[ $line ] = true;
			}
		}
		$blackouts = array_keys( $blackouts );
		sort( $blackouts );

		$settings = array(
			'hours'        => $hours,
			'blackouts'    => $blackouts,
			'midday'       => '' !== self::hhmm( $raw['midday'] ?? '' ) ? self::hhmm( $raw['midday'] ) : '12:00',
			'lead_hours'   => self::clamp( $raw['lead_hours'] ?? 24, 0, 336 ),
			'max_per_day'  => self::clamp( $raw['max_per_day'] ?? 3, 1, 20 ),
			'horizon_days' => self::clamp( $raw['horizon_days'] ?? 30, 1, 180 ),
		);
		update_option( self::OPTION, $settings, false );
		return $settings;
	}

	/**
	 * A week of hours, cleaned up: a day whose times cannot be read, or that
	 * closes before it opens, or that was not sent, is closed. Used for the
	 * business's hours and each technician's alike.
	 *
	 * @param array<string,mixed> $raw By weekday key: array( 'open' => 'HH:MM', 'close' => 'HH:MM' ).
	 * @return array<string,array{open:string,close:string}>
	 */
	public static function clean_hours( array $raw ) {
		$hours = array();
		foreach ( self::DAYS as $day ) {
			$open          = self::hhmm( $raw[ $day ]['open'] ?? '' );
			$close         = self::hhmm( $raw[ $day ]['close'] ?? '' );
			$hours[ $day ] = ( '' !== $open && '' !== $close && $open < $close )
				? array( 'open' => $open, 'close' => $close )
				: array( 'open' => '', 'close' => '' );
		}
		return $hours;
	}

	/**
	 * The open slots over a run of days, by day. Days with none are left out.
	 *
	 * @param string                 $from Y-m-d, the first day.
	 * @param int                    $days How many days.
	 * @param DateTimeImmutable|null $now  "Now" (the site's time by default).
	 * @return array<string,array<int,array{start:string,end:string,part:string,name:string,times:string,label:string}>>
	 */
	public static function slots( $from, $days, $now = null ) {
		$s       = self::settings();
		$now     = $now ?: new DateTimeImmutable( current_time( 'mysql' ) );
		$earliest = $now->modify( '+' . (int) $s['lead_hours'] . ' hours' );
		$latest  = $now->setTime( 0, 0 )->modify( '+' . ( (int) $s['horizon_days'] + 1 ) . ' days' );
		$day     = DateTimeImmutable::createFromFormat( '!Y-m-d', (string) $from );
		if ( ! $day ) {
			return array();
		}
		$busy  = AMAT_Job_Workflow::busy_intervals();
		$techs = AMAT_Technicians::ids();
		$off   = array();
		foreach ( $techs as $tech ) {
			$off[ $tech ] = AMAT_Time_Off_Model::for_user( $tech, $day->format( 'Y-m-d H:i:s' ), $day->modify( '+' . (int) $days . ' days' )->format( 'Y-m-d H:i:s' ) );
		}
		$out = array();

		for ( $i = 0; $i < (int) $days; $i++, $day = $day->modify( '+1 day' ) ) {
			$date  = $day->format( 'Y-m-d' );
			$hours = $s['hours'][ strtolower( $day->format( 'D' ) ) ] ?? array( 'open' => '', 'close' => '' );
			if ( '' === $hours['open'] || in_array( $date, $s['blackouts'], true ) || $day >= $latest ) {
				continue;
			}

			// The day's cap: each job with an appointment or a proposal that day
			// counts once - against the business, or (with technicians) against
			// each tech, for the jobs assigned to them.
			$day_end  = $day->modify( '+1 day' );
			$jobs     = array();
			$that_day = array();
			foreach ( $busy as $b ) {
				if ( $b['start'] < $day_end && $day < $b['end'] ) {
					$jobs[ $b['job'] ]                   = true;
					$that_day[ $b['tech'] ][ $b['job'] ] = true;
				}
			}
			if ( ! $techs && count( $jobs ) >= (int) $s['max_per_day'] ) {
				continue;
			}

			$open   = new DateTimeImmutable( $date . ' ' . $hours['open'] );
			$close  = new DateTimeImmutable( $date . ' ' . $hours['close'] );
			$midday = new DateTimeImmutable( $date . ' ' . $s['midday'] );
			$halves = array(
				'morning'   => array( __( 'Morning', 'auto-mation' ), $open, min( $midday, $close ) ),
				'afternoon' => array( __( 'Afternoon', 'auto-mation' ), max( $midday, $open ), $close ),
			);
			foreach ( $halves as $part => list( $name, $start, $end ) ) {
				if ( $start >= $end || $start < $earliest ) {
					continue;
				}
				if ( ! $techs ) {
					// One calendar: anything in the half takes it.
					foreach ( $busy as $b ) {
						if ( $start < $b['end'] && $b['start'] < $end ) {
							continue 2;
						}
					}
				} elseif ( self::free_techs( $techs, $start, $end, $busy, $off, $that_day, (int) $s['max_per_day'] ) <= self::unassigned( $busy, $start, $end ) ) {
					continue;
				}
				$times          = $start->format( 'g:i A' ) . '–' . $end->format( 'g:i A' );
				$out[ $date ][] = array(
					'start' => $start->format( 'Y-m-d H:i:s' ),
					'end'   => $end->format( 'Y-m-d H:i:s' ),
					'part'  => $part,
					'name'  => $name,
					'times' => $times,
					/* translators: 1: Morning or Afternoon, 2: its times. */
					'label' => sprintf( __( '%1$s, %2$s', 'auto-mation' ), $name, $times ),
				);
			}
		}
		return $out;
	}

	/**
	 * How many technicians could take a half-day: working all of it (their
	 * hours, inside the business's), not off in it, nothing assigned to them in
	 * it, and under their daily cap.
	 *
	 * @param int[]                            $techs    Technician ids.
	 * @param DateTimeImmutable                $start    The half's start.
	 * @param DateTimeImmutable                $end      Its end.
	 * @param array<int,array<string,mixed>>   $busy     AMAT_Job_Workflow::busy_intervals().
	 * @param array<int,array<int,array>>      $off      Time-off rows by technician.
	 * @param array<int,array<int,bool>>       $that_day Jobs that day, by technician.
	 * @param int                              $cap      Jobs a day, per technician.
	 * @return int
	 */
	private static function free_techs( array $techs, DateTimeImmutable $start, DateTimeImmutable $end, array $busy, array $off, array $that_day, $cap ) {
		$free = 0;
		foreach ( $techs as $tech ) {
			$window = AMAT_Technicians::day_window( $tech, $start->format( 'Y-m-d' ) );
			if ( ! $window || $window[0] > $start || $window[1] < $end || count( $that_day[ $tech ] ?? array() ) >= $cap ) {
				continue;
			}
			foreach ( $off[ $tech ] ?? array() as $o ) {
				if ( $start < new DateTimeImmutable( (string) $o['end_at'] ) && new DateTimeImmutable( (string) $o['start_at'] ) < $end ) {
					continue 2;
				}
			}
			foreach ( $busy as $b ) {
				if ( $tech === $b['tech'] && $start < $b['end'] && $b['start'] < $end ) {
					continue 2;
				}
			}
			++$free;
		}
		return $free;
	}

	/**
	 * Jobs with no technician yet, and proposed times, in a half-day: each will
	 * need a tech, so each uses one of the free ones up.
	 *
	 * @param array<int,array<string,mixed>> $busy  AMAT_Job_Workflow::busy_intervals().
	 * @param DateTimeImmutable              $start The half's start.
	 * @param DateTimeImmutable              $end   Its end.
	 * @return int
	 */
	private static function unassigned( array $busy, DateTimeImmutable $start, DateTimeImmutable $end ) {
		$n = 0;
		foreach ( $busy as $b ) {
			if ( 0 === $b['tech'] && $start < $b['end'] && $b['start'] < $end ) {
				++$n;
			}
		}
		return $n;
	}

	/**
	 * Whether one slot (by its start) is open right now - what a booking must
	 * pass before it is recorded, since the page it came from may be stale.
	 *
	 * @param string                 $start 'Y-m-d H:i:s'.
	 * @param DateTimeImmutable|null $now   "Now" (the site's time by default).
	 * @return array<string,string>|false The slot, or false.
	 */
	public static function is_open( $start, $now = null ) {
		$date = substr( (string) $start, 0, 10 );
		foreach ( self::slots( $date, 1, $now )[ $date ] ?? array() as $slot ) {
			if ( $slot['start'] === (string) $start ) {
				return $slot;
			}
		}
		return false;
	}

	/**
	 * 'HH:MM' (24-hour), or '' when it cannot be read.
	 *
	 * @param mixed $value As typed.
	 * @return string
	 */
	private static function hhmm( $value ) {
		$value = trim( (string) $value );
		return preg_match( '/^([01]\d|2[0-3]):[0-5]\d$/', $value ) ? $value : '';
	}

	/**
	 * An integer held between limits.
	 *
	 * @param mixed $value As typed.
	 * @param int   $min   Lowest.
	 * @param int   $max   Highest.
	 * @return int
	 */
	private static function clamp( $value, $min, $max ) {
		return max( $min, min( $max, (int) $value ) );
	}
}
