/**
 * AUTOmation Jobs calendar: FullCalendar on the Jobs page (v2.16.0).
 *
 * - Desktop opens on the month grid; a phone opens on the list view.
 * - Tapping a day (or a job in a grid view) lists that day's jobs below.
 * - Dragging or resizing a job reschedules it through AMAT_Job_Calendar, with
 *   an Undo; a refusal from the server snaps it back.
 *
 * Times are wall-clock: FullCalendar runs in UTC mode and the server sends and
 * receives the stored time untouched, so nothing shifts with the browser's zone.
 *
 * @package AUTOmation
 */
( function () {
	'use strict';

	var el = document.getElementById( 'amat-job-calendar' );
	if ( ! el || 'undefined' === typeof FullCalendar || 'undefined' === typeof amatCalendar ) {
		return;
	}

	var cfg    = amatCalendar;
	var t      = cfg.i18n;
	var phone  = window.matchMedia( '(max-width: 782px)' ).matches;
	var detail = document.getElementById( 'amat-cal-detail' );
	var notice = document.getElementById( 'amat-cal-notice' );
	var calendar;

	/* ------------------------------------------------------------------ */
	/* Server                                                             */
	/* ------------------------------------------------------------------ */

	function post( data ) {
		var body = new URLSearchParams( data );
		body.append( 'nonce', cfg.nonce );
		return fetch( cfg.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: body } )
			.then( function ( r ) { return r.json(); } );
	}

	/** A calendar Date (UTC fields = wall clock) as the server's string. */
	function fmt( date, allDay ) {
		var iso = date.toISOString();
		return allDay ? iso.slice( 0, 10 ) : iso.slice( 0, 19 );
	}

	/* ------------------------------------------------------------------ */
	/* Notices (reschedule result + Undo)                                  */
	/* ------------------------------------------------------------------ */

	function say( message, type, undo ) {
		notice.textContent = '';
		var box = document.createElement( 'div' );
		box.className = 'notice inline notice-' + ( type || 'success' );
		var p = document.createElement( 'p' );
		p.textContent = message + ' ';
		if ( undo ) {
			var btn = document.createElement( 'button' );
			btn.type = 'button';
			btn.className = 'button button-small';
			btn.textContent = t.undo;
			btn.addEventListener( 'click', function () {
				btn.disabled = true;
				undo();
			} );
			p.appendChild( btn );
		}
		box.appendChild( p );
		notice.appendChild( box );
	}

	function when( date, allDay ) {
		return calendar.formatDate( date, allDay
			? { weekday: 'short', month: 'short', day: 'numeric', timeZone: 'UTC' }
			: { weekday: 'short', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit', timeZone: 'UTC' } );
	}

	/* ------------------------------------------------------------------ */
	/* Reschedule (drag + resize)                                         */
	/* ------------------------------------------------------------------ */

	function reschedule( info, resized ) {
		var ev = info.event;
		// A job stored with no end is drawn an hour long; moving it must not turn
		// that hour into a real end. Resizing IS setting an end.
		var keepEnd = ev.extendedProps.hasEnd || resized;
		var end     = ( keepEnd && ev.end ) ? fmt( ev.end, ev.allDay ) : '';

		post( {
			action: 'amat_calendar_reschedule',
			id: ev.id,
			start: fmt( ev.start, ev.allDay ),
			end: end,
			allDay: ev.allDay ? '1' : '0'
		} ).then( function ( r ) {
			if ( ! r || ! r.success ) {
				info.revert();
				say( ( r && r.data && r.data.message ) ? r.data.message : t.failed, 'error' );
				return;
			}
			var previous = r.data.previous;
			say( t.moved.replace( '%1$s', ev.title ).replace( '%2$s', when( ev.start, ev.allDay ) ), 'success', function () {
				post( {
					action: 'amat_calendar_reschedule',
					id: ev.id,
					start: previous.start,
					end: previous.end,
					allDay: previous.allDay ? '1' : '0'
				} ).then( function ( back ) {
					if ( back && back.success ) {
						say( t.movedBack, 'success' );
					} else {
						say( ( back && back.data && back.data.message ) ? back.data.message : t.failed, 'error' );
					}
					calendar.refetchEvents();
				} ).catch( function () {
					say( t.failed, 'error' );
				} );
			} );
			calendar.refetchEvents(); // Pick up the server's view of the job (e.g. hasEnd).
		} ).catch( function () {
			info.revert();
			say( t.failed, 'error' );
		} );
	}

	/* ------------------------------------------------------------------ */
	/* Day detail below the calendar                                      */
	/* ------------------------------------------------------------------ */

	function showDay( ymd ) {
		var dayStart = new Date( ymd + 'T00:00:00Z' );
		var dayEnd   = new Date( dayStart.getTime() + 86400000 );

		var todays = calendar.getEvents().filter( function ( ev ) {
			var end = ev.end || ev.start;
			return ev.start < dayEnd && ( end > dayStart || ev.start >= dayStart );
		} ).sort( function ( a, b ) {
			return a.start - b.start;
		} );

		detail.textContent = '';
		var h = document.createElement( 'h2' );
		h.textContent = calendar.formatDate( dayStart, { weekday: 'long', month: 'long', day: 'numeric', timeZone: 'UTC' } );
		detail.appendChild( h );

		if ( ! todays.length ) {
			var empty = document.createElement( 'p' );
			empty.className = 'description';
			empty.textContent = t.nothing;
			detail.appendChild( empty );
			return;
		}

		todays.forEach( function ( ev ) {
			var p    = ev.extendedProps;
			var item = document.createElement( 'div' );
			item.className = 'amat-cal-item amat-cal-stage-' + p.stage + ( p.proposal ? ' amat-cal-proposed' : '' );

			var line = document.createElement( 'div' );
			line.className = 'amat-cal-item-when';
			line.textContent = ev.allDay
				? t.allDay
				: calendar.formatRange( ev.start, ev.end || ev.start, { hour: 'numeric', minute: '2-digit', timeZone: 'UTC' } );
			var pill = document.createElement( 'span' );
			pill.className = 'amat-stage-pill amat-stage-' + p.stage;
			pill.textContent = p.stepLabel;
			line.appendChild( document.createTextNode( ' ' ) );
			line.appendChild( pill );
			if ( p.holdReason ) {
				var hold = document.createElement( 'span' );
				hold.className = 'amat-flag amat-flag-hold';
				hold.textContent = t.onHold.replace( '%s', p.holdReason );
				line.appendChild( document.createTextNode( ' ' ) );
				line.appendChild( hold );
			}
			if ( p.standby ) {
				var sb = document.createElement( 'span' );
				sb.className = 'amat-flag amat-flag-standby';
				sb.textContent = t.standby;
				line.appendChild( document.createTextNode( ' ' ) );
				line.appendChild( sb );
			}
			item.appendChild( line );

			var link = document.createElement( 'a' );
			link.className = 'amat-cal-item-title';
			link.href = ev.url;
			link.textContent = ev.title;
			item.appendChild( link );

			[ p.vehicle, p.service ].forEach( function ( text ) {
				if ( text ) {
					var sub = document.createElement( 'div' );
					sub.className = 'amat-cal-item-sub';
					sub.textContent = text;
					item.appendChild( sub );
				}
			} );
			detail.appendChild( item );
		} );
	}

	/* ------------------------------------------------------------------ */
	/* The calendar                                                       */
	/* ------------------------------------------------------------------ */

	calendar = new FullCalendar.Calendar( el, {
		timeZone: 'UTC',
		now: cfg.now,
		initialDate: cfg.initialDate,
		initialView: phone ? 'listMonth' : 'dayGridMonth',
		headerToolbar: {
			left: 'prev,next today',
			center: 'title',
			right: phone ? 'listMonth,dayGridMonth' : 'dayGridMonth,timeGridWeek,timeGridDay,listMonth'
		},
		buttonText: { today: t.today, month: t.month, week: t.week, day: t.day, list: t.list },
		firstDay: 0,
		height: 'auto',
		dayMaxEvents: 4,
		nowIndicator: true,
		slotMinTime: '06:00:00',
		slotMaxTime: '21:00:00',
		eventTimeFormat: { hour: 'numeric', minute: '2-digit', meridiem: 'short' },
		editable: true,
		longPressDelay: 400,

		events: function ( info, ok, fail ) {
			post( { action: 'amat_calendar_events', start: info.startStr.slice( 0, 10 ), end: info.endStr.slice( 0, 10 ) } )
				.then( function ( r ) {
					if ( r && r.success ) {
						ok( r.data );
					} else {
						say( t.loadFail, 'error' );
						fail( new Error( 'feed refused' ) );
					}
				} )
				.catch( function ( e ) {
					say( t.loadFail, 'error' );
					fail( e );
				} );
		},

		// In a list view the list already is the day detail, so the panel below
		// would only say "tap a day" to someone who cannot. Hide it there.
		datesSet: function ( info ) {
			detail.hidden = 0 === info.view.type.indexOf( 'list' );
		},

		eventDidMount: function ( info ) {
			var p = info.event.extendedProps;
			info.el.title = [ p.stepLabel, p.holdReason ? t.onHold.replace( '%s', p.holdReason ) : '', p.vehicle, p.service ].filter( Boolean ).join( ' · ' );
		},

		dateClick: function ( info ) {
			showDay( info.dateStr.slice( 0, 10 ) );
		},

		eventClick: function ( info ) {
			// In the list view the list IS the detail: a tap opens the job. In a
			// grid, a tap lists that day below (each entry links to its job).
			if ( 0 === info.view.type.indexOf( 'list' ) ) {
				return;
			}
			info.jsEvent.preventDefault();
			showDay( fmt( info.event.start, true ) );
		},

		eventDrop: function ( info ) {
			reschedule( info, false );
		},
		eventResize: function ( info ) {
			reschedule( info, true );
		}
	} );

	calendar.render();
}() );
