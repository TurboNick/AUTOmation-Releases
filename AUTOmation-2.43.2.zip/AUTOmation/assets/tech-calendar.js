/**
 * AUTOmation: a technician's calendar (Jobs > Technicians > a tech).
 *
 * - Their working hours are shaded as business hours; their time off and the
 *   jobs assigned to them come from AMAT_Technicians_Page::events().
 * - Drag across days (press and hold on a phone) to add time off, with an
 *   optional note; tap time off to remove it. Jobs link to the job.
 *
 * Times are wall-clock: FullCalendar runs in UTC mode, as on the Jobs calendar.
 *
 * @package AUTOmation
 */
( function () {
	'use strict';

	var el = document.getElementById( 'amat-tech-calendar' );
	if ( ! el || 'undefined' === typeof FullCalendar || 'undefined' === typeof amatTechCalendar ) {
		return;
	}

	var cfg    = amatTechCalendar;
	var t      = cfg.i18n;
	var notice = document.getElementById( 'amat-tech-notice' );
	var phone  = window.matchMedia( '(max-width: 782px)' ).matches;
	var calendar;

	function post( action, data ) {
		var body = new URLSearchParams( data );
		body.append( 'action', action );
		body.append( 'nonce', cfg.nonce );
		return fetch( cfg.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: body } )
			.then( function ( r ) { return r.json(); } );
	}

	function say( message, type ) {
		notice.textContent = '';
		var box = document.createElement( 'div' );
		box.className = 'notice inline notice-' + ( type || 'success' );
		var p = document.createElement( 'p' );
		p.textContent = message;
		box.appendChild( p );
		notice.appendChild( box );
	}

	/** A calendar Date (UTC fields = wall clock) as the server's string. */
	function fmt( date, allDay ) {
		var iso = date.toISOString();
		return allDay ? iso.slice( 0, 10 ) : iso.slice( 0, 16 ).replace( 'T', ' ' );
	}

	/** The last day of an all-day range (FullCalendar's end is exclusive). */
	function lastDay( end ) {
		var d = new Date( end.getTime() );
		d.setUTCDate( d.getUTCDate() - 1 );
		return d;
	}

	calendar = new FullCalendar.Calendar( el, {
		timeZone: 'UTC',
		now: cfg.now,
		initialView: 'dayGridMonth',
		height: 'auto',
		fixedWeekCount: false,
		headerToolbar: { left: 'prev,next today', center: 'title', right: phone ? 'dayGridMonth,timeGridDay' : 'dayGridMonth,timeGridWeek' },
		buttonText: { today: t.today, month: t.month, week: t.week, day: t.day },
		businessHours: cfg.hours,
		selectable: true,
		selectMirror: true,
		longPressDelay: 400,
		eventDisplay: 'block',
		events: function ( info, success, failure ) {
			post( 'amat_tech_events', { tech: cfg.tech, start: info.startStr.slice( 0, 10 ), end: info.endStr.slice( 0, 10 ) } )
				.then( function ( r ) {
					if ( r && r.success ) {
						success( r.data );
					} else {
						failure( new Error( 'load' ) );
					}
				} )
				.catch( failure );
		},
		select: function ( info ) {
			var note = window.prompt( t.notePrompt, '' );
			calendar.unselect();
			if ( null === note ) {
				return; // cancelled
			}
			var end = info.allDay ? fmt( lastDay( info.end ), true ) : fmt( info.end, false );
			post( 'amat_tech_add_off', { tech: cfg.tech, start: fmt( info.start, info.allDay ), end: end, note: note } )
				.then( function ( r ) {
					if ( r && r.success ) {
						say( t.added );
						calendar.refetchEvents();
					} else {
						say( ( r && r.data && r.data.message ) || t.failed, 'error' );
					}
				} )
				.catch( function () { say( t.failed, 'error' ); } );
		},
		eventClick: function ( info ) {
			var off = info.event.extendedProps.off;
			if ( ! off ) {
				return; // a job: its link opens it
			}
			info.jsEvent.preventDefault();
			var when = calendar.formatDate( info.event.start, { month: 'short', day: 'numeric', timeZone: 'UTC' } );
			if ( ! window.confirm( t.removeOff.replace( '%s', when ) ) ) {
				return;
			}
			post( 'amat_tech_remove_off', { id: off } )
				.then( function ( r ) {
					if ( r && r.success ) {
						say( t.removed );
						calendar.refetchEvents();
					} else {
						say( ( r && r.data && r.data.message ) || t.failed, 'error' );
					}
				} )
				.catch( function () { say( t.failed, 'error' ); } );
		},
	} );

	calendar.render();
}() );
