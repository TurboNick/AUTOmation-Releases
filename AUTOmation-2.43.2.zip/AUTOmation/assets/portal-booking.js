/**
 * AUTOmation portal: pick a time on a calendar (the request form and the
 * portal's Book page).
 *
 * The server renders every open time as a radio button - that is what the form
 * posts, and what a browser without JavaScript chooses from - and hands the same
 * times over in the picker's data-slots. This draws them on FullCalendar:
 *
 * - the month marks the days with openings; tapping one offers its Morning and
 *   Afternoon (a slot is half a day - AMAT_Availability);
 * - the week (three days on a phone) shows the same halves as blocks to tap.
 *
 * It opens on the month: a customer picks a day, then a half. Picking one ticks
 * its box; the customer is proposing it, and the owner confirms.
 *
 * Times are wall-clock: FullCalendar runs in UTC mode and the server's times go
 * in untouched, as on the admin calendar (assets/job-calendar.js).
 *
 * @package AUTOmation
 */
( function () {
	'use strict';

	if ( 'undefined' === typeof FullCalendar ) {
		return;
	}

	document.querySelectorAll( '.amat-slot-picker' ).forEach( function ( picker ) {
		var cfg;
		try {
			cfg = JSON.parse( picker.getAttribute( 'data-slots' ) || '' );
		} catch ( e ) {
			return;
		}
		if ( ! cfg || ! cfg.slots || ! cfg.slots.length ) {
			return;
		}

		var t       = cfg.i18n;
		var phone   = window.matchMedia( '(max-width: 700px)' ).matches;
		var dayList = picker.querySelector( '.amat-slot-daylist' );
		var chosen  = picker.querySelector( '.amat-slot-chosen' );
		var byDay   = {};
		var chosenStarts = [];
		var pickedDay    = '';
		var calendar;

		cfg.slots.forEach( function ( slot ) {
			var day = slot.start.slice( 0, 10 );
			( byDay[ day ] = byDay[ day ] || [] ).push( slot );
		} );

		var days  = Object.keys( byDay ).sort();
		var first = days[ 0 ];
		var last  = days[ days.length - 1 ];
		var times = cfg.slots.map( function ( s ) { return s.start.slice( 11, 16 ); } ).sort();
		var ends  = cfg.slots.map( function ( s ) { return s.end.slice( 11, 16 ); } ).sort();

		function boxFor( start ) {
			return picker.querySelector( 'input[name="slot[]"][value="' + start.replace( 'T', ' ' ) + '"]' );
		}

		function dayLabel( ymd ) {
			return calendar.formatDate( ymd + 'T00:00:00Z', { weekday: 'short', month: 'short', day: 'numeric', timeZone: 'UTC' } );
		}

		function describe( start ) {
			var slot = cfg.slots.filter( function ( s ) { return s.start === start; } )[ 0 ];
			return dayLabel( start.slice( 0, 10 ) ) + ' \u00b7 ' + ( slot.name ? slot.name + ' (' + slot.times + ')' : slot.label );
		}

		/* ---------------------------------------------------------------- */
		/* Choosing - up to cfg.max times, in the order picked               */
		/* ---------------------------------------------------------------- */

		function refresh( full ) {
			calendar.getEvents().forEach( function ( ev ) {
				ev.setProp( 'classNames', chosenStarts.indexOf( ev.id ) > -1 ? [ 'amat-open-slot', 'is-chosen' ] : [ 'amat-open-slot' ] );
			} );
			dayList.querySelectorAll( 'button' ).forEach( function ( b ) {
				b.setAttribute( 'aria-pressed', chosenStarts.indexOf( b.getAttribute( 'data-start' ) ) > -1 ? 'true' : 'false' );
			} );

			chosen.textContent = '';
			if ( ! chosenStarts.length ) {
				return;
			}
			var head = document.createElement( 'p' );
			head.textContent = t.chosen;
			chosen.appendChild( head );

			var list = document.createElement( 'ol' );
			chosenStarts.forEach( function ( start, i ) {
				var li  = document.createElement( 'li' );
				var tag = document.createElement( 'span' );
				tag.className   = 'amat-slot-rank';
				tag.textContent = 0 === i ? t.first : t.second;
				li.appendChild( tag );
				li.appendChild( document.createTextNode( ' ' + describe( start ) + ' ' ) );
				var remove = document.createElement( 'button' );
				remove.type        = 'button';
				remove.className   = 'amat-link-button';
				remove.textContent = t.change;
				remove.addEventListener( 'click', function () {
					choose( start );
				} );
				li.appendChild( remove );
				list.appendChild( li );
			} );
			chosen.appendChild( list );

			if ( full ) {
				var note = document.createElement( 'p' );
				note.className   = 'amat-slot-full';
				note.textContent = t.full;
				chosen.appendChild( note );
			}
		}

		/** Pick a time, or un-pick one already picked. */
		function choose( start ) {
			var at = chosenStarts.indexOf( start );
			if ( at > -1 ) {
				chosenStarts.splice( at, 1 );
			} else if ( chosenStarts.length >= ( cfg.max || 1 ) ) {
				refresh( true );
				return;
			} else {
				chosenStarts.push( start );
			}
			picker.querySelectorAll( 'input[name="slot[]"]' ).forEach( function ( box ) {
				box.checked = chosenStarts.indexOf( box.value.replace( ' ', 'T' ) ) > -1;
			} );
			refresh( false );
		}

		/** The month's "tap a day": its open times, listed below the calendar. */
		function showDay( ymd ) {
			pickedDay = ymd;
			picker.querySelectorAll( '.amat-day-picked' ).forEach( function ( c ) { c.classList.remove( 'amat-day-picked' ); } );
			var cell = picker.querySelector( '.fc-daygrid-day[data-date="' + ymd + '"]' );
			if ( cell ) {
				cell.classList.add( 'amat-day-picked' );
			}

			dayList.textContent = '';
			var h = document.createElement( 'h4' );
			h.textContent = dayLabel( ymd );
			dayList.appendChild( h );

			if ( ! byDay[ ymd ] ) {
				var none = document.createElement( 'p' );
				none.textContent = t.none;
				dayList.appendChild( none );
				return;
			}
			var wrap = document.createElement( 'div' );
			wrap.className = 'amat-slot-times';
			byDay[ ymd ].forEach( function ( slot ) {
				var b = document.createElement( 'button' );
				b.type        = 'button';
				b.className   = 'amat-slot-time';
				var name      = document.createElement( 'span' );
				name.className   = 'amat-slot-time-name';
				name.textContent = slot.name || slot.label;
				b.appendChild( name );
				if ( slot.times ) {
					var when = document.createElement( 'span' );
					when.className   = 'amat-slot-time-hours';
					when.textContent = slot.times;
					b.appendChild( when );
				}
				b.setAttribute( 'data-start', slot.start );
				b.setAttribute( 'aria-pressed', chosenStarts.indexOf( slot.start ) > -1 ? 'true' : 'false' );
				b.addEventListener( 'click', function () {
					choose( slot.start );
				} );
				wrap.appendChild( b );
			} );
			dayList.appendChild( wrap );
		}

		function hint() {
			dayList.textContent = '';
			var p = document.createElement( 'p' );
			p.className   = 'amat-muted';
			p.textContent = t.pick;
			dayList.appendChild( p );
		}

		/* ---------------------------------------------------------------- */
		/* The calendar                                                     */
		/* ---------------------------------------------------------------- */

		var weekView = phone ? 'timeGridThreeDay' : 'timeGridWeek';

		/*
		 * The open times as blocks: in the week views only. The month marks the
		 * days instead (dayCellClassNames) - 80-odd blocks would bury it.
		 */
		var blocks = cfg.slots.map( function ( slot ) {
			return { id: slot.start, start: slot.start, end: slot.end, title: slot.name || t.open, classNames: [ 'amat-open-slot' ] };
		} );

		/*
		 * No paging before the first open day or past the last. (Not FullCalendar's
		 * validRange: that draws the days outside it as blank, headerless columns.)
		 */
		function clampNav( view ) {
			var from = view.currentStart.toISOString().slice( 0, 10 );
			var to   = view.currentEnd.toISOString().slice( 0, 10 ); // exclusive
			var prev = picker.querySelector( '.fc-prev-button' );
			var next = picker.querySelector( '.fc-next-button' );
			if ( prev ) {
				prev.disabled = from <= first;
			}
			if ( next ) {
				next.disabled = to > last;
			}
		}

		function showBlocks( on ) {
			var has = calendar.getEventSources().length > 0;
			if ( on && ! has ) {
				calendar.addEventSource( blocks );
				refresh();
			} else if ( ! on && has ) {
				calendar.removeAllEventSources();
			}
		}

		calendar = new FullCalendar.Calendar( picker.querySelector( '.amat-slot-calendar' ), {
			timeZone: 'UTC',
			initialView: 'dayGridMonth',
			initialDate: first,
			height: 'auto',
			fixedWeekCount: false,
			allDaySlot: false,
			slotMinTime: times[ 0 ] + ':00',
			slotMaxTime: ends[ ends.length - 1 ] + ':00',
			slotDuration: '01:00:00',
			expandRows: true,
			nowIndicator: false,
			headerToolbar: { left: 'prev,next', center: 'title', right: 'dayGridMonth,' + weekView },
			buttonText: { month: t.month, week: t.week },
			views: {
				timeGridThreeDay: { type: 'timeGrid', duration: { days: 3 }, buttonText: t.days3 || t.week },
			},
			dayCellClassNames: function ( arg ) {
				var ymd = arg.date.toISOString().slice( 0, 10 );
				var out = byDay[ ymd ] ? [ 'amat-has-slots' ] : [];
				if ( ymd === pickedDay ) {
					out.push( 'amat-day-picked' );
				}
				return out;
			},
			eventDidMount: function ( arg ) {
				arg.el.setAttribute( 'data-start', arg.event.id );
				arg.el.setAttribute( 'role', 'button' );
				arg.el.setAttribute( 'aria-label', dayLabel( arg.event.id.slice( 0, 10 ) ) + ', ' + ( cfg.slots.filter( function ( s ) { return s.start === arg.event.id; } )[ 0 ] || {} ).label );
			},
			eventClick: function ( arg ) {
				arg.jsEvent.preventDefault();
				choose( arg.event.id );
			},
			dateClick: function ( arg ) {
				if ( 'dayGridMonth' === arg.view.type ) {
					showDay( arg.dateStr.slice( 0, 10 ) );
				}
			},
			datesSet: function ( arg ) {
				showBlocks( 'dayGridMonth' !== arg.view.type );
				clampNav( arg.view );
				if ( 'dayGridMonth' !== arg.view.type ) {
					dayList.textContent = '';
				} else if ( pickedDay ) {
					showDay( pickedDay );
				} else {
					hint();
				}
			},
		} );

		calendar.render();
		picker.classList.add( 'is-calendar' );

		// Times already ticked (the browser restoring the form) carry over.
		picker.querySelectorAll( 'input[name="slot[]"]:checked' ).forEach( function ( box ) {
			if ( chosenStarts.length < ( cfg.max || 1 ) ) {
				chosenStarts.push( box.value.replace( ' ', 'T' ) );
			}
		} );
		if ( chosenStarts.length ) {
			choose( chosenStarts.pop() );
		}
	} );
}() );
