/**
 * My account ([amat_portal], Nick, 2026-10-13): My details, Vehicles and
 * Addresses save without leaving the page.
 *
 *  - Every form marked .amat-account-ajax sends itself in the background. A
 *    refusal marks each bad field with what is wrong and keeps everything
 *    typed; success redraws that section from the server's answer, with the
 *    message at its top. An expired page is given a fresh key and sends again
 *    by itself. (The customer-form rule, CLAUDE.md §10.)
 *  - A vehicle form looks its VIN up as soon as it is whole, filling in year,
 *    make and model - always editable (the request form's lookup).
 *
 * Listeners sit on the document, so a redrawn section works at once. Without
 * this script the forms post the ordinary way and the server redirects back
 * with its message (AMAT_Portal::handle_account()).
 */
( function () {
	'use strict';

	if ( ! window.fetch || ! window.FormData ) {
		return;
	}

	/**
	 * Remove a form's marks and message.
	 *
	 * @param {HTMLFormElement} form The form.
	 */
	function clear( form ) {
		form.querySelectorAll( '.amat-field.is-invalid' ).forEach( function ( field ) {
			field.classList.remove( 'is-invalid' );
			var err = field.querySelector( '.amat-field-error' );
			if ( err ) {
				err.remove();
			}
		} );
		form.querySelectorAll( '[aria-invalid]' ).forEach( function ( input ) {
			input.removeAttribute( 'aria-invalid' );
		} );
		var note = form.querySelector( ':scope > .amat-portal-notice' );
		if ( note ) {
			note.remove();
		}
	}

	/**
	 * A message at the top of an element.
	 *
	 * @param {Element} where The form or section.
	 * @param {string}  text  What to say.
	 * @param {string}  kind  success or error.
	 * @return {HTMLElement}
	 */
	function say( where, text, kind ) {
		var note = document.createElement( 'p' );
		note.className = 'amat-portal-notice is-' + kind;
		note.setAttribute( 'role', 'success' === kind ? 'status' : 'alert' );
		note.setAttribute( 'tabindex', '-1' );
		note.textContent = text;
		var heading = 'SECTION' === where.tagName ? where.querySelector( 'h2' ) : null;
		if ( heading ) {
			heading.insertAdjacentElement( 'afterend', note );
		} else {
			where.insertAdjacentElement( 'afterbegin', note );
		}
		return note;
	}

	/**
	 * Mark each bad field, by name (or data-field for the contact rows).
	 *
	 * @param {HTMLFormElement}        form   The form.
	 * @param {Object<string,string>}  fields Field => what is wrong.
	 * @return {HTMLElement|null} The first one marked.
	 */
	function mark( form, fields ) {
		var first = null;
		Object.keys( fields || {} ).forEach( function ( name ) {
			var input = form.querySelector( '[data-field="' + name + '"]' ) || form.querySelector( '[name="' + name + '"]' );
			var field = input ? input.closest( '.amat-field' ) : null;
			if ( ! field ) {
				return;
			}
			field.classList.add( 'is-invalid' );
			var err = document.createElement( 'span' );
			err.className = 'amat-field-error';
			err.textContent = fields[ name ];
			field.appendChild( err );
			input.setAttribute( 'aria-invalid', 'true' );
			first = first || input;
		} );
		return first;
	}

	/**
	 * Send a form; on success redraw its section.
	 *
	 * @param {HTMLFormElement} form    The form.
	 * @param {boolean}         retried Already sent again with a fresh key.
	 */
	function send( form, retried ) {
		var button = form.querySelector( 'button[type="submit"]' );
		if ( button ) {
			button.disabled = true;
		}
		fetch( form.getAttribute( 'data-submit' ), { method: 'POST', credentials: 'same-origin', body: new FormData( form ) } )
			.then( function ( r ) {
				return r.json();
			} )
			.then( function ( res ) {
				var d = ( res && res.data ) || {};
				if ( res && res.success ) {
					var old = d.section ? document.getElementById( d.section ) : null;
					if ( old && d.html ) {
						var box = document.createElement( 'div' );
						box.innerHTML = d.html;
						var fresh = box.firstElementChild;
						old.replaceWith( fresh );
						var done = say( fresh, d.message, 'success' );
						done.focus( { preventScroll: true } );
						done.scrollIntoView( { behavior: 'smooth', block: 'center' } );
					} else {
						window.location.reload();
					}
					return;
				}
				if ( button ) {
					button.disabled = false;
				}
				var nonce = form.querySelector( 'input[name="_wpnonce"]' );
				if ( d.nonce && ! retried && nonce ) {
					nonce.value = d.nonce; // an old page: a fresh key, and again
					send( form, true );
					return;
				}
				var note = say( form, d.message || 'Something went wrong - please try again.', 'error' );
				var first = mark( form, d.fields );
				( first || note ).scrollIntoView( { behavior: 'smooth', block: 'center' } );
				if ( first ) {
					first.focus( { preventScroll: true } );
				}
			} )
			.catch( function () {
				if ( button ) {
					button.disabled = false;
				}
				say( form, 'We could not send that - check your connection and try again. What you typed is still here.', 'error' ).scrollIntoView( { behavior: 'smooth', block: 'center' } );
			} );
	}

	document.addEventListener( 'submit', function ( e ) {
		var form = e.target;
		if ( ! form || ! form.matches || ! form.matches( 'form.amat-account-ajax[data-submit]' ) ) {
			return;
		}
		e.preventDefault();
		clear( form );
		send( form, false );
	} );

	// Fixing a field clears its mark.
	document.addEventListener( 'input', function ( e ) {
		var field = e.target && e.target.closest ? e.target.closest( '.amat-account-ajax .amat-field.is-invalid' ) : null;
		if ( field ) {
			field.classList.remove( 'is-invalid' );
			var err = field.querySelector( '.amat-field-error' );
			if ( err ) {
				err.remove();
			}
			e.target.removeAttribute( 'aria-invalid' );
		}
	} );

	/* ---- My details: trash a row, add another (Nick, 2026-10-22) -------- */

	// The trash icon is a checkbox: a ticked row is greyed out and goes when the
	// form is saved; ticking again keeps it.
	document.addEventListener( 'change', function ( e ) {
		var box = e.target;
		if ( box && box.matches && box.matches( '.amat-cm-remove input[type="checkbox"]' ) ) {
			var row = box.closest( '.amat-portal-cm' );
			if ( row ) {
				row.classList.toggle( 'is-removed', box.checked );
			}
		}
	} );

	// Add another: a copy of the blank row, numbered after the last, so its
	// trash box and any error name the right row.
	document.addEventListener( 'click', function ( e ) {
		var add = e.target && e.target.closest ? e.target.closest( '.amat-cm-add' ) : null;
		var form = add ? add.closest( 'form' ) : null;
		var list = form ? form.querySelector( '.amat-cm-list' ) : null;
		var tpl = form ? form.querySelector( 'template.amat-cm-template' ) : null;
		if ( ! list || ! tpl ) {
			return;
		}
		e.preventDefault();
		var n = String( list.querySelectorAll( '.amat-portal-cm' ).length );
		var box = document.createElement( 'div' );
		box.innerHTML = tpl.innerHTML.replace( /__N__/g, n );
		var row = box.firstElementChild;
		list.appendChild( row );
		var value = row.querySelector( 'input[name="cm_value[]"]' );
		if ( value ) {
			value.focus();
		}
	} );

	/* ---- VIN -> year, make and model ------------------------------------ */
	var asked = new WeakMap();

	/**
	 * Look a vehicle form's VIN up, once it is whole.
	 *
	 * @param {HTMLInputElement} vin The VIN field.
	 */
	function decode( vin ) {
		var form = vin.form;
		var ymm = form ? form.querySelector( 'input[name="vehicle"]' ) : null;
		if ( ! form || ! ymm || ! form.getAttribute( 'data-vin-decode' ) ) {
			return;
		}
		var value = vin.value.toUpperCase().replace( /[^A-Z0-9]/g, '' );
		vin.value = value;
		if ( 17 !== value.length || asked.get( vin ) === value ) {
			return;
		}
		asked.set( vin, value );
		var status = vin.parentNode.querySelector( '.amat-vin-status' );
		if ( ! status ) {
			status = document.createElement( 'span' );
			status.className = 'amat-vin-status';
			status.setAttribute( 'role', 'status' );
			vin.insertAdjacentElement( 'afterend', status );
		}
		status.className = 'amat-vin-status is-busy';
		status.textContent = 'Looking up the VIN…';

		var body = new URLSearchParams();
		body.append( 'action', 'amat_request_vin' );
		body.append( 'nonce', form.getAttribute( 'data-vin-nonce' ) || '' );
		body.append( 'vin', value );
		fetch( form.getAttribute( 'data-vin-decode' ), { method: 'POST', credentials: 'same-origin', body: body } )
			.then( function ( r ) {
				return r.json();
			} )
			.then( function ( res ) {
				if ( asked.get( vin ) !== value ) {
					return; // another VIN typed since
				}
				if ( res && res.success && res.data && res.data.text ) {
					ymm.value = res.data.text;
					status.className = 'amat-vin-status is-ok';
					status.textContent = 'Found: ' + res.data.text;
				} else {
					status.className = 'amat-vin-status is-error';
					status.textContent = res && res.data && res.data.message ? res.data.message : 'We could not look up that VIN - please type the year, make and model.';
				}
			} )
			.catch( function () {
				status.className = 'amat-vin-status is-error';
				status.textContent = 'We could not look up that VIN just now - please type the year, make and model.';
			} );
	}

	document.addEventListener( 'input', function ( e ) {
		var vin = e.target;
		if ( vin && vin.matches && vin.matches( '.amat-account-ajax input[name="vin"]' ) && vin.value.replace( /[^A-Za-z0-9]/g, '' ).length >= 17 ) {
			decode( vin );
		}
	} );
	document.addEventListener( 'change', function ( e ) {
		if ( e.target && e.target.matches && e.target.matches( '.amat-account-ajax input[name="vin"]' ) ) {
			decode( e.target );
		}
	} );
}() );
