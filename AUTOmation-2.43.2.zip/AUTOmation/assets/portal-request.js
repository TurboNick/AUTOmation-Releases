/**
 * The "Request service" form ([amat_request_service]):
 *
 *  - The VIN is decoded as soon as it is whole (17 characters) or the field is
 *    left, and year/make/model is filled in from it - always editable, because a
 *    decode can be wrong and some vehicles don't decode at all. When it can't,
 *    the form says so and leaves the field to the customer.
 *  - A logged-in customer picks one of their vehicles and addresses; "A different
 *    vehicle…" / "Somewhere else…" shows the fields for a new one, which are
 *    required only while shown.
 *  - The form sends itself in the background (Nick, 2026-10-06: a refusal used
 *    to reload the page and lose every answer). A refusal marks each bad field
 *    with what is wrong and keeps everything typed; the thank-you replaces the
 *    form only once the request is in. An expired page is given a fresh key by
 *    the server and sends again by itself.
 *
 * Without this script the form still works: every field shows, it posts the
 * ordinary way, and the server checks everything (AMAT_Portal::handle_request()).
 */
( function () {
	'use strict';

	/**
	 * The thank-you's "Create your account" (Nick, 2026-10-07): sent in the
	 * background like the request; a refusal marks the field and keeps what was
	 * typed; success says so, with the way to My account (they are logged in).
	 *
	 * @param {Element|null} box The invite the server sent with the thank-you.
	 */
	function wireInvite( box ) {
		var form = box ? box.querySelector( '.amat-account-form' ) : null;
		if ( ! form ) {
			return;
		}
		var button = form.querySelector( 'button[type="submit"]' );
		var note = null;
		form.addEventListener( 'submit', function ( e ) {
			e.preventDefault();
			form.querySelectorAll( '.amat-field.is-invalid' ).forEach( function ( field ) {
				field.classList.remove( 'is-invalid' );
				var err = field.querySelector( '.amat-field-error' );
				if ( err ) {
					err.remove();
				}
			} );
			if ( note ) {
				note.remove();
				note = null;
			}
			button.disabled = true;
			fetch( form.getAttribute( 'data-submit' ), { method: 'POST', credentials: 'same-origin', body: new FormData( form ) } )
				.then( function ( r ) {
					return r.json();
				} )
				.then( function ( res ) {
					var d = ( res && res.data ) || {};
					if ( res && res.success ) {
						var ok = document.createElement( 'p' );
						ok.className = 'amat-portal-notice is-success';
						ok.setAttribute( 'role', 'status' );
						ok.textContent = d.message + ' ';
						var link = document.createElement( 'a' );
						link.href = d.account;
						link.textContent = 'Go to My account';
						ok.appendChild( link );
						box.replaceWith( ok );
						return;
					}
					button.disabled = false;
					note = document.createElement( 'p' );
					note.className = 'amat-portal-notice is-error';
					note.setAttribute( 'role', 'alert' );
					note.textContent = d.message || 'Something went wrong - please try again.';
					form.insertAdjacentElement( 'afterbegin', note );
					Object.keys( d.fields || {} ).forEach( function ( name ) {
						var input = form.querySelector( '[name="' + name + '"]' );
						var field = input ? input.closest( '.amat-field' ) : null;
						if ( field ) {
							field.classList.add( 'is-invalid' );
							var err = document.createElement( 'span' );
							err.className = 'amat-field-error';
							err.textContent = d.fields[ name ];
							field.appendChild( err );
						}
					} );
				} )
				.catch( function () {
					button.disabled = false;
				} );
		} );
	}

	document.querySelectorAll( '.amat-request-form' ).forEach( function ( form ) {
		var vin = form.querySelector( 'input[name="vin"]' );
		var ymm = form.querySelector( 'input[name="vehicle"]' );
		var nonce = form.querySelector( 'input[name="_wpnonce"]' );
		var url = form.getAttribute( 'data-vin-decode' );

		/* ---- Reveal the "new vehicle" / "new address" fields ------------- */
		form.querySelectorAll( 'select[data-reveals]' ).forEach( function ( select ) {
			var box = document.getElementById( select.getAttribute( 'data-reveals' ) );
			if ( ! box ) {
				return;
			}
			var sync = function () {
				var show = 'new' === select.value;
				box.hidden = ! show;
				box.querySelectorAll( '[data-required]' ).forEach( function ( input ) {
					input.required = show;
				} );
			};
			select.addEventListener( 'change', sync );
			sync();
		} );

		/* ---- Send in the background: nothing typed is ever lost ------------ */
		var submitUrl = form.getAttribute( 'data-submit' );
		if ( submitUrl && window.fetch && window.FormData ) {
			var button = form.querySelector( 'button[type="submit"]' );
			var buttonText = button ? button.textContent : '';
			var summary = null;

			var clearMark = function ( field ) {
				field.classList.remove( 'is-invalid' );
				var err = field.querySelector( '.amat-field-error' );
				if ( err ) {
					err.remove();
				}
			};
			var clearAll = function () {
				form.querySelectorAll( '.amat-field.is-invalid' ).forEach( clearMark );
				if ( summary ) {
					summary.remove();
					summary = null;
				}
			};
			var say = function ( text, kind ) {
				summary = document.createElement( 'p' );
				summary.className = 'amat-portal-notice is-' + kind;
				summary.setAttribute( 'role', 'alert' );
				summary.textContent = text;
				form.insertAdjacentElement( 'afterbegin', summary );
			};
			var markFields = function ( fields ) {
				var first = null;
				Object.keys( fields || {} ).forEach( function ( name ) {
					var input = form.querySelector( '[name="' + name + '"]' );
					var field = input ? input.closest( '.amat-field' ) : null;
					if ( ! field ) {
						return;
					}
					field.classList.add( 'is-invalid' );
					var err = document.createElement( 'span' );
					err.className = 'amat-field-error';
					err.textContent = fields[ name ];
					field.appendChild( err );
					input.setAttribute( 'aria-invalid', 'true' );
					first = first || input;
				} );
				return first;
			};
			var busy = function ( on ) {
				if ( button ) {
					button.disabled = on;
					button.textContent = on ? 'Sending…' : buttonText;
				}
			};

			// Fixing a field clears its mark.
			form.addEventListener( 'input', function ( e ) {
				var field = e.target.closest ? e.target.closest( '.amat-field.is-invalid' ) : null;
				if ( field ) {
					clearMark( field );
					e.target.removeAttribute( 'aria-invalid' );
				}
			} );

			var send = function ( retried ) {
				var data = new FormData( form );
				busy( true );
				fetch( submitUrl, { method: 'POST', credentials: 'same-origin', body: data } )
					.then( function ( r ) {
						return r.json();
					} )
					.then( function ( res ) {
						if ( res && res.success ) {
							var done = document.createElement( 'p' );
							done.className = 'amat-portal-notice is-success';
							done.setAttribute( 'role', 'status' );
							done.textContent = res.data.message;
							form.replaceWith( done );
							if ( res.data.invite ) {
								done.insertAdjacentHTML( 'afterend', res.data.invite );
								wireInvite( done.nextElementSibling );
							}
							done.scrollIntoView( { behavior: 'smooth', block: 'center' } );
							return;
						}
						busy( false );
						var d = ( res && res.data ) || {};
						if ( d.nonce && ! retried && nonce ) {
							nonce.value = d.nonce; // an old page: a fresh key, and again
							send( true );
							return;
						}
						say( d.message || 'Something went wrong - please try again.', 'error' );
						var first = markFields( d.fields );
						( first || summary ).scrollIntoView( { behavior: 'smooth', block: 'center' } );
						if ( first ) {
							first.focus( { preventScroll: true } );
						}
					} )
					.catch( function () {
						busy( false );
						say( 'We could not send that - check your connection and try again. Your answers are all still here.', 'error' );
						summary.scrollIntoView( { behavior: 'smooth', block: 'center' } );
					} );
			};

			form.addEventListener( 'submit', function ( e ) {
				e.preventDefault();
				clearAll();
				send( false );
			} );
		}

		/* ---- Someone we already know: ask them to log in first ------------- */
		// Nick, 2026-10-07: catch it before it is a problem. When the phone or
		// email typed belongs to a customer who can log in, the form is put aside
		// and the website is asked to open its login, filled in. If they close it
		// instead, the form comes back with a warning and a way to log in after
		// all. (A theme that has no login panel: the warning shows at once, its
		// Log in going to the portal's own login.) The review hold on the server
		// still catches anyone who sends it regardless.
		var knownUrl = form.getAttribute( 'data-known' );
		var aboutYou = form.querySelector( 'fieldset' );
		if ( knownUrl && nonce && aboutYou && window.fetch ) {
			var loginLink = form.querySelector( '.amat-login-link' );
			var portalUrl = loginLink ? loginLink.getAttribute( 'href' ) : '';
			var checked = {};
			var knownAs = '';
			var warned = null;
			var LOGIN_MESSAGE = 'Please log in to continue service request';

			var lock = function ( on ) {
				form.classList.toggle( 'is-locked', on );
				form.querySelectorAll( 'fieldset, button[type="submit"]' ).forEach( function ( el ) {
					el.disabled = on;
				} );
			};
			var askLogin = function () {
				var ask = new CustomEvent( 'amat:login-wanted', { cancelable: true, detail: { login: knownAs, message: LOGIN_MESSAGE } } );
				return ! document.dispatchEvent( ask ); // true when the site opened its login
			};
			var warn = function () {
				if ( warned ) {
					return;
				}
				warned = document.createElement( 'div' );
				warned.className = 'amat-portal-notice is-warning amat-known-warning';
				warned.setAttribute( 'role', 'alert' );
				var text = document.createElement( 'p' );
				text.textContent = 'This request may not be recorded in your account and could delay service unless you log in.';
				var again = document.createElement( 'a' );
				again.className = 'amat-button amat-known-login';
				again.href = portalUrl || '#';
				again.textContent = 'Log in';
				again.addEventListener( 'click', function ( e ) {
					if ( askLogin() ) {
						e.preventDefault();
					}
				} );
				warned.appendChild( text );
				warned.appendChild( again );
				aboutYou.insertAdjacentElement( 'afterbegin', warned );
			};
			var unwarn = function () {
				if ( warned ) {
					warned.remove();
					warned = null;
				}
			};

			// They closed the website's login without logging in.
			document.addEventListener( 'amat:login-closed', function () {
				if ( form.classList.contains( 'is-locked' ) ) {
					lock( false );
					warn();
					warned.scrollIntoView( { behavior: 'smooth', block: 'center' } );
				}
			} );

			var check = function ( input ) {
				var value = input.value.trim();
				var looksWhole = 'email' === input.name ? /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test( value ) : 10 <= value.replace( /\D/g, '' ).replace( /^1(?=\d{10}$)/, '' ).length;
				if ( ! looksWhole || Object.prototype.hasOwnProperty.call( checked, value ) ) {
					return;
				}
				checked[ value ] = null;
				var body = new URLSearchParams();
				body.append( 'action', 'amat_request_known' );
				body.append( 'nonce', nonce.value );
				body.append( 'value', value );
				fetch( knownUrl, { method: 'POST', credentials: 'same-origin', body: body } )
					.then( function ( r ) {
						return r.json();
					} )
					.then( function ( res ) {
						var known = !! ( res && res.success && res.data && res.data.known );
						checked[ value ] = known;
						if ( input.value.trim() !== value ) {
							return; // typed something else since
						}
						if ( ! known ) {
							if ( knownAs === value ) {
								knownAs = '';
								unwarn();
							}
							return;
						}
						knownAs = value;
						if ( askLogin() ) {
							lock( true );
						} else {
							warn();
						}
					} )
					.catch( function () {
						delete checked[ value ]; // try again next time
					} );
			};

			form.querySelectorAll( 'input[name="phone"], input[name="email"]' ).forEach( function ( input ) {
				var timer = null;
				input.addEventListener( 'input', function () {
					clearTimeout( timer );
					timer = setTimeout( function () {
						check( input );
					}, 600 );
				} );
				input.addEventListener( 'change', function () {
					clearTimeout( timer );
					check( input );
				} );
			} );
		}

		/* ---- VIN -> year, make and model ---------------------------------- */
		if ( ! vin || ! ymm || ! url || ! nonce ) {
			return;
		}
		var status = document.createElement( 'span' );
		status.className = 'amat-vin-status';
		status.setAttribute( 'role', 'status' );
		vin.insertAdjacentElement( 'afterend', status );

		var asked = '';
		var decode = function () {
			var value = vin.value.toUpperCase().replace( /[^A-Z0-9]/g, '' );
			vin.value = value;
			if ( value.length !== 17 || value === asked ) {
				return;
			}
			asked = value;
			status.className = 'amat-vin-status is-busy';
			status.textContent = 'Looking up your VIN…';

			var body = new URLSearchParams();
			body.append( 'action', 'amat_request_vin' );
			body.append( 'nonce', nonce.value );
			body.append( 'vin', value );
			fetch( url, { method: 'POST', credentials: 'same-origin', body: body } )
				.then( function ( r ) {
					return r.json();
				} )
				.then( function ( res ) {
					if ( value !== asked ) {
						return; // they have typed another VIN since
					}
					if ( res && res.success && res.data && res.data.text ) {
						ymm.value = res.data.text;
						status.className = 'amat-vin-status is-ok';
						status.textContent = 'Found: ' + res.data.text;
					} else {
						status.className = 'amat-vin-status is-error';
						status.textContent = res && res.data && res.data.message ? res.data.message : 'We could not look up that VIN - please type the year, make and model.';
					}
				} )
				.catch( function () {
					status.className = 'amat-vin-status is-error';
					status.textContent = 'We could not look up that VIN just now - please type the year, make and model.';
				} );
		};

		vin.addEventListener( 'input', function () {
			if ( vin.value.replace( /[^A-Za-z0-9]/g, '' ).length >= 17 ) {
				decode();
			}
		} );
		vin.addEventListener( 'change', decode );
	} );
}() );
