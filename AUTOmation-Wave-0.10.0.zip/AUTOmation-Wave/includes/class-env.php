<?php
/**
 * Minimal .env reader for secrets that must stay out of the repo and DB.
 *
 * @package AUTOmation_Wave
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Reads key=value pairs from a git-ignored .env file in the plugin root.
 *
 * Per §6 of CLAUDE.md the Wave Full Access Token is stored here, never
 * hardcoded or committed. Values are parsed once and cached for the request.
 * A real environment variable (getenv) takes precedence over the file so the
 * same code works on hosts that inject env vars directly.
 */
class AMAT_Env {

	/**
	 * Parsed key => value pairs from the .env file. Null until first load.
	 *
	 * @var array<string,string>|null
	 */
	private static $cache = null;

	/**
	 * Get a value by key, falling back to a default.
	 *
	 * @param string $key     Variable name, e.g. 'WAVE_API_TOKEN'.
	 * @param string $default Value returned when the key is absent/empty.
	 * @return string
	 */
	public static function get( $key, $default = '' ) {
		// Real environment variables win over the file.
		$env = getenv( $key );
		if ( false !== $env && '' !== $env ) {
			return $env;
		}

		if ( null === self::$cache ) {
			self::$cache = self::load();
		}

		if ( isset( self::$cache[ $key ] ) && '' !== self::$cache[ $key ] ) {
			return self::$cache[ $key ];
		}

		return $default;
	}

	/**
	 * Parse the .env file in the plugin root into an associative array.
	 *
	 * Supports `KEY=value`, optional `export ` prefix, `#` comments, and
	 * single/double quoted values. Intentionally tiny — no interpolation.
	 *
	 * @return array<string,string>
	 */
	private static function load() {
		$path = AMAW_DIR . '.env';
		$vars = array();

		if ( ! is_readable( $path ) ) {
			return $vars;
		}

		$lines = file( $path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES );
		if ( false === $lines ) {
			return $vars;
		}

		foreach ( $lines as $line ) {
			$line = trim( $line );

			if ( '' === $line || str_starts_with( $line, '#' ) ) {
				continue;
			}

			if ( str_starts_with( $line, 'export ' ) ) {
				$line = substr( $line, strlen( 'export ' ) );
			}

			$pos = strpos( $line, '=' );
			if ( false === $pos ) {
				continue;
			}

			$key   = trim( substr( $line, 0, $pos ) );
			$value = trim( substr( $line, $pos + 1 ) );

			// Strip surrounding matching quotes.
			if ( strlen( $value ) >= 2 ) {
				$first = $value[0];
				$last  = $value[ strlen( $value ) - 1 ];
				if ( ( '"' === $first && '"' === $last ) || ( "'" === $first && "'" === $last ) ) {
					$value = substr( $value, 1, -1 );
				}
			}

			if ( '' !== $key ) {
				$vars[ $key ] = $value;
			}
		}

		return $vars;
	}
}
