<?php
/**
 * Plugin Name:       AUTOmation for Wave
 * Plugin URI:        https://mrgind.com/
 * Update URI:        https://raw.githubusercontent.com/TurboNick/AUTOmation-Releases/main/automation-wave.json
 * Description:       Wave (waveapps) integration for the AUTOmation plugin: sync customers, push estimates/invoices, and read payment status back. Requires the AUTOmation plugin.
 * Version:           0.10.0
 * Requires at least: 7.0
 * Requires PHP:      8.2
 * Author:            Nick G
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       auto-mation
 *
 * @package AUTOmation_Wave
 */

// Abort if this file is called directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Plugin version.
 */
define( 'AMAW_VERSION', '0.10.0' );

/**
 * Absolute path to this plugin's directory (with trailing slash). class-env.php
 * reads the git-ignored .env (WAVE_API_TOKEN) from here.
 */
define( 'AMAW_DIR', plugin_dir_path( __FILE__ ) );

/**
 * This plugin's main file, for update checks and (de)activation hooks.
 */
define( 'AMAW_FILE', __FILE__ );

/**
 * URL to this plugin's directory (with trailing slash).
 */
define( 'AMAW_URL', plugin_dir_url( __FILE__ ) );

/**
 * Autoloader for this plugin's classes.
 *
 * The Wave integration classes kept their original AMAT_Wave_* / AMAT_Env names
 * when they moved out of core (avoids a churny rename + keeps the option/transient
 * keys and hook names stable). Core's own autoloader searches core's directories
 * and simply misses these, so this loader picks them up from here. Maps e.g.
 * AMAT_Wave_Client -> includes/class-wave-client.php and AMAT_Env -> includes/class-env.php.
 *
 * @param string $class Fully-qualified class name being loaded.
 * @return void
 */
function amaw_autoload( $class ) {
	if ( 'AMAT_Env' !== $class && 0 !== strpos( $class, 'AMAT_Wave_' ) ) {
		return;
	}

	// Strip the AMAT_ prefix, lowercase, underscores -> hyphens.
	$slug = strtolower( str_replace( '_', '-', substr( $class, strlen( 'AMAT_' ) ) ) );
	$file = AMAW_DIR . 'includes/class-' . $slug . '.php';

	if ( is_readable( $file ) ) {
		require_once $file;
	}
}
spl_autoload_register( 'amaw_autoload' );

/**
 * Boot the integration once all plugins are loaded.
 *
 * Runs at priority 20 — after AUTOmation's own bootstrap (priority 10) — so the
 * core hooks this listens on already exist. If AUTOmation isn't active, show a
 * notice and bail rather than fatal (the runtime guard; we deliberately omit a
 * `Requires Plugins:` header because its slug matching is unreliable for a
 * non-wordpress.org, locally-installed plugin and could block activation).
 *
 * @return void
 */
function amaw_init() {
	if ( ! class_exists( 'AMAT_Admin' ) || ! class_exists( 'AMAT_External_Ref_Model' ) ) {
		add_action( 'admin_notices', 'amaw_dependency_notice' );
		return;
	}

	// Automatic sync + retry: registered in EVERY context, because its cron
	// callbacks fire in a WP-Cron request (which is not is_admin()) and would have
	// no listener otherwise. The lifecycle hooks it also listens on only ever fire
	// from admin save paths, so this is harmless outside admin.
	( new AMAT_Wave_Sync() )->register();

	// Same reasoning: the mass-link runs its batches on WP-Cron, so its callback
	// must be attached outside admin too or a queued batch would never fire.
	( new AMAT_Wave_Mass_Link() )->register();

	// All Wave UI is admin-side; nothing to wire on the front end.
	if ( is_admin() ) {
		// Self-hosted updates, using core's shared updater (this plugin already
		// requires core, so there is no independence lost by sharing it).
		( new AMAT_Updater( AMAW_FILE, AMAT_Updater::manifest_url( 'automation-wave' ), AMAW_VERSION ) )->register();
		( new AMAT_Wave_Provider() )->register();
	}
}
add_action( 'plugins_loaded', 'amaw_init', 20 );

/**
 * Clear this integration's scheduled events on deactivation, so a disabled
 * plugin leaves no orphaned WP-Cron entries behind.
 *
 * @return void
 */
function amaw_deactivate() {
	if ( class_exists( 'AMAT_Wave_Sync' ) ) {
		AMAT_Wave_Sync::unschedule();
	}
	if ( class_exists( 'AMAT_Wave_Mass_Link' ) ) {
		AMAT_Wave_Mass_Link::unschedule();
	}
}
register_deactivation_hook( __FILE__, 'amaw_deactivate' );

/**
 * Admin notice shown when the required AUTOmation plugin isn't active.
 *
 * @return void
 */
function amaw_dependency_notice() {
	if ( ! current_user_can( 'activate_plugins' ) ) {
		return;
	}
	echo '<div class="notice notice-error"><p>'
		. esc_html__( 'AUTOmation for Wave requires the AUTOmation plugin to be installed and active. Wave features are disabled until it is.', 'auto-mation' )
		. '</p></div>';
}
