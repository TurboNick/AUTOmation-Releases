<?php
/**
 * Job model.
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Data access for the jobs table.
 *
 * A job ties a customer + vehicle + location + work together and has many
 * parts orders. Front-end bookings are created as `requested` for the owner
 * to approve (§4 of CLAUDE.md).
 */
class AMAT_Job_Model extends AMAT_Base_Model {

	/**
	 * Allowed job statuses (§4 status vocabulary).
	 *
	 * @var string[]
	 */
	const STATUSES = array( 'requested', 'scheduled', 'in_progress', 'completed', 'invoiced', 'cancelled' );

	/**
	 * {@inheritDoc}
	 */
	protected static function table_slug() {
		return 'jobs';
	}

	/**
	 * {@inheritDoc}
	 */
	protected static function schema() {
		return array(
			'customer_id'      => 'int',
			'vehicle_id'       => 'int',
			'location_id'      => 'int',
			'name'             => 'text',
			'scheduled_start'  => 'datetime',
			'scheduled_end'    => 'datetime',
			'status'           => 'text',
			'description'      => 'textarea',
			'mileage'          => 'int',
			'wave_estimate_id' => 'text',
			'wave_invoice_id'  => 'text',
		);
	}

	/**
	 * Human labels for each status slug, in workflow order.
	 *
	 * @return array<string,string>
	 */
	public static function statuses_labeled() {
		return array(
			'requested'   => __( 'Requested', 'auto-mation' ),
			'scheduled'   => __( 'Scheduled', 'auto-mation' ),
			'in_progress' => __( 'In progress', 'auto-mation' ),
			'completed'   => __( 'Completed', 'auto-mation' ),
			'invoiced'    => __( 'Invoiced', 'auto-mation' ),
			'cancelled'   => __( 'Cancelled', 'auto-mation' ),
		);
	}

	/**
	 * Human label for a status slug (falls back to the slug).
	 *
	 * @param string $status Status slug.
	 * @return string
	 */
	public static function status_label( $status ) {
		$labels = self::statuses_labeled();
		return $labels[ $status ] ?? (string) $status;
	}

	/**
	 * Sanitize, forcing status to the allowed vocabulary.
	 *
	 * @param array<string,mixed> $data Raw input.
	 * @return array<string,mixed>
	 */
	protected static function sanitize( array $data ) {
		$clean = parent::sanitize( $data );
		if ( isset( $clean['status'] ) && ! in_array( $clean['status'], self::STATUSES, true ) ) {
			$clean['status'] = 'requested';
		}
		return $clean;
	}

	/**
	 * The job's display label: its optional Name, else the given fallback
	 * (typically the customer's display name). Shown wherever a job is
	 * referenced — calendar, grid, detail heading, customer Jobs block.
	 *
	 * @param array<string,mixed> $job      Job row.
	 * @param string              $fallback Text to use when the job has no name.
	 * @return string
	 */
	public static function label( array $job, $fallback = '' ) {
		$name = trim( (string) ( $job['name'] ?? '' ) );
		return '' !== $name ? $name : (string) $fallback;
	}

	/**
	 * All jobs for a customer, by schedule.
	 *
	 * @param int $customer_id Customer id.
	 * @return array<int,array<string,mixed>>
	 */
	public static function for_customer( $customer_id ) {
		return self::all( array( 'customer_id' => absint( $customer_id ) ), array( 'orderby' => 'scheduled_start' ) );
	}
}
