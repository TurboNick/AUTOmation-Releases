<?php
/**
 * The send API: everything between "send this" and the connector.
 *
 * @package AUTOmation_Comms
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Orchestrates a send: build the context, render the template, find the
 * recipient, check the dry-run gate, hand off to the active connector, record
 * the result.
 *
 * All of that policy lives here rather than in the connectors so it stays
 * identical for every route. A connector only delivers.
 */
class AMAC_Comms {

	/**
	 * Log channel for core's AMAT_Log. One slug for the plugin; the Logs page
	 * filters by it. (Core's own log docblock anticipates this one — it names
	 * "a customer email that was sent" as a thing the log is for.)
	 */
	const CHANNEL = 'comms';

	/**
	 * Option holding the dry-run flag.
	 */
	const DRY_RUN_OPTION = 'amat_comms_dry_run';

	/**
	 * Whether dry-run mode is on.
	 *
	 * DEFAULTS TO ON, deliberately. A mis-sent Wave push creates a draft you can
	 * delete; a mis-sent message reaches a real customer and cannot be recalled.
	 * So the plugin will not deliver anything until someone turns delivery on
	 * explicitly, having seen the previews. The gate is enforced here, in the one
	 * path every send goes through — not in the UI, and not left to each
	 * connector to remember.
	 *
	 * @return bool
	 */
	public static function is_dry_run() {
		return '1' === (string) get_option( self::DRY_RUN_OPTION, '1' );
	}

	/**
	 * An estimate that has gone to the customer is Sent (only a draft moves - a
	 * decision already made stays), announced, and its job allowed to move on.
	 *
	 * @param int $estimate_id Estimate id.
	 * @return void
	 */
	private static function mark_sent( $estimate_id ) {
		$est = AMAT_Estimate_Model::find( (int) $estimate_id );
		if ( ! $est || 'draft' !== (string) $est['status'] ) {
			return;
		}
		AMAT_Estimate_Model::update( (int) $estimate_id, array( 'status' => 'sent' ) );
		/** This action is documented in core's includes/admin/class-jobs-page.php */
		do_action( 'amat_after_estimate_save', (int) $estimate_id, false );
		if ( (int) $est['job_id'] && class_exists( 'AMAT_Job_Workflow' ) ) {
			AMAT_Job_Workflow::reconcile( (int) $est['job_id'] );
		}
	}

	/**
	 * Where a customer sees their jobs: core's jobs page (the home page since
	 * core 2.40.0), else the portal page on an older core.
	 *
	 * @return string
	 */
	private static function jobs_link() {
		return method_exists( 'AMAT_Portal', 'jobs_url' ) ? AMAT_Portal::jobs_url() : AMAT_Portal::portal_url();
	}

	/**
	 * Render (and optionally send) a message about a core document.
	 *
	 * @param array{
	 *     entity_type:string,
	 *     entity_id:int,
	 *     channel:string,
	 *     message_type?:string,
	 *     recipient?:string,
	 *     preview_only?:bool
	 * } $args Send arguments.
	 * @return array{status:string,message:string,subject?:string,body?:string,recipient?:string,message_id?:int}
	 *         status is 'success', 'error' or 'preview'.
	 */
	public static function send_document( array $args ) {
		$entity_type  = (string) ( $args['entity_type'] ?? '' );
		$entity_id    = (int) ( $args['entity_id'] ?? 0 );
		$channel      = (string) ( $args['channel'] ?? '' );
		$preview_only = ! empty( $args['preview_only'] );

		if ( ! AMAC_Channels::is_valid( $channel ) ) {
			return self::error( __( 'Unknown message channel.', 'auto-mation' ) );
		}

		$context = self::document_context( $entity_type, $entity_id );
		if ( is_wp_error( $context ) ) {
			return self::error( $context->get_error_message() );
		}

		$customer_id = (int) $context['_customer_id'];
		$doc_status  = (string) $context['_status'];
		unset( $context['_customer_id'], $context['_status'] );
		// The link the message delivers. An estimate's is in core's portal:
		// previews and dry runs ask without side effects; a real send asks again
		// below, which may make the customer a login (core). An invoice's is its
		// online view-and-pay page, from whichever provider answers core's neutral
		// amat_invoice_view_url filter - Comms knows no provider.
		// A job's message (an appointment confirmation) links to the customer's
		// bookings in the portal, through the same core helper.
		$is_estimate         = 'estimate' === $entity_type && class_exists( 'AMAT_Portal' );
		$is_job              = 'job' === $entity_type && class_exists( 'AMAT_Portal' );
		$context['doc_link'] = $is_estimate ? AMAT_Portal::estimate_link( $entity_id, false ) : '';
		if ( $is_job ) {
			$context['doc_link'] = AMAT_Portal::customer_link( $customer_id, self::jobs_link(), false );
		}
		if ( 'invoice' === $entity_type ) {
			$context['doc_link'] = self::invoice_link( $entity_id );
		}

		// A void document is a cancelled record, and sending one to a customer is
		// wrong whoever asks. Refused here, in the one path every send takes, and
		// not only in the Send block's UI: a crafted POST, or a future triggered
		// send, never sees that UI. Not even recorded as a dry run.
		if ( 'void' === $doc_status ) {
			return self::error( __( 'This document is void — it cannot be sent.', 'auto-mation' ) );
		}

		// Likewise a confirmation is never sent for a closed job, or one with no
		// appointment to confirm.
		if ( 'closed' === $doc_status ) {
			return self::error( __( 'Not sent: this job is closed.', 'auto-mation' ) );
		}
		if ( 'unbooked' === $doc_status ) {
			return self::error( __( 'Not sent: this job has no appointment booked yet.', 'auto-mation' ) );
		}

		// An invoice email exists to deliver its payment link (Nick, 2026-10-09), so
		// one without a link is never sent - nor recorded, not even as a dry run.
		if ( 'invoice' === $entity_type && '' === $context['doc_link'] ) {
			return self::error( __( "Not sent: this invoice isn't in Wave yet, so there's no payment link - save & push it to Wave first.", 'auto-mation' ) );
		}

		// Message type: the caller's, else the first one defined for this entity.
		$message_type = (string) ( $args['message_type'] ?? '' );
		if ( '' === $message_type ) {
			$types        = AMAC_Templates::types_for_entity( $entity_type );
			$message_type = $types ? $types[0] : '';
		}
		if ( ! AMAC_Templates::is_valid_type( $message_type ) ) {
			return self::error( __( 'No message template applies to this record.', 'auto-mation' ) );
		}

		$rendered = AMAC_Templates::render( $message_type, $channel, $context );

		// Recipient: explicit, else the customer's preferred address for this
		// channel (contact methods are stored in the customer's own priority
		// order, so "first usable" is their stated preference).
		$recipient = trim( (string) ( $args['recipient'] ?? '' ) );
		if ( '' === $recipient ) {
			$recipient = AMAC_Channels::address_for( $customer_id, $channel );
		}

		if ( $preview_only ) {
			return array(
				'status'    => 'preview',
				'message'   => '',
				'subject'   => $rendered['subject'],
				'body'      => $rendered['body'],
				'html'      => (string) ( $rendered['html'] ?? '' ),
				'recipient' => $recipient,
			);
		}

		if ( '' === $recipient ) {
			return self::error(
				AMAC_Channels::EMAIL === $channel
					? __( 'This customer has no email contact method.', 'auto-mation' )
					: __( 'This customer has no contact method that accepts texts. (A "Call Only" number is not textable.)', 'auto-mation' )
			);
		}

		$connector = AMAC_Connector_Registry::active( $channel );
		if ( ! $connector ) {
			return self::error( __( 'No delivery connector is selected for this channel. Choose one in Settings → Comms.', 'auto-mation' ) );
		}
		if ( ! $connector->is_configured() ) {
			$hint = $connector->config_hint();
			return self::error(
				sprintf(
					/* translators: 1: connector label, 2: reason it isn't ready. */
					__( '%1$s is not configured: %2$s', 'auto-mation' ),
					$connector->label(),
					'' !== $hint ? $hint : __( 'check its settings', 'auto-mation' )
				)
			);
		}

		$row = array(
			'channel'      => $channel,
			'connector'    => $connector->slug(),
			'message_type' => $message_type,
			'customer_id'  => $customer_id,
			'entity_type'  => $entity_type,
			'entity_id'    => $entity_id,
			'recipient'    => $recipient,
			'subject'      => $rendered['subject'],
			'body'         => $rendered['body'],
			'external_id'  => '',
		);

		// The dry-run gate. The message is fully rendered and recorded — so the
		// trail shows exactly what would have gone out — but never delivered.
		if ( self::is_dry_run() ) {
			$row['status']  = AMAC_Message_Model::STATUS_DRY_RUN;
			$row['sent_at'] = '';
			$message_id     = (int) AMAC_Message_Model::create( $row );

			AMAT_Log::info(
				self::CHANNEL,
				sprintf(
					/* translators: 1: channel label, 2: recipient. */
					__( 'Dry run: %1$s to %2$s was rendered but not sent.', 'auto-mation' ),
					AMAC_Channels::label( $channel ),
					$recipient
				),
				array(
					'entity_type' => $entity_type,
					'entity_id'   => $entity_id,
					'context'     => array( 'message_type' => $message_type ),
				)
			);

			return array(
				'status'     => 'success',
				'message'    => sprintf(
					/* translators: %s: recipient address. */
					__( 'Dry run — nothing was sent. The message for %s was recorded so you can review it. Turn off dry-run mode in Settings → Comms to send for real.', 'auto-mation' ),
					$recipient
				),
				'subject'    => $rendered['subject'],
				'body'       => $rendered['body'],
				'recipient'  => $recipient,
				'message_id' => $message_id,
			);
		}

		// A real send: the link that makes a login for someone with none.
		if ( $is_estimate || $is_job ) {
			$context['doc_link'] = $is_estimate
				? AMAT_Portal::estimate_link( $entity_id, true )
				: AMAT_Portal::customer_link( $customer_id, self::jobs_link(), true );
			$rendered            = AMAC_Templates::render( $message_type, $channel, $context );
			$row['subject']      = $rendered['subject'];
			$row['body']         = $rendered['body'];
		}

		$result = $connector->send( $recipient, $rendered, $row );

		$sent            = AMAC_Message_Model::STATUS_SENT === ( $result['status'] ?? '' );
		$row['status']   = $sent ? AMAC_Message_Model::STATUS_SENT : AMAC_Message_Model::STATUS_FAILED;
		$row['error']    = $sent ? '' : (string) ( $result['message'] ?? '' );
		$row['sent_at']  = $sent ? current_time( 'mysql' ) : '';
		$row['external_id'] = (string) ( $result['external_id'] ?? '' );

		$message_id = (int) AMAC_Message_Model::create( $row );

		if ( $sent && $is_estimate ) {
			self::mark_sent( $entity_id );
		}

		if ( $sent ) {
			AMAT_Log::info(
				self::CHANNEL,
				sprintf(
					/* translators: 1: channel label, 2: recipient. */
					__( 'Sent %1$s to %2$s.', 'auto-mation' ),
					AMAC_Channels::label( $channel ),
					$recipient
				),
				array(
					'entity_type' => $entity_type,
					'entity_id'   => $entity_id,
					'context'     => array(
						'message_type' => $message_type,
						'connector'    => $connector->slug(),
					),
				)
			);

			return array(
				'status'     => 'success',
				'message'    => sprintf(
					/* translators: 1: channel label, 2: recipient. */
					__( '%1$s sent to %2$s.', 'auto-mation' ),
					AMAC_Channels::label( $channel ),
					$recipient
				),
				'recipient'  => $recipient,
				'message_id' => $message_id,
			);
		}

		AMAT_Log::error(
			self::CHANNEL,
			sprintf(
				/* translators: 1: channel label, 2: recipient, 3: reason. */
				__( 'Failed to send %1$s to %2$s: %3$s', 'auto-mation' ),
				AMAC_Channels::label( $channel ),
				$recipient,
				$row['error']
			),
			array(
				'entity_type' => $entity_type,
				'entity_id'   => $entity_id,
				'context'     => array(
					'message_type' => $message_type,
					'connector'    => $connector->slug(),
				),
			)
		);

		return array(
			'status'     => 'error',
			'message'    => $row['error'],
			'recipient'  => $recipient,
			'message_id' => $message_id,
		);
	}

	/**
	 * Build the token context for an estimate or invoice.
	 *
	 * Returns the context plus `_customer_id` and `_status` keys the caller strips
	 * off (needed for routing and the void check, but not template tokens), and
	 * `_facts`, the lines the branded email shows in its box.
	 *
	 * @param string $entity_type 'estimate' or 'invoice'.
	 * @param int    $entity_id   Document row id.
	 * @return array<string,mixed>|WP_Error
	 */
	public static function document_context( $entity_type, $entity_id ) {
		$entity_id = (int) $entity_id;

		if ( 'job' === $entity_type ) {
			return self::job_context( $entity_id );
		}

		if ( 'estimate' === $entity_type ) {
			$doc = AMAT_Estimate_Model::find( $entity_id );
			if ( ! $doc ) {
				return new WP_Error( 'amac_not_found', __( 'Estimate not found.', 'auto-mation' ) );
			}
			$item_class = 'AMAT_Estimate_Item_Model';
			$items      = AMAT_Estimate_Item_Model::for_parent( $entity_id );
			$total      = AMAT_Estimate_Model::total( $entity_id );
			$number     = AMAT_Estimates_Page::label( $doc );
			$doc_type   = __( 'Estimate', 'auto-mation' );
			$due        = (string) ( $doc['valid_until'] ?? '' );
		} elseif ( 'invoice' === $entity_type ) {
			$doc = AMAT_Invoice_Model::find( $entity_id );
			if ( ! $doc ) {
				return new WP_Error( 'amac_not_found', __( 'Invoice not found.', 'auto-mation' ) );
			}
			$item_class = 'AMAT_Invoice_Item_Model';
			$items      = AMAT_Invoice_Item_Model::for_parent( $entity_id );
			$total      = AMAT_Invoice_Model::total( $entity_id );
			$number     = AMAT_Invoices_Page::label( $doc );
			$doc_type   = __( 'Invoice', 'auto-mation' );
			$due        = (string) ( $doc['due_date'] ?? '' );
		} else {
			return new WP_Error( 'amac_bad_entity', __( 'Messages can only be sent about an estimate, an invoice or a job.', 'auto-mation' ) );
		}

		$customer_id = (int) ( $doc['customer_id'] ?? 0 );
		$customer    = $customer_id ? AMAT_Customer_Model::find( $customer_id ) : null;

		if ( ! $customer ) {
			return new WP_Error( 'amac_no_customer', __( 'This document has no customer to send to.', 'auto-mation' ) );
		}

		$number  = self::document_number( $number, $doc_type );
		$vehicle = self::vehicle_label( $doc );
		$amount  = AMAT_Money::format_amount( $total );
		$due     = 'invoice' === $entity_type ? self::format_date( $due ) : '';

		// The facts the branded email shows in its box (not tokens).
		$facts = array(
			'' !== $vehicle ? $number . ' · ' . $vehicle : $number,
			/* translators: %s: the document total. */
			sprintf( __( 'Total %s', 'auto-mation' ), $amount ),
		);
		if ( '' !== $due ) {
			/* translators: %s: the invoice's due date. */
			$facts[] = sprintf( __( 'Due %s', 'auto-mation' ), $due );
		}

		return array(
			'first_name'    => trim( (string) ( $customer['first_name'] ?? '' ) ),
			'customer_name' => AMAT_Customer_Model::display_name( $customer ),
			'business_name' => class_exists( 'AMAT_Branded_Email' ) ? AMAT_Branded_Email::business_name() : (string) get_option( 'amat_business_name', '' ),
			'doc_type'      => $doc_type,
			'doc_number'    => $number,
			'doc_total'     => $amount,
			'doc_date'      => self::format_date( (string) ( $doc['issue_date'] ?? '' ) ),
			'doc_due'       => $due,
			// "for the vehicle" reads better than "for the " when none is known.
			'vehicle'       => '' !== $vehicle ? $vehicle : __( 'vehicle', 'auto-mation' ),
			'line_items'    => self::line_items_block( $items, $item_class ),
			'notes'         => trim( (string) ( $doc['notes'] ?? '' ) ),
			'_facts'        => $facts,
			'_customer_id'  => (string) $customer_id,
			'_status'       => (string) ( $doc['status'] ?? '' ),
		);
	}

	/**
	 * The token context for a message about a job - an appointment confirmation:
	 * the appointment, the vehicle and the address, as tokens and as the facts in
	 * the email's box. `_status` is 'closed' or 'unbooked' when there is nothing
	 * to confirm (send_document() refuses those), else 'booked'.
	 *
	 * @param int $job_id Job id.
	 * @return array<string,mixed>|WP_Error
	 */
	private static function job_context( $job_id ) {
		$job = AMAT_Job_Model::find( (int) $job_id );
		if ( ! $job ) {
			return new WP_Error( 'amac_not_found', __( 'Job not found.', 'auto-mation' ) );
		}
		$customer_id = (int) ( $job['customer_id'] ?? 0 );
		$customer    = $customer_id ? AMAT_Customer_Model::find( $customer_id ) : null;
		if ( ! $customer ) {
			return new WP_Error( 'amac_no_customer', __( 'This job has no customer to send to.', 'auto-mation' ) );
		}

		$vehicle     = (int) $job['vehicle_id'] ? AMAT_Vehicle_Model::find( (int) $job['vehicle_id'] ) : null;
		$vehicle     = $vehicle ? AMAT_Vehicle_Model::label( $vehicle ) : '';
		$location    = (int) $job['location_id'] ? AMAT_Location_Model::find( (int) $job['location_id'] ) : null;
		$address     = $location ? AMAT_Location_Model::one_line( $location ) : '';
		$appointment = self::appointment_text( (string) $job['scheduled_start'], (string) $job['scheduled_end'] );
		$status      = '' !== (string) $job['closed_reason'] ? 'closed' : ( '' === $appointment ? 'unbooked' : 'booked' );

		return array(
			'first_name'    => trim( (string) ( $customer['first_name'] ?? '' ) ),
			'customer_name' => AMAT_Customer_Model::display_name( $customer ),
			'business_name' => class_exists( 'AMAT_Branded_Email' ) ? AMAT_Branded_Email::business_name() : (string) get_option( 'amat_business_name', '' ),
			'doc_type'      => __( 'Appointment', 'auto-mation' ),
			'doc_number'    => '',
			'doc_total'     => '',
			'doc_date'      => '',
			'doc_due'       => '',
			'vehicle'       => '' !== $vehicle ? $vehicle : __( 'vehicle', 'auto-mation' ),
			'appointment'   => $appointment,
			'address'       => $address,
			'line_items'    => '',
			'notes'         => '',
			'_facts'        => array( $appointment, $vehicle, $address ),
			'_customer_id'  => (string) $customer_id,
			'_status'       => $status,
		);
	}

	/**
	 * An appointment as a customer reads it: "Wed, Oct 15 – morning (8:00 AM–
	 * 12:00 PM)" for a half-day slot (the halves split at the owner's midday,
	 * Settings → Scheduling), "Fri, Oct 17, 10:30 AM–2:00 PM" for any other
	 * time, "Wed, Oct 15" for an all-day booking. '' when there is none.
	 *
	 * @param string $start Stored start.
	 * @param string $end   Stored end, or ''.
	 * @return string
	 */
	public static function appointment_text( $start, $end ) {
		$from = AMAT_Job_Workflow::parse_when( (string) $start );
		if ( ! $from ) {
			return '';
		}
		$to  = AMAT_Job_Workflow::parse_when( (string) $end );
		$day = $from->format( 'D, M j' );
		if ( '00:00' === $from->format( 'H:i' ) && ( ! $to || '00:00' === $to->format( 'H:i' ) ) ) {
			return ( $to && $to->format( 'Y-m-d' ) > $from->modify( '+1 day' )->format( 'Y-m-d' ) )
				? $day . ' – ' . $to->modify( '-1 day' )->format( 'D, M j' )
				: $day;
		}
		if ( ! $to || $to <= $from ) {
			/* translators: 1: the day, 2: the time. */
			return sprintf( __( '%1$s at %2$s', 'auto-mation' ), $day, $from->format( 'g:i A' ) );
		}
		if ( $to->format( 'Y-m-d' ) !== $from->format( 'Y-m-d' ) ) {
			return $day . ', ' . $from->format( 'g:i A' ) . ' – ' . $to->format( 'D, M j, g:i A' );
		}
		$times  = $from->format( 'g:i A' ) . '–' . $to->format( 'g:i A' );
		$midday = class_exists( 'AMAT_Availability' ) ? (string) ( AMAT_Availability::settings()['midday'] ?? '12:00' ) : '12:00';
		if ( $to->format( 'H:i' ) <= $midday ) {
			/* translators: 1: the day, 2: the times. */
			return sprintf( __( '%1$s – morning (%2$s)', 'auto-mation' ), $day, $times );
		}
		if ( $from->format( 'H:i' ) >= $midday ) {
			/* translators: 1: the day, 2: the times. */
			return sprintf( __( '%1$s – afternoon (%2$s)', 'auto-mation' ), $day, $times );
		}
		return $day . ', ' . $times;
	}

	/**
	 * An invoice's online view-and-pay link, from core (its neutral
	 * amat_invoice_view_url filter), or '' when there is none.
	 *
	 * @param int $invoice_id Invoice id.
	 * @return string
	 */
	private static function invoice_link( $invoice_id ) {
		$invoice = AMAT_Invoice_Model::find( (int) $invoice_id );
		if ( ! $invoice ) {
			return '';
		}
		if ( method_exists( 'AMAT_Invoice_Model', 'view_url' ) ) {
			return AMAT_Invoice_Model::view_url( $invoice );
		}
		return esc_url_raw( trim( (string) apply_filters( 'amat_invoice_view_url', '', $invoice ) ) );
	}

	/**
	 * A document's number as a customer reads it: "Estimate #12", and "Invoice
	 * #1042" for a bare number a provider gave it.
	 *
	 * @param string $label    Core's label for the document.
	 * @param string $doc_type "Estimate" or "Invoice".
	 * @return string
	 */
	private static function document_number( $label, $doc_type ) {
		$label = trim( (string) $label );
		if ( ctype_digit( $label ) ) {
			return $doc_type . ' #' . $label;
		}
		return false === stripos( $label, $doc_type ) ? $doc_type . ' ' . $label : $label;
	}

	/**
	 * The vehicle a document is about.
	 *
	 * Prefers the parent job's vehicle, falling back to the document's own —
	 * the same precedence the Wave companion uses when building its memo header,
	 * because the job is the owner and the document inherits from it.
	 *
	 * @param array<string,mixed> $doc Estimate or invoice row.
	 * @return string
	 */
	private static function vehicle_label( array $doc ) {
		$vehicle_id = 0;

		$job_id = (int) ( $doc['job_id'] ?? 0 );
		if ( $job_id ) {
			$job = AMAT_Job_Model::find( $job_id );
			if ( $job ) {
				$vehicle_id = (int) ( $job['vehicle_id'] ?? 0 );
			}
		}

		if ( ! $vehicle_id ) {
			$vehicle_id = (int) ( $doc['vehicle_id'] ?? 0 );
		}

		if ( ! $vehicle_id ) {
			return '';
		}

		$vehicle = AMAT_Vehicle_Model::find( $vehicle_id );
		return $vehicle ? AMAT_Vehicle_Model::label( $vehicle ) : '';
	}

	/**
	 * Render line items as a plain-text block.
	 *
	 * Plain text, not a table: this has to survive in an email client and in a
	 * text message, and neither is a good place for HTML column alignment.
	 *
	 * @param array<int,array<string,mixed>> $items      Line item rows.
	 * @param string                         $item_class The matching line-item model.
	 * @return string
	 */
	private static function line_items_block( array $items, $item_class ) {
		$lines = array();

		foreach ( $items as $item ) {
			$description = trim( (string) ( $item['description'] ?? '' ) );
			if ( '' === $description ) {
				continue;
			}

			$qty    = AMAT_Money::quantity( $item['quantity'] ?? null );
			$amount = AMAT_Money::format_amount( call_user_func( array( $item_class, 'line_amount' ), $item ) );

			$lines[] = ( '' !== $qty && '1' !== $qty )
				? sprintf( '- %1$s x%2$s — %3$s', $description, $qty, $amount )
				: sprintf( '- %1$s — %2$s', $description, $amount );
		}

		return implode( "\n", $lines );
	}

	/**
	 * Format a stored date for a customer-facing message, or '' when unset.
	 *
	 * @param string $date Stored Y-m-d date.
	 * @return string
	 */
	private static function format_date( $date ) {
		$date = trim( (string) $date );
		if ( '' === $date || '0000-00-00' === $date ) {
			return '';
		}

		$ts = strtotime( $date );
		return $ts ? wp_date( (string) get_option( 'date_format', 'F j, Y' ), $ts ) : $date;
	}

	/**
	 * Build an error result.
	 *
	 * @param string $message Reason.
	 * @return array{status:string,message:string}
	 */
	private static function error( $message ) {
		return array(
			'status'  => 'error',
			'message' => (string) $message,
		);
	}
}
