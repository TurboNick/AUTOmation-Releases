<?php
/**
 * The appointment confirmation: telling the customer their booking stands.
 *
 * @package AUTOmation_Comms
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Sends the `appointment_confirmed` message (Nick, 2026-10-09: "Yes please build
 * the other email and follow the same style as the others").
 *
 *  - Automatically, when core announces `amat_appointment_confirmed` - the owner
 *    (or a tech allowed to) confirmed one of the customer's proposed times. Its
 *    listener is registered in EVERY context, not only wp-admin: confirming is an
 *    admin action today, but nothing here should depend on that.
 *  - By hand, from "Send to customer" beside the appointment (AMAC_Provider),
 *    for a booking made by phone or a time that moved.
 *
 * Nothing else sends it: moving a job on the calendar or typing a new time is
 * not a confirmation. Every send goes through AMAC_Comms::send_document(), so the
 * dry-run gate, the message record and the refusals (a closed or unbooked job)
 * are the same as for estimates and invoices.
 */
class AMAC_Appointments {

	/**
	 * The message type.
	 */
	const TYPE = 'appointment_confirmed';

	/**
	 * How each automatic send went this request, by job id - read back by the
	 * notice core shows the owner after confirming.
	 *
	 * @var array<int,array<string,mixed>>
	 */
	private static $outcomes = array();

	/**
	 * Listen for confirmed appointments. Safe to call more than once.
	 *
	 * @return void
	 */
	public static function register() {
		if ( false === has_action( 'amat_appointment_confirmed', array( __CLASS__, 'on_confirmed' ) ) ) {
			add_action( 'amat_appointment_confirmed', array( __CLASS__, 'on_confirmed' ) );
			add_filter( 'amat_appointment_confirmed_notices', array( __CLASS__, 'confirmed_notices' ), 10, 2 );
		}
	}

	/**
	 * Send the confirmation for a job, by the customer's preferred channel that
	 * Comms can deliver.
	 *
	 * @param int $job_id Job id.
	 * @return array{status:string,message:string,message_id?:int}
	 */
	public static function send( $job_id ) {
		$job = AMAT_Job_Model::find( (int) $job_id );
		if ( ! $job ) {
			return array( 'status' => 'error', 'message' => __( 'Job not found.', 'auto-mation' ) );
		}
		$channel = AMAC_Channels::preferred_for( (int) $job['customer_id'] );
		if ( '' === $channel ) {
			return array( 'status' => 'error', 'message' => __( 'Not sent: this customer has no email, and no number we can text. Add one on the job\'s Info stage.', 'auto-mation' ) );
		}
		return AMAC_Comms::send_document(
			array(
				'entity_type'  => 'job',
				'entity_id'    => (int) $job_id,
				'channel'      => $channel,
				'message_type' => self::TYPE,
			)
		);
	}

	/**
	 * Core's `amat_appointment_confirmed`: tell the customer. Never fatal - the
	 * booking has already happened, and a message that cannot go must not undo
	 * or break it. A refusal or failure is logged against the job and reported
	 * in the owner's notice.
	 *
	 * @param int $job_id Job id.
	 * @return void
	 */
	public static function on_confirmed( $job_id ) {
		$job_id = (int) $job_id;
		try {
			$result = self::send( $job_id );
		} catch ( \Throwable $e ) {
			$result = array( 'status' => 'error', 'message' => $e->getMessage() );
		}
		self::$outcomes[ $job_id ] = $result;

		// send_document() logs what it recorded (a dry run, a send, a failed send);
		// a refusal before that - nobody to send to - is logged here.
		if ( 'error' === ( $result['status'] ?? '' ) && empty( $result['message_id'] ) && class_exists( 'AMAT_Log' ) ) {
			AMAT_Log::warning(
				AMAC_Comms::CHANNEL,
				/* translators: %s: the reason. */
				sprintf( __( 'Appointment confirmation not sent: %s', 'auto-mation' ), (string) ( $result['message'] ?? '' ) ),
				array(
					'entity_type' => 'job',
					'entity_id'   => $job_id,
					'context'     => array( 'message_type' => self::TYPE ),
				)
			);
		}
	}

	/**
	 * Core's `amat_appointment_confirmed_notices`: how the confirmation went, for
	 * the notice the owner reads after "Customer picked this".
	 *
	 * @param array<int,array<string,string>> $notices Reports so far.
	 * @param int                             $job_id  Job id.
	 * @return array<int,array<string,string>>
	 */
	public static function confirmed_notices( $notices, $job_id ) {
		$notices = (array) $notices;
		$result  = self::$outcomes[ (int) $job_id ] ?? null;
		if ( ! $result ) {
			return $notices;
		}
		unset( self::$outcomes[ (int) $job_id ] );
		$failed    = 'error' === ( $result['status'] ?? '' );
		$notices[] = array(
			'status'  => $failed ? 'error' : 'success',
			'message' => $failed
				/* translators: %s: the reason. */
				? sprintf( __( 'Appointment confirmation not sent: %s', 'auto-mation' ), (string) ( $result['message'] ?? '' ) )
				/* translators: %s: how the send went. */
				: sprintf( __( 'Appointment confirmation: %s', 'auto-mation' ), (string) ( $result['message'] ?? '' ) ),
		);
		return $notices;
	}
}
