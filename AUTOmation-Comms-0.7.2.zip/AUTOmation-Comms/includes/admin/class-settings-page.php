<?php
/**
 * The Comms settings page.
 *
 * @package AUTOmation_Comms
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Settings → ↳ Comms: pick a connector per channel, control the dry-run gate,
 * set the From identity, and edit the message templates.
 */
class AMAC_Settings_Page {

	/**
	 * admin_post action for the delivery/sending settings form.
	 */
	const SAVE_DELIVERY = 'amac_save_delivery';

	/**
	 * admin_post action for the templates form.
	 */
	const SAVE_TEMPLATES = 'amac_save_templates';

	/**
	 * Action: send a test email through the chosen email route.
	 */
	const SEND_TEST = 'amac_send_test';

	/**
	 * Register the form handlers.
	 *
	 * @return void
	 */
	public function register() {
		add_action( 'admin_post_' . self::SAVE_DELIVERY, array( $this, 'handle_save_delivery' ) );
		add_action( 'admin_post_' . self::SAVE_TEMPLATES, array( $this, 'handle_save_templates' ) );
		add_action( 'admin_post_' . self::SEND_TEST, array( $this, 'handle_send_test' ) );
	}

	/* --------------------------------------------------------------------- */
	/* Handlers                                                              */
	/* --------------------------------------------------------------------- */

	/**
	 * Save the connector choices, dry-run flag and From identity.
	 *
	 * @return void
	 */
	public function handle_save_delivery() {
		$this->guard( self::SAVE_DELIVERY );

		foreach ( array_keys( AMAC_Channels::all() ) as $channel ) {
			$field = 'amac_connector_' . $channel;
			$slug  = isset( $_POST[ $field ] ) ? sanitize_key( wp_unslash( $_POST[ $field ] ) ) : '';

			// Only accept a slug that is actually registered for this channel,
			// so a tampered POST can't point a channel at someone else's route.
			$connector = '' !== $slug ? AMAC_Connector_Registry::get( $slug ) : null;
			AMAC_Connector_Registry::set_active(
				$channel,
				( $connector && $connector->channel() === $channel ) ? $slug : ''
			);
		}

		// Absent checkbox = unchecked = dry run OFF. Storing '1'/'0' explicitly
		// rather than deleting, so "never configured" (default ON) stays
		// distinguishable from "deliberately turned off".
		$dry_run = ! empty( $_POST['amac_dry_run'] ) ? '1' : '0';
		update_option( AMAC_Comms::DRY_RUN_OPTION, $dry_run, false );

		$from_name = isset( $_POST['amac_from_name'] )
			? sanitize_text_field( wp_unslash( $_POST['amac_from_name'] ) )
			: '';
		update_option( AMAC_Connector_Wp_Mail::FROM_NAME_OPTION, $from_name, false );

		$from_email = isset( $_POST['amac_from_email'] )
			? sanitize_email( wp_unslash( $_POST['amac_from_email'] ) )
			: '';
		update_option( AMAC_Connector_Wp_Mail::FROM_EMAIL_OPTION, $from_email, false );

		// The SMTP server. Never a password: that is a wp-config.php constant.
		$text = static function ( $key ) {
			return isset( $_POST[ $key ] ) ? trim( sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- guard() checked it.
		};
		$port   = (int) $text( 'amac_smtp_port' );
		$secure = $text( 'amac_smtp_secure' );
		update_option( AMAC_Connector_Smtp::HOST_OPTION, $text( 'amac_smtp_host' ), false );
		update_option( AMAC_Connector_Smtp::PORT_OPTION, (string) ( $port > 0 && $port < 65536 ? $port : 587 ), false );
		update_option( AMAC_Connector_Smtp::SECURE_OPTION, in_array( $secure, AMAC_Connector_Smtp::SECURE_CHOICES, true ) ? $secure : 'tls', false );
		update_option( AMAC_Connector_Smtp::USER_OPTION, $text( 'amac_smtp_user' ), false );

		$this->notice( 'success', __( 'Delivery settings saved.', 'auto-mation' ) );
		$this->redirect_back();
	}

	/**
	 * Send a test email through whatever the site's mail now goes by (SMTP when
	 * chosen), and say how it went - the way to prove the credentials before a
	 * customer is mailed. Ignores dry-run: it goes to you, not a customer.
	 *
	 * @return void
	 */
	public function handle_send_test() {
		$this->guard( self::SEND_TEST );
		$to = isset( $_POST['amac_test_to'] ) ? sanitize_email( wp_unslash( $_POST['amac_test_to'] ) ) : '';
		if ( ! is_email( $to ) ) {
			$this->notice( 'error', __( 'Give an email address to send the test to.', 'auto-mation' ) );
			$this->redirect_back( 'amac-test' );
		}
		$reason  = '';
		$capture = static function ( $error ) use ( &$reason ) {
			$reason = is_wp_error( $error ) ? $error->get_error_message() : '';
		};
		add_action( 'wp_mail_failed', $capture );
		try {
			$ok = wp_mail( $to, __( 'Test email from AUTOmation', 'auto-mation' ), __( 'If you are reading this, the site\'s email works.', 'auto-mation' ) );
		} catch ( \Throwable $e ) {
			$ok     = false;
			$reason = $e->getMessage();
		}
		remove_action( 'wp_mail_failed', $capture );
		$active = AMAC_Connector_Registry::active( AMAC_Channels::EMAIL );
		$this->notice(
			$ok ? 'success' : 'error',
			$ok
				/* translators: 1: address, 2: the route. */
				? sprintf( __( 'Test email sent to %1$s by %2$s - check that it arrived (and not in spam).', 'auto-mation' ), $to, $active ? $active->label() : 'wp_mail' )
				/* translators: %s: the reason. */
				: sprintf( __( 'The test email failed: %s', 'auto-mation' ), '' !== $reason ? $reason : __( 'no reason given.', 'auto-mation' ) )
		);
		$this->redirect_back( 'amac-test' );
	}

	/**
	 * Save the message templates.
	 *
	 * @return void
	 */
	public function handle_save_templates() {
		$this->guard( self::SAVE_TEMPLATES );

		foreach ( array_keys( AMAC_Templates::types() ) as $type ) {
			foreach ( array_keys( AMAC_Channels::all() ) as $channel ) {
				foreach ( AMAC_Templates::parts( $channel ) as $part ) {
					$field = 'amac_tpl_' . $type . '_' . $channel . '_' . $part;

					if ( ! isset( $_POST[ $field ] ) ) {
						continue;
					}

					// Each part is one plain line with {tokens}; the layout around it
					// is not editable, so nothing typed here can break it. save()
					// trims, and blank or default resets.
					AMAC_Templates::save(
						$type,
						$channel,
						$part,
						sanitize_text_field( wp_unslash( $_POST[ $field ] ) )
					);
				}
			}
		}

		$this->notice( 'success', __( 'Templates saved. Blank fields, or ones matching the built-in wording, are reset to the default.', 'auto-mation' ) );
		$this->redirect_back( 'templates' );
	}

	/* --------------------------------------------------------------------- */
	/* Rendering                                                             */
	/* --------------------------------------------------------------------- */

	/**
	 * Render the settings page.
	 *
	 * @return void
	 */
	public function render() {
		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'auto-mation' ) );
		}

		$this->render_notice();

		echo '<div class="wrap">';
		echo '<h1>' . esc_html__( 'Comms', 'auto-mation' ) . '</h1>';
		echo '<p class="description">'
			. esc_html__( 'Send estimates and invoices to customers by email or text. A channel is the kind of message; a connector is the route that delivers it.', 'auto-mation' )
			. '</p>';

		$this->render_delivery_form();
		$this->render_templates_form();

		echo '</div>';
	}

	/**
	 * The delivery + sending form.
	 *
	 * @return void
	 */
	private function render_delivery_form() {
		$dry_run = AMAC_Comms::is_dry_run();

		echo '<h2>' . esc_html__( 'Delivery', 'auto-mation' ) . '</h2>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( self::SAVE_DELIVERY );
		echo '<input type="hidden" name="action" value="' . esc_attr( self::SAVE_DELIVERY ) . '">';

		echo '<table class="form-table" role="presentation"><tbody>';

		foreach ( AMAC_Channels::all() as $channel => $channel_label ) {
			$available = AMAC_Connector_Registry::all( $channel );
			$active    = AMAC_Connector_Registry::active( $channel );

			echo '<tr>';
			echo '<th scope="row"><label for="amac-connector-' . esc_attr( $channel ) . '">'
				. esc_html( $channel_label ) . '</label></th>';
			echo '<td>';

			if ( ! $available ) {
				echo '<p class="description">'
					. esc_html__( 'No connector is available for this channel yet.', 'auto-mation' )
					. '</p>';
				echo '</td></tr>';
				continue;
			}

			echo '<select name="amac_connector_' . esc_attr( $channel ) . '" id="amac-connector-' . esc_attr( $channel ) . '">';
			echo '<option value="">' . esc_html__( '— Not set —', 'auto-mation' ) . '</option>';
			foreach ( $available as $slug => $connector ) {
				printf(
					'<option value="%1$s"%2$s>%3$s</option>',
					esc_attr( $slug ),
					selected( $active && $active->slug() === $slug, true, false ),
					esc_html( $connector->label() )
				);
			}
			echo '</select>';

			foreach ( $available as $connector ) {
				$description = $connector->description();
				if ( '' === $description ) {
					continue;
				}
				echo '<p class="description"><strong>' . esc_html( $connector->label() ) . ':</strong> '
					. esc_html( $description );
				if ( ! $connector->is_configured() ) {
					echo ' <em>' . esc_html( $connector->config_hint() ) . '</em>';
				}
				echo '</p>';
			}

			echo '</td></tr>';
		}

		echo '<tr>';
		echo '<th scope="row">' . esc_html__( 'Dry-run mode', 'auto-mation' ) . '</th>';
		echo '<td>';
		echo '<label><input type="checkbox" name="amac_dry_run" value="1"' . checked( $dry_run, true, false ) . '> '
			. esc_html__( 'Render and record messages, but do not actually deliver them', 'auto-mation' )
			. '</label>';
		echo '<p class="description">'
			. esc_html__( 'On by default. A message that reaches a customer cannot be recalled, so leave this on until you have reviewed the previews on a real estimate. Every send is still recorded while it is on, so you can see exactly what would have gone out.', 'auto-mation' )
			. '</p>';
		echo '</td></tr>';

		echo '<tr>';
		echo '<th scope="row"><label for="amac-from-name">' . esc_html__( 'From name', 'auto-mation' ) . '</label></th>';
		echo '<td><input type="text" class="regular-text" id="amac-from-name" name="amac_from_name" value="'
			. esc_attr( (string) get_option( AMAC_Connector_Wp_Mail::FROM_NAME_OPTION, '' ) ) . '">';
		echo '<p class="description">'
			. esc_html__( 'Shown as the sender on emails. Blank uses your business name from Settings → My Business.', 'auto-mation' )
			. '</p></td></tr>';

		echo '<tr>';
		echo '<th scope="row"><label for="amac-from-email">' . esc_html__( 'From address', 'auto-mation' ) . '</label></th>';
		echo '<td><input type="email" class="regular-text" id="amac-from-email" name="amac_from_email" value="'
			. esc_attr( (string) get_option( AMAC_Connector_Wp_Mail::FROM_EMAIL_OPTION, '' ) ) . '">';
		echo '<p class="description">'
			. esc_html__( 'Blank uses the WordPress default. Use an address at your own domain — mail claiming to be from a domain the server is not authorized to send for is what spam filters catch.', 'auto-mation' )
			. '</p></td></tr>';

		// The SMTP server (used when SMTP is the email connector above).
		$secure = AMAC_Connector_Smtp::secure();
		echo '<tr><th scope="row" colspan="2"><h3 style="margin:0;">' . esc_html__( 'SMTP server', 'auto-mation' ) . '</h3>'
			. '<p class="description" style="font-weight:400;">' . esc_html__( 'Your email provider\'s outgoing (SMTP) settings. Used when SMTP is chosen above.', 'auto-mation' ) . '</p></th></tr>';
		echo '<tr><th scope="row"><label for="amac-smtp-host">' . esc_html__( 'Server', 'auto-mation' ) . '</label></th>'
			. '<td><input type="text" class="regular-text" id="amac-smtp-host" name="amac_smtp_host" placeholder="smtp.example.com" value="' . esc_attr( AMAC_Connector_Smtp::host() ) . '"></td></tr>';
		echo '<tr><th scope="row"><label for="amac-smtp-port">' . esc_html__( 'Port', 'auto-mation' ) . '</label></th>'
			. '<td><input type="number" class="small-text" id="amac-smtp-port" name="amac_smtp_port" min="1" max="65535" value="' . esc_attr( (string) AMAC_Connector_Smtp::port() ) . '"> '
			. '<select name="amac_smtp_secure" aria-label="' . esc_attr__( 'Encryption', 'auto-mation' ) . '">'
			. '<option value="tls"' . selected( 'tls', $secure, false ) . '>' . esc_html__( 'STARTTLS (usually port 587)', 'auto-mation' ) . '</option>'
			. '<option value="ssl"' . selected( 'ssl', $secure, false ) . '>' . esc_html__( 'SSL (usually port 465)', 'auto-mation' ) . '</option>'
			. '<option value=""' . selected( '', $secure, false ) . '>' . esc_html__( 'None', 'auto-mation' ) . '</option>'
			. '</select></td></tr>';
		echo '<tr><th scope="row"><label for="amac-smtp-user">' . esc_html__( 'Username', 'auto-mation' ) . '</label></th>'
			. '<td><input type="text" class="regular-text" id="amac-smtp-user" name="amac_smtp_user" autocomplete="off" value="' . esc_attr( AMAC_Connector_Smtp::user() ) . '">'
			. '<p class="description">' . esc_html__( 'Usually your full email address. Mail is sent from it unless a From address is set above.', 'auto-mation' ) . '</p></td></tr>';
		echo '<tr><th scope="row">' . esc_html__( 'Password', 'auto-mation' ) . '</th><td>'
			. ( AMAC_Connector_Smtp::has_password()
				? '<p>' . esc_html__( 'Set (in wp-config.php).', 'auto-mation' ) . '</p>'
				: '<p>' . esc_html__( 'Not set. For safety it is never typed here or stored in the database - add this line to wp-config.php, above "That\'s all, stop editing!":', 'auto-mation' ) . '</p><p><code>define( \'AMAC_SMTP_PASSWORD\', \'your-password\' );</code></p>' )
			. '<p class="description">' . esc_html__( 'Many providers (Google, Microsoft) need an app password rather than your normal one.', 'auto-mation' ) . '</p></td></tr>';

		echo '</tbody></table>';
		submit_button( __( 'Save delivery settings', 'auto-mation' ) );
		echo '</form>';

		// A test email, through whatever the site's mail now goes by.
		echo '<h2 id="amac-test">' . esc_html__( 'Send a test email', 'auto-mation' ) . '</h2>'
			. '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( self::SEND_TEST );
		echo '<input type="hidden" name="action" value="' . esc_attr( self::SEND_TEST ) . '">'
			. '<p><label for="amac-test-to">' . esc_html__( 'Send to', 'auto-mation' ) . '</label> '
			. '<input type="email" class="regular-text" id="amac-test-to" name="amac_test_to" value="' . esc_attr( (string) get_option( 'admin_email' ) ) . '"> ';
		submit_button( __( 'Send test email', 'auto-mation' ), 'secondary', 'submit', false );
		echo '</p><p class="description">' . esc_html__( 'Goes to you, not a customer, so it is sent even in dry-run mode. Save the settings above first.', 'auto-mation' ) . '</p></form>';
	}

	/**
	 * The templates form.
	 *
	 * @return void
	 */
	private function render_templates_form() {
		echo '<h2 id="templates">' . esc_html__( 'Message templates', 'auto-mation' ) . '</h2>';
		echo '<p class="description">'
			. esc_html__( 'Each message delivers a link: to the estimate, or to their bookings, in your customer portal, or to the invoice\'s online view-and-pay page. An email is your branded layout - the same as the welcome emails - filled with the lines below: the greeting, the facts (the document number, vehicle, total and an invoice\'s due date; or the appointment, vehicle and address), the button\'s link and your sign-off are added for you. A text is one short line. Leave a line blank to go back to the built-in wording. The appointment confirmation goes out by itself when you confirm a time the customer picked ("Customer picked this"), and from "Send to customer" beside a booked appointment.', 'auto-mation' )
			. '</p>';

		echo '<p><strong>' . esc_html__( 'Available placeholders:', 'auto-mation' ) . '</strong></p>';
		echo '<ul style="columns:2;max-width:900px;">';
		foreach ( AMAC_Templates::tokens() as $token => $description ) {
			echo '<li><code>' . esc_html( $token ) . '</code> — ' . esc_html( $description ) . '</li>';
		}
		echo '</ul>';

		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( self::SAVE_TEMPLATES );
		echo '<input type="hidden" name="action" value="' . esc_attr( self::SAVE_TEMPLATES ) . '">';

		$labels = AMAC_Templates::part_labels();
		foreach ( AMAC_Templates::types() as $type => $definition ) {
			echo '<h3>' . esc_html( $definition['label'] ) . '</h3>';
			echo '<table class="form-table" role="presentation"><tbody>';

			foreach ( AMAC_Channels::all() as $channel => $channel_label ) {
				echo '<tr><th scope="row" colspan="2" style="padding-bottom:0;">' . esc_html( $channel_label ) . '</th></tr>';
				foreach ( AMAC_Templates::parts( $channel ) as $part ) {
					$field = 'amac_tpl_' . $type . '_' . $channel . '_' . $part;
					echo '<tr>';
					echo '<th scope="row"><label for="' . esc_attr( $field ) . '">' . esc_html( $labels[ $part ] ?? $part ) . '</label></th>';
					echo '<td><input type="text" class="large-text" id="' . esc_attr( $field ) . '" name="' . esc_attr( $field ) . '" value="'
						. esc_attr( AMAC_Templates::get( $type, $channel, $part ) ) . '" placeholder="' . esc_attr( AMAC_Templates::default_for( $type, $channel, $part ) ) . '">';
					if ( AMAC_Channels::SMS === $channel ) {
						echo '<p class="description">'
							. esc_html__( 'Keep it short and keep {doc_link} in it. Carriers split anything over 160 characters into multiple messages, and most providers bill per part.', 'auto-mation' )
							. '</p>';
					}
					echo '</td></tr>';
				}

				if ( AMAC_Channels::EMAIL === $channel ) {
					echo '<tr><th scope="row">' . esc_html__( 'What it looks like', 'auto-mation' ) . '</th><td>';
					echo '<p class="description">' . esc_html__( 'Your saved wording, with example details. Save to update it.', 'auto-mation' ) . '</p>';
					echo '<iframe class="amac-email-preview" title="' . esc_attr__( 'Email preview', 'auto-mation' ) . '" style="width:100%;max-width:620px;height:560px;border:1px solid #dcdcde;border-radius:6px;background:#f4f4f5;" sandbox="" srcdoc="'
						. esc_attr( (string) ( AMAC_Templates::render( $type, $channel, $this->example_context( $definition['entity'] ) )['html'] ?? '' ) ) . '"></iframe>';
					echo '</td></tr>';
				}
			}

			echo '</tbody></table>';
		}

		submit_button( __( 'Save templates', 'auto-mation' ) );
		echo '</form>';
	}

	/**
	 * Example details for the email previews (nothing real is read or sent).
	 *
	 * @param string $entity 'estimate' or 'invoice'.
	 * @return array<string,mixed>
	 */
	private function example_context( $entity ) {
		if ( 'job' === $entity ) {
			// An appointment confirmation: the appointment, vehicle and address.
			$day         = new DateTimeImmutable( wp_date( 'Y-m-d', time() + 3 * DAY_IN_SECONDS ) . ' 08:00' );
			$appointment = AMAC_Comms::appointment_text( $day->format( 'Y-m-d H:i:s' ), $day->setTime( 12, 0 )->format( 'Y-m-d H:i:s' ) );
			return array(
				'first_name'    => 'Pat',
				'customer_name' => 'Pat Driver',
				'business_name' => class_exists( 'AMAT_Branded_Email' ) ? AMAT_Branded_Email::business_name() : (string) get_option( 'amat_business_name', '' ),
				'doc_type'      => __( 'Appointment', 'auto-mation' ),
				'vehicle'       => '2015 Ford F-150',
				'appointment'   => $appointment,
				'address'       => '12 Oak Lane, Elkhart IN 46514',
				'doc_link'      => home_url( '/' ),
				'_facts'        => array( $appointment, '2015 Ford F-150', '12 Oak Lane, Elkhart IN 46514' ),
			);
		}
		$is_invoice = 'invoice' === $entity;
		$doc_type   = $is_invoice ? __( 'Invoice', 'auto-mation' ) : __( 'Estimate', 'auto-mation' );
		$number     = $doc_type . ' #12';
		$vehicle    = '2015 Ford F-150';
		$total      = class_exists( 'AMAT_Money' ) ? AMAT_Money::format_amount( 640 ) : '$640.00';
		$due        = wp_date( (string) get_option( 'date_format', 'F j, Y' ), time() + 30 * DAY_IN_SECONDS );
		/* translators: %s: the document total. */
		$facts = array( $number . ' · ' . $vehicle, sprintf( __( 'Total %s', 'auto-mation' ), $total ) );
		if ( $is_invoice ) {
			/* translators: %s: the invoice's due date. */
			$facts[] = sprintf( __( 'Due %s', 'auto-mation' ), $due );
		}
		return array(
			'first_name'    => 'Pat',
			'customer_name' => 'Pat Driver',
			'business_name' => class_exists( 'AMAT_Branded_Email' ) ? AMAT_Branded_Email::business_name() : (string) get_option( 'amat_business_name', '' ),
			'doc_type'      => $doc_type,
			'doc_number'    => $number,
			'doc_total'     => $total,
			'doc_date'      => wp_date( (string) get_option( 'date_format', 'F j, Y' ) ),
			'doc_due'       => $is_invoice ? $due : '',
			'vehicle'       => $vehicle,
			'notes'         => '',
			'doc_link'      => home_url( '/' ),
			'_facts'        => $facts,
		);
	}

	/* --------------------------------------------------------------------- */
	/* Helpers                                                               */
	/* --------------------------------------------------------------------- */

	/**
	 * Capability + nonce check for a form handler.
	 *
	 * @param string $action Nonce action.
	 * @return void
	 */
	private function guard( $action ) {
		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to do that.', 'auto-mation' ) );
		}
		check_admin_referer( $action );
	}

	/**
	 * Stash a one-shot notice for the next page load.
	 *
	 * @param string $status 'success' or 'error'.
	 * @param string $text   Message.
	 * @return void
	 */
	private function notice( $status, $text ) {
		set_transient(
			'amac_notice_' . get_current_user_id(),
			array(
				'status'  => $status,
				'message' => $text,
			),
			MINUTE_IN_SECONDS
		);
	}

	/**
	 * Print and clear the stashed notice.
	 *
	 * @return void
	 */
	private function render_notice() {
		$key    = 'amac_notice_' . get_current_user_id();
		$notice = get_transient( $key );

		if ( ! is_array( $notice ) ) {
			return;
		}
		delete_transient( $key );

		printf(
			'<div class="notice notice-%1$s is-dismissible"><p>%2$s</p></div>',
			'success' === ( $notice['status'] ?? '' ) ? 'success' : 'error',
			esc_html( (string) ( $notice['message'] ?? '' ) )
		);
	}

	/**
	 * Redirect back to this settings page.
	 *
	 * @param string $fragment Optional anchor.
	 * @return void
	 */
	private function redirect_back( $fragment = '' ) {
		$url = add_query_arg( array( 'page' => AMAC_Provider::PAGE_SLUG ), admin_url( 'admin.php' ) );
		if ( '' !== $fragment ) {
			$url .= '#' . $fragment;
		}
		wp_safe_redirect( $url );
		exit;
	}
}
