<?php
/**
 * Email connector: SMTP, through the business's own mail account.
 *
 * @package AUTOmation_Comms
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Delivers email by logging in to a real mail server (Nick, 2026-10-09: "I have
 * credentials for my branded email"). Same email templates as wp_mail - a
 * connector is only the route - but authenticated, so it is not spam-filed the
 * way mail straight from a web server is.
 *
 * **It carries all of the site's email, not only Comms messages.** Core's own
 * emails - the portal welcome, the thank-you's invitation, a technician's
 * welcome, password resets - go by wp_mail() directly, and a new customer's
 * set-password email is the one that most needs to arrive. So while SMTP is the
 * chosen email route and is configured, a phpmailer_init hook points every
 * wp_mail() at it. Half-configured, it does nothing: the host's own route is
 * better than a login that fails.
 *
 * **The password is never stored here.** It is a wp-config.php constant,
 * `AMAC_SMTP_PASSWORD` (an environment variable of that name, or the plugin's
 * dev-only .env, also work). Core's standing rule: no new place secrets are
 * kept - not an option, not a transient. A plugin update deletes the plugin
 * folder, so on a live site the constant is the only home that survives.
 */
class AMAC_Connector_Smtp extends AMAC_Connector_Wp_Mail {

	const HOST_OPTION   = 'amat_comms_smtp_host';
	const PORT_OPTION   = 'amat_comms_smtp_port';
	const SECURE_OPTION = 'amat_comms_smtp_secure';
	const USER_OPTION   = 'amat_comms_smtp_user';

	/**
	 * The wp-config.php constant (or environment variable) holding the password.
	 */
	const PASSWORD_KEY = 'AMAC_SMTP_PASSWORD';

	/**
	 * Encryption choices: '' none, 'tls' STARTTLS (port 587), 'ssl' (port 465).
	 */
	const SECURE_CHOICES = array( 'tls', 'ssl', '' );

	/**
	 * Point all of the site's mail at this server while it is the chosen,
	 * configured email route. Called once at start-up, in every context (cron
	 * and the front end send mail too).
	 *
	 * @return void
	 */
	public static function hook() {
		add_action( 'phpmailer_init', array( __CLASS__, 'configure' ), 20 );
	}

	/**
	 * phpmailer_init: route this message through SMTP, when SMTP is in use.
	 *
	 * @param PHPMailer\PHPMailer\PHPMailer $mailer WordPress's mailer.
	 * @return void
	 */
	public static function configure( $mailer ) {
		$active = AMAC_Connector_Registry::active( AMAC_Channels::EMAIL );
		if ( ! $active instanceof self || ! $active->is_configured() ) {
			return;
		}
		$user = self::user();

		$mailer->isSMTP();
		$mailer->Host       = self::host();
		$mailer->Port       = self::port();
		$mailer->SMTPSecure = self::secure();
		$mailer->SMTPAuth   = true;
		$mailer->Username   = $user;
		$mailer->Password   = self::password();
		$mailer->Timeout    = 20;

		// Sent as the account it logs in as, unless a From address is set - many
		// mail servers refuse a From they do not own.
		$from = sanitize_email( (string) get_option( self::FROM_EMAIL_OPTION, '' ) );
		$from = is_email( $from ) ? $from : ( is_email( $user ) ? $user : '' );
		if ( '' !== $from ) {
			$name = trim( (string) get_option( self::FROM_NAME_OPTION, '' ) );
			$name = '' !== $name ? $name : trim( (string) get_option( 'amat_business_name', '' ) );
			$mailer->setFrom( $from, '' !== $name ? $name : $mailer->FromName, false );
		}
	}

	/** @return string */
	public static function host() {
		return trim( (string) get_option( self::HOST_OPTION, '' ) );
	}

	/** @return int */
	public static function port() {
		$port = (int) get_option( self::PORT_OPTION, 587 );
		return $port > 0 && $port < 65536 ? $port : 587;
	}

	/** @return string */
	public static function secure() {
		$secure = (string) get_option( self::SECURE_OPTION, 'tls' );
		return in_array( $secure, self::SECURE_CHOICES, true ) ? $secure : 'tls';
	}

	/** @return string */
	public static function user() {
		return trim( (string) get_option( self::USER_OPTION, '' ) );
	}

	/**
	 * The password: the wp-config.php constant, else an environment variable or
	 * the dev-only .env of the same name. Never an option.
	 *
	 * @return string
	 */
	private static function password() {
		if ( defined( self::PASSWORD_KEY ) ) {
			return (string) constant( self::PASSWORD_KEY );
		}
		return AMAC_Env::get( self::PASSWORD_KEY );
	}

	/**
	 * Whether the password is in place (the settings page says so, never what).
	 *
	 * @return bool
	 */
	public static function has_password() {
		return '' !== self::password();
	}

	/** @return string */
	public function slug() {
		return 'smtp';
	}

	/** @return string */
	public function label() {
		return __( 'SMTP (your own email account)', 'auto-mation' );
	}

	/** @return string */
	public function description() {
		return __( 'Logs in to your own mail server, so mail arrives as genuinely yours instead of in spam. Carries all of the site\'s email while chosen - estimates, welcomes and password resets alike.', 'auto-mation' );
	}

	/** @return bool */
	public function is_configured() {
		return '' !== self::host() && '' !== self::user() && self::has_password();
	}

	/** @return string */
	public function config_hint() {
		if ( '' === self::host() || '' === self::user() ) {
			return __( 'Fill in the server and username below.', 'auto-mation' );
		}
		return sprintf(
			/* translators: %s: the line to add. */
			__( 'Add the password to wp-config.php: %s', 'auto-mation' ),
			"define( 'AMAC_SMTP_PASSWORD', 'your-password' );"
		);
	}
}
