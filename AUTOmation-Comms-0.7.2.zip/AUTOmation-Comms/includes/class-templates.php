<?php
/**
 * Message templates: one per message type, per channel.
 *
 * @package AUTOmation_Comms
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Editable message wording, keyed by (message type × channel).
 *
 * A template belongs to a CHANNEL, not to a connector. Email and SMS get
 * genuinely separate templates. wp_mail and SMTP are two routes for the *same*
 * email, so they share the email template: switching delivery route must never
 * mean rewriting content.
 *
 * **An email is a few plain lines that fill a fixed layout** (Nick, 2026-10-09:
 * the text email was "really dull and boring" - it should match the branded
 * welcome emails, and "the point of the email or txt is to get people to the
 * website to view the estimate/invoice. It's delivering a link"). The owner
 * edits the subject, the intro, the button's label and a note; core's
 * AMAT_Branded_Email draws the rest - the greeting, the facts (number, vehicle,
 * total, due date), the button to {doc_link} and the sign-off. He can reword it
 * without a developer, and can't break the layout. A text stays one line.
 *
 * Wording is stored in options and falls back to the defaults below when unset,
 * so the plugin works before anything is customized and a "reset" is just
 * deleting the option. (Before v0.6.0 an email was one big 'body'; a stored one
 * is simply no longer read.)
 */
class AMAC_Templates {

	/**
	 * Option key prefix: amat_comms_tpl_{type}_{channel}_{part}.
	 */
	const OPTION_PREFIX = 'amat_comms_tpl_';

	/**
	 * The message types this plugin can send.
	 *
	 * `entity` ties a type to the core record it describes, which is what lets
	 * the send button on an estimate know which templates apply to it.
	 *
	 * `first_time` is the line under the button when the link sets a new
	 * customer's password first (not editable - it is about how the link works).
	 *
	 * @return array<string,array{label:string,entity:string,first_time:string}>
	 */
	public static function types() {
		return array(
			'estimate_ready'        => array(
				'label'      => __( 'Estimate ready', 'auto-mation' ),
				'entity'     => 'estimate',
				'first_time' => __( 'First time? You\'ll choose a password, then see your estimate.', 'auto-mation' ),
			),
			'invoice_ready'         => array(
				'label'      => __( 'Invoice', 'auto-mation' ),
				'entity'     => 'invoice',
				'first_time' => '', // its link is the payment provider's page: never a set-password link
			),
			// Sent when the owner confirms one of the customer's proposed times, or
			// from "Send to customer" beside the appointment (Nick, 2026-10-09).
			'appointment_confirmed' => array(
				'label'      => __( 'Appointment confirmed', 'auto-mation' ),
				'entity'     => 'job',
				'first_time' => __( 'First time? You\'ll choose a password, then see your booking.', 'auto-mation' ),
			),
		);
	}

	/**
	 * Whether a message type exists.
	 *
	 * @param string $type Message type slug.
	 * @return bool
	 */
	public static function is_valid_type( $type ) {
		return array_key_exists( $type, self::types() );
	}

	/**
	 * Human label for a message type.
	 *
	 * @param string $type Message type slug.
	 * @return string
	 */
	public static function type_label( $type ) {
		$types = self::types();
		return $types[ $type ]['label'] ?? $type;
	}

	/**
	 * The message types that apply to a core entity.
	 *
	 * @param string $entity Entity slug, e.g. 'estimate'.
	 * @return array<int,string> Message type slugs.
	 */
	public static function types_for_entity( $entity ) {
		$out = array();
		foreach ( self::types() as $slug => $def ) {
			if ( $def['entity'] === $entity ) {
				$out[] = $slug;
			}
		}
		return $out;
	}

	/**
	 * The editable parts of a channel's template, in the editor's order.
	 *
	 * @param string $channel Channel slug.
	 * @return string[]
	 */
	public static function parts( $channel ) {
		return AMAC_Channels::EMAIL === $channel
			? array( 'subject', 'intro', 'button', 'note' )
			: array( 'body' );
	}

	/**
	 * Labels for the editable parts.
	 *
	 * @return array<string,string>
	 */
	public static function part_labels() {
		return array(
			'subject' => __( 'Subject', 'auto-mation' ),
			'intro'   => __( 'Opening line', 'auto-mation' ),
			'button'  => __( 'Button', 'auto-mation' ),
			'note'    => __( 'Note under the button', 'auto-mation' ),
			'body'    => __( 'Text message', 'auto-mation' ),
		);
	}

	/**
	 * The placeholder tokens a template may use, with a description each.
	 *
	 * Shown as a cheat-sheet next to the editor.
	 *
	 * @return array<string,string>
	 */
	public static function tokens() {
		return array(
			'{first_name}'    => __( 'The customer\'s first name', 'auto-mation' ),
			'{customer_name}' => __( 'The customer\'s display name', 'auto-mation' ),
			'{business_name}' => __( 'Your business name (Settings → My Business)', 'auto-mation' ),
			'{doc_type}'      => __( 'Estimate or Invoice', 'auto-mation' ),
			'{doc_number}'    => __( 'Document number, e.g. "Estimate #12"', 'auto-mation' ),
			'{doc_total}'     => __( 'Document total, e.g. "$487.50"', 'auto-mation' ),
			'{doc_date}'      => __( 'Issue date', 'auto-mation' ),
			'{doc_due}'       => __( 'Due date (invoice)', 'auto-mation' ),
			'{vehicle}'       => __( 'Year Make Model of the vehicle ("vehicle" when unknown)', 'auto-mation' ),
			'{notes}'         => __( 'The document\'s notes', 'auto-mation' ),
			'{appointment}'   => __( 'The appointment (confirmation), e.g. "Wed, Oct 15 – morning (8:00 AM–12:00 PM)"', 'auto-mation' ),
			'{address}'       => __( 'Where the work is done (confirmation)', 'auto-mation' ),
			'{doc_link}'      => __( 'The link: an estimate, or a confirmation\'s bookings, in your customer portal (for a customer with no login yet, it sets their password first); an invoice\'s online view-and-pay page. The email\'s button always uses it.', 'auto-mation' ),
		);
	}

	/**
	 * Built-in default templates, keyed type => channel => part => text.
	 *
	 * Every one delivers a link - none lists the lines or asks for a reply.
	 *
	 * @return array<string,array<string,array<string,string>>>
	 */
	public static function defaults() {
		return array(
			'estimate_ready' => array(
				AMAC_Channels::EMAIL => array(
					'subject' => __( 'Your estimate from {business_name} is ready', 'auto-mation' ),
					'intro'   => __( 'Your estimate for the {vehicle} is ready to view.', 'auto-mation' ),
					'button'  => __( 'View your estimate', 'auto-mation' ),
					'note'    => __( 'You can accept it online in a minute.', 'auto-mation' ),
				),
				AMAC_Channels::SMS   => array(
					'subject' => '',
					'body'    => __( 'Hi {first_name}, your estimate from {business_name} for the {vehicle} is ready. View it here: {doc_link}', 'auto-mation' ),
				),
			),
			'invoice_ready'  => array(
				AMAC_Channels::EMAIL => array(
					'subject' => __( 'Your invoice from {business_name}', 'auto-mation' ),
					'intro'   => __( 'Thanks for choosing us. Your invoice for the {vehicle} is ready.', 'auto-mation' ),
					'button'  => __( 'View and pay your invoice', 'auto-mation' ),
					'note'    => __( 'You can pay securely online by card.', 'auto-mation' ),
				),
				AMAC_Channels::SMS   => array(
					'subject' => '',
					'body'    => __( 'Hi {first_name}, thanks for choosing {business_name}. Your invoice for the {vehicle} is ready - view and pay it here: {doc_link}', 'auto-mation' ),
				),
			),
			// Draft wording (2026-10-09), for the owner to approve.
			'appointment_confirmed' => array(
				AMAC_Channels::EMAIL => array(
					'subject' => __( 'Your appointment with {business_name} is confirmed', 'auto-mation' ),
					'intro'   => __( 'You\'re booked in for your {vehicle}.', 'auto-mation' ),
					'button'  => __( 'View your booking', 'auto-mation' ),
					'note'    => __( 'Need to change it? Just give us a call.', 'auto-mation' ),
				),
				AMAC_Channels::SMS   => array(
					'subject' => '',
					'body'    => __( 'Hi {first_name}, your {vehicle} is booked in with {business_name}: {appointment}. Details: {doc_link}', 'auto-mation' ),
				),
			),
		);
	}

	/**
	 * Option key for one template part.
	 *
	 * @param string $type    Message type slug.
	 * @param string $channel Channel slug.
	 * @param string $part    A part from parts() (or the retired email 'body').
	 * @return string
	 */
	public static function option_key( $type, $channel, $part ) {
		return self::OPTION_PREFIX . $type . '_' . $channel . '_' . $part;
	}

	/**
	 * The stored template part, falling back to the built-in default.
	 *
	 * @param string $type    Message type slug.
	 * @param string $channel Channel slug.
	 * @param string $part    Part slug.
	 * @return string
	 */
	public static function get( $type, $channel, $part ) {
		$stored = get_option( self::option_key( $type, $channel, $part ), null );
		if ( null !== $stored && '' !== $stored ) {
			return (string) $stored;
		}
		return self::default_for( $type, $channel, $part );
	}

	/**
	 * The built-in default for a template part.
	 *
	 * @param string $type    Message type slug.
	 * @param string $channel Channel slug.
	 * @param string $part    Part slug.
	 * @return string
	 */
	public static function default_for( $type, $channel, $part ) {
		$defaults = self::defaults();
		return (string) ( $defaults[ $type ][ $channel ][ $part ] ?? '' );
	}

	/**
	 * Store a template part. Saving a value identical to the default (or blank)
	 * deletes the option instead, so "reset to default" needs no separate
	 * mechanism and the option table doesn't fill with redundant copies.
	 *
	 * @param string $type    Message type slug.
	 * @param string $channel Channel slug.
	 * @param string $part    Part slug.
	 * @param string $value   New text.
	 * @return void
	 */
	public static function save( $type, $channel, $part, $value ) {
		$key   = self::option_key( $type, $channel, $part );
		$value = trim( (string) $value );

		if ( '' === $value || $value === trim( self::default_for( $type, $channel, $part ) ) ) {
			delete_option( $key );
			return;
		}

		update_option( $key, $value, false );
	}

	/**
	 * Substitute tokens into a template.
	 *
	 * Unknown tokens are left as-is rather than blanked, so a typo is visible in
	 * the preview instead of silently producing a gap in a customer's message.
	 * Keys starting with "_" are layout facts, not tokens, and are skipped.
	 *
	 * @param string               $text    Template text.
	 * @param array<string,string> $context Token => replacement (without braces).
	 * @return string
	 */
	public static function substitute( $text, array $context ) {
		$find    = array();
		$replace = array();

		foreach ( $context as $token => $value ) {
			if ( '_' === substr( (string) $token, 0, 1 ) ) {
				continue;
			}
			$find[]    = '{' . $token . '}';
			$replace[] = (string) $value;
		}

		$out = str_replace( $find, $replace, (string) $text );

		// Collapse the runs of blank lines left behind when an optional block
		// (notes) resolved to nothing.
		$out = preg_replace( "/\n{3,}/", "\n\n", $out );

		return trim( (string) $out );
	}

	/**
	 * Render a full message for a type + channel from a token context.
	 *
	 * A text is its one line. An email is the branded layout filled with the
	 * owner's lines, plus a plain-text copy of the same words: `html` is what is
	 * sent, `body` rides along for mail apps without HTML and is what the message
	 * history keeps. Layout facts come from the context's "_"-keys (_facts).
	 *
	 * @param string               $type    Message type slug.
	 * @param string               $channel Channel slug.
	 * @param array<string,mixed>  $context Token => replacement (without braces).
	 * @return array{subject:string,body:string,html?:string}
	 */
	public static function render( $type, $channel, array $context ) {
		$subject = self::substitute( self::get( $type, $channel, 'subject' ), $context );
		if ( AMAC_Channels::EMAIL !== $channel ) {
			return array(
				'subject' => $subject,
				'body'    => self::substitute( self::get( $type, $channel, 'body' ), $context ),
			);
		}

		$intro  = self::substitute( self::get( $type, $channel, 'intro' ), $context );
		$button = self::substitute( self::get( $type, $channel, 'button' ), $context );
		$note   = self::substitute( self::get( $type, $channel, 'note' ), $context );
		$link   = trim( (string) ( $context['doc_link'] ?? '' ) );
		$first  = trim( (string) ( $context['first_name'] ?? '' ) );
		$facts  = array_values( array_filter( array_map( 'trim', (array) ( $context['_facts'] ?? array() ) ), 'strlen' ) );
		$notes  = array_values( array_filter( array( $note ), 'strlen' ) );
		// A new customer's link sets their password first; say so, so the page it
		// opens is not a surprise (not editable - it is about how the link works).
		$first_time = (string) ( self::types()[ $type ]['first_time'] ?? '' );
		// Core says what such a link looks like (since 2.39.0 the portal's own
		// branded page, before that WordPress's wp-login.php?action=rp).
		$sets_password = method_exists( 'AMAT_Portal', 'is_set_password_link' )
			? AMAT_Portal::is_set_password_link( $link )
			: false !== strpos( $link, 'action=rp' );
		if ( '' !== $first_time && $sets_password ) {
			$notes[] = $first_time;
		}
		// The sign-off is the business's name, as on a letter.
		$closing = trim( (string) ( $context['business_name'] ?? '' ) );

		$html = class_exists( 'AMAT_Branded_Email' )
			? AMAT_Branded_Email::html(
				array(
					'first'   => $first,
					'intro'   => $intro,
					'facts'   => $facts,
					'button'  => $button,
					'url'     => $link,
					'notes'   => $notes,
					'closing' => $closing,
				)
			)
			: '';

		/* translators: %s: their first name. */
		$text = array( '' !== $first ? sprintf( __( 'Hi %s,', 'auto-mation' ), $first ) : __( 'Hi,', 'auto-mation' ), $intro );
		if ( $facts ) {
			$text[] = implode( "\n", $facts );
		}
		if ( '' !== $link ) {
			$text[] = $button . ":\n" . $link;
		}
		if ( $notes ) {
			$text[] = implode( "\n", $notes );
		}
		if ( '' !== $closing ) {
			$text[] = $closing;
		}

		return array(
			'subject' => $subject,
			'body'    => trim( implode( "\n\n", array_filter( $text, 'strlen' ) ) ),
			'html'    => $html,
		);
	}
}
