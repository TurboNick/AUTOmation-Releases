<?php
/**
 * Uninstall routine: runs when the plugin is deleted from wp-admin.
 *
 * Unlike deactivation, uninstall is destructive and permanent. It drops the
 * plugin's custom tables, removes its options, and deletes the custom role
 * (§8 of CLAUDE.md). Deactivation leaves data intact.
 *
 * @package AUTOmation
 */

// Only run when WordPress is genuinely uninstalling this plugin.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

global $wpdb;

$prefix = $wpdb->prefix . 'amat_';
$tables = array(
	$prefix . 'logs',
	$prefix . 'external_refs',
	$prefix . 'invoice_items',
	$prefix . 'invoices',
	$prefix . 'estimate_items',
	$prefix . 'estimates',
	$prefix . 'service_records',
	$prefix . 'job_parts',
	$prefix . 'job_services',
	$prefix . 'parts',
	$prefix . 'services',
	$prefix . 'parts_orders',
	$prefix . 'jobs',
	$prefix . 'vehicles',
	$prefix . 'locations',
	$prefix . 'customers',
);

foreach ( $tables as $table ) {
	// Table identifiers cannot be bound via prepare(); they are built from a
	// trusted constant prefix plus a hardcoded suffix, so no user input here.
	$wpdb->query( "DROP TABLE IF EXISTS {$table}" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
}

delete_option( 'amat_db_version' );
delete_option( 'amat_dev_feedback' );
delete_option( 'amat_dev_allow_delete' );
delete_option( 'amat_business_name' );
delete_option( 'amat_log_retention_days' );

// The log's daily prune cron (registered on activation).
wp_clear_scheduled_hook( 'amat_prune_logs' );
delete_option( 'amat_wave_business_id' );
delete_option( 'amat_wave_service_product_id' );
delete_option( 'amat_wave_parts_product_id' );
delete_option( 'amat_wave_estimate_expiry_days' );

// Cached Wave lookups (best-effort; transients also expire on their own).
delete_transient( 'amat_wave_business_id' );
delete_transient( 'amat_wave_businesses' );
delete_transient( 'amat_wave_customers' );
delete_transient( 'amat_wave_products' );

remove_role( 'amat_customer' );
