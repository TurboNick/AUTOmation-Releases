<?php
/**
 * The plugin's event log — write API, secret redaction, and retention.
 *
 * A **generic, append-only** record of things that happened: a provider sync
 * that failed, a VIN decode that came back empty, later a customer email that
 * was sent. Provider-agnostic on purpose (§6) — the Wave companion writes to it
 * through this API, and core never learns what "wave" means.
 *
 * Deliberately **separate from a retry queue**. A log is append-only, immutable
 * and grows forever; a queue is mutable state with a lifecycle that a worker
 * drains. Same table for both jobs makes both worse — so retryable sync state
 * lives on `external_refs` (which already carries `status` + `synced_at`) and
 * the log records *why* something failed, linked by entity.
 *
 * Two rules are enforced here rather than left to callers:
 *
 * 1. **Secrets never land in the log.** `redact()` scrubs anything that looks
 *    like a token/key/password out of the context before it is stored. A log is
 *    read by humans, copied into bug reports and included in backups; an API
 *    token in it is a leak that outlives the request.
 * 2. **The log cannot grow without bound.** Context is size-capped per row, and
 *    a daily cron prunes rows past the retention window.
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Writes to (and prunes) the event log.
 */
class AMAT_Log {

	/**
	 * Option holding the retention window in days. 0 = keep forever.
	 *
	 * @var string
	 */
	const RETENTION_OPTION = 'amat_log_retention_days';

	/**
	 * Default retention window, in days.
	 *
	 * @var int
	 */
	const RETENTION_DEFAULT = 30;

	/**
	 * Cron hook that prunes the log daily.
	 *
	 * @var string
	 */
	const PRUNE_HOOK = 'amat_prune_logs';

	/**
	 * Max characters of encoded context stored per row. A log entry is a
	 * breadcrumb, not an archive: an unbounded blob (say, a whole API response)
	 * would bloat the table and every backup that includes it.
	 *
	 * @var int
	 */
	const CONTEXT_MAX = 20000;

	/**
	 * Context keys whose values are replaced with a placeholder before storage.
	 * Matched case-insensitively as a substring of the key, so `WAVE_API_TOKEN`,
	 * `authorization` and `client_secret` are all caught.
	 *
	 * @var string[]
	 */
	const SECRET_KEYS = array( 'token', 'secret', 'password', 'passwd', 'apikey', 'api_key', 'authorization', 'bearer', 'credential', 'auth' );

	/**
	 * Write a log entry.
	 *
	 * @param string              $level   One of AMAT_Log_Model::LEVELS.
	 * @param string              $channel Source slug, e.g. 'wave', 'vin', 'core'.
	 * @param string              $message Human-readable summary.
	 * @param array<string,mixed> $args    Optional: entity_type, entity_id, context (array).
	 * @return int|false Row id, or false on failure.
	 */
	public static function write( $level, $channel, $message, array $args = array() ) {
		$context = isset( $args['context'] ) && is_array( $args['context'] ) ? self::redact( $args['context'] ) : null;

		$encoded = null;
		if ( null !== $context && array() !== $context ) {
			$encoded = wp_json_encode( $context );
			if ( is_string( $encoded ) && strlen( $encoded ) > self::CONTEXT_MAX ) {
				$encoded = wp_json_encode(
					array(
						'_truncated' => true,
						'_note'      => sprintf( 'Context exceeded %d characters and was dropped.', self::CONTEXT_MAX ),
					)
				);
			}
		}

		return AMAT_Log_Model::create(
			array(
				'level'       => (string) $level,
				'channel'     => (string) $channel,
				'message'     => (string) $message,
				'entity_type' => (string) ( $args['entity_type'] ?? '' ),
				'entity_id'   => (int) ( $args['entity_id'] ?? 0 ),
				'context'     => $encoded,
				'user_id'     => get_current_user_id(),
			)
		);
	}

	/**
	 * Log a debug entry.
	 *
	 * @param string              $channel Source slug.
	 * @param string              $message Message.
	 * @param array<string,mixed> $args    Optional entity_type/entity_id/context.
	 * @return int|false
	 */
	public static function debug( $channel, $message, array $args = array() ) {
		return self::write( 'debug', $channel, $message, $args );
	}

	/**
	 * Log an info entry.
	 *
	 * @param string              $channel Source slug.
	 * @param string              $message Message.
	 * @param array<string,mixed> $args    Optional entity_type/entity_id/context.
	 * @return int|false
	 */
	public static function info( $channel, $message, array $args = array() ) {
		return self::write( 'info', $channel, $message, $args );
	}

	/**
	 * Log a warning entry.
	 *
	 * @param string              $channel Source slug.
	 * @param string              $message Message.
	 * @param array<string,mixed> $args    Optional entity_type/entity_id/context.
	 * @return int|false
	 */
	public static function warning( $channel, $message, array $args = array() ) {
		return self::write( 'warning', $channel, $message, $args );
	}

	/**
	 * Log an error entry.
	 *
	 * @param string              $channel Source slug.
	 * @param string              $message Message.
	 * @param array<string,mixed> $args    Optional entity_type/entity_id/context.
	 * @return int|false
	 */
	public static function error( $channel, $message, array $args = array() ) {
		return self::write( 'error', $channel, $message, $args );
	}

	/**
	 * Recursively replace secret-looking values with a placeholder.
	 *
	 * Key-based, not value-based: we cannot reliably recognise a token by its
	 * shape, but callers name them honestly. Keys are matched as substrings so
	 * `WAVE_API_TOKEN` and `client_secret` are both caught.
	 *
	 * @param array<string,mixed> $context Raw context.
	 * @return array<string,mixed> Context with secrets masked.
	 */
	public static function redact( array $context ) {
		$clean = array();

		foreach ( $context as $key => $value ) {
			if ( is_array( $value ) ) {
				$clean[ $key ] = self::redact( $value );
				continue;
			}

			$clean[ $key ] = self::is_secret_key( (string) $key ) ? '[redacted]' : $value;
		}

		return $clean;
	}

	/**
	 * Whether a context key names a secret.
	 *
	 * @param string $key Context key.
	 * @return bool
	 */
	private static function is_secret_key( $key ) {
		$haystack = strtolower( $key );
		foreach ( self::SECRET_KEYS as $needle ) {
			if ( false !== strpos( $haystack, $needle ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * The configured retention window in days (0 = keep forever).
	 *
	 * @return int
	 */
	public static function retention_days() {
		$days = get_option( self::RETENTION_OPTION, self::RETENTION_DEFAULT );
		if ( '' === $days || null === $days ) {
			return self::RETENTION_DEFAULT;
		}
		return max( 0, (int) $days );
	}

	/**
	 * Prune the log to the retention window. The daily cron callback.
	 *
	 * @return int Rows removed.
	 */
	public static function prune() {
		$days = self::retention_days();
		if ( $days < 1 ) {
			return 0; // Keep forever.
		}
		return AMAT_Log_Model::prune_older_than( $days );
	}

	/**
	 * Ensure the daily prune cron is scheduled. Called on activation.
	 *
	 * @return void
	 */
	public static function schedule_prune() {
		if ( ! wp_next_scheduled( self::PRUNE_HOOK ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', self::PRUNE_HOOK );
		}
	}

	/**
	 * Remove the prune cron. Called on deactivation.
	 *
	 * @return void
	 */
	public static function unschedule_prune() {
		wp_clear_scheduled_hook( self::PRUNE_HOOK );
	}
}
