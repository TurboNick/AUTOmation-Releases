<?php
/**
 * Backup / restore of the plugin's own data as a portable JSON snapshot.
 *
 * Exists so a test run against a real provider sandbox (or a risky schema
 * migration) can be undone: take a snapshot, test destructively, restore.
 *
 * Two deliberate design choices, both worth keeping:
 *
 * 1. **Schema-generic.** The table list is discovered from the database
 *    (`SHOW TABLES LIKE '{prefix}amat_%'`), never hardcoded — so a new table is
 *    covered the moment it exists, and this file needs no edit when the schema
 *    changes. Rows are keyed by the *unprefixed* table slug so a snapshot can be
 *    restored into a site with a different `$wpdb->prefix`. On restore only the
 *    columns that exist in *both* the file and the live table are written, so a
 *    snapshot survives additive column changes.
 * 2. **Never persisted server-side.** A snapshot contains every customer's name,
 *    address, phone and email. It is streamed straight to the browser as a
 *    download and read back from an upload — nothing sensitive is ever written
 *    into wp-content, where a stray URL (or an nginx site, where .htaccess deny
 *    rules do nothing) could expose it.
 *
 * The snapshot is stamped with AMAT_DB_VERSION; restore refuses a mismatch
 * rather than shredding data into a schema it was not taken from.
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Exports and imports the plugin's data as a JSON snapshot.
 */
class AMAT_Backup {

	/**
	 * Marker identifying our own files, so an unrelated JSON upload is rejected
	 * with a useful message instead of a stack trace.
	 *
	 * @var string
	 */
	const FORMAT = 'amat-backup';

	/**
	 * Version of the *envelope* (not the DB schema — that is stamped separately
	 * as db_version). Bump only if the file's shape changes.
	 *
	 * @var int
	 */
	const FORMAT_VERSION = 1;

	/**
	 * Options excluded from a snapshot. The schema version is DB state, not a
	 * user setting: restoring it could silently drive the upgrade routine
	 * backwards. The version we care about is stamped on the envelope instead.
	 *
	 * @var string[]
	 */
	const OPTION_EXCLUDES = array( 'amat_db_version' );

	/**
	 * Every option kept out of a snapshot: the built-in list plus whatever
	 * integrations register on `amat_backup_excluded_options`.
	 *
	 * The filter exists for **secrets**. A snapshot is streamed to the browser and
	 * kept as a file, so anything in it outlives the request and travels — the same
	 * reasoning that makes AMAT_Log redact tokens. A provider that has to fall back
	 * to storing an API token in wp_options (because the host offers no way to keep
	 * a file outside the plugin directory) must be able to say "not this one", and
	 * core must not have to learn any provider's option names to honour it.
	 *
	 * Excluded on the way in as well as out, so a restore never deletes or
	 * overwrites a live credential with one from an older snapshot.
	 *
	 * @return string[]
	 */
	private static function option_excludes() {
		$excludes = (array) apply_filters( 'amat_backup_excluded_options', array() );
		$excludes = array_map( 'strval', $excludes );

		return array_values( array_unique( array_merge( self::OPTION_EXCLUDES, $excludes ) ) );
	}

	/**
	 * The plugin's tables, discovered live, as unprefixed slugs.
	 *
	 * @return string[] e.g. array( 'customers', 'jobs', ... ), sorted.
	 */
	public static function tables() {
		global $wpdb;

		$prefix = $wpdb->prefix . 'amat_';
		$like   = $wpdb->esc_like( $prefix ) . '%';
		// SHOW TABLES LIKE takes the pattern as a value, so it binds safely.
		$found = $wpdb->get_col( $wpdb->prepare( 'SHOW TABLES LIKE %s', $like ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

		$slugs = array();
		foreach ( (array) $found as $table ) {
			$slugs[] = substr( (string) $table, strlen( $prefix ) );
		}
		sort( $slugs );

		return $slugs;
	}

	/**
	 * Build a snapshot of every plugin table (and optionally the amat_* options).
	 *
	 * @param bool $include_options Whether to include the plugin's options.
	 * @return array<string,mixed> The snapshot, ready for wp_json_encode().
	 */
	public static function export( $include_options = true ) {
		global $wpdb;

		$data = array(
			'format'         => self::FORMAT,
			'format_version' => self::FORMAT_VERSION,
			'generated_at'   => gmdate( 'c' ),
			'site_url'       => home_url(),
			'plugin_version' => AMAT_VERSION,
			'db_version'     => AMAT_DB_VERSION,
			'tables'         => array(),
		);

		foreach ( self::tables() as $slug ) {
			$table = $wpdb->prefix . 'amat_' . $slug;
			// Identifier comes from our own SHOW TABLES scan — no user input.
			$rows                    = $wpdb->get_results( "SELECT * FROM {$table}", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery
			$data['tables'][ $slug ] = is_array( $rows ) ? $rows : array();
		}

		if ( $include_options ) {
			$data['options'] = self::export_options();
		}

		return $data;
	}

	/**
	 * The plugin's options, as raw (still-serialized) option_value strings so a
	 * round-trip preserves them byte-for-byte.
	 *
	 * Transients are not matched: WordPress stores them as `_transient_amat_*`,
	 * which does not start with `amat_`. That is deliberate — they are caches.
	 *
	 * @return array<string,string>
	 */
	private static function export_options() {
		global $wpdb;

		$like = $wpdb->esc_like( 'amat_' ) . '%';
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT option_name, option_value FROM {$wpdb->options} WHERE option_name LIKE %s", $like ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

		$excludes = self::option_excludes();
		$options  = array();
		foreach ( (array) $rows as $row ) {
			$name = (string) $row['option_name'];
			if ( in_array( $name, $excludes, true ) ) {
				continue;
			}
			$options[ $name ] = (string) $row['option_value'];
		}

		return $options;
	}

	/**
	 * Validate a decoded snapshot before it is allowed anywhere near the data.
	 *
	 * @param mixed $data Decoded JSON.
	 * @return true|WP_Error
	 */
	public static function validate( $data ) {
		if ( ! is_array( $data ) ) {
			return new WP_Error( 'amat_backup_format', __( 'That file is not a valid backup (it is not JSON).', 'auto-mation' ) );
		}
		if ( ! isset( $data['format'] ) || self::FORMAT !== $data['format'] ) {
			return new WP_Error( 'amat_backup_format', __( 'That file is not an AUTOmation backup.', 'auto-mation' ) );
		}
		if ( ! isset( $data['tables'] ) || ! is_array( $data['tables'] ) ) {
			return new WP_Error( 'amat_backup_format', __( 'That backup file has no table data in it.', 'auto-mation' ) );
		}

		$db_version = isset( $data['db_version'] ) ? (string) $data['db_version'] : '';
		if ( $db_version !== (string) AMAT_DB_VERSION ) {
			return new WP_Error(
				'amat_backup_db_version',
				sprintf(
					/* translators: 1: backup's DB schema version, 2: the current DB schema version. */
					__( 'That backup was taken on database schema v%1$s but this install is on v%2$s. Restoring it could corrupt your data, so it was refused.', 'auto-mation' ),
					$db_version ? $db_version : '?',
					AMAT_DB_VERSION
				)
			);
		}

		return true;
	}

	/**
	 * Restore a validated snapshot, replacing the current data.
	 *
	 * Wrapped in a transaction and using DELETE rather than TRUNCATE: TRUNCATE
	 * forces an implicit commit in MySQL, which would leave a half-restored
	 * database if a later insert failed. With DELETE the whole restore is
	 * all-or-nothing on InnoDB. Explicit ids are written, so AUTO_INCREMENT
	 * follows the restored rows.
	 *
	 * @param array<string,mixed> $data            A snapshot that passed validate().
	 * @param bool                $include_options Whether to restore amat_* options too.
	 * @return array{tables:int,rows:int,options:int}|WP_Error Counts actually written.
	 */
	public static function import( array $data, $include_options = true ) {
		global $wpdb;

		$valid = self::validate( $data );
		if ( is_wp_error( $valid ) ) {
			return $valid;
		}

		$live    = self::tables();
		$tables  = 0;
		$rows    = 0;
		$skipped = array();

		$wpdb->query( 'START TRANSACTION' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

		foreach ( $data['tables'] as $slug => $table_rows ) {
			$slug = (string) $slug;
			// Only touch tables this install actually has: a snapshot from an
			// install with an extra table must not blow up the restore.
			if ( ! in_array( $slug, $live, true ) ) {
				$skipped[] = $slug;
				continue;
			}

			$table   = $wpdb->prefix . 'amat_' . $slug;
			$columns = self::columns( $table );

			// Identifier from our own SHOW TABLES scan; DELETE keeps the
			// transaction intact where TRUNCATE would commit it.
			$wpdb->query( "DELETE FROM {$table}" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery
			++$tables;

			foreach ( (array) $table_rows as $row ) {
				if ( ! is_array( $row ) ) {
					continue;
				}
				// Intersect with the live columns so a snapshot taken before an
				// additive column change still restores (the new column takes
				// its default) and a stale column is dropped rather than fatal.
				$insert = array_intersect_key( $row, array_flip( $columns ) );
				if ( empty( $insert ) ) {
					continue;
				}
				$ok = $wpdb->insert( $table, $insert ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
				if ( false === $ok ) {
					$wpdb->query( 'ROLLBACK' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
					return new WP_Error(
						'amat_backup_insert',
						sprintf(
							/* translators: 1: table name, 2: database error text. */
							__( 'Restore failed while writing to %1$s (%2$s). Nothing was changed.', 'auto-mation' ),
							$slug,
							$wpdb->last_error ? $wpdb->last_error : __( 'unknown error', 'auto-mation' )
						)
					);
				}
				++$rows;
			}
		}

		$options = 0;
		if ( $include_options && isset( $data['options'] ) && is_array( $data['options'] ) ) {
			$options = self::import_options( $data['options'] );
		}

		$wpdb->query( 'COMMIT' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

		return array(
			'tables'  => $tables,
			'rows'    => $rows,
			'options' => $options,
			'skipped' => $skipped,
		);
	}

	/**
	 * Replace the plugin's options with the snapshot's set.
	 *
	 * A true restore, not a merge: options present now but absent from the
	 * snapshot are removed, so the result matches the moment of the backup.
	 *
	 * @param array<string,string> $options Raw option_name => option_value pairs.
	 * @return int Number of options written.
	 */
	private static function import_options( array $options ) {
		global $wpdb;

		$like    = $wpdb->esc_like( 'amat_' ) . '%';
		$current = $wpdb->get_col( $wpdb->prepare( "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s", $like ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

		$excludes = self::option_excludes();

		foreach ( (array) $current as $name ) {
			if ( in_array( $name, $excludes, true ) ) {
				continue;
			}
			delete_option( $name );
		}

		$written = 0;
		foreach ( $options as $name => $value ) {
			$name = (string) $name;
			if ( in_array( $name, $excludes, true ) || 0 !== strpos( $name, 'amat_' ) ) {
				continue;
			}
			// Values were stored raw (still serialized); unserialize so
			// update_option() re-serializes exactly once.
			update_option( $name, maybe_unserialize( $value ) );
			++$written;
		}

		return $written;
	}

	/**
	 * Column names of a table.
	 *
	 * @param string $table Fully-qualified table name.
	 * @return string[]
	 */
	private static function columns( $table ) {
		global $wpdb;

		// Identifier from our own SHOW TABLES scan — no user input.
		$rows = $wpdb->get_results( "SHOW COLUMNS FROM {$table}", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery

		$columns = array();
		foreach ( (array) $rows as $row ) {
			if ( isset( $row['Field'] ) ) {
				$columns[] = (string) $row['Field'];
			}
		}

		return $columns;
	}

	/**
	 * Filename for a downloaded snapshot, stamped so several are distinguishable.
	 *
	 * @return string
	 */
	public static function filename() {
		return 'automation-backup-' . gmdate( 'Ymd-His' ) . '.json';
	}
}
