<?php
/**
 * Money helpers.
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Small shared helpers for storing and displaying prices, so services, parts,
 * estimates, and invoices format money the same way. Prices are stored as
 * DECIMAL(10,2) with NULL meaning "unset" (distinct from $0.00).
 */
class AMAT_Money {

	/**
	 * Normalize a raw price input for storage: NULL when blank, else a 2-decimal
	 * numeric string. Mirrors AMAT_Service_Model's price handling.
	 *
	 * @param mixed $raw Raw input.
	 * @return string|null
	 */
	public static function sanitize( $raw ) {
		$value = trim( (string) $raw );
		if ( '' === $value ) {
			return null;
		}
		return number_format( (float) $value, 2, '.', '' );
	}

	/**
	 * Format a stored price for display (e.g. "$45.00"), or '' when unset.
	 *
	 * @param mixed $price Stored price (null when unset).
	 * @return string
	 */
	public static function format( $price ) {
		if ( null === $price || '' === $price ) {
			return '';
		}
		return '$' . number_format( (float) $price, 2 );
	}

	/**
	 * Format a computed amount that is always present (e.g. a line/total), so
	 * even $0.00 renders rather than coming back blank.
	 *
	 * @param mixed $amount Numeric amount.
	 * @return string
	 */
	public static function format_amount( $amount ) {
		return '$' . number_format( (float) $amount, 2 );
	}

	/**
	 * Format a stored quantity for display, trimming trailing zeros ("1", "2.5"),
	 * or '' when unset. Shared by services/parts defaults and line items.
	 *
	 * @param mixed $qty Stored quantity (null when unset).
	 * @return string
	 */
	public static function quantity( $qty ) {
		if ( null === $qty || '' === $qty ) {
			return '';
		}
		return rtrim( rtrim( number_format( (float) $qty, 2 ), '0' ), '.' );
	}
}
