<?php
/**
 * NHTSA vPIC VIN decoder. ALL vPIC API calls live here.
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Decodes a VIN into vehicle spec fields via the free NHTSA vPIC API.
 *
 * Per §7 of CLAUDE.md: send the model year to disambiguate the 30-year VIN
 * cycle, parse Results[0], and map vPIC fields to our vehicles columns. The
 * caller caches the result on the vehicle row — do NOT call on every page
 * load. Every field may be empty and is user-overridable. Color is not
 * VIN-decodable and is entered manually.
 */
class AMAT_Vin_Decoder {

	/**
	 * vPIC DecodeVinValues endpoint (note: /api/, not the /decoder/ web page).
	 *
	 * @var string
	 */
	const ENDPOINT = 'https://vpic.nhtsa.dot.gov/api/vehicles/DecodeVinValues/';

	/**
	 * Map of our `vehicles` column => vPIC Results field (§4/§7).
	 *
	 * @var array<string,string>
	 */
	const FIELD_MAP = array(
		'year'                => 'ModelYear',
		'make'                => 'Make',
		'model'               => 'Model',
		'trim'                => 'Trim',
		'series'              => 'Series',
		'body_type'           => 'BodyClass',
		'engine_displacement' => 'DisplacementL',
		'engine_cylinders'    => 'EngineCylinders',
		'fuel_type_primary'   => 'FuelTypePrimary',
		'fuel_type_secondary' => 'FuelTypeSecondary',
		'drive_type'          => 'DriveType',
		'transmission_type'   => 'TransmissionStyle',
		'transmission_speeds' => 'TransmissionSpeeds',
	);

	/**
	 * Characters a VIN can never contain (they'd be confused with 1/0).
	 *
	 * @var string
	 */
	const ILLEGAL_CHARS = 'IOQ';

	/**
	 * Full VIN length.
	 *
	 * @var int
	 */
	const VIN_LENGTH = 17;

	/**
	 * Uppercase a VIN and drop separators/whitespace.
	 *
	 * @param string $vin Raw VIN as typed.
	 * @return string
	 */
	public static function normalize( $vin ) {
		return strtoupper( preg_replace( '/[^A-Za-z0-9]/', '', (string) $vin ) );
	}

	/**
	 * Validate a VIN locally, before spending a round trip on vPIC.
	 *
	 * Fatal problems (empty, illegal characters, over-length) come back as a
	 * WP_Error. Survivable ones (a partial VIN, a check digit that doesn't
	 * calculate) come back as a list of human-readable notes — vPIC decodes
	 * these anyway, and a mechanic reading a VIN off a dirty door jamb often
	 * has good reason to push a partial through.
	 *
	 * @param string $vin Normalized VIN.
	 * @return array<int,string>|WP_Error Notes (possibly empty), or a fatal error.
	 */
	public static function validate( $vin ) {
		$vin = self::normalize( $vin );

		if ( '' === $vin ) {
			return new WP_Error( 'amat_vin_empty', __( 'A VIN is required to decode.', 'auto-mation' ) );
		}

		$bad = array();
		foreach ( str_split( self::ILLEGAL_CHARS ) as $char ) {
			if ( false !== strpos( $vin, $char ) ) {
				$bad[] = $char;
			}
		}
		if ( $bad ) {
			return new WP_Error(
				'amat_vin_chars',
				sprintf(
					/* translators: %s: comma-separated list of illegal characters found in the VIN. */
					__( 'A VIN never contains the letters I, O or Q (found: %s) — they are easily confused with 1 and 0. Check the entry.', 'auto-mation' ),
					implode( ', ', $bad )
				)
			);
		}

		$len = strlen( $vin );
		if ( $len > self::VIN_LENGTH ) {
			return new WP_Error(
				'amat_vin_long',
				sprintf(
					/* translators: 1: number of characters entered, 2: the correct VIN length (17). */
					__( 'That VIN is %1$d characters — a VIN is %2$d.', 'auto-mation' ),
					$len,
					self::VIN_LENGTH
				)
			);
		}

		$notes = array();
		if ( $len < self::VIN_LENGTH ) {
			$notes[] = sprintf(
				/* translators: 1: number of characters entered, 2: the full VIN length (17). */
				__( 'Partial VIN — %1$d of %2$d characters. vPIC decoded what it could; the year and trim are often missing.', 'auto-mation' ),
				$len,
				self::VIN_LENGTH
			);
		} elseif ( ! self::check_digit_ok( $vin ) ) {
			$notes[] = __( 'The check digit (9th character) does not calculate — the VIN is probably mistyped. Decoded data may be for a different vehicle.', 'auto-mation' );
		}

		return $notes;
	}

	/**
	 * Verify a full VIN's check digit (9th character) per ISO 3779.
	 *
	 * Each character is transliterated to a value, multiplied by its position
	 * weight, summed, and taken mod 11; the remainder (10 = "X") must equal the
	 * 9th character. A mistyped character almost always breaks this.
	 *
	 * @param string $vin Normalized, 17-character VIN.
	 * @return bool True when the check digit matches (or the VIN isn't 17 chars).
	 */
	public static function check_digit_ok( $vin ) {
		$vin = self::normalize( $vin );
		if ( self::VIN_LENGTH !== strlen( $vin ) ) {
			return true; // Not our call to make on a partial VIN.
		}

		$values  = array(
			'A' => 1,
			'B' => 2,
			'C' => 3,
			'D' => 4,
			'E' => 5,
			'F' => 6,
			'G' => 7,
			'H' => 8,
			'J' => 1,
			'K' => 2,
			'L' => 3,
			'M' => 4,
			'N' => 5,
			'P' => 7,
			'R' => 9,
			'S' => 2,
			'T' => 3,
			'U' => 4,
			'V' => 5,
			'W' => 6,
			'X' => 7,
			'Y' => 8,
			'Z' => 9,
		);
		$weights = array( 8, 7, 6, 5, 4, 3, 2, 10, 0, 9, 8, 7, 6, 5, 4, 3, 2 );

		$sum = 0;
		for ( $i = 0; $i < self::VIN_LENGTH; $i++ ) {
			$char = $vin[ $i ];
			if ( ctype_digit( $char ) ) {
				$value = (int) $char;
			} elseif ( isset( $values[ $char ] ) ) {
				$value = $values[ $char ];
			} else {
				return false; // An illegal letter (I/O/Q) can never check out.
			}
			$sum += $value * $weights[ $i ];
		}

		$remainder = $sum % 11;
		$expected  = ( 10 === $remainder ) ? 'X' : (string) $remainder;

		return $vin[8] === $expected;
	}

	/**
	 * Decode a VIN and return values keyed by our `vehicles` columns.
	 *
	 * Thin wrapper over decode_full() for callers that only want the field map
	 * (the save paths); the admin AJAX endpoint uses decode_full() so it can
	 * report *how well* the decode went.
	 *
	 * @param string   $vin   17-character VIN (shorter is accepted by vPIC,
	 *                        which fills what it can).
	 * @param int|null $year  Model year; strongly recommended (§7).
	 * @return array<string,string>|WP_Error Column => value map, or WP_Error.
	 */
	public function decode( $vin, $year = null ) {
		$result = $this->decode_full( $vin, $year );

		return is_wp_error( $result ) ? $result : $result['fields'];
	}

	/**
	 * Decode a VIN and report both the fields and the quality of the decode.
	 *
	 * vPIC answers HTTP 200 for anything — a clean VIN, a mistyped one, and a
	 * string of Z's all "succeed" — and reports what actually happened in the
	 * row's ErrorCode/ErrorText. So a decode is only clean when vPIC says code
	 * 0 AND the row carries real vehicle data; otherwise we hand the caller
	 * vPIC's own wording (it is written for humans) to show the user.
	 *
	 * @param string   $vin  VIN as typed (normalized here).
	 * @param int|null $year Model year; strongly recommended (§7).
	 * @return array<string,mixed>|WP_Error {
	 *     @type array<string,string> $fields        Column => value map.
	 *     @type string               $vin           The normalized VIN.
	 *     @type string               $level         'ok' | 'warning' | 'error'.
	 *     @type string               $message       One-line headline for the user.
	 *     @type array<int,string>    $notes         Specifics (ours + vPIC's).
	 *     @type string               $suggested_vin vPIC's correction, if any.
	 * }
	 */
	public function decode_full( $vin, $year = null ) {
		$vin   = self::normalize( $vin );
		$check = self::validate( $vin );
		if ( is_wp_error( $check ) ) {
			return $check; // Unusable — don't spend a round trip on it.
		}

		// validate()'s *survivable* notes (incomplete VIN, check digit) are only
		// for pre-flight feedback in the form: vPIC re-reports both conditions
		// itself, so from here on it does the talking and we don't say it twice.
		$notes = array();

		$args = array( 'format' => 'json' );
		if ( $year ) {
			$args['modelyear'] = absint( $year );
		}
		$url = add_query_arg( $args, self::ENDPOINT . rawurlencode( $vin ) );

		$response = wp_remote_get( $url, array( 'timeout' => 20 ) );
		if ( is_wp_error( $response ) ) {
			$this->log( 'HTTP transport error: ' . $response->get_error_message() );
			return $response;
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		if ( 200 !== $code ) {
			$this->log( 'Non-200 from vPIC: HTTP ' . $code );
			return new WP_Error(
				'amat_vin_http',
				/* translators: %d: HTTP status code. */
				sprintf( __( 'VIN decoder returned HTTP %d.', 'auto-mation' ), $code )
			);
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		$row  = $body['Results'][0] ?? null;
		if ( ! is_array( $row ) ) {
			$this->log( 'Unexpected vPIC response shape.' );
			return new WP_Error( 'amat_vin_bad_body', __( 'Could not parse the VIN decoder response.', 'auto-mation' ) );
		}

		$mapped = array();
		foreach ( self::FIELD_MAP as $column => $vpic_field ) {
			$value = isset( $row[ $vpic_field ] ) ? trim( (string) $row[ $vpic_field ] ) : '';
			// vPIC uses placeholder strings for "no data"; treat them as empty.
			if ( in_array( strtolower( $value ), array( 'not applicable', '0', 'null' ), true ) ) {
				$value = '';
			}
			$mapped[ $column ] = $value;
		}

		// vPIC reports what went wrong in the row, not in the HTTP status: a
		// semicolon-separated ErrorText, each entry prefixed with its code.
		// "0 - VIN decoded clean…" is the all-good entry — drop it and keep the rest.
		foreach ( explode( ';', (string) ( $row['ErrorText'] ?? '' ) ) as $entry ) {
			$entry = trim( $entry );
			if ( '' === $entry || 0 === strpos( $entry, '0 - ' ) ) {
				continue;
			}
			$notes[] = $entry;
		}

		$additional = trim( (string) ( $row['AdditionalErrorText'] ?? '' ) );
		if ( '' !== $additional ) {
			$notes[] = $additional;
		}

		$suggested = trim( (string) ( $row['SuggestedVIN'] ?? '' ) );
		if ( '' !== $suggested ) {
			$notes[] = sprintf(
				/* translators: %s: the VIN vPIC suggests instead (may contain ! for unresolvable positions). */
				__( 'vPIC suggests this VIN instead: %s', 'auto-mation' ),
				$suggested
			);
		}

		// "Did we actually identify a vehicle?" is the question that matters — a
		// garbage VIN still comes back 200 with every field empty.
		$identified = ( '' !== $mapped['make'] || '' !== $mapped['model'] || '' !== $mapped['year'] );

		if ( ! $identified ) {
			$level   = 'error';
			$message = __( 'No vehicle data found for that VIN.', 'auto-mation' );
		} elseif ( $notes ) {
			$level   = 'warning';
			$message = __( 'Decoded, with warnings — check the fields below.', 'auto-mation' );
		} else {
			$level   = 'ok';
			$message = __( 'Decoded ✓', 'auto-mation' );
		}

		if ( 'ok' !== $level ) {
			$this->log( sprintf( '%s decode of %s: %s', $level, $vin, implode( ' | ', $notes ) ) );
		}

		return array(
			'fields'        => $mapped,
			'vin'           => $vin,
			'level'         => $level,
			'message'       => $message,
			'notes'         => $notes,
			'suggested_vin' => $suggested,
		);
	}

	/**
	 * Write a message to the error log, namespaced for grep-ability.
	 *
	 * @param string $message Message to record.
	 * @return void
	 */
	private function log( $message ) {
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			error_log( '[AUTOmation VIN] ' . $message ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
		}
	}
}
