<?php
/**
 * Registry of contact-method types and their validation/formatting rules.
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Defines the available contact-method types in ONE place.
 *
 * The built-in types (Call/TXT, TXT/Call, Call Only, Email) are hard-coded here
 * for now, with a Settings-driven registry deferred to a later increment (§11).
 * Three are phone-based (see phone_types()); Email is the lone non-phone type.
 * Keep this the single source of truth: validation, formatting, and labels all
 * flow from definitions(), so adding a type later (or swapping in an
 * options-backed registry) only changes this file.
 */
class AMAT_Contact_Method_Types {

	/**
	 * Max stored length for a contact value (matches the column width).
	 *
	 * @var int
	 */
	const MAX_VALUE_LENGTH = 191;

	/**
	 * Type definitions keyed by slug.
	 *
	 * Each: label, input_type (HTML input type for the form), placeholder.
	 *
	 * @return array<string,array<string,string>>
	 */
	public static function definitions() {
		return array(
			'call_text' => array(
				'label'       => __( 'Call/TXT', 'auto-mation' ),
				'input_type'  => 'tel',
				'placeholder' => '555-444-3333',
			),
			'text_call' => array(
				'label'       => __( 'TXT/Call', 'auto-mation' ),
				'input_type'  => 'tel',
				'placeholder' => '555-444-3333',
			),
			'call_only' => array(
				'label'       => __( 'Call Only', 'auto-mation' ),
				'input_type'  => 'tel',
				'placeholder' => '555-444-3333',
			),
			'email'     => array(
				'label'       => __( 'Email', 'auto-mation' ),
				'input_type'  => 'email',
				'placeholder' => 'name@example.com',
			),
		);
	}

	/**
	 * Type slugs that hold a phone number (all but email). Validation, formatting,
	 * and the live phone mask key off this.
	 *
	 * @return string[]
	 */
	public static function phone_types() {
		return array( 'call_text', 'text_call', 'call_only' );
	}

	/**
	 * Whether a type slug holds a phone number.
	 *
	 * @param string $type Type slug.
	 * @return bool
	 */
	public static function is_phone_type( $type ) {
		return in_array( $type, self::phone_types(), true );
	}

	/**
	 * Whether a type slug is known/allowed.
	 *
	 * @param string $type Type slug.
	 * @return bool
	 */
	public static function is_valid_type( $type ) {
		return array_key_exists( $type, self::definitions() );
	}

	/**
	 * Human label for a type slug (falls back to the slug).
	 *
	 * @param string $type Type slug.
	 * @return string
	 */
	public static function label( $type ) {
		$defs = self::definitions();
		return $defs[ $type ]['label'] ?? $type;
	}

	/**
	 * Validate and normalize a raw value for a given type.
	 *
	 * Returns the value to STORE (normalized) on success, or a WP_Error whose
	 * message is suitable for display. Phone types normalize to 10 digits;
	 * email is lower-cased and format-checked. All values are length-capped.
	 *
	 * @param string $type Type slug.
	 * @param string $raw  Raw user input.
	 * @return string|WP_Error Normalized value to store, or WP_Error.
	 */
	public static function validate( $type, $raw ) {
		$raw = trim( (string) $raw );

		if ( ! self::is_valid_type( $type ) ) {
			return new WP_Error( 'amat_cm_type', __( 'Unknown contact method type.', 'auto-mation' ) );
		}

		if ( '' === $raw ) {
			return new WP_Error( 'amat_cm_empty', __( 'Contact value cannot be empty.', 'auto-mation' ) );
		}

		if ( strlen( $raw ) > self::MAX_VALUE_LENGTH ) {
			return new WP_Error(
				'amat_cm_length',
				/* translators: %d: maximum length. */
				sprintf( __( 'Value is too long (max %d characters).', 'auto-mation' ), self::MAX_VALUE_LENGTH )
			);
		}

		if ( 'email' === $type ) {
			$email = sanitize_email( $raw );
			if ( ! is_email( $email ) ) {
				return new WP_Error( 'amat_cm_email', __( 'Enter a valid email address.', 'auto-mation' ) );
			}
			return strtolower( $email );
		}

		if ( self::is_phone_type( $type ) ) {
			$digits = preg_replace( '/\D+/', '', $raw );
			// Allow a leading US country code.
			if ( 11 === strlen( $digits ) && '1' === $digits[0] ) {
				$digits = substr( $digits, 1 );
			}
			if ( 10 !== strlen( $digits ) ) {
				return new WP_Error( 'amat_cm_phone', __( 'Enter a 10-digit US phone number (digits only or with dashes).', 'auto-mation' ) );
			}
			return $digits;
		}

		return sanitize_text_field( $raw );
	}

	/**
	 * Build a clickable href for a stored value (tel: / mailto:).
	 *
	 * @param string $type  Type slug.
	 * @param string $value Stored (normalized) value.
	 * @return string href, or '' if the type isn't linkable.
	 */
	public static function href( $type, $value ) {
		$value = (string) $value;

		if ( 'email' === $type ) {
			return '' !== $value ? 'mailto:' . $value : '';
		}

		if ( self::is_phone_type( $type ) ) {
			$digits = preg_replace( '/\D+/', '', $value );
			if ( '' === $digits ) {
				return '';
			}
			// A text-primary number taps to compose a text; the rest tap to call.
			return ( 'text_call' === $type ? 'sms:+1' : 'tel:+1' ) . $digits;
		}

		return '';
	}

	/**
	 * Format a stored value for display.
	 *
	 * @param string $type  Type slug.
	 * @param string $value Stored (normalized) value.
	 * @return string Pretty value, e.g. 555-444-3333.
	 */
	public static function format( $type, $value ) {
		$value = (string) $value;

		if ( self::is_phone_type( $type ) && 10 === strlen( $value ) ) {
			return substr( $value, 0, 3 ) . '-' . substr( $value, 3, 3 ) . '-' . substr( $value, 6 );
		}

		return $value;
	}
}
