<?php
/**
 * Plugin deactivation.
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handles cleanup on deactivation.
 *
 * Deactivation is reversible, so it must NOT drop tables or delete data —
 * that belongs in uninstall.php. Use this only for transient/scheduled-event
 * cleanup so reactivating restores the plugin intact.
 */
class AMAT_Deactivator {

	/**
	 * Run on plugin deactivation.
	 *
	 * @return void
	 */
	public static function deactivate() {
		// Clear the plugin's scheduled cron events. The log rows themselves stay
		// (deactivation is reversible; dropping them belongs in uninstall.php) —
		// only the recurring prune stops. Reactivating re-schedules it.
		AMAT_Log::unschedule_prune();

		// Placeholder hook from before any real cron existed; harmless to clear.
		wp_clear_scheduled_hook( 'amat_daily_maintenance' );

		flush_rewrite_rules();
	}
}
