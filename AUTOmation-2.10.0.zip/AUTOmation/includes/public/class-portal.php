<?php
/**
 * Front-end customer portal (stub).
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Front-end portal where customers manage their account.
 *
 * Per §1 of CLAUDE.md, logged-in customers can view/update contact info, view
 * vehicles and service history, view/approve estimates, view/pay invoices
 * (via Wave's hosted pages — no payment UI here, §9), and request service.
 *
 * Auth model (§4): each customer is linked to a WordPress user with a
 * dedicated `amat_customer` role via customers.wp_user_id. Magic-link login
 * is a Future Feature (§11).
 *
 * This is a stub: it registers the portal hook surface so later increments
 * can fill in the account/vehicles/scheduling screens.
 */
class AMAT_Portal {

	/**
	 * Custom role slug for portal customers.
	 *
	 * @var string
	 */
	const ROLE = 'amat_customer';

	/**
	 * Hook front-end behavior.
	 *
	 * @return void
	 */
	public function register() {
		// Portal routing, shortcodes, and template handling are added in a
		// later increment. Intentionally minimal for now.
	}

	/**
	 * Ensure the customer role exists. Called from activation.
	 *
	 * A minimal role: portal customers can read their own data through the
	 * plugin but have no wp-admin capabilities.
	 *
	 * @return void
	 */
	public static function add_role() {
		if ( null === get_role( self::ROLE ) ) {
			add_role( self::ROLE, __( 'Customer', 'auto-mation' ), array( 'read' => true ) );
		}
	}
}
