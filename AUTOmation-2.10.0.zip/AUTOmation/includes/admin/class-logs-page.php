<?php
/**
 * Logs page: a read-only viewer for the plugin's event log.
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Renders the event log with level/channel filters and paging.
 *
 * Read-only by design: the log is append-only, so there is nothing to edit —
 * the only writes here are retention settings and a manual purge, both posted
 * to admin-post.php (handled in AMAT_Admin, next to the other Settings actions).
 */
class AMAT_Logs_Page extends AMAT_Admin_Page {

	const NONCE_ACTION = 'amat_logs';
	const PAGE_SLUG    = 'amat-logs';
	const POST_ACTION  = 'amat_logs';

	/**
	 * Rows shown per page.
	 *
	 * @var int
	 */
	const PER_PAGE = 50;

	/**
	 * The log is append-only: nothing on this page saves a record.
	 *
	 * Required by AMAT_Admin_Page. Never triggered — no form here issues this
	 * page's nonce (retention/purge post to admin-post.php instead).
	 *
	 * @return array{status:string,message:string}
	 */
	protected function save() {
		return array( 'status' => 'error', 'message' => __( 'The log is read-only.', 'auto-mation' ) );
	}

	/**
	 * Render the log viewer.
	 *
	 * @return void
	 */
	public function render() {
		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'auto-mation' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only list filters, no state change.
		$level   = isset( $_GET['level'] ) ? sanitize_key( wp_unslash( $_GET['level'] ) ) : '';
		$channel = isset( $_GET['channel'] ) ? sanitize_key( wp_unslash( $_GET['channel'] ) ) : '';
		$paged   = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1;
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		if ( ! in_array( $level, AMAT_Log_Model::LEVELS, true ) ) {
			$level = '';
		}
		$channels = AMAT_Log_Model::channels();
		if ( ! in_array( $channel, $channels, true ) ) {
			$channel = '';
		}

		$where = array();
		if ( '' !== $level ) {
			$where['level'] = $level;
		}
		if ( '' !== $channel ) {
			$where['channel'] = $channel;
		}

		$total = AMAT_Log_Model::count_filtered( $level, $channel );
		$pages = max( 1, (int) ceil( $total / self::PER_PAGE ) );
		$paged = min( $paged, $pages );

		$rows = AMAT_Log_Model::all(
			$where,
			array(
				'orderby' => 'id',
				'order'   => 'DESC',
				'limit'   => self::PER_PAGE,
				'offset'  => ( $paged - 1 ) * self::PER_PAGE,
			)
		);

		$flash   = $this->take_flash();
		$success = ( $flash && 'success' === $flash['status'] ) ? $flash['message'] : '';
		$error   = ( $flash && 'error' === $flash['status'] ) ? $flash['message'] : '';
		?>
		<div class="wrap">
			<h1 class="wp-heading-inline"><?php esc_html_e( 'Logs', 'auto-mation' ); ?></h1>
			<hr class="wp-header-end" />

			<?php if ( $success ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php echo esc_html( $success ); ?></p></div>
			<?php endif; ?>
			<?php if ( $error ) : ?>
				<div class="notice notice-error is-dismissible"><p><?php echo esc_html( $error ); ?></p></div>
			<?php endif; ?>

			<p class="description">
				<?php esc_html_e( 'What the plugin has been doing: integration syncs, lookups, and errors. Useful when something did not reach an external system and you want to know why.', 'auto-mation' ); ?>
			</p>

			<div class="amat-list-bar">
				<form method="get" class="amat-search-form">
					<input type="hidden" name="page" value="<?php echo esc_attr( self::PAGE_SLUG ); ?>" />
					<select name="level">
						<option value=""><?php esc_html_e( 'All levels', 'auto-mation' ); ?></option>
						<?php foreach ( AMAT_Log_Model::LEVELS as $slug ) : ?>
							<option value="<?php echo esc_attr( $slug ); ?>" <?php selected( $slug, $level ); ?>><?php echo esc_html( self::level_label( $slug ) ); ?></option>
						<?php endforeach; ?>
					</select>
					<select name="channel">
						<option value=""><?php esc_html_e( 'All sources', 'auto-mation' ); ?></option>
						<?php foreach ( $channels as $slug ) : ?>
							<option value="<?php echo esc_attr( $slug ); ?>" <?php selected( $slug, $channel ); ?>><?php echo esc_html( $slug ); ?></option>
						<?php endforeach; ?>
					</select>
					<?php submit_button( __( 'Filter', 'auto-mation' ), '', '', false ); ?>
				</form>
			</div>

			<table class="wp-list-table widefat fixed striped">
				<thead>
					<tr>
						<th class="amat-col-when"><?php esc_html_e( 'When', 'auto-mation' ); ?></th>
						<th class="amat-col-level"><?php esc_html_e( 'Level', 'auto-mation' ); ?></th>
						<th class="amat-col-level"><?php esc_html_e( 'Source', 'auto-mation' ); ?></th>
						<th><?php esc_html_e( 'Message', 'auto-mation' ); ?></th>
						<th class="amat-col-level"><?php esc_html_e( 'Record', 'auto-mation' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php if ( empty( $rows ) ) : ?>
						<tr><td colspan="5"><?php esc_html_e( 'Nothing logged yet.', 'auto-mation' ); ?></td></tr>
					<?php else : ?>
						<?php foreach ( $rows as $row ) : ?>
							<?php
							$context = ! empty( $row['context'] ) ? json_decode( (string) $row['context'], true ) : null;
							$entity  = trim( (string) $row['entity_type'] );
							?>
							<tr class="amat-log-row amat-log-<?php echo esc_attr( $row['level'] ); ?>">
								<td><?php echo esc_html( self::when( $row['created_at'] ) ); ?></td>
								<td><span class="amat-status amat-log-badge-<?php echo esc_attr( $row['level'] ); ?>"><?php echo esc_html( self::level_label( $row['level'] ) ); ?></span></td>
								<td><?php echo esc_html( $row['channel'] ); ?></td>
								<td>
									<?php echo esc_html( (string) $row['message'] ); ?>
									<?php if ( is_array( $context ) && $context ) : ?>
										<details class="amat-log-context">
											<summary><?php esc_html_e( 'details', 'auto-mation' ); ?></summary>
											<pre><?php echo esc_html( wp_json_encode( $context, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) ); ?></pre>
										</details>
									<?php endif; ?>
								</td>
								<td><?php echo $entity ? esc_html( $entity . ' #' . (int) $row['entity_id'] ) : '—'; ?></td>
							</tr>
						<?php endforeach; ?>
					<?php endif; ?>
				</tbody>
			</table>

			<?php if ( $pages > 1 ) : ?>
				<div class="tablenav"><div class="tablenav-pages">
					<?php
					echo paginate_links( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- paginate_links() escapes its own output.
						array(
							'base'      => add_query_arg( 'paged', '%#%' ),
							'format'    => '',
							'prev_text' => '&laquo;',
							'next_text' => '&raquo;',
							'total'     => $pages,
							'current'   => $paged,
						)
					);
					?>
				</div></div>
			<?php endif; ?>

			<?php
			/* translators: %d: total number of matching log entries. */
			printf( '<p class="description">' . esc_html__( '%d entries.', 'auto-mation' ) . '</p>', (int) $total );
			?>

			<hr />
			<h2><?php esc_html_e( 'Retention', 'auto-mation' ); ?></h2>
			<p class="description"><?php esc_html_e( 'Entries older than this are removed automatically once a day. Set to 0 to keep everything (the log will grow without limit).', 'auto-mation' ); ?></p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'amat_save_log_options' ); ?>
				<input type="hidden" name="action" value="amat_save_log_options" />
				<label>
					<?php esc_html_e( 'Keep entries for', 'auto-mation' ); ?>
					<input type="number" name="retention_days" min="0" max="3650" value="<?php echo esc_attr( AMAT_Log::retention_days() ); ?>" class="small-text" />
					<?php esc_html_e( 'days', 'auto-mation' ); ?>
				</label>
				<?php submit_button( __( 'Save', 'auto-mation' ), 'secondary', 'submit', false ); ?>
			</form>

			<h2><?php esc_html_e( 'Clear the log', 'auto-mation' ); ?></h2>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="amat-purge-logs-form">
				<?php wp_nonce_field( 'amat_purge_logs' ); ?>
				<input type="hidden" name="action" value="amat_purge_logs" />
				<p class="description"><?php esc_html_e( 'Deletes every entry. The log is a record of what happened, not data you can recover — but nothing else depends on it.', 'auto-mation' ); ?></p>
				<?php submit_button( __( 'Delete all entries', 'auto-mation' ), 'delete', 'submit', false ); ?>
			</form>
		</div>
		<?php
	}

	/**
	 * Human label for a level slug.
	 *
	 * @param string $level Level slug.
	 * @return string
	 */
	private static function level_label( $level ) {
		$labels = array(
			'debug'   => __( 'Debug', 'auto-mation' ),
			'info'    => __( 'Info', 'auto-mation' ),
			'warning' => __( 'Warning', 'auto-mation' ),
			'error'   => __( 'Error', 'auto-mation' ),
		);
		return $labels[ $level ] ?? (string) $level;
	}

	/**
	 * Format a stored timestamp in the site's timezone/format.
	 *
	 * @param string $mysql MySQL datetime.
	 * @return string
	 */
	private static function when( $mysql ) {
		$ts = strtotime( (string) $mysql );
		if ( ! $ts ) {
			return '—';
		}
		return wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $ts );
	}
}
