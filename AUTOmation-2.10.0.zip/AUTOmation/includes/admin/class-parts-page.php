<?php
/**
 * Parts admin page: manage the master list of pre-set parts a job can include.
 * A submenu of Jobs, mirroring the Services page.
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Renders the Parts list and the add/edit form.
 *
 * Deliberately simple (like Services): a management catalog, not an analysis
 * grid, so there is no search/filter/sort — just add/edit and a Show-disabled
 * toggle so soft-deleted parts can be re-enabled. Parts are disabled (is_active)
 * rather than deleted so past jobs keep referencing them.
 *
 * Security pattern per §5 (nonce, capability, sanitize in, escape out).
 */
class AMAT_Parts_Page extends AMAT_Admin_Page {

	const NONCE_ACTION = 'amat_save_part';
	const PAGE_SLUG    = 'amat-parts';
	const POST_ACTION  = 'save_part';

	/**
	 * Parts support enable/disable (soft delete).
	 *
	 * @return string
	 */
	protected static function active_model() {
		return 'AMAT_Part_Model';
	}

	/**
	 * Render the page: show any flashed notice, then route to list or form.
	 *
	 * @return void
	 */
	public function render() {
		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'auto-mation' ) );
		}

		$flash  = $this->take_flash();
		$action = isset( $_GET['action'] ) ? sanitize_key( wp_unslash( $_GET['action'] ) ) : '';

		if ( 'new' === $action || 'edit' === $action ) {
			if ( $flash && 'error' === $flash['status'] ) {
				$this->render_form( $flash['data'], $flash['editing_id'], $flash['message'] );
				return;
			}
			if ( 'new' === $action ) {
				$this->render_form( array(), 0 );
				return;
			}
			$id   = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0;
			$part = $id ? AMAT_Part_Model::find( $id ) : null;
			if ( ! $part ) {
				$this->render_list( '', __( 'Part not found.', 'auto-mation' ) );
				return;
			}
			$this->render_form( $part, $id );
			return;
		}

		$success = ( $flash && 'success' === $flash['status'] ) ? $flash['message'] : '';
		$error   = ( $flash && 'error' === $flash['status'] ) ? $flash['message'] : '';
		$this->render_list( $success, $error );
	}

	/* --------------------------------------------------------------------- */
	/* List                                                                  */
	/* --------------------------------------------------------------------- */

	/**
	 * Render the parts list.
	 *
	 * @param string $success Optional success notice.
	 * @param string $error   Optional error notice.
	 * @return void
	 */
	private function render_list( $success = '', $error = '' ) {
		$show_disabled = $this->read_show_disabled();

		// The toggle is exclusive: active rows, or disabled rows, never both.
		$parts = $this->filter_active_rows( AMAT_Part_Model::all_by_name(), $show_disabled );

		$new_url    = $this->list_url( array( 'action' => 'new' ) );
		$return_url = $this->list_url( array_filter( array( 'show_disabled' => $show_disabled ? '1' : '' ) ) );
		?>
		<div class="wrap">
			<h1 class="wp-heading-inline"><?php esc_html_e( 'Parts', 'auto-mation' ); ?></h1>
			<hr class="wp-header-end" />

			<?php if ( $success ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php echo esc_html( $success ); ?></p></div>
			<?php endif; ?>
			<?php if ( $error ) : ?>
				<div class="notice notice-error is-dismissible"><p><?php echo esc_html( $error ); ?></p></div>
			<?php endif; ?>

			<div class="amat-list-bar">
				<a href="<?php echo esc_url( $new_url ); ?>" class="button amat-btn-primary amat-add-inline"><?php esc_html_e( 'Add part', 'auto-mation' ); ?></a>
				<form method="get" class="amat-search-form">
					<input type="hidden" name="page" value="<?php echo esc_attr( self::PAGE_SLUG ); ?>" />
					<label class="amat-show-disabled"><input type="checkbox" name="show_disabled" value="1" <?php checked( $show_disabled ); ?> /> <?php esc_html_e( 'Show disabled only', 'auto-mation' ); ?></label>
					<?php submit_button( __( 'Apply', 'auto-mation' ), '', '', false ); ?>
				</form>
			</div>

			<p class="description"><?php esc_html_e( 'These parts are the options you pick from when building a job.', 'auto-mation' ); ?></p>

			<table class="wp-list-table widefat fixed striped">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Part', 'auto-mation' ); ?></th>
						<th><?php esc_html_e( 'Price', 'auto-mation' ); ?></th>
						<th><?php esc_html_e( 'Qty', 'auto-mation' ); ?></th>
						<th class="amat-col-actions"></th>
					</tr>
				</thead>
				<tbody>
					<?php if ( empty( $parts ) ) : ?>
						<tr><td colspan="4"><?php echo $show_disabled ? esc_html__( 'No disabled parts.', 'auto-mation' ) : esc_html__( 'No parts yet. Add one to start building jobs from preset parts.', 'auto-mation' ); ?></td></tr>
					<?php else : ?>
						<?php foreach ( $parts as $part ) : ?>
							<?php
							$disabled = empty( $part['is_active'] );
							$edit_url = $this->list_url( array( 'action' => 'edit', 'id' => (int) $part['id'] ) );
							?>
							<tr class="<?php echo $disabled ? 'amat-row-disabled' : ''; ?>">
								<td>
									<a href="<?php echo esc_url( $edit_url ); ?>"><?php echo esc_html( $part['name'] ); ?></a>
									<?php if ( $disabled ) : ?><span class="amat-badge amat-badge-off"><?php esc_html_e( 'disabled', 'auto-mation' ); ?></span><?php endif; ?>
								</td>
								<td><?php echo esc_html( AMAT_Part_Model::format_price( $part['default_price'] ?? null ) ); ?></td>
								<td><?php echo esc_html( AMAT_Money::quantity( $part['default_quantity'] ?? null ) ); ?></td>
								<td class="amat-col-actions">
									<div class="amat-row-actions">
										<a href="<?php echo esc_url( $edit_url ); ?>" class="button"><?php esc_html_e( 'Edit', 'auto-mation' ); ?></a>
										<?php
										echo $this->active_toggle_button( self::POST_ACTION, self::NONCE_ACTION, (int) $part['id'], ! $disabled, $return_url ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built with esc_* internally.
										echo $this->delete_button( self::POST_ACTION, self::NONCE_ACTION, (int) $part['id'], $return_url ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built with esc_* internally.
										?>
									</div>
								</td>
							</tr>
						<?php endforeach; ?>
					<?php endif; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	/* --------------------------------------------------------------------- */
	/* Add / edit form                                                       */
	/* --------------------------------------------------------------------- */

	/**
	 * Render the add/edit form.
	 *
	 * @param array<string,mixed> $data  Part row or submitted values.
	 * @param int                 $id    Part id (0 = new).
	 * @param string              $error Optional error notice.
	 * @return void
	 */
	private function render_form( array $data, $id, $error = '' ) {
		$id      = absint( $id );
		$is_edit = $id > 0;
		$name     = (string) ( $data['name'] ?? '' );
		$desc     = (string) ( $data['description'] ?? '' );
		$price    = ( null === ( $data['default_price'] ?? null ) ) ? '' : (string) $data['default_price'];
		$quantity = AMAT_Money::quantity( $data['default_quantity'] ?? null );

		$cancel_url = $this->list_url();
		?>
		<div class="wrap">
			<h1><?php echo $is_edit ? esc_html__( 'Edit part', 'auto-mation' ) : esc_html__( 'Add part', 'auto-mation' ); ?></h1>

			<?php if ( $error ) : ?>
				<div class="notice notice-error"><p><?php echo esc_html( $error ); ?></p></div>
			<?php endif; ?>

			<form method="post">
				<?php wp_nonce_field( self::NONCE_ACTION ); ?>
				<input type="hidden" name="amat_action" value="save_part" />
				<input type="hidden" name="part_id" value="<?php echo esc_attr( $id ); ?>" />

				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="amat-part-name"><?php esc_html_e( 'Name', 'auto-mation' ); ?> <span class="description">(<?php esc_html_e( 'required', 'auto-mation' ); ?>)</span></label></th>
						<td><input name="name" id="amat-part-name" type="text" class="regular-text" maxlength="191" value="<?php echo esc_attr( $name ); ?>" required /></td>
					</tr>
					<tr>
						<th scope="row"><label for="amat-part-desc"><?php esc_html_e( 'Description', 'auto-mation' ); ?></label></th>
						<td><textarea name="description" id="amat-part-desc" class="large-text" rows="3"><?php echo esc_textarea( $desc ); ?></textarea></td>
					</tr>
					<tr>
						<th scope="row"><label for="amat-part-price"><?php esc_html_e( 'Default price', 'auto-mation' ); ?></label></th>
						<td>
							<input name="default_price" id="amat-part-price" type="number" step="0.01" min="0" class="small-text" value="<?php echo esc_attr( $price ); ?>" />
							<p class="description"><?php esc_html_e( 'Optional. Prefills the price when this part is added as a line item.', 'auto-mation' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="amat-part-quantity"><?php esc_html_e( 'Default quantity', 'auto-mation' ); ?></label></th>
						<td>
							<input name="default_quantity" id="amat-part-quantity" type="number" step="0.01" min="0" class="small-text" value="<?php echo esc_attr( $quantity ); ?>" />
							<p class="description"><?php esc_html_e( 'Optional. Prefills the quantity when this part is added as a line item.', 'auto-mation' ); ?></p>
						</td>
					</tr>
				</table>

				<?php submit_button( $is_edit ? __( 'Save changes', 'auto-mation' ) : __( 'Add part', 'auto-mation' ) ); ?>
				<a href="<?php echo esc_url( $cancel_url ); ?>" class="button amat-btn-secondary"><?php esc_html_e( 'Cancel', 'auto-mation' ); ?></a>
			</form>
		</div>
		<?php
	}

	/* --------------------------------------------------------------------- */
	/* Save                                                                  */
	/* --------------------------------------------------------------------- */

	/**
	 * Validate and persist the submitted part.
	 *
	 * Called from the base class on `admin_init` once it confirms this is the
	 * part save POST; always returns a result array (never null).
	 *
	 * @return array{status:string,message:string,data?:array,editing_id?:int}
	 */
	protected function save() {
		check_admin_referer( self::NONCE_ACTION );
		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			return array( 'status' => 'error', 'message' => __( 'You are not allowed to save parts.', 'auto-mation' ), 'data' => array(), 'editing_id' => 0 );
		}

		$id = isset( $_POST['part_id'] ) ? absint( $_POST['part_id'] ) : 0;

		$data = array(
			'name'             => sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) ),
			'description'      => sanitize_textarea_field( wp_unslash( $_POST['description'] ?? '' ) ),
			'default_price'    => wp_unslash( $_POST['default_price'] ?? '' ),
			'default_quantity' => wp_unslash( $_POST['default_quantity'] ?? '' ),
		);

		if ( '' === $data['name'] ) {
			return array( 'status' => 'error', 'message' => __( 'A part name is required.', 'auto-mation' ), 'data' => $data, 'editing_id' => $id );
		}

		// Preserve is_active on edit; new parts default to active.
		if ( ! $id ) {
			$data['is_active'] = 1;
		}

		if ( $id ) {
			AMAT_Part_Model::update( $id, $data );
		} else {
			$id = AMAT_Part_Model::create( $data );
		}

		if ( ! $id ) {
			return array( 'status' => 'error', 'message' => __( 'Could not save the part. Please try again.', 'auto-mation' ), 'data' => $data, 'editing_id' => 0 );
		}

		return array( 'status' => 'success', 'message' => __( 'Part saved.', 'auto-mation' ) );
	}
}
