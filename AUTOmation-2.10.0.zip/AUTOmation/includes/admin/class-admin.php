<?php
/**
 * Admin layer: menus and page routing.
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers the plugin's admin menu and dispatches to page renderers.
 *
 * This is the operational hub UI. Every state-changing action verifies a
 * nonce and a capability before touching data (§5 of CLAUDE.md).
 */
class AMAT_Admin {

	/**
	 * Capability required to manage the plugin's data.
	 *
	 * @var string
	 */
	const CAPABILITY = 'manage_options';

	/**
	 * Top-level menu slug.
	 *
	 * @var string
	 */
	const MENU_SLUG = 'amat-dashboard';

	/**
	 * Settings page slug.
	 *
	 * @var string
	 */
	const SETTINGS_SLUG = 'amat-settings';

	/**
	 * Option key holding the Dev Tools feedback scratchpad text.
	 *
	 * @var string
	 */
	const FEEDBACK_OPTION = 'amat_dev_feedback';

	/**
	 * Option key (Dev Tools) gating the per-record hard-delete button shown on
	 * disabled records. Off by default — it permanently deletes data.
	 *
	 * @var string
	 */
	const DEV_DELETE_OPTION = 'amat_dev_allow_delete';

	/**
	 * Whether the Dev Tools per-record delete button is enabled.
	 *
	 * @return bool
	 */
	public static function delete_enabled() {
		return (bool) get_option( self::DEV_DELETE_OPTION, false );
	}

	/**
	 * Option key holding the business name (My Business). May feed the public
	 * portal and/or Wave later.
	 *
	 * @var string
	 */
	const BUSINESS_NAME_OPTION = 'amat_business_name';

	/**
	 * Dev Tools entities the data-clear tool can hard-delete, each mapped to the
	 * table(s) (without the `{$wpdb->prefix}amat_` prefix) truncated when chosen.
	 * Child/join rows are included so a wipe leaves no orphans — clearing
	 * Customers therefore also removes everything owned by them (the union of all
	 * entries below covers every plugin table, which is what the "All" reset does).
	 *
	 * @var array<string,string[]>
	 */
	const CLEARABLE = array(
		'customers' => array( 'customers', 'contact_methods', 'locations', 'vehicles', 'jobs', 'parts_orders', 'service_records', 'estimates', 'estimate_items', 'invoices', 'invoice_items', 'external_refs' ),
		'vehicles'  => array( 'vehicles', 'service_records' ),
		'locations' => array( 'locations' ),
		'jobs'      => array( 'jobs', 'parts_orders', 'service_records' ),
		'services'  => array( 'services' ),
		'parts'     => array( 'parts' ),
		'estimates' => array( 'estimates', 'estimate_items' ),
		'invoices'  => array( 'invoices', 'invoice_items' ),
		'logs'      => array( 'logs' ),
	);

	/**
	 * Hook suffixes of this plugin's admin pages, for scoping asset enqueues.
	 *
	 * @var string[]
	 */
	private $page_hooks = array();

	/**
	 * Hook admin actions.
	 *
	 * @return void
	 */
	public function register() {
		add_action( 'admin_menu', array( $this, 'add_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_action( 'wp_ajax_amat_decode_vin', array( 'AMAT_Vehicles_Page', 'ajax_decode_vin' ) );
		add_action( 'wp_ajax_amat_job_search_customers', array( 'AMAT_Jobs_Page', 'ajax_search_customers' ) );
		add_action( 'wp_ajax_amat_job_customer_items', array( 'AMAT_Jobs_Page', 'ajax_customer_items' ) );
		add_action( 'wp_ajax_amat_search_catalog', array( 'AMAT_Estimates_Page', 'ajax_search_catalog' ) );

		// Handle CRUD saves early (before any output) so they post/redirect/get:
		// each ignores every request but its own form POST. See AMAT_Admin_Page.
		add_action( 'admin_init', array( new AMAT_Customers_Page(), 'maybe_process' ) );
		add_action( 'admin_init', array( new AMAT_Vehicles_Page(), 'maybe_process' ) );
		add_action( 'admin_init', array( new AMAT_Locations_Page(), 'maybe_process' ) );
		add_action( 'admin_init', array( new AMAT_Jobs_Page(), 'maybe_process' ) );
		add_action( 'admin_init', array( new AMAT_Services_Page(), 'maybe_process' ) );
		add_action( 'admin_init', array( new AMAT_Parts_Page(), 'maybe_process' ) );
		add_action( 'admin_init', array( new AMAT_Estimates_Page(), 'maybe_process' ) );
		add_action( 'admin_init', array( new AMAT_Invoices_Page(), 'maybe_process' ) );

		// Dev Tools (Settings) destructive/scratchpad actions, posted to
		// admin-post.php so they run before output and redirect back cleanly.
		add_action( 'admin_post_amat_clear_data', array( $this, 'handle_clear_data' ) );
		add_action( 'admin_post_amat_backup_export', array( $this, 'handle_backup_export' ) );
		add_action( 'admin_post_amat_backup_import', array( $this, 'handle_backup_import' ) );
		add_action( 'admin_post_amat_save_log_options', array( $this, 'handle_save_log_options' ) );
		add_action( 'admin_post_amat_purge_logs', array( $this, 'handle_purge_logs' ) );
		add_action( 'admin_post_amat_save_feedback', array( $this, 'handle_save_feedback' ) );
		add_action( 'admin_post_amat_save_dev_options', array( $this, 'handle_save_dev_options' ) );
		add_action( 'admin_post_amat_save_business', array( $this, 'handle_save_business' ) );
		add_action( 'admin_post_amat_save_shop', array( $this, 'handle_save_shop' ) );
		add_action( 'admin_post_amat_toggle_shop', array( $this, 'handle_toggle_shop' ) );
	}

	/**
	 * Enqueue admin CSS/JS on this plugin's pages, with AJAX config for JS.
	 *
	 * @param string $hook Current admin page hook suffix.
	 * @return void
	 */
	public function enqueue_assets( $hook ) {
		if ( ! in_array( $hook, $this->page_hooks, true ) ) {
			return;
		}

		wp_enqueue_style(
			'amat-admin',
			AMAT_PLUGIN_URL . 'assets/admin.css',
			array(),
			AMAT_VERSION
		);

		wp_enqueue_script(
			'amat-admin',
			AMAT_PLUGIN_URL . 'assets/admin.js',
			array( 'jquery', 'jquery-ui-sortable' ),
			AMAT_VERSION,
			true
		);

		wp_localize_script(
			'amat-admin',
			'amatData',
			array(
				'ajaxUrl'   => admin_url( 'admin-ajax.php' ),
				'vinNonce'  => wp_create_nonce( AMAT_Vehicles_Page::VIN_NONCE ),
				'custNonce' => wp_create_nonce( AMAT_Jobs_Page::CUST_NONCE ),
				'catalogNonce' => wp_create_nonce( AMAT_Estimates_Page::CATALOG_NONCE ),
				'i18n'     => array(
					'decoding'    => __( 'Decoding…', 'auto-mation' ),
					'decoded'     => __( 'Decoded ✓', 'auto-mation' ),
					'failed'      => __( 'VIN decode failed.', 'auto-mation' ),
					'vinRequired' => __( 'Enter a VIN first.', 'auto-mation' ),
					'copyVin'     => __( 'Copy VIN', 'auto-mation' ),
					/* translators: %s: comma-separated list of illegal characters found in the VIN. */
					'vinIllegal'    => __( 'A VIN never contains the letters I, O or Q (found: %s) — they are easily confused with 1 and 0.', 'auto-mation' ),
					/* translators: 1: characters entered, 2: the full VIN length (17). */
					'vinPartial'    => __( 'Partial VIN — %1$d of %2$d characters. It will decode, but the year and trim are often missing.', 'auto-mation' ),
					'vinCheckDigit' => __( 'The check digit (9th character) does not calculate — the VIN is probably mistyped.', 'auto-mation' ),
					'vinValid'      => __( 'VIN looks valid.', 'auto-mation' ),
					'selectOne'         => __( '— Select —', 'auto-mation' ),
					'none'              => __( '— None —', 'auto-mation' ),
					'remove'            => __( 'Remove', 'auto-mation' ),
					'customerLocations' => __( 'Customer locations', 'auto-mation' ),
					'yourShops'         => __( 'Your shops', 'auto-mation' ),
					'service'           => __( 'Service', 'auto-mation' ),
					'part'              => __( 'Part', 'auto-mation' ),
				),
			)
		);
	}

	/**
	 * Build the admin menu tree.
	 *
	 * @return void
	 */
	public function add_menu() {
		add_menu_page(
			__( 'AUTOmation', 'auto-mation' ),
			__( 'AUTOmation', 'auto-mation' ),
			self::CAPABILITY,
			self::MENU_SLUG,
			array( $this, 'render_dashboard' ),
			'dashicons-car',
			56
		);

		add_submenu_page(
			self::MENU_SLUG,
			__( 'Dashboard', 'auto-mation' ),
			__( 'Dashboard', 'auto-mation' ),
			self::CAPABILITY,
			self::MENU_SLUG,
			array( $this, 'render_dashboard' )
		);

		$this->page_hooks[] = add_submenu_page(
			self::MENU_SLUG,
			__( 'Customers', 'auto-mation' ),
			__( 'Customers', 'auto-mation' ),
			self::CAPABILITY,
			'amat-customers',
			array( new AMAT_Customers_Page(), 'render' )
		);

		$this->page_hooks[] = add_submenu_page(
			self::MENU_SLUG,
			__( 'Vehicles', 'auto-mation' ),
			__( '↳ Vehicles', 'auto-mation' ),
			self::CAPABILITY,
			AMAT_Vehicles_Page::PAGE_SLUG,
			array( new AMAT_Vehicles_Page(), 'render' )
		);

		$this->page_hooks[] = add_submenu_page(
			self::MENU_SLUG,
			__( 'Locations', 'auto-mation' ),
			__( '↳ Locations', 'auto-mation' ),
			self::CAPABILITY,
			AMAT_Locations_Page::PAGE_SLUG,
			array( new AMAT_Locations_Page(), 'render' )
		);

		$this->page_hooks[] = add_submenu_page(
			self::MENU_SLUG,
			__( 'Jobs', 'auto-mation' ),
			__( 'Jobs', 'auto-mation' ),
			self::CAPABILITY,
			AMAT_Jobs_Page::PAGE_SLUG,
			array( new AMAT_Jobs_Page(), 'render' )
		);

		// Estimates + Invoices are job-owned: they sit under Jobs in the menu.
		$this->page_hooks[] = add_submenu_page(
			self::MENU_SLUG,
			__( 'Estimates', 'auto-mation' ),
			__( '↳ Estimates', 'auto-mation' ),
			self::CAPABILITY,
			AMAT_Estimates_Page::PAGE_SLUG,
			array( new AMAT_Estimates_Page(), 'render' )
		);

		$this->page_hooks[] = add_submenu_page(
			self::MENU_SLUG,
			__( 'Invoices', 'auto-mation' ),
			__( '↳ Invoices', 'auto-mation' ),
			self::CAPABILITY,
			AMAT_Invoices_Page::PAGE_SLUG,
			array( new AMAT_Invoices_Page(), 'render' )
		);

		$this->page_hooks[] = add_submenu_page(
			self::MENU_SLUG,
			__( 'Services', 'auto-mation' ),
			__( '↳ Services', 'auto-mation' ),
			self::CAPABILITY,
			AMAT_Services_Page::PAGE_SLUG,
			array( new AMAT_Services_Page(), 'render' )
		);

		$this->page_hooks[] = add_submenu_page(
			self::MENU_SLUG,
			__( 'Parts', 'auto-mation' ),
			__( '↳ Parts', 'auto-mation' ),
			self::CAPABILITY,
			AMAT_Parts_Page::PAGE_SLUG,
			array( new AMAT_Parts_Page(), 'render' )
		);

		$this->page_hooks[] = add_submenu_page(
			self::MENU_SLUG,
			__( 'Settings', 'auto-mation' ),
			__( 'Settings', 'auto-mation' ),
			self::CAPABILITY,
			self::SETTINGS_SLUG,
			array( $this, 'render_settings' )
		);

		// The event log gets its own page under Settings — it is a real operational
		// surface (and the record of every provider sync + future customer message),
		// not a Dev Tools scratchpad. A provider integration adds its own submenu
		// here too (e.g. the Wave companion's ↳ Wave).
		$this->page_hooks[] = add_submenu_page(
			self::MENU_SLUG,
			__( 'Logs', 'auto-mation' ),
			__( '↳ Logs', 'auto-mation' ),
			self::CAPABILITY,
			AMAT_Logs_Page::PAGE_SLUG,
			array( new AMAT_Logs_Page(), 'render' )
		);
	}

	/**
	 * Render the dashboard landing page with at-a-glance counts.
	 *
	 * @return void
	 */
	public function render_dashboard() {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'auto-mation' ) );
		}

		$customers  = count( AMAT_Customer_Model::all() );
		$vehicles   = count( AMAT_Vehicle_Model::all() );
		$requested  = count( AMAT_Job_Model::all( array( 'status' => 'requested' ) ) );
		$scheduled  = count( AMAT_Job_Model::all( array( 'status' => 'scheduled' ) ) );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'AUTOmation', 'auto-mation' ); ?></h1>
			<p><?php esc_html_e( 'Operational hub for customers, vehicles, jobs, parts, and service history.', 'auto-mation' ); ?></p>
			<ul>
				<li><?php printf( esc_html__( 'Customers: %d', 'auto-mation' ), (int) $customers ); ?></li>
				<li><?php printf( esc_html__( 'Vehicles: %d', 'auto-mation' ), (int) $vehicles ); ?></li>
				<li><?php printf( esc_html__( 'Job requests awaiting approval: %d', 'auto-mation' ), (int) $requested ); ?></li>
				<li><?php printf( esc_html__( 'Scheduled jobs: %d', 'auto-mation' ), (int) $scheduled ); ?></li>
			</ul>
		</div>
		<?php
	}

	/**
	 * Render the settings page (Wave connection status from .env, plus Dev Tools).
	 *
	 * @return void
	 */
	public function render_settings() {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'auto-mation' ) );
		}

		// Sub-route: the add/edit form for a business location (shop).
		$shop_action = isset( $_GET['shop_action'] ) ? sanitize_key( wp_unslash( $_GET['shop_action'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only nav.
		if ( 'new' === $shop_action || 'edit' === $shop_action ) {
			$this->render_shop_form();
			return;
		}

		$notice = $this->take_settings_notice();
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Settings', 'auto-mation' ); ?></h1>

			<?php if ( $notice ) : ?>
				<div class="notice notice-<?php echo esc_attr( $notice['type'] ); ?> is-dismissible"><p><?php echo esc_html( $notice['message'] ); ?></p></div>
			<?php endif; ?>

			<?php $this->render_my_business(); ?>

			<?php $this->render_dev_tools(); ?>
		</div>
		<?php
	}

	/* --------------------------------------------------------------------- */
	/* My Business (Settings)                                                */
	/* --------------------------------------------------------------------- */

	/**
	 * Render the My Business block: the business name and the list of the
	 * business's own locations (shops), which can be assigned to jobs.
	 *
	 * @return void
	 */
	private function render_my_business() {
		$name  = (string) get_option( self::BUSINESS_NAME_OPTION, '' );
		$shops = AMAT_Location_Model::business_locations( true );
		?>
		<h2><?php esc_html_e( 'My Business', 'auto-mation' ); ?></h2>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<?php wp_nonce_field( 'amat_save_business' ); ?>
			<input type="hidden" name="action" value="amat_save_business" />
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="amat-business-name"><?php esc_html_e( 'Business name', 'auto-mation' ); ?></label></th>
					<td>
						<input name="business_name" id="amat-business-name" type="text" class="regular-text" maxlength="191" value="<?php echo esc_attr( $name ); ?>" />
						<p class="description"><?php esc_html_e( 'Shown to customers in the portal and used with Wave later.', 'auto-mation' ); ?></p>
					</td>
				</tr>
			</table>
			<?php submit_button( __( 'Save business name', 'auto-mation' ) ); ?>
		</form>

		<h3><?php esc_html_e( 'Business locations (shops)', 'auto-mation' ); ?></h3>
		<p class="description"><?php esc_html_e( 'The shops you work out of. These appear after a customer\'s own locations when assigning a job.', 'auto-mation' ); ?></p>
		<p>
			<a href="<?php echo esc_url( $this->settings_url( array( 'shop_action' => 'new' ) ) ); ?>" class="button amat-btn-primary"><?php esc_html_e( 'Add shop', 'auto-mation' ); ?></a>
		</p>
		<?php if ( empty( $shops ) ) : ?>
			<p class="description"><?php esc_html_e( 'No shops yet.', 'auto-mation' ); ?></p>
		<?php else : ?>
			<table class="wp-list-table widefat fixed striped">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Label', 'auto-mation' ); ?></th>
						<th><?php esc_html_e( 'Address', 'auto-mation' ); ?></th>
						<th class="amat-col-actions"></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $shops as $shop ) : ?>
						<?php
						$disabled = empty( $shop['is_active'] );
						$edit_url = $this->settings_url( array( 'shop_action' => 'edit', 'shop' => (int) $shop['id'] ) );
						?>
						<tr class="<?php echo $disabled ? 'amat-row-disabled' : ''; ?>">
							<td>
								<a href="<?php echo esc_url( $edit_url ); ?>"><?php echo esc_html( '' !== $shop['label'] ? $shop['label'] : __( '(no label)', 'auto-mation' ) ); ?></a>
								<?php if ( $disabled ) : ?><span class="amat-badge amat-badge-off"><?php esc_html_e( 'disabled', 'auto-mation' ); ?></span><?php endif; ?>
							</td>
							<td><?php echo esc_html( AMAT_Location_Model::one_line( $shop ) ); ?></td>
							<td class="amat-col-actions">
								<div class="amat-row-actions">
									<a href="<?php echo esc_url( $edit_url ); ?>" class="button"><?php esc_html_e( 'Edit', 'auto-mation' ); ?></a>
									<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="amat-inline-form">
										<?php wp_nonce_field( 'amat_toggle_shop' ); ?>
										<input type="hidden" name="action" value="amat_toggle_shop" />
										<input type="hidden" name="shop" value="<?php echo esc_attr( (int) $shop['id'] ); ?>" />
										<input type="hidden" name="active" value="<?php echo $disabled ? '1' : '0'; ?>" />
										<button type="submit" class="button <?php echo $disabled ? 'amat-btn-primary' : 'amat-btn-disable'; ?>"><?php echo $disabled ? esc_html__( 'Enable', 'auto-mation' ) : esc_html__( 'Disable', 'auto-mation' ); ?></button>
									</form>
								</div>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>
		<?php
	}

	/**
	 * Render the add/edit form for a business location (shop).
	 *
	 * @return void
	 */
	private function render_shop_form() {
		$id   = isset( $_GET['shop'] ) ? absint( $_GET['shop'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only nav.
		$flash = $this->take_shop_flash();

		if ( $flash && ! empty( $flash['data'] ) ) {
			$shop = $flash['data'];
		} elseif ( $id ) {
			$shop = AMAT_Location_Model::find( $id );
			if ( ! $shop || (int) $shop['customer_id'] !== AMAT_Location_Model::BUSINESS_OWNER_ID ) {
				wp_safe_redirect( $this->settings_url() );
				exit;
			}
		} else {
			$shop = array();
		}

		$is_edit = $id > 0;
		$error   = $flash['message'] ?? '';
		$val     = static function ( $key ) use ( $shop ) {
			return esc_attr( (string) ( $shop[ $key ] ?? '' ) );
		};
		?>
		<div class="wrap">
			<h1><?php echo $is_edit ? esc_html__( 'Edit shop', 'auto-mation' ) : esc_html__( 'Add shop', 'auto-mation' ); ?></h1>

			<?php if ( $error ) : ?>
				<div class="notice notice-error"><p><?php echo esc_html( $error ); ?></p></div>
			<?php endif; ?>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'amat_save_shop' ); ?>
				<input type="hidden" name="action" value="amat_save_shop" />
				<input type="hidden" name="shop_id" value="<?php echo esc_attr( $id ); ?>" />
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="amat-shop-label"><?php esc_html_e( 'Label', 'auto-mation' ); ?> <span class="description">(<?php esc_html_e( 'required', 'auto-mation' ); ?>)</span></label></th>
						<td><input name="label" id="amat-shop-label" type="text" class="regular-text" maxlength="100" value="<?php echo $val( 'label' ); ?>" required placeholder="<?php esc_attr_e( 'e.g. Eastside Shop', 'auto-mation' ); ?>" /></td>
					</tr>
					<tr>
						<th scope="row"><label for="amat-shop-street1"><?php esc_html_e( 'Street address', 'auto-mation' ); ?></label></th>
						<td>
							<input name="street_1" id="amat-shop-street1" type="text" class="regular-text" maxlength="191" value="<?php echo $val( 'street_1' ); ?>" /><br />
							<input name="street_2" type="text" class="regular-text" maxlength="191" value="<?php echo $val( 'street_2' ); ?>" placeholder="<?php esc_attr_e( 'Apt, suite, etc. (optional)', 'auto-mation' ); ?>" style="margin-top:4px;" />
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="amat-shop-city"><?php esc_html_e( 'City', 'auto-mation' ); ?></label></th>
						<td><input name="city" id="amat-shop-city" type="text" class="regular-text" maxlength="100" value="<?php echo $val( 'city' ); ?>" /></td>
					</tr>
					<tr>
						<th scope="row"><label for="amat-shop-state"><?php esc_html_e( 'State', 'auto-mation' ); ?></label></th>
						<td>
							<input name="state" id="amat-shop-state" type="text" class="amat-state-input" list="amat-state-list" maxlength="2" autocapitalize="characters" autocomplete="off" inputmode="text" pattern="[A-Za-z]{2}" value="<?php echo $val( 'state' ); ?>" placeholder="<?php esc_attr_e( 'e.g. CA', 'auto-mation' ); ?>" />
							<datalist id="amat-state-list">
								<?php foreach ( AMAT_Location_Model::state_codes() as $code ) : ?>
									<option value="<?php echo esc_attr( $code ); ?>"></option>
								<?php endforeach; ?>
							</datalist>
							<p class="description"><?php esc_html_e( 'Two-letter US state code (e.g. CA, TX, NY).', 'auto-mation' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="amat-shop-zip"><?php esc_html_e( 'Zipcode', 'auto-mation' ); ?></label></th>
						<td><input name="zipcode" id="amat-shop-zip" type="text" class="regular-text" maxlength="20" value="<?php echo $val( 'zipcode' ); ?>" /></td>
					</tr>
					<tr>
						<th scope="row"><label for="amat-shop-code"><?php esc_html_e( 'Code', 'auto-mation' ); ?></label></th>
						<td><input name="code" id="amat-shop-code" type="text" class="regular-text" maxlength="100" value="<?php echo $val( 'code' ); ?>" placeholder="<?php esc_attr_e( 'Gate / entry code (optional)', 'auto-mation' ); ?>" /></td>
					</tr>
					<tr>
						<th scope="row"><label for="amat-shop-notes"><?php esc_html_e( 'Notes', 'auto-mation' ); ?></label></th>
						<td><textarea name="notes" id="amat-shop-notes" class="large-text" rows="3"><?php echo esc_textarea( (string) ( $shop['notes'] ?? '' ) ); ?></textarea></td>
					</tr>
				</table>
				<?php submit_button( $is_edit ? __( 'Save shop', 'auto-mation' ) : __( 'Add shop', 'auto-mation' ) ); ?>
				<a href="<?php echo esc_url( $this->settings_url() ); ?>" class="button amat-btn-secondary"><?php esc_html_e( 'Cancel', 'auto-mation' ); ?></a>
			</form>
		</div>
		<?php
	}

	/**
	 * Save the business name.
	 *
	 * @return void
	 */
	public function handle_save_business() {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'auto-mation' ) );
		}
		check_admin_referer( 'amat_save_business' );

		$name = isset( $_POST['business_name'] ) ? sanitize_text_field( wp_unslash( $_POST['business_name'] ) ) : '';
		update_option( self::BUSINESS_NAME_OPTION, $name, false );

		$this->set_settings_notice( 'success', __( 'Business name saved.', 'auto-mation' ) );
		$this->redirect_to_settings();
	}

	/**
	 * Create or update a business location (shop).
	 *
	 * @return void
	 */
	public function handle_save_shop() {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'auto-mation' ) );
		}
		check_admin_referer( 'amat_save_shop' );

		$id   = isset( $_POST['shop_id'] ) ? absint( $_POST['shop_id'] ) : 0;
		$data = array(
			'customer_id' => AMAT_Location_Model::BUSINESS_OWNER_ID,
			'label'       => sanitize_text_field( wp_unslash( $_POST['label'] ?? '' ) ),
			'street_1'    => sanitize_text_field( wp_unslash( $_POST['street_1'] ?? '' ) ),
			'street_2'    => sanitize_text_field( wp_unslash( $_POST['street_2'] ?? '' ) ),
			'city'        => sanitize_text_field( wp_unslash( $_POST['city'] ?? '' ) ),
			'state'       => strtoupper( sanitize_text_field( wp_unslash( $_POST['state'] ?? '' ) ) ),
			'zipcode'     => sanitize_text_field( wp_unslash( $_POST['zipcode'] ?? '' ) ),
			'code'        => sanitize_text_field( wp_unslash( $_POST['code'] ?? '' ) ),
			'notes'       => sanitize_textarea_field( wp_unslash( $_POST['notes'] ?? '' ) ),
			'is_primary'  => 0,
			'is_billing'  => 0,
		);

		$fail = function ( $message ) use ( $data, $id ) {
			$this->set_shop_flash( $message, $data );
			$args = array( 'shop_action' => $id ? 'edit' : 'new' );
			if ( $id ) {
				$args['shop'] = $id;
			}
			wp_safe_redirect( $this->settings_url( $args ) );
			exit;
		};

		if ( '' === $data['label'] ) {
			$fail( __( 'A label is required for the shop.', 'auto-mation' ) );
		}
		if ( '' !== $data['state'] && ! AMAT_Location_Model::is_valid_state( $data['state'] ) ) {
			$fail( __( 'Enter a valid 2-letter US state code (e.g. CA).', 'auto-mation' ) );
		}

		if ( $id ) {
			$existing = AMAT_Location_Model::find( $id );
			if ( ! $existing || (int) $existing['customer_id'] !== AMAT_Location_Model::BUSINESS_OWNER_ID ) {
				$fail( __( 'That shop no longer exists.', 'auto-mation' ) );
			}
			$data['is_active'] = (int) $existing['is_active']; // preserve enabled/disabled state
			AMAT_Location_Model::update( $id, $data );
		} else {
			$data['is_active'] = 1;
			$id                = AMAT_Location_Model::create( $data );
			if ( ! $id ) {
				$fail( __( 'Could not save the shop. Please try again.', 'auto-mation' ) );
			}
		}

		$this->set_settings_notice( 'success', __( 'Shop saved.', 'auto-mation' ) );
		$this->redirect_to_settings();
	}

	/**
	 * Enable/disable (soft delete) a business location (shop).
	 *
	 * @return void
	 */
	public function handle_toggle_shop() {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'auto-mation' ) );
		}
		check_admin_referer( 'amat_toggle_shop' );

		$id     = isset( $_POST['shop'] ) ? absint( $_POST['shop'] ) : 0;
		$active = ( isset( $_POST['active'] ) && '1' === (string) $_POST['active'] ) ? 1 : 0;
		$shop   = $id ? AMAT_Location_Model::find( $id ) : null;

		if ( $shop && (int) $shop['customer_id'] === AMAT_Location_Model::BUSINESS_OWNER_ID ) {
			AMAT_Location_Model::update( $id, array( 'is_active' => $active ) );
			$this->set_settings_notice( 'success', $active ? __( 'Shop enabled.', 'auto-mation' ) : __( 'Shop disabled.', 'auto-mation' ) );
		}

		$this->redirect_to_settings();
	}

	/**
	 * Build a URL to the Settings page with optional extra query args.
	 *
	 * @param array<string,mixed> $extra Additional query args.
	 * @return string
	 */
	private function settings_url( array $extra = array() ) {
		return add_query_arg(
			array_merge( array( 'page' => self::SETTINGS_SLUG ), $extra ),
			admin_url( 'admin.php' )
		);
	}

	/**
	 * Stash a one-shot shop-form error (message + submitted data) for re-render.
	 *
	 * @param string               $message Error message.
	 * @param array<string,mixed>  $data    Submitted values to repopulate.
	 * @return void
	 */
	private function set_shop_flash( $message, array $data ) {
		set_transient( 'amat_shop_flash_' . get_current_user_id(), array( 'message' => $message, 'data' => $data ), MINUTE_IN_SECONDS );
	}

	/**
	 * Read and clear the current user's shop-form flash, if any.
	 *
	 * @return array{message:string,data:array}|null
	 */
	private function take_shop_flash() {
		$key     = 'amat_shop_flash_' . get_current_user_id();
		$payload = get_transient( $key );
		if ( false === $payload ) {
			return null;
		}
		delete_transient( $key );
		return is_array( $payload ) ? $payload : null;
	}

	/* --------------------------------------------------------------------- */
	/* Dev Tools (Settings)                                                  */
	/* --------------------------------------------------------------------- */

	/**
	 * Render the Dev Tools block: a feedback scratchpad and a destructive,
	 * confirm-gated data-clear tool for testing with real-world data.
	 *
	 * @return void
	 */
	private function render_dev_tools() {
		$feedback = (string) get_option( self::FEEDBACK_OPTION, '' );

		$counts = array(
			'customers' => count( AMAT_Customer_Model::all() ),
			'vehicles'  => count( AMAT_Vehicle_Model::all() ),
			'locations' => count( AMAT_Location_Model::all() ),
			'jobs'      => count( AMAT_Job_Model::all() ),
			'services'  => count( AMAT_Service_Model::all() ),
			'parts'     => count( AMAT_Part_Model::all() ),
			'estimates' => count( AMAT_Estimate_Model::all() ),
			'invoices'  => count( AMAT_Invoice_Model::all() ),
			'logs'      => AMAT_Log_Model::count_filtered(),
		);
		$labels = self::clearable_labels();
		?>
		<hr />
		<h2><?php esc_html_e( 'Dev Tools', 'auto-mation' ); ?></h2>

		<h3><?php esc_html_e( 'Feedback scratchpad', 'auto-mation' ); ?></h3>
		<p class="description"><?php esc_html_e( 'A quick place to jot testing notes as you go. Saved to the database (not committed to the repo).', 'auto-mation' ); ?></p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<?php wp_nonce_field( 'amat_save_feedback' ); ?>
			<input type="hidden" name="action" value="amat_save_feedback" />
			<textarea name="amat_feedback" class="large-text" rows="8"><?php echo esc_textarea( $feedback ); ?></textarea>
			<?php submit_button( __( 'Save feedback', 'auto-mation' ) ); ?>
		</form>

		<h3><?php esc_html_e( 'Record deletion', 'auto-mation' ); ?></h3>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<?php wp_nonce_field( 'amat_save_dev_options' ); ?>
			<input type="hidden" name="action" value="amat_save_dev_options" />
			<label>
				<input type="checkbox" name="allow_delete" value="1" <?php checked( self::delete_enabled() ); ?> />
				<?php esc_html_e( 'Show a per-record Delete button on individual records', 'auto-mation' ); ?>
			</label>
			<p class="description amat-danger-text"><?php esc_html_e( 'For testing only. Adds a Delete button to individual records (customers, vehicles, locations, jobs, services, parts, estimates, invoices) so errant test data can be removed one at a time. Deleting a customer also removes everything they own. There is no undo.', 'auto-mation' ); ?></p>
			<?php submit_button( __( 'Save options', 'auto-mation' ) ); ?>
		</form>

		<h3><?php esc_html_e( 'Backup &amp; restore', 'auto-mation' ); ?></h3>
		<p class="description">
			<?php esc_html_e( 'Download a snapshot of every AUTOmation record as a JSON file, and restore it later. Use this to take a safety copy before testing destructively or before a schema change.', 'auto-mation' ); ?>
			<br />
			<?php esc_html_e( 'The file holds your customers\' names, addresses, phone numbers and emails, so it is downloaded straight to you and never stored on the server — keep it somewhere safe.', 'auto-mation' ); ?>
		</p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<?php wp_nonce_field( 'amat_backup_export' ); ?>
			<input type="hidden" name="action" value="amat_backup_export" />
			<label>
				<input type="checkbox" name="include_options" value="1" checked="checked" />
				<?php esc_html_e( 'Include settings (business name, integration settings, dev options)', 'auto-mation' ); ?>
			</label>
			<?php submit_button( __( 'Download backup', 'auto-mation' ), 'secondary' ); ?>
		</form>

		<h4><?php esc_html_e( 'Restore from a backup', 'auto-mation' ); ?></h4>
		<p class="description amat-danger-text">
			<strong><?php esc_html_e( 'Warning:', 'auto-mation' ); ?></strong>
			<?php esc_html_e( 'Restoring REPLACES all current AUTOmation data with the contents of the file. Anything not in the backup is lost. A backup taken on a different database schema version will be refused.', 'auto-mation' ); ?>
		</p>
		<form method="post" enctype="multipart/form-data" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="amat-restore-form">
			<?php wp_nonce_field( 'amat_backup_import' ); ?>
			<input type="hidden" name="action" value="amat_backup_import" />
			<p><input type="file" name="amat_backup_file" accept=".json,application/json" required="required" /></p>
			<label>
				<input type="checkbox" name="include_options" value="1" checked="checked" />
				<?php esc_html_e( 'Restore settings too (if the backup contains them)', 'auto-mation' ); ?>
			</label>
			<p class="amat-clear-confirm">
				<label>
					<input type="checkbox" name="confirm_restore" value="1" />
					<?php esc_html_e( 'I understand this replaces all current AUTOmation data.', 'auto-mation' ); ?>
				</label>
			</p>
			<?php submit_button( __( 'Restore from file', 'auto-mation' ), 'delete', 'submit', true, array( 'id' => 'amat-restore-submit' ) ); ?>
		</form>

		<h3><?php esc_html_e( 'Clear data', 'auto-mation' ); ?></h3>
		<p class="description amat-danger-text">
			<strong><?php esc_html_e( 'Warning:', 'auto-mation' ); ?></strong>
			<?php esc_html_e( 'This permanently DELETES the selected records from the database — it is not the reversible Disable used elsewhere. There is no undo. Clearing Customers also removes everything owned by them (locations, vehicles, jobs, and related records). "All" wipes every table back to a just-installed state.', 'auto-mation' ); ?>
		</p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="amat-clear-data-form">
			<?php wp_nonce_field( 'amat_clear_data' ); ?>
			<input type="hidden" name="action" value="amat_clear_data" />
			<fieldset class="amat-clear-list">
				<label class="amat-clear-option amat-clear-all">
					<input type="checkbox" name="clear_all" id="amat-clear-all" value="1" />
					<strong><?php esc_html_e( 'All — reset to just-installed state', 'auto-mation' ); ?></strong>
				</label>
				<?php foreach ( self::CLEARABLE as $key => $tables ) : ?>
					<label class="amat-clear-option">
						<input type="checkbox" name="clear[]" value="<?php echo esc_attr( $key ); ?>" class="amat-clear-entity" />
						<?php
						/* translators: 1: entity label, 2: current row count. */
						printf( esc_html__( '%1$s (%2$d)', 'auto-mation' ), esc_html( $labels[ $key ] ), (int) $counts[ $key ] );
						?>
					</label>
				<?php endforeach; ?>
			</fieldset>
			<p class="amat-clear-confirm">
				<label>
					<input type="checkbox" name="confirm_delete" value="1" />
					<?php esc_html_e( 'I understand this permanently deletes the selected data.', 'auto-mation' ); ?>
				</label>
			</p>
			<?php submit_button( __( 'Delete selected data', 'auto-mation' ), 'delete', 'submit', true, array( 'id' => 'amat-clear-data-submit' ) ); ?>
		</form>
		<?php
	}

	/**
	 * Handle the Dev Tools data-clear POST: validate, hard-delete the chosen
	 * tables, and redirect back to Settings with a notice.
	 *
	 * @return void
	 */
	public function handle_clear_data() {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'auto-mation' ) );
		}
		check_admin_referer( 'amat_clear_data' );

		$clear_all = ! empty( $_POST['clear_all'] );
		$selected  = isset( $_POST['clear'] ) ? array_map( 'sanitize_key', (array) wp_unslash( $_POST['clear'] ) ) : array();
		$selected  = array_values( array_intersect( $selected, array_keys( self::CLEARABLE ) ) );
		if ( $clear_all ) {
			$selected = array_keys( self::CLEARABLE ); // union of all entries = every table
		}
		$confirm = ! empty( $_POST['confirm_delete'] );

		if ( empty( $selected ) ) {
			$this->set_settings_notice( 'error', __( 'Nothing selected — no data was deleted.', 'auto-mation' ) );
			$this->redirect_to_settings();
		}
		if ( ! $confirm ) {
			$this->set_settings_notice( 'error', __( 'Please tick the confirmation box before deleting.', 'auto-mation' ) );
			$this->redirect_to_settings();
		}

		// Union the tables for the selected entities (dedupe shared join tables).
		$tables = array();
		foreach ( $selected as $entity ) {
			foreach ( self::CLEARABLE[ $entity ] as $table ) {
				$tables[ $table ] = true;
			}
		}

		global $wpdb;
		foreach ( array_keys( $tables ) as $table ) {
			$full = $wpdb->prefix . 'amat_' . $table;
			// Identifier built from a trusted constant prefix + hardcoded suffix.
			$wpdb->query( "TRUNCATE TABLE {$full}" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery
		}

		if ( $clear_all ) {
			$this->set_settings_notice( 'success', __( 'All data deleted — the plugin is back to a just-installed state.', 'auto-mation' ) );
			$this->redirect_to_settings();
		}

		$labels = self::clearable_labels();
		$names  = array();
		foreach ( $selected as $entity ) {
			$names[] = $labels[ $entity ];
		}

		/* translators: %s: comma-separated list of cleared data types. */
		$this->set_settings_notice( 'success', sprintf( __( 'Permanently deleted: %s.', 'auto-mation' ), implode( ', ', $names ) ) );
		$this->redirect_to_settings();
	}

	/**
	 * Stream a JSON snapshot of the plugin's data to the browser as a download.
	 *
	 * Deliberately never written to disk: the snapshot contains the whole
	 * customer book (names, addresses, phones, emails), and anything under
	 * wp-content is one guessed URL away from being public. See AMAT_Backup.
	 *
	 * @return void
	 */
	public function handle_backup_export() {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'auto-mation' ) );
		}
		check_admin_referer( 'amat_backup_export' );

		$include_options = ! empty( $_POST['include_options'] );
		$data            = AMAT_Backup::export( $include_options );
		$json            = wp_json_encode( $data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );

		if ( false === $json ) {
			$this->set_settings_notice( 'error', __( 'Could not build the backup file.', 'auto-mation' ) );
			$this->redirect_to_settings();
		}

		nocache_headers();
		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . AMAT_Backup::filename() . '"' );
		header( 'Content-Length: ' . strlen( $json ) );
		// Raw file body, not HTML — escaping would corrupt the JSON.
		echo $json; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		exit;
	}

	/**
	 * Handle a backup-file upload: validate, restore, redirect with a notice.
	 *
	 * The upload is read straight from PHP's temp file and never moved into
	 * wp-content (same reasoning as the export side).
	 *
	 * @return void
	 */
	public function handle_backup_import() {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'auto-mation' ) );
		}
		check_admin_referer( 'amat_backup_import' );

		if ( empty( $_POST['confirm_restore'] ) ) {
			$this->set_settings_notice( 'error', __( 'Please tick the confirmation box before restoring.', 'auto-mation' ) );
			$this->redirect_to_settings();
		}

		$file = isset( $_FILES['amat_backup_file'] ) ? $_FILES['amat_backup_file'] : null; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		if ( ! $file || ! isset( $file['tmp_name'] ) || '' === $file['tmp_name'] || ! empty( $file['error'] ) ) {
			$this->set_settings_notice( 'error', __( 'No backup file was uploaded (or it was too large for the server to accept).', 'auto-mation' ) );
			$this->redirect_to_settings();
		}

		$tmp = $file['tmp_name'];
		if ( ! is_uploaded_file( $tmp ) ) {
			$this->set_settings_notice( 'error', __( 'That upload could not be verified.', 'auto-mation' ) );
			$this->redirect_to_settings();
		}

		$raw = file_get_contents( $tmp ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		if ( false === $raw || '' === $raw ) {
			$this->set_settings_notice( 'error', __( 'The uploaded file was empty.', 'auto-mation' ) );
			$this->redirect_to_settings();
		}

		$data = json_decode( $raw, true );
		if ( null === $data && JSON_ERROR_NONE !== json_last_error() ) {
			$this->set_settings_notice( 'error', __( 'The uploaded file is not valid JSON.', 'auto-mation' ) );
			$this->redirect_to_settings();
		}

		$valid = AMAT_Backup::validate( $data );
		if ( is_wp_error( $valid ) ) {
			$this->set_settings_notice( 'error', $valid->get_error_message() );
			$this->redirect_to_settings();
		}

		$result = AMAT_Backup::import( (array) $data, ! empty( $_POST['include_options'] ) );
		if ( is_wp_error( $result ) ) {
			$this->set_settings_notice( 'error', $result->get_error_message() );
			$this->redirect_to_settings();
		}

		$message = sprintf(
			/* translators: 1: number of rows restored, 2: number of tables, 3: number of settings. */
			__( 'Restored %1$d records across %2$d tables (%3$d settings).', 'auto-mation' ),
			(int) $result['rows'],
			(int) $result['tables'],
			(int) $result['options']
		);
		if ( ! empty( $result['skipped'] ) ) {
			$message .= ' ' . sprintf(
				/* translators: %s: comma-separated list of table names present in the file but not on this install. */
				__( 'Skipped unknown tables: %s.', 'auto-mation' ),
				implode( ', ', array_map( 'sanitize_key', (array) $result['skipped'] ) )
			);
		}

		$this->set_settings_notice( 'success', $message );
		$this->redirect_to_settings();
	}

	/**
	 * Save the event log's retention window (Logs page).
	 *
	 * @return void
	 */
	public function handle_save_log_options() {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'auto-mation' ) );
		}
		check_admin_referer( 'amat_save_log_options' );

		$days = isset( $_POST['retention_days'] ) ? absint( wp_unslash( $_POST['retention_days'] ) ) : AMAT_Log::RETENTION_DEFAULT;
		$days = min( 3650, $days );
		update_option( AMAT_Log::RETENTION_OPTION, $days, false );

		$this->set_logs_notice(
			'success',
			$days > 0
				/* translators: %d: number of days. */
				? sprintf( __( 'Log entries are now kept for %d days.', 'auto-mation' ), $days )
				: __( 'Log entries are now kept forever. Keep an eye on the table size.', 'auto-mation' )
		);
		$this->redirect_to_logs();
	}

	/**
	 * Delete every event-log entry (Logs page).
	 *
	 * @return void
	 */
	public function handle_purge_logs() {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'auto-mation' ) );
		}
		check_admin_referer( 'amat_purge_logs' );

		$removed = AMAT_Log_Model::purge_all();

		/* translators: %d: number of log entries deleted. */
		$this->set_logs_notice( 'success', sprintf( __( 'Deleted %d log entries.', 'auto-mation' ), (int) $removed ) );
		$this->redirect_to_logs();
	}

	/**
	 * Redirect to the Logs page and exit.
	 *
	 * @return void
	 */
	private function redirect_to_logs() {
		wp_safe_redirect( add_query_arg( array( 'page' => AMAT_Logs_Page::PAGE_SLUG ), admin_url( 'admin.php' ) ) );
		exit;
	}

	/**
	 * Stash a one-shot notice for the Logs page.
	 *
	 * Uses the AMAT_Admin_Page flash key, so the Logs page's take_flash() picks
	 * it up on the redirect's destination.
	 *
	 * @param string $status 'success' or 'error'.
	 * @param string $message Notice text.
	 * @return void
	 */
	private function set_logs_notice( $status, $message ) {
		set_transient(
			'amat_flash_' . AMAT_Logs_Page::PAGE_SLUG . '_' . get_current_user_id(),
			array( 'status' => $status, 'message' => $message ),
			MINUTE_IN_SECONDS
		);
	}

	/**
	 * Human labels for the Dev Tools clearable entities.
	 *
	 * @return array<string,string>
	 */
	private static function clearable_labels() {
		return array(
			'customers' => __( 'Customers', 'auto-mation' ),
			'vehicles'  => __( 'Vehicles', 'auto-mation' ),
			'locations' => __( 'Locations', 'auto-mation' ),
			'jobs'      => __( 'Jobs', 'auto-mation' ),
			'services'  => __( 'Services', 'auto-mation' ),
			'parts'     => __( 'Parts', 'auto-mation' ),
			'estimates' => __( 'Estimates', 'auto-mation' ),
			'invoices'  => __( 'Invoices', 'auto-mation' ),
			'logs'      => __( 'Logs', 'auto-mation' ),
		);
	}

	/**
	 * Handle the Dev Tools feedback scratchpad save.
	 *
	 * @return void
	 */
	public function handle_save_feedback() {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'auto-mation' ) );
		}
		check_admin_referer( 'amat_save_feedback' );

		$feedback = isset( $_POST['amat_feedback'] ) ? sanitize_textarea_field( wp_unslash( $_POST['amat_feedback'] ) ) : '';
		update_option( self::FEEDBACK_OPTION, $feedback, false );

		$this->set_settings_notice( 'success', __( 'Feedback saved.', 'auto-mation' ) );
		$this->redirect_to_settings();
	}

	/**
	 * Handle the Dev Tools development-options save (the delete-button toggle).
	 *
	 * @return void
	 */
	public function handle_save_dev_options() {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'auto-mation' ) );
		}
		check_admin_referer( 'amat_save_dev_options' );

		update_option( self::DEV_DELETE_OPTION, ! empty( $_POST['allow_delete'] ), false );

		$this->set_settings_notice( 'success', __( 'Development options saved.', 'auto-mation' ) );
		$this->redirect_to_settings();
	}

	/**
	 * Redirect to the Settings page and exit (used after a Dev Tools POST).
	 *
	 * @return void
	 */
	private function redirect_to_settings() {
		wp_safe_redirect( add_query_arg( array( 'page' => self::SETTINGS_SLUG ), admin_url( 'admin.php' ) ) );
		exit;
	}

	/**
	 * Stash a one-shot Settings notice for the current user.
	 *
	 * @param string $type    'success' or 'error'.
	 * @param string $message Notice text.
	 * @return void
	 */
	private function set_settings_notice( $type, $message ) {
		set_transient(
			'amat_settings_notice_' . get_current_user_id(),
			array( 'type' => ( 'error' === $type ? 'error' : 'success' ), 'message' => $message ),
			MINUTE_IN_SECONDS
		);
	}

	/**
	 * Read and clear the current user's Settings notice, if any.
	 *
	 * @return array{type:string,message:string}|null
	 */
	private function take_settings_notice() {
		$key     = 'amat_settings_notice_' . get_current_user_id();
		$payload = get_transient( $key );
		if ( false === $payload ) {
			return null;
		}
		delete_transient( $key );
		return is_array( $payload ) ? $payload : null;
	}
}
