<?php
/**
 * Invoices admin page: native customer-owned invoice documents.
 *
 * Parallel to AMAT_Estimates_Page (same PRG base, customer lock, vehicle
 * dropdown, line-item repeater) with invoice-specific fields (due date, payment
 * status). Sending + payment collection are delegated to a provider integration
 * via external_refs, rendered through the `amat_invoice_detail_actions` hook.
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Renders the Invoices list, read-only detail, and add/edit form.
 */
class AMAT_Invoices_Page extends AMAT_Admin_Page {

	const NONCE_ACTION = 'amat_save_invoice';
	const PAGE_SLUG    = 'amat-invoices';
	const POST_ACTION  = 'save_invoice';

	/**
	 * Invoices opt into the Dev Tools per-record delete. They have no soft-delete
	 * (no is_active): a cancelled invoice carries the 'void' *status* instead
	 * (DB v16) — hence this overrides deletable_model() directly rather than
	 * inheriting it from active_model().
	 *
	 * @return string
	 */
	protected static function deletable_model() {
		return 'AMAT_Invoice_Model';
	}

	/**
	 * Cascade an invoice hard-delete to its line items (Dev Tools delete).
	 *
	 * @param int $id Deleted invoice id.
	 * @return void
	 */
	protected function after_delete( $id ) {
		global $wpdb;
		$wpdb->delete( $wpdb->prefix . 'amat_invoice_items', array( 'invoice_id' => (int) $id ) );
	}

	/**
	 * Render the page: route to list / detail / form.
	 *
	 * @return void
	 */
	public function render() {
		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'auto-mation' ) );
		}

		$flash  = $this->take_flash();
		$action = isset( $_GET['action'] ) ? sanitize_key( wp_unslash( $_GET['action'] ) ) : '';

		// Invoices are created and edited on their parent job now (§ job-owned
		// documents). 'view' stays read-only; 'edit'/'new' collapse to it/the list.
		if ( 'view' === $action || 'edit' === $action ) {
			$id      = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0;
			$invoice = $id ? AMAT_Invoice_Model::find( $id ) : null;
			if ( ! $invoice ) {
				$this->render_list( '', __( 'Invoice not found.', 'auto-mation' ) );
				return;
			}
			$success = ( $flash && 'success' === $flash['status'] ) ? $flash['message'] : '';
			$error   = ( $flash && 'error' === $flash['status'] ) ? $flash['message'] : '';
			$this->render_view( $invoice, $success, $error );
			return;
		}

		$success = ( $flash && 'success' === $flash['status'] ) ? $flash['message'] : '';
		$error   = ( $flash && 'error' === $flash['status'] ) ? $flash['message'] : '';
		$this->render_list( $success, $error );
	}

	/* --------------------------------------------------------------------- */
	/* List                                                                  */
	/* --------------------------------------------------------------------- */

	/**
	 * Render the invoices list (all invoices, newest first).
	 *
	 * @param string $success Optional success notice.
	 * @param string $error   Optional error notice.
	 * @return void
	 */
	private function render_list( $success = '', $error = '' ) {
		$invoices = AMAT_Invoice_Model::all( array(), array( 'orderby' => 'id', 'order' => 'DESC' ) );
		?>
		<div class="wrap">
			<h1 class="wp-heading-inline"><?php esc_html_e( 'Invoices', 'auto-mation' ); ?></h1>
			<hr class="wp-header-end" />

			<?php if ( $success ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php echo esc_html( $success ); ?></p></div>
			<?php endif; ?>
			<?php if ( $error ) : ?>
				<div class="notice notice-error is-dismissible"><p><?php echo esc_html( $error ); ?></p></div>
			<?php endif; ?>

			<p class="description"><?php esc_html_e( 'A read-only list of every invoice. Open one to view it; invoices are created and edited on their job.', 'auto-mation' ); ?></p>

			<table class="wp-list-table widefat fixed striped">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Invoice', 'auto-mation' ); ?></th>
						<th><?php esc_html_e( 'Customer', 'auto-mation' ); ?></th>
						<th><?php esc_html_e( 'Status', 'auto-mation' ); ?></th>
						<th><?php esc_html_e( 'Total', 'auto-mation' ); ?></th>
						<th><?php esc_html_e( 'Issued', 'auto-mation' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php if ( empty( $invoices ) ) : ?>
						<tr><td colspan="5"><?php esc_html_e( 'No invoices yet.', 'auto-mation' ); ?></td></tr>
					<?php else : ?>
						<?php foreach ( $invoices as $invoice ) : ?>
							<?php
							$view_url = $this->list_url( array( 'action' => 'view', 'id' => (int) $invoice['id'] ) );
							$owner    = $invoice['customer_id'] ? AMAT_Customer_Model::find( (int) $invoice['customer_id'] ) : null;
							?>
							<tr class="amat-clickable-row" data-href="<?php echo esc_url( $view_url ); ?>">
								<td><a href="<?php echo esc_url( $view_url ); ?>"><?php echo esc_html( self::label( $invoice ) ); ?></a></td>
								<td><?php echo esc_html( $owner ? AMAT_Customer_Model::display_name( $owner ) : '—' ); ?></td>
								<td><span class="amat-status amat-status-<?php echo esc_attr( $invoice['status'] ); ?>"><?php echo esc_html( AMAT_Invoice_Model::status_label( $invoice['status'] ) ); ?></span></td>
								<td><?php echo esc_html( AMAT_Money::format_amount( AMAT_Invoice_Model::total( (int) $invoice['id'] ) ) ); ?></td>
								<td><?php echo esc_html( AMAT_Estimates_Page::date_display( $invoice['issue_date'] ?? '' ) ); ?></td>
							</tr>
						<?php endforeach; ?>
					<?php endif; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	/* --------------------------------------------------------------------- */
	/* Read-only detail view                                                 */
	/* --------------------------------------------------------------------- */

	/**
	 * Render the read-only invoice detail.
	 *
	 * @param array<string,mixed> $invoice Invoice row.
	 * @param string              $success Optional success notice.
	 * @param string              $error   Optional error notice.
	 * @return void
	 */
	private function render_view( array $invoice, $success = '', $error = '' ) {
		$id              = (int) $invoice['id'];
		$return_customer = isset( $_GET['return_customer'] ) ? absint( $_GET['return_customer'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only nav context.
		$owner           = $invoice['customer_id'] ? AMAT_Customer_Model::find( (int) $invoice['customer_id'] ) : null;
		$vehicle         = $invoice['vehicle_id'] ? AMAT_Vehicle_Model::find( (int) $invoice['vehicle_id'] ) : null;
		$items           = AMAT_Invoice_Item_Model::for_parent( $id );
		$notes           = trim( (string) ( $invoice['notes'] ?? '' ) );

		$job_id   = (int) ( $invoice['job_id'] ?? 0 );
		$job_edit = $job_id
			? add_query_arg( array( 'page' => AMAT_Jobs_Page::PAGE_SLUG, 'action' => 'edit', 'id' => $job_id ), admin_url( 'admin.php' ) )
			: '';
		$back_url   = $return_customer
			? add_query_arg( array( 'page' => AMAT_Customers_Page::PAGE_SLUG, 'action' => 'view', 'id' => $return_customer ), admin_url( 'admin.php' ) )
			: $this->list_url();
		$back_label = $return_customer ? __( 'Back to customer', 'auto-mation' ) : __( 'Back to invoices', 'auto-mation' );
		?>
		<div class="wrap amat-detail">
			<h1><?php echo esc_html( self::label( $invoice ) ); ?></h1>
			<div class="amat-detail-actions">
				<?php if ( $job_edit ) : ?>
					<a href="<?php echo esc_url( $job_edit ); ?>" class="button amat-btn-primary"><?php esc_html_e( 'Edit on job', 'auto-mation' ); ?></a>
				<?php endif; ?>
				<a href="<?php echo esc_url( $back_url ); ?>" class="button amat-btn-secondary"><?php echo esc_html( $back_label ); ?></a>
			</div>
			<hr class="wp-header-end" />

			<?php if ( $success ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php echo esc_html( $success ); ?></p></div>
			<?php endif; ?>
			<?php if ( $error ) : ?>
				<div class="notice notice-error is-dismissible"><p><?php echo esc_html( $error ); ?></p></div>
			<?php endif; ?>

			<table class="amat-detail-table">
				<tbody>
					<tr><th><?php esc_html_e( 'Customer', 'auto-mation' ); ?></th><td><?php echo esc_html( $owner ? AMAT_Customer_Model::display_name( $owner ) : '—' ); ?></td></tr>
					<tr><th><?php esc_html_e( 'Status', 'auto-mation' ); ?></th><td><span class="amat-status amat-status-<?php echo esc_attr( $invoice['status'] ); ?>"><?php echo esc_html( AMAT_Invoice_Model::status_label( $invoice['status'] ) ); ?></span></td></tr>
					<?php
					$src_estimate = (int) ( $invoice['estimate_id'] ?? 0 ) ? AMAT_Estimate_Model::find( (int) $invoice['estimate_id'] ) : null;
					if ( $src_estimate ) :
						$est_url = add_query_arg( array( 'page' => AMAT_Estimates_Page::PAGE_SLUG, 'action' => 'view', 'id' => (int) $src_estimate['id'] ), admin_url( 'admin.php' ) );
						?>
						<tr><th><?php esc_html_e( 'From estimate', 'auto-mation' ); ?></th><td><a href="<?php echo esc_url( $est_url ); ?>"><?php echo esc_html( AMAT_Estimates_Page::label( $src_estimate ) ); ?></a></td></tr>
					<?php endif; ?>
					<tr><th><?php esc_html_e( 'Vehicle', 'auto-mation' ); ?></th><td><?php echo esc_html( $vehicle ? AMAT_Vehicle_Model::label( $vehicle ) : '—' ); ?></td></tr>
					<tr><th><?php esc_html_e( 'Issue date', 'auto-mation' ); ?></th><td><?php echo esc_html( AMAT_Estimates_Page::date_display( $invoice['issue_date'] ?? '' ) ?: '—' ); ?></td></tr>
					<tr><th><?php esc_html_e( 'Due date', 'auto-mation' ); ?></th><td><?php echo esc_html( AMAT_Estimates_Page::date_display( $invoice['due_date'] ?? '' ) ?: '—' ); ?></td></tr>
					<tr><th><?php esc_html_e( 'Amount paid', 'auto-mation' ); ?></th><td><?php echo esc_html( AMAT_Money::format( $invoice['amount_paid'] ?? null ) ?: '—' ); ?><?php echo trim( (string) ( $invoice['paid_date'] ?? '' ) ) && 0 !== strpos( (string) $invoice['paid_date'], '0000' ) ? ' <span class="description">(' . esc_html( AMAT_Estimates_Page::date_display( $invoice['paid_date'] ) ) . ')</span>' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inline. ?></td></tr>
				</tbody>
			</table>

			<h2><?php esc_html_e( 'Line items', 'auto-mation' ); ?></h2>
			<?php $this->render_items_table( $items ); ?>

			<h2><?php esc_html_e( 'Notes', 'auto-mation' ); ?></h2>
			<p><?php echo '' !== $notes ? nl2br( esc_html( $notes ) ) : '<span class="description">' . esc_html__( 'No notes.', 'auto-mation' ) . '</span>'; ?></p>

			<?php
			/**
			 * Let a provider integration add actions to the invoice detail
			 * — "Push to Wave", payment status, etc. Core ships no default.
			 *
			 * @param array<string,mixed> $invoice Invoice row.
			 */
			do_action( 'amat_invoice_detail_actions', $invoice );
			?>
		</div>
		<?php
	}

	/**
	 * Render a read-only line-items table with computed amounts + total.
	 *
	 * @param array<int,array<string,mixed>> $items Line item rows.
	 * @return void
	 */
	private function render_items_table( array $items ) {
		if ( empty( $items ) ) {
			echo '<p class="description">' . esc_html__( 'No line items.', 'auto-mation' ) . '</p>';
			return;
		}
		$total = 0.0;
		?>
		<table class="wp-list-table widefat fixed striped amat-items-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Description', 'auto-mation' ); ?></th>
					<th class="amat-col-num"><?php esc_html_e( 'Qty', 'auto-mation' ); ?></th>
					<th class="amat-col-num"><?php esc_html_e( 'Unit price', 'auto-mation' ); ?></th>
					<th class="amat-col-num"><?php esc_html_e( 'Amount', 'auto-mation' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $items as $item ) : ?>
					<?php
					$amount = AMAT_Invoice_Item_Model::line_amount( $item );
					$total += $amount;
					?>
					<tr>
						<td><?php echo esc_html( $item['description'] ); ?></td>
						<td class="amat-col-num"><?php echo esc_html( rtrim( rtrim( number_format( (float) $item['quantity'], 2 ), '0' ), '.' ) ); ?></td>
						<td class="amat-col-num"><?php echo esc_html( AMAT_Money::format( $item['unit_price'] ?? null ) ?: '—' ); ?></td>
						<td class="amat-col-num"><?php echo esc_html( AMAT_Money::format_amount( $amount ) ); ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
			<tfoot>
				<tr>
					<th colspan="3" class="amat-col-num"><?php esc_html_e( 'Total', 'auto-mation' ); ?></th>
					<th class="amat-col-num"><?php echo esc_html( AMAT_Money::format_amount( $total ) ); ?></th>
				</tr>
			</tfoot>
		</table>
		<?php
	}

	/* --------------------------------------------------------------------- */
	/* Save                                                                  */
	/* --------------------------------------------------------------------- */

	/**
	 * Validate and persist the submitted invoice.
	 *
	 * @return array{status:string,message:string,data?:array,editing_id?:int}
	 */
	protected function save() {
		check_admin_referer( self::NONCE_ACTION );
		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			return array( 'status' => 'error', 'message' => __( 'You are not allowed to save invoices.', 'auto-mation' ), 'data' => array(), 'editing_id' => 0 );
		}

		$id              = isset( $_POST['invoice_id'] ) ? absint( $_POST['invoice_id'] ) : 0;
		$return_customer = isset( $_POST['return_customer'] ) ? absint( $_POST['return_customer'] ) : 0;
		$status          = isset( $_POST['status'] ) ? sanitize_key( wp_unslash( $_POST['status'] ) ) : 'draft';
		$rows            = AMAT_Estimates_Page::collect_item_rows();

		$data = array(
			'customer_id'     => isset( $_POST['customer_id'] ) ? absint( $_POST['customer_id'] ) : 0,
			'return_customer' => $return_customer,
			'vehicle_id'      => isset( $_POST['vehicle_id'] ) ? absint( $_POST['vehicle_id'] ) : 0,
			'status'          => in_array( $status, AMAT_Invoice_Model::STATUSES, true ) ? $status : 'draft',
			'number'          => sanitize_text_field( wp_unslash( $_POST['number'] ?? '' ) ),
			'issue_date'      => sanitize_text_field( wp_unslash( $_POST['issue_date'] ?? '' ) ),
			'due_date'        => sanitize_text_field( wp_unslash( $_POST['due_date'] ?? '' ) ),
			'notes'           => sanitize_textarea_field( wp_unslash( $_POST['notes'] ?? '' ) ),
			'_items'          => $rows,
		);

		if ( ! $data['customer_id'] ) {
			return array( 'status' => 'error', 'message' => __( 'Please choose a customer for this invoice.', 'auto-mation' ), 'data' => $data, 'editing_id' => $id );
		}

		if ( $id ) {
			AMAT_Invoice_Model::update( $id, $data );
		} else {
			$id = AMAT_Invoice_Model::create( $data );
		}
		if ( ! $id ) {
			return array( 'status' => 'error', 'message' => __( 'Could not save the invoice. Please try again.', 'auto-mation' ), 'data' => $data, 'editing_id' => 0 );
		}

		AMAT_Invoice_Item_Model::replace_for_parent( $id, AMAT_Estimates_Page::persist_catalog_flags( $rows ) );

		$success = array( 'status' => 'success', 'message' => __( 'Invoice saved.', 'auto-mation' ) );
		if ( $return_customer ) {
			$success['redirect'] = add_query_arg( array( 'page' => AMAT_Customers_Page::PAGE_SLUG, 'action' => 'view', 'id' => $return_customer ), admin_url( 'admin.php' ) );
		} else {
			$success['redirect'] = $this->list_url( array( 'action' => 'view', 'id' => (int) $id ) );
		}
		return $success;
	}

	/**
	 * Display label for an invoice: its number, else "#ID".
	 *
	 * @param array<string,mixed> $invoice Invoice row.
	 * @return string
	 */
	public static function label( array $invoice ) {
		$number = trim( (string) ( $invoice['number'] ?? '' ) );
		/* translators: %d: invoice id. */
		return '' !== $number ? $number : sprintf( __( 'Invoice #%d', 'auto-mation' ), (int) $invoice['id'] );
	}
}
