<?php
/**
 * Jobs admin page: a month calendar (default) and a status-filterable grid of
 * all jobs, plus the add/edit form. Jobs tie a customer + vehicle + location +
 * work + status together.
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Renders the Jobs calendar/grid views and the add/edit form.
 *
 * Two list views share a toolbar (Add job + Calendar/Grid toggle):
 *  - Calendar (default): a server-rendered month grid; scheduled jobs sit on
 *    their day, unscheduled jobs are listed below so requests aren't lost.
 *  - Grid: a status-filterable, click-to-sort table.
 *
 * A job's owning customer is chosen with an AJAX search (not a dropdown). When
 * a job is added from a customer (`return_customer`) or edited, the customer is
 * fixed/locked instead. Vehicle/location options are scoped to the customer —
 * server-rendered when the customer is known, or loaded via AJAX on selection.
 *
 * Security pattern per §5 (nonce, capability, sanitize in, escape out).
 */
class AMAT_Jobs_Page extends AMAT_Admin_Page {

	const NONCE_ACTION = 'amat_save_job';
	const PAGE_SLUG    = 'amat-jobs';
	const POST_ACTION  = 'save_job';
	const CUST_NONCE   = 'amat_job_customer';
	const DOC_NONCE    = 'amat_job_doc';

	/**
	 * Jobs have no soft-delete, but opt into the Dev Tools per-record delete.
	 *
	 * @return string
	 */
	protected static function deletable_model() {
		return 'AMAT_Job_Model';
	}

	/**
	 * Cascade a job hard-delete to its parts orders and service records (Dev Tools
	 * delete). The job's linked draft estimate is left in place (it is a
	 * customer-owned financial document, deletable on its own).
	 *
	 * @param int $id Deleted job id.
	 * @return void
	 */
	protected function after_delete( $id ) {
		global $wpdb;
		$wpdb->delete( $wpdb->prefix . 'amat_parts_orders', array( 'job_id' => (int) $id ) );
		$wpdb->delete( $wpdb->prefix . 'amat_service_records', array( 'job_id' => (int) $id ) );
	}

	/**
	 * Render the page: show any flashed notice, then route to a view or form.
	 *
	 * @return void
	 */
	public function render() {
		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'auto-mation' ) );
		}

		$flash  = $this->take_flash();
		$action = isset( $_GET['action'] ) ? sanitize_key( wp_unslash( $_GET['action'] ) ) : '';

		if ( 'view' === $action ) {
			$id  = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0;
			$job = $id ? AMAT_Job_Model::find( $id ) : null;
			if ( ! $job ) {
				$this->render_grid( '', __( 'Job not found.', 'auto-mation' ) );
				return;
			}
			$success = ( $flash && 'success' === $flash['status'] ) ? $flash['message'] : '';
			$error   = ( $flash && 'error' === $flash['status'] ) ? $flash['message'] : '';
			$this->render_view( $job, $success, $error );
			return;
		}

		if ( 'new' === $action || 'edit' === $action ) {
			if ( $flash && 'error' === $flash['status'] ) {
				$this->render_form( $flash['data'], $flash['editing_id'], $flash['message'] );
				return;
			}
			if ( 'new' === $action ) {
				$this->render_form( array(), 0 );
				return;
			}
			$id  = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0;
			$job = $id ? AMAT_Job_Model::find( $id ) : null;
			if ( ! $job ) {
				$this->render_grid( '', __( 'Job not found.', 'auto-mation' ) );
				return;
			}
			$this->render_form( $job, $id );
			return;
		}

		$success = ( $flash && 'success' === $flash['status'] ) ? $flash['message'] : '';
		$error   = ( $flash && 'error' === $flash['status'] ) ? $flash['message'] : '';

		$view = isset( $_GET['view'] ) ? sanitize_key( wp_unslash( $_GET['view'] ) ) : 'calendar';
		if ( 'grid' === $view ) {
			$this->render_grid( $success, $error );
		} else {
			$this->render_calendar( $success, $error );
		}
	}

	/* --------------------------------------------------------------------- */
	/* Shared toolbar                                                        */
	/* --------------------------------------------------------------------- */

	/**
	 * Echo the page heading, the Add job button, and the Calendar/Grid toggle.
	 *
	 * @param string $active 'calendar' or 'grid'.
	 * @return void
	 */
	private function toolbar( $active ) {
		$add_url  = $this->list_url( array( 'action' => 'new' ) );
		$cal_url  = $this->list_url( array( 'view' => 'calendar' ) );
		$grid_url = $this->list_url( array( 'view' => 'grid' ) );
		?>
		<h1 class="wp-heading-inline"><?php esc_html_e( 'Jobs', 'auto-mation' ); ?></h1>
		<hr class="wp-header-end" />
		<div class="amat-list-bar">
			<a href="<?php echo esc_url( $add_url ); ?>" class="button amat-btn-primary amat-add-inline"><?php esc_html_e( 'Add job', 'auto-mation' ); ?></a>
			<span class="amat-view-toggle">
				<a href="<?php echo esc_url( $cal_url ); ?>" class="button <?php echo 'calendar' === $active ? 'amat-btn-primary' : ''; ?>"><?php esc_html_e( 'Calendar', 'auto-mation' ); ?></a>
				<a href="<?php echo esc_url( $grid_url ); ?>" class="button <?php echo 'grid' === $active ? 'amat-btn-primary' : ''; ?>"><?php esc_html_e( 'Grid', 'auto-mation' ); ?></a>
			</span>
		</div>
		<?php
	}

	/* --------------------------------------------------------------------- */
	/* Calendar view                                                         */
	/* --------------------------------------------------------------------- */

	/**
	 * Render a month calendar of scheduled jobs, with prev/next/today nav and a
	 * list of unscheduled jobs below.
	 *
	 * @param string $success Optional success notice.
	 * @param string $error   Optional error notice.
	 * @return void
	 */
	private function render_calendar( $success = '', $error = '' ) {
		$today = current_time( 'Y-m-d' );

		$month = isset( $_GET['month'] ) ? sanitize_text_field( wp_unslash( $_GET['month'] ) ) : '';
		if ( ! preg_match( '/^\d{4}-\d{2}$/', $month ) ) {
			$month = substr( $today, 0, 7 );
		}
		$first = date_create( $month . '-01' );
		if ( ! $first ) {
			$month = substr( $today, 0, 7 );
			$first = date_create( $month . '-01' );
		}

		$days_in_month = (int) $first->format( 't' );
		$start_dow     = (int) $first->format( 'w' ); // 0 = Sunday.
		$prev_month    = date_create( $month . '-01' )->modify( '-1 month' )->format( 'Y-m' );
		$next_month    = date_create( $month . '-01' )->modify( '+1 month' )->format( 'Y-m' );

		// Bucket scheduled jobs by day (any month, so the grid's leading/trailing
		// overflow days can show events too); collect unscheduled ones separately.
		$by_day      = array();
		$unscheduled = array();
		foreach ( AMAT_Job_Model::all() as $job ) {
			$start = trim( (string) ( $job['scheduled_start'] ?? '' ) );
			if ( '' === $start || 0 === strpos( $start, '0000' ) ) {
				$unscheduled[] = $job;
				continue;
			}
			$by_day[ substr( $start, 0, 10 ) ][] = $job;
		}

		// The grid's first cell is the Sunday on/before the 1st (so leading days
		// belong to the previous month; trailing cells spill into the next).
		$grid_start = date_create( $month . '-01' )->modify( "-{$start_dow} days" );

		$weekdays   = array( __( 'Sun', 'auto-mation' ), __( 'Mon', 'auto-mation' ), __( 'Tue', 'auto-mation' ), __( 'Wed', 'auto-mation' ), __( 'Thu', 'auto-mation' ), __( 'Fri', 'auto-mation' ), __( 'Sat', 'auto-mation' ) );
		$total      = $start_dow + $days_in_month;
		$cells      = (int) ( ceil( $total / 7 ) * 7 );
		$prev_url   = $this->list_url( array( 'view' => 'calendar', 'month' => $prev_month ) );
		$next_url   = $this->list_url( array( 'view' => 'calendar', 'month' => $next_month ) );
		$today_url  = $this->list_url( array( 'view' => 'calendar' ) );
		?>
		<div class="wrap">
			<?php $this->toolbar( 'calendar' ); ?>

			<?php if ( $success ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php echo esc_html( $success ); ?></p></div>
			<?php endif; ?>
			<?php if ( $error ) : ?>
				<div class="notice notice-error is-dismissible"><p><?php echo esc_html( $error ); ?></p></div>
			<?php endif; ?>

			<div class="amat-cal-nav">
				<a href="<?php echo esc_url( $prev_url ); ?>" class="button">&lsaquo; <?php esc_html_e( 'Prev', 'auto-mation' ); ?></a>
				<a href="<?php echo esc_url( $today_url ); ?>" class="button"><?php esc_html_e( 'Today', 'auto-mation' ); ?></a>
				<a href="<?php echo esc_url( $next_url ); ?>" class="button"><?php esc_html_e( 'Next', 'auto-mation' ); ?> &rsaquo;</a>
				<h2 class="amat-cal-title"><?php echo esc_html( $first->format( 'F Y' ) ); ?></h2>
			</div>

			<table class="amat-calendar">
				<thead>
					<tr>
						<?php foreach ( $weekdays as $wd ) : ?>
							<th><?php echo esc_html( $wd ); ?></th>
						<?php endforeach; ?>
					</tr>
				</thead>
				<tbody>
					<tr>
					<?php for ( $i = 0; $i < $cells; $i++ ) : ?>
						<?php
						$cell     = ( clone $grid_start )->modify( "+{$i} days" );
						$date     = $cell->format( 'Y-m-d' );
						$day_num  = (int) $cell->format( 'j' );
						$in_month = ( $cell->format( 'Y-m' ) === $month );
						$is_today = ( $date === $today );
						$classes  = 'amat-cal-cell' . ( $in_month ? '' : ' amat-cal-other' ) . ( $is_today ? ' amat-cal-today' : '' );
						?>
						<td class="<?php echo esc_attr( $classes ); ?>">
							<div class="amat-cal-daynum"><?php echo (int) $day_num; ?></div>
							<?php if ( ! empty( $by_day[ $date ] ) ) : ?>
								<div class="amat-cal-events">
									<?php foreach ( $by_day[ $date ] as $job ) : ?>
										<?php
										$view_url = $this->list_url( array( 'action' => 'view', 'id' => (int) $job['id'] ) );
										$owner    = AMAT_Customer_Model::find( (int) $job['customer_id'] );
										$who      = $owner ? AMAT_Customer_Model::display_name( $owner ) : __( '(no customer)', 'auto-mation' );
										$time     = $this->dt_time( $job['scheduled_start'] ?? '' );
										$svc      = $this->first_service_name( (int) $job['id'] );
										?>
										<a href="<?php echo esc_url( $view_url ); ?>" class="amat-cal-event amat-status-<?php echo esc_attr( $job['status'] ); ?>" title="<?php echo esc_attr( AMAT_Job_Model::status_label( $job['status'] ) ); ?>">
											<span class="amat-cal-who"><?php if ( '' !== $time ) : ?><span class="amat-cal-time"><?php echo esc_html( $time ); ?></span> <?php endif; ?><?php echo esc_html( AMAT_Job_Model::label( $job, $who ) ); ?></span>
											<?php if ( '' !== $svc ) : ?><span class="amat-cal-svc"><?php echo esc_html( $svc ); ?></span><?php endif; ?>
										</a>
									<?php endforeach; ?>
								</div>
							<?php endif; ?>
						</td>
						<?php if ( 6 === $i % 7 && $i + 1 < $cells ) : ?></tr><tr><?php endif; ?>
					<?php endfor; ?>
					</tr>
				</tbody>
			</table>

			<?php if ( ! empty( $unscheduled ) ) : ?>
				<h2 class="amat-unsched-head"><?php esc_html_e( 'Unscheduled', 'auto-mation' ); ?></h2>
				<p class="description"><?php esc_html_e( 'Jobs with no scheduled start (e.g. open requests).', 'auto-mation' ); ?></p>
				<ul class="amat-unsched-list">
					<?php foreach ( $unscheduled as $job ) : ?>
						<?php
						$view_url = $this->list_url( array( 'action' => 'view', 'id' => (int) $job['id'] ) );
						$owner    = AMAT_Customer_Model::find( (int) $job['customer_id'] );
						$who      = $owner ? AMAT_Customer_Model::display_name( $owner ) : __( '(no customer)', 'auto-mation' );
						$vehicle  = $job['vehicle_id'] ? AMAT_Vehicle_Model::find( (int) $job['vehicle_id'] ) : null;
						?>
						<li>
							<a href="<?php echo esc_url( $view_url ); ?>"><?php echo esc_html( AMAT_Job_Model::label( $job, $who ) ); ?></a>
							<?php if ( $vehicle ) : ?> — <?php echo esc_html( AMAT_Vehicle_Model::label( $vehicle ) ); ?><?php endif; ?>
							<span class="amat-status amat-status-<?php echo esc_attr( $job['status'] ); ?>"><?php echo esc_html( AMAT_Job_Model::status_label( $job['status'] ) ); ?></span>
						</li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>

			<?php
			// Open requests across all time (any month), oldest first, so the
			// owner can triage pending scheduling requests from the calendar.
			$requested = AMAT_Job_Model::all( array( 'status' => 'requested' ), array( 'orderby' => 'created_at', 'order' => 'ASC' ) );
			?>
			<h2 class="amat-requested-head"><?php esc_html_e( 'Requested', 'auto-mation' ); ?></h2>
			<p class="description"><?php esc_html_e( 'All jobs awaiting approval, oldest request first.', 'auto-mation' ); ?></p>
			<?php if ( empty( $requested ) ) : ?>
				<p class="description"><?php esc_html_e( 'No open requests.', 'auto-mation' ); ?></p>
			<?php else : ?>
				<table class="wp-list-table widefat fixed striped">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Customer', 'auto-mation' ); ?></th>
							<th><?php esc_html_e( 'Vehicle', 'auto-mation' ); ?></th>
							<th><?php esc_html_e( 'Requested for', 'auto-mation' ); ?></th>
							<th><?php esc_html_e( 'Created', 'auto-mation' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $requested as $job ) : ?>
							<?php
							$view_url = $this->list_url( array( 'action' => 'view', 'id' => (int) $job['id'] ) );
							$owner    = AMAT_Customer_Model::find( (int) $job['customer_id'] );
							$who      = $owner ? AMAT_Customer_Model::display_name( $owner ) : __( '(no customer)', 'auto-mation' );
							$vehicle  = $job['vehicle_id'] ? AMAT_Vehicle_Model::find( (int) $job['vehicle_id'] ) : null;
							?>
							<tr>
								<td><a href="<?php echo esc_url( $view_url ); ?>"><?php echo esc_html( $who ); ?></a></td>
								<td><?php echo esc_html( $vehicle ? AMAT_Vehicle_Model::label( $vehicle ) : '—' ); ?></td>
								<td><?php echo esc_html( $this->dt_display( $job['scheduled_start'] ?? '' ) ); ?></td>
								<td><?php echo esc_html( $this->dt_display( $job['created_at'] ?? '' ) ); ?></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>
		</div>
		<?php
	}

	/* --------------------------------------------------------------------- */
	/* Grid view                                                             */
	/* --------------------------------------------------------------------- */

	/**
	 * Render the jobs grid with a status filter and click-to-sort headers.
	 *
	 * @param string $success Optional success notice.
	 * @param string $error   Optional error notice.
	 * @return void
	 */
	private function render_grid( $success = '', $error = '' ) {
		$f_status = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '';
		if ( '' !== $f_status && ! in_array( $f_status, AMAT_Job_Model::STATUSES, true ) ) {
			$f_status = '';
		}

		list( $orderby, $order ) = $this->read_sort( array( 'name', 'customer', 'vehicle', 'scheduled', 'status' ), 'scheduled' );

		$jobs = '' !== $f_status
			? AMAT_Job_Model::all( array( 'status' => $f_status ) )
			: AMAT_Job_Model::all();

		foreach ( $jobs as &$j ) {
			$owner         = AMAT_Customer_Model::find( (int) $j['customer_id'] );
			$j['_customer'] = $owner ? AMAT_Customer_Model::display_name( $owner ) : '';
			$vehicle       = $j['vehicle_id'] ? AMAT_Vehicle_Model::find( (int) $j['vehicle_id'] ) : null;
			$j['_vehicle']  = $vehicle ? AMAT_Vehicle_Model::label( $vehicle ) : '';
		}
		unset( $j );

		$jobs = $this->sort_rows(
			$jobs,
			$order,
			static function ( $j ) use ( $orderby ) {
				switch ( $orderby ) {
					case 'customer':
						return (string) $j['_customer'];
					case 'name':
						return (string) ( $j['name'] ?? '' );
					case 'vehicle':
						return (string) $j['_vehicle'];
					case 'status':
						return (string) $j['status'];
					case 'scheduled':
					default:
						return (string) ( $j['scheduled_start'] ?? '' );
				}
			}
		);

		$base_args = array( 'view' => 'grid', 'status' => $f_status );
		?>
		<div class="wrap">
			<?php $this->toolbar( 'grid' ); ?>

			<?php if ( $success ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php echo esc_html( $success ); ?></p></div>
			<?php endif; ?>
			<?php if ( $error ) : ?>
				<div class="notice notice-error is-dismissible"><p><?php echo esc_html( $error ); ?></p></div>
			<?php endif; ?>

			<form method="get" class="amat-list-filters">
				<input type="hidden" name="page" value="<?php echo esc_attr( self::PAGE_SLUG ); ?>" />
				<input type="hidden" name="view" value="grid" />
				<input type="hidden" name="orderby" value="<?php echo esc_attr( $orderby ); ?>" />
				<input type="hidden" name="order" value="<?php echo esc_attr( strtolower( $order ) ); ?>" />
				<label class="screen-reader-text" for="amat-job-status-filter"><?php esc_html_e( 'Filter by status', 'auto-mation' ); ?></label>
				<select name="status" id="amat-job-status-filter">
					<option value=""><?php esc_html_e( 'All statuses', 'auto-mation' ); ?></option>
					<?php foreach ( AMAT_Job_Model::statuses_labeled() as $slug => $label ) : ?>
						<option value="<?php echo esc_attr( $slug ); ?>" <?php selected( $slug, $f_status ); ?>><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select>
				<?php submit_button( __( 'Filter', 'auto-mation' ), '', '', false ); ?>
			</form>

			<table class="wp-list-table widefat fixed striped">
				<thead>
					<tr>
						<?php
						// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- sortable_th() returns escaped HTML.
						echo $this->sortable_th( __( 'Name', 'auto-mation' ), 'name', $orderby, $order, $base_args );
						echo $this->sortable_th( __( 'Scheduled', 'auto-mation' ), 'scheduled', $orderby, $order, $base_args );
						echo $this->sortable_th( __( 'Customer', 'auto-mation' ), 'customer', $orderby, $order, $base_args );
						echo $this->sortable_th( __( 'Vehicle', 'auto-mation' ), 'vehicle', $orderby, $order, $base_args );
						echo $this->sortable_th( __( 'Status', 'auto-mation' ), 'status', $orderby, $order, $base_args );
						// phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
						?>
					</tr>
				</thead>
				<tbody>
					<?php if ( empty( $jobs ) ) : ?>
						<tr><td colspan="5"><?php echo '' !== $f_status ? esc_html__( 'No matching jobs.', 'auto-mation' ) : esc_html__( 'No jobs yet.', 'auto-mation' ); ?></td></tr>
					<?php else : ?>
						<?php foreach ( $jobs as $job ) : ?>
							<?php $view_url = $this->list_url( array( 'action' => 'view', 'id' => (int) $job['id'] ) ); ?>
							<tr class="amat-clickable-row" data-href="<?php echo esc_url( $view_url ); ?>">
								<td><a href="<?php echo esc_url( $view_url ); ?>"><?php echo esc_html( '' !== trim( (string) ( $job['name'] ?? '' ) ) ? $job['name'] : '—' ); ?></a></td>
								<td><?php echo esc_html( $this->dt_display( $job['scheduled_start'] ?? '' ) ); ?></td>
								<td><?php echo esc_html( '' !== $job['_customer'] ? $job['_customer'] : '—' ); ?></td>
								<td><?php echo esc_html( '' !== $job['_vehicle'] ? $job['_vehicle'] : '—' ); ?></td>
								<td><span class="amat-status amat-status-<?php echo esc_attr( $job['status'] ); ?>"><?php echo esc_html( AMAT_Job_Model::status_label( $job['status'] ) ); ?></span></td>
							</tr>
						<?php endforeach; ?>
					<?php endif; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	/* --------------------------------------------------------------------- */
	/* Read-only view                                                        */
	/* --------------------------------------------------------------------- */

	/**
	 * Render a job's read-only detail with an Edit button — the default landing
	 * when a job is opened (mirrors the customer detail), so editing is a
	 * deliberate click rather than an accident.
	 *
	 * @param array<string,mixed> $job     Job row.
	 * @param string              $success Optional success notice.
	 * @param string              $error   Optional error notice.
	 * @return void
	 */
	private function render_view( array $job, $success = '', $error = '' ) {
		$id              = (int) $job['id'];
		$return_customer = isset( $_GET['return_customer'] ) ? absint( $_GET['return_customer'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only nav context.

		$owner     = $job['customer_id'] ? AMAT_Customer_Model::find( (int) $job['customer_id'] ) : null;
		$methods   = $owner ? AMAT_Contact_Method_Model::for_customer( (int) $job['customer_id'] ) : array();
		$vehicle   = $job['vehicle_id'] ? AMAT_Vehicle_Model::find( (int) $job['vehicle_id'] ) : null;
		$location  = $job['location_id'] ? AMAT_Location_Model::find( (int) $job['location_id'] ) : null;
		$estimates = AMAT_Estimate_Model::all( array( 'job_id' => $id ), array( 'orderby' => 'id', 'order' => 'DESC' ) );
		$notes     = trim( (string) ( $job['description'] ?? '' ) );

		$edit_args = array( 'action' => 'edit', 'id' => $id );
		if ( $return_customer ) {
			$edit_args['return_customer'] = $return_customer;
		}
		$edit_url = $this->list_url( $edit_args );
		$back_url = $return_customer
			? add_query_arg( array( 'page' => AMAT_Customers_Page::PAGE_SLUG, 'action' => 'view', 'id' => $return_customer ), admin_url( 'admin.php' ) )
			: $this->list_url();
		$back_label = $return_customer ? __( 'Back to customer', 'auto-mation' ) : __( 'Back to jobs', 'auto-mation' );

		$loc_label   = $location ? trim( (string) $location['label'] ) : '';
		$loc_oneline = $location ? AMAT_Location_Model::one_line( $location ) : '';
		$loc_map     = $location ? AMAT_Location_Model::map_url( $location ) : '';
		?>
		<div class="wrap amat-detail">
			<?php $owner_name = $owner ? AMAT_Customer_Model::display_name( $owner ) : __( 'Job', 'auto-mation' ); ?>
			<h1><?php echo esc_html( AMAT_Job_Model::label( $job, $owner_name ) ); ?></h1>
			<div class="amat-detail-actions">
				<a href="<?php echo esc_url( $edit_url ); ?>" class="button amat-btn-primary"><?php esc_html_e( 'Edit', 'auto-mation' ); ?></a>
				<a href="<?php echo esc_url( $back_url ); ?>" class="button amat-btn-secondary"><?php echo esc_html( $back_label ); ?></a>
				<?php echo $this->delete_button( self::POST_ACTION, self::NONCE_ACTION, $id, $this->list_url() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built with esc_* internally. ?>
			</div>
			<hr class="wp-header-end" />

			<?php if ( $success ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php echo esc_html( $success ); ?></p></div>
			<?php endif; ?>
			<?php if ( $error ) : ?>
				<div class="notice notice-error is-dismissible"><p><?php echo esc_html( $error ); ?></p></div>
			<?php endif; ?>

			<p class="description"><?php esc_html_e( 'Read-only. Tap Edit to change this job.', 'auto-mation' ); ?></p>

			<table class="amat-detail-table">
				<tbody>
					<?php if ( $owner ) : ?>
						<tr>
							<th><?php esc_html_e( 'Customer', 'auto-mation' ); ?></th>
							<td><a href="<?php echo esc_url( add_query_arg( array( 'page' => AMAT_Customers_Page::PAGE_SLUG, 'action' => 'view', 'id' => (int) $owner['id'] ), admin_url( 'admin.php' ) ) ); ?>"><?php echo esc_html( AMAT_Customer_Model::display_name( $owner ) ); ?></a></td>
						</tr>
					<?php endif; ?>
					<tr>
						<th><?php esc_html_e( 'Status', 'auto-mation' ); ?></th>
						<td><span class="amat-status amat-status-<?php echo esc_attr( $job['status'] ); ?>"><?php echo esc_html( AMAT_Job_Model::status_label( $job['status'] ) ); ?></span></td>
					</tr>
					<?php if ( ! empty( $methods ) ) : ?>
						<tr>
							<th><?php esc_html_e( 'Contact', 'auto-mation' ); ?></th>
							<td>
								<ul class="amat-detail-contact">
									<?php foreach ( $methods as $m ) : ?>
										<?php
										$m_type  = (string) ( $m['type'] ?? '' );
										$m_label = AMAT_Contact_Method_Types::label( $m_type );
										$m_show  = AMAT_Contact_Method_Types::format( $m_type, (string) ( $m['value'] ?? '' ) );
										$m_href  = AMAT_Contact_Method_Types::href( $m_type, (string) ( $m['value'] ?? '' ) );
										?>
										<li>
											<span class="amat-contact-label"><?php echo esc_html( $m_label ); ?>:</span>
											<?php if ( $m_href ) : ?>
												<a href="<?php echo esc_url( $m_href ); ?>"><?php echo esc_html( $m_show ); ?></a>
											<?php else : ?>
												<?php echo esc_html( $m_show ); ?>
											<?php endif; ?>
										</li>
									<?php endforeach; ?>
								</ul>
							</td>
						</tr>
					<?php endif; ?>
					<tr>
						<th><?php esc_html_e( 'Vehicle', 'auto-mation' ); ?></th>
						<td><?php echo esc_html( $vehicle ? AMAT_Vehicle_Model::label( $vehicle ) : '—' ); ?></td>
					</tr>
					<?php $view_vin = $vehicle ? trim( (string) ( $vehicle['vin'] ?? '' ) ) : ''; ?>
					<?php if ( '' !== $view_vin ) : ?>
						<tr>
							<th><?php esc_html_e( 'VIN', 'auto-mation' ); ?></th>
							<td><?php $this->render_vin_copy( $view_vin ); ?></td>
						</tr>
					<?php endif; ?>
					<tr>
						<th><?php esc_html_e( 'Location', 'auto-mation' ); ?></th>
						<td>
							<?php if ( ! $location ) : ?>
								—
							<?php else : ?>
								<?php if ( '' !== $loc_label ) : ?><span class="amat-loc-label"><?php echo esc_html( $loc_label ); ?></span><?php endif; ?>
								<?php if ( '' !== $loc_oneline ) : ?>
									<?php if ( '' !== $loc_label ) : ?><br /><?php endif; ?>
									<?php if ( $loc_map ) : ?>
										<a href="<?php echo esc_url( $loc_map ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $loc_oneline ); ?></a>
									<?php else : ?>
										<?php echo esc_html( $loc_oneline ); ?>
									<?php endif; ?>
								<?php elseif ( '' === $loc_label ) : ?>
									—
								<?php endif; ?>
							<?php endif; ?>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Scheduled start', 'auto-mation' ); ?></th>
						<td><?php echo esc_html( $this->dt_display( $job['scheduled_start'] ?? '' ) ); ?></td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Scheduled end', 'auto-mation' ); ?></th>
						<td><?php echo esc_html( $this->dt_display( $job['scheduled_end'] ?? '' ) ); ?></td>
					</tr>
					<?php $mileage = ( null !== ( $job['mileage'] ?? null ) && '' !== (string) $job['mileage'] ) ? (int) $job['mileage'] : null; ?>
					<?php if ( null !== $mileage ) : ?>
						<tr>
							<th><?php esc_html_e( 'Mileage', 'auto-mation' ); ?></th>
							<td><?php echo esc_html( number_format_i18n( $mileage ) ); ?></td>
						</tr>
					<?php endif; ?>
					<tr>
						<th><?php esc_html_e( 'Created', 'auto-mation' ); ?></th>
						<td><?php echo esc_html( $this->dt_display( $job['created_at'] ?? '' ) ); ?></td>
					</tr>
				</tbody>
			</table>

			<h2><?php esc_html_e( 'Notes', 'auto-mation' ); ?></h2>
			<p><?php echo '' !== $notes ? nl2br( esc_html( $notes ) ) : '<span class="description">' . esc_html__( 'No notes.', 'auto-mation' ) . '</span>'; ?></p>

			<?php $invoices = AMAT_Invoice_Model::all( array( 'job_id' => $id ), array( 'orderby' => 'id', 'order' => 'DESC' ) ); ?>

			<h2><?php esc_html_e( 'Estimates', 'auto-mation' ); ?></h2>
			<?php if ( empty( $estimates ) ) : ?>
				<p class="description"><?php esc_html_e( 'No estimates yet. Edit this job to add one.', 'auto-mation' ); ?></p>
			<?php else : ?>
				<ul class="amat-job-service-list">
					<?php foreach ( $estimates as $est ) : ?>
						<?php
						$est_url = add_query_arg(
							array( 'page' => AMAT_Estimates_Page::PAGE_SLUG, 'action' => 'view', 'id' => (int) $est['id'] ),
							admin_url( 'admin.php' )
						);
						?>
						<li>
							<a href="<?php echo esc_url( $est_url ); ?>"><?php echo esc_html( AMAT_Estimates_Page::label( $est ) ); ?></a>
							<span class="amat-status amat-status-<?php echo esc_attr( $est['status'] ); ?>"><?php echo esc_html( AMAT_Estimate_Model::status_label( $est['status'] ) ); ?></span>
							<span class="description"><?php echo esc_html( AMAT_Money::format_amount( AMAT_Estimate_Model::total( (int) $est['id'] ) ) ); ?></span>
						</li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>

			<h2><?php esc_html_e( 'Invoices', 'auto-mation' ); ?></h2>
			<?php if ( empty( $invoices ) ) : ?>
				<p class="description"><?php esc_html_e( 'No invoices yet.', 'auto-mation' ); ?></p>
			<?php else : ?>
				<ul class="amat-job-service-list">
					<?php foreach ( $invoices as $inv ) : ?>
						<?php
						$inv_url = add_query_arg(
							array( 'page' => AMAT_Invoices_Page::PAGE_SLUG, 'action' => 'view', 'id' => (int) $inv['id'] ),
							admin_url( 'admin.php' )
						);
						?>
						<li>
							<a href="<?php echo esc_url( $inv_url ); ?>"><?php echo esc_html( AMAT_Invoices_Page::label( $inv ) ); ?></a>
							<span class="amat-status amat-status-<?php echo esc_attr( $inv['status'] ); ?>"><?php echo esc_html( AMAT_Invoice_Model::status_label( $inv['status'] ) ); ?></span>
							<span class="description"><?php echo esc_html( AMAT_Money::format_amount( AMAT_Invoice_Model::total( (int) $inv['id'] ) ) ); ?></span>
						</li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>

			<?php
			/**
			 * Let a provider integration add actions to the job detail. Core ships
			 * no default (estimate→provider sync lives on the native estimate).
			 *
			 * @param array<string,mixed>      $job   Job row.
			 * @param array<string,mixed>|null $owner Owning customer row.
			 */
			do_action( 'amat_job_detail_actions', $job, $owner );
			?>
		</div>
		<?php
	}

	/**
	 * First line-item description of the job's newest estimate, truncated for
	 * compact display (e.g. on the calendar), or '' when there's none.
	 *
	 * @param int $job_id Job id.
	 * @param int $limit  Max characters before truncating with an ellipsis.
	 * @return string
	 */
	private function first_service_name( $job_id, $limit = 24 ) {
		$ests = AMAT_Estimate_Model::all( array( 'job_id' => absint( $job_id ) ), array( 'orderby' => 'id', 'order' => 'DESC', 'limit' => 1 ) );
		if ( empty( $ests ) ) {
			return '';
		}
		$items = AMAT_Estimate_Item_Model::for_parent( (int) $ests[0]['id'] );
		if ( empty( $items ) ) {
			return '';
		}
		$name = (string) $items[0]['description'];
		if ( function_exists( 'mb_strlen' ) ? mb_strlen( $name ) > $limit : strlen( $name ) > $limit ) {
			$name = ( function_exists( 'mb_substr' ) ? mb_substr( $name, 0, $limit - 1 ) : substr( $name, 0, $limit - 1 ) ) . '…';
		}
		return $name;
	}

	/**
	 * Echo a VIN with a copy-to-clipboard button (for 3rd-party parts lookups).
	 * Shown on the job view + edit screens when the vehicle has a VIN.
	 *
	 * @param string $vin The vehicle VIN.
	 * @return void
	 */
	private function render_vin_copy( $vin ) {
		$vin = trim( (string) $vin );
		if ( '' === $vin ) {
			return;
		}
		?>
		<span class="amat-vin-display">
			<code class="amat-vin-value"><?php echo esc_html( $vin ); ?></code>
			<button type="button" class="button-link amat-copy-btn" data-copy="<?php echo esc_attr( $vin ); ?>" title="<?php esc_attr_e( 'Copy VIN', 'auto-mation' ); ?>" aria-label="<?php esc_attr_e( 'Copy VIN', 'auto-mation' ); ?>"><span class="dashicons dashicons-clipboard"></span></button>
		</span>
		<?php
	}

	/* --------------------------------------------------------------------- */
	/* Add / edit form                                                       */
	/* --------------------------------------------------------------------- */

	/**
	 * Render the add/edit form.
	 *
	 * The owning customer is locked when the job is reached from a customer
	 * (`return_customer`) or being edited; otherwise it is chosen with an AJAX
	 * search. Vehicle/location options are server-rendered when the customer is
	 * known (locked, or repopulated after a validation error) and loaded via
	 * AJAX when a customer is picked in the search.
	 *
	 * @param array<string,mixed> $data  Job row or submitted values.
	 * @param int                 $id    Job id (0 = new).
	 * @param string              $error Optional error notice.
	 * @return void
	 */
	private function render_form( array $data, $id, $error = '' ) {
		$id      = absint( $id );
		$is_edit = $id > 0;
		$cust_id = (int) ( $data['customer_id'] ?? 0 );

		$return_customer = isset( $data['return_customer'] )
			? absint( $data['return_customer'] )
			: ( isset( $_GET['return_customer'] ) ? absint( $_GET['return_customer'] ) : 0 ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only nav context; the save itself is nonce-checked.
		if ( ! $cust_id && $return_customer ) {
			$cust_id = $return_customer;
		}

		// Customer is fixed when arriving from a customer or editing a job.
		$locked = ( $return_customer > 0 ) || $is_edit;
		$owner  = $cust_id ? AMAT_Customer_Model::find( $cust_id ) : null;

		if ( $locked && ! $owner ) {
			$this->render_grid( '', __( 'That customer no longer exists.', 'auto-mation' ) );
			return;
		}

		$cancel_url = $return_customer
			? add_query_arg( array( 'page' => AMAT_Customers_Page::PAGE_SLUG, 'action' => 'view', 'id' => $return_customer ), admin_url( 'admin.php' ) )
			: $this->list_url();

		$veh_id   = (int) ( $data['vehicle_id'] ?? 0 );
		$loc_id   = (int) ( $data['location_id'] ?? 0 );
		$status   = (string) ( $data['status'] ?? 'requested' );
		$job_name = (string) ( $data['name'] ?? '' );

		$veh_choices = $cust_id ? self::vehicle_choices( $cust_id, $veh_id ) : array();
		$veh_opts    = array();
		foreach ( $veh_choices as $vc ) {
			$veh_opts[ $vc['id'] ] = $vc['label'];
		}
		$loc_opts = $cust_id ? self::location_options( $cust_id, $loc_id ) : array();

		// Default a new job's location to the customer's primary, if known.
		if ( ! $is_edit && ! $loc_id && $cust_id ) {
			$primary = AMAT_Location_Model::primary_for_customer( $cust_id );
			if ( $primary ) {
				$loc_id = (int) $primary['id'];
			}
		}
		?>
		<div class="wrap">
			<h1><?php echo $is_edit ? esc_html__( 'Edit job', 'auto-mation' ) : esc_html__( 'Add job', 'auto-mation' ); ?></h1>

			<?php if ( $error ) : ?>
				<div class="notice notice-error"><p><?php echo esc_html( $error ); ?></p></div>
			<?php endif; ?>

			<form method="post">
				<?php wp_nonce_field( self::NONCE_ACTION ); ?>
				<input type="hidden" name="amat_action" value="save_job" />
				<input type="hidden" name="job_id" value="<?php echo esc_attr( $id ); ?>" />
				<?php if ( $return_customer ) : ?>
					<input type="hidden" name="return_customer" value="<?php echo esc_attr( $return_customer ); ?>" />
				<?php endif; ?>

				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="amat-job-name"><?php esc_html_e( 'Name', 'auto-mation' ); ?></label></th>
						<td>
							<input name="name" id="amat-job-name" type="text" class="regular-text" maxlength="255" value="<?php echo esc_attr( $job_name ); ?>" />
							<p class="description"><?php esc_html_e( 'Optional label shown wherever this job appears (calendar, lists). Defaults to the customer name when blank.', 'auto-mation' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row">
							<?php if ( $locked ) : ?>
								<?php esc_html_e( 'Customer', 'auto-mation' ); ?>
							<?php else : ?>
								<label for="amat-job-customer-search"><?php esc_html_e( 'Customer', 'auto-mation' ); ?></label>
							<?php endif; ?>
						</th>
						<td>
							<?php if ( $locked ) : ?>
								<strong><?php echo esc_html( AMAT_Customer_Model::display_name( $owner ) ); ?></strong>
								<input type="hidden" name="customer_id" value="<?php echo esc_attr( $cust_id ); ?>" />
							<?php else : ?>
								<div class="amat-search-wrap">
									<input type="search" id="amat-job-customer-search" name="customer_search" class="regular-text" autocomplete="off" placeholder="<?php esc_attr_e( 'Search customers, or type a name to add a new one…', 'auto-mation' ); ?>" value="<?php echo esc_attr( $owner ? AMAT_Customer_Model::display_name( $owner ) : '' ); ?>" />
									<span id="amat-job-customer-new" class="amat-new-tag" style="display:none;"><?php esc_html_e( '(NEW)', 'auto-mation' ); ?></span>
									<div id="amat-job-customer-results" class="amat-search-results"></div>
								</div>
								<input type="hidden" name="customer_id" id="amat-job-customer-id" value="<?php echo esc_attr( $cust_id ); ?>" />
								<p class="description"><?php esc_html_e( 'Pick an existing customer, or just type a name (e.g. “Jane Doe”) to add a new customer for follow-up.', 'auto-mation' ); ?></p>
							<?php endif; ?>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="amat-job-vehicle-search"><?php esc_html_e( 'Vehicle', 'auto-mation' ); ?></label></th>
						<td>
							<?php
							$veh_label = ( $veh_id && isset( $veh_opts[ $veh_id ] ) ) ? $veh_opts[ $veh_id ] : '';
							?>
							<div class="amat-search-wrap" id="amat-job-vehicle-wrap" data-vehicles="<?php echo esc_attr( (string) wp_json_encode( $veh_choices ) ); ?>">
								<input type="search" id="amat-job-vehicle-search" name="vehicle_search" class="regular-text" autocomplete="off" placeholder="<?php esc_attr_e( 'Search a vehicle, or type Year Make Model to add one…', 'auto-mation' ); ?>" value="<?php echo esc_attr( $veh_label ); ?>" />
								<span id="amat-job-vehicle-new" class="amat-new-tag" style="display:none;"><?php esc_html_e( '(NEW)', 'auto-mation' ); ?></span>
								<div id="amat-job-vehicle-results" class="amat-search-results"></div>
							</div>
							<input type="hidden" name="vehicle_id" id="amat-job-vehicle-id" value="<?php echo esc_attr( $veh_id ); ?>" />
							<p class="description"><?php esc_html_e( 'Pick an existing vehicle, or type Year Make Model (e.g. 2015 Ford F-150) to add a new one for this customer.', 'auto-mation' ); ?></p>
							<details class="amat-vin-quickadd">
								<summary><?php esc_html_e( 'Add a new vehicle by VIN', 'auto-mation' ); ?></summary>
								<div class="amat-vin-quickadd-body">
									<input type="text" name="new_vehicle_vin" id="amat-job-vin" maxlength="17" autocomplete="off" placeholder="<?php esc_attr_e( 'VIN', 'auto-mation' ); ?>" />
									<input type="number" name="new_vehicle_year" id="amat-job-vin-year" min="1981" max="2100" placeholder="<?php esc_attr_e( 'Year', 'auto-mation' ); ?>" />
									<button type="button" class="button" id="amat-job-vin-decode"><?php esc_html_e( 'Decode VIN', 'auto-mation' ); ?></button>
									<div id="amat-job-vin-status" class="amat-vin-status"></div>
									<p class="description"><?php esc_html_e( 'Live NHTSA lookup. Enter the VIN (and Year for accuracy), then Decode — the full spec is stored when the job is saved.', 'auto-mation' ); ?></p>
								</div>
							</details>
							<?php
							// Kept in sync with the picked vehicle by initJobVehicleSearch().
							$cur_vin = '';
							foreach ( $veh_choices as $vc ) {
								if ( (int) $vc['id'] === $veh_id ) {
									$cur_vin = (string) $vc['vin'];
									break;
								}
							}
							?>
							<div id="amat-job-vin-display"><?php $this->render_vin_copy( $cur_vin ); ?></div>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="amat-job-location"><?php esc_html_e( 'Location', 'auto-mation' ); ?></label></th>
						<td>
							<select name="location_id" id="amat-job-location">
								<option value="0"><?php esc_html_e( '— None —', 'auto-mation' ); ?></option>
								<?php if ( $loc_opts ) : ?>
									<optgroup label="<?php esc_attr_e( 'Customer locations', 'auto-mation' ); ?>" class="amat-loc-customer">
										<?php foreach ( $loc_opts as $opt_id => $opt_label ) : ?>
											<option value="<?php echo esc_attr( $opt_id ); ?>" <?php selected( $opt_id, $loc_id ); ?>><?php echo esc_html( $opt_label ); ?></option>
										<?php endforeach; ?>
									</optgroup>
								<?php endif; ?>
								<?php $shop_opts = self::business_location_options( $loc_id ); ?>
								<?php if ( $shop_opts ) : ?>
									<optgroup label="<?php esc_attr_e( 'Your shops', 'auto-mation' ); ?>" class="amat-loc-shops">
										<?php foreach ( $shop_opts as $opt_id => $opt_label ) : ?>
											<option value="<?php echo esc_attr( $opt_id ); ?>" <?php selected( $opt_id, $loc_id ); ?>><?php echo esc_html( $opt_label ); ?></option>
										<?php endforeach; ?>
									</optgroup>
								<?php endif; ?>
							</select>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="amat-job-status"><?php esc_html_e( 'Status', 'auto-mation' ); ?></label></th>
						<td>
							<select name="status" id="amat-job-status">
								<?php foreach ( AMAT_Job_Model::statuses_labeled() as $slug => $label ) : ?>
									<option value="<?php echo esc_attr( $slug ); ?>" <?php selected( $slug, $status ); ?>><?php echo esc_html( $label ); ?></option>
								<?php endforeach; ?>
							</select>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="amat-job-start-date"><?php esc_html_e( 'Scheduled start', 'auto-mation' ); ?></label></th>
						<td><?php $this->datetime_fields( 'scheduled_start', 'amat-job-start', $data['scheduled_start'] ?? '' ); ?></td>
					</tr>
					<tr>
						<th scope="row"><label for="amat-job-end-date"><?php esc_html_e( 'Scheduled end', 'auto-mation' ); ?></label></th>
						<td><?php $this->datetime_fields( 'scheduled_end', 'amat-job-end', $data['scheduled_end'] ?? '' ); ?></td>
					</tr>
					<tr>
						<th scope="row"><label for="amat-job-mileage"><?php esc_html_e( 'Mileage', 'auto-mation' ); ?></label></th>
						<td>
							<?php $mileage_val = ( null !== ( $data['mileage'] ?? null ) && '' !== (string) $data['mileage'] ) ? (int) $data['mileage'] : ''; ?>
							<input name="mileage" id="amat-job-mileage" type="number" class="regular-text" min="0" step="1" inputmode="numeric" value="<?php echo esc_attr( $mileage_val ); ?>" />
							<p class="description"><?php esc_html_e( 'Odometer reading at this job (optional). Recorded for your records and the customer portal.', 'auto-mation' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="amat-job-description"><?php esc_html_e( 'Notes', 'auto-mation' ); ?></label></th>
						<td>
							<textarea name="description" id="amat-job-description" class="large-text" rows="4"><?php echo esc_textarea( (string) ( $data['description'] ?? '' ) ); ?></textarea>
							<p class="description"><?php esc_html_e( 'Optional notes specific to this job.', 'auto-mation' ); ?></p>
						</td>
					</tr>
				</table>

				<?php submit_button( $is_edit ? __( 'Save changes', 'auto-mation' ) : __( 'Add job', 'auto-mation' ) ); ?>
				<a href="<?php echo esc_url( $cancel_url ); ?>" class="button amat-btn-secondary"><?php esc_html_e( 'Cancel', 'auto-mation' ); ?></a>
			</form>

			<?php
			if ( $is_edit ) {
				// Estimates & invoices are managed here, on the job — each is its own
				// sub-form (below the job form; forms can't nest). A new job must be
				// saved first (it needs an id + customer to attach documents to).
				$this->render_documents_manager( $id, $cust_id, $veh_id );
			} else {
				echo '<p class="description amat-doc-manager-hint">' . esc_html__( 'Save the job first, then add estimates and invoices to it.', 'auto-mation' ) . '</p>';
			}
			?>
		</div>
		<?php
	}

	/* --------------------------------------------------------------------- */
	/* Embedded estimates / invoices manager (on the job edit page)          */
	/* --------------------------------------------------------------------- */

	/**
	 * Render the job's estimates and invoices as individually-saved sub-forms.
	 *
	 * Each estimate/invoice is its own `<form>` (Save / Convert / Delete), so line
	 * items are edited inline per document and one document's save never touches
	 * another. "Add" creates a fresh draft attached to this job.
	 *
	 * @param int $job_id  Job id.
	 * @param int $cust_id Owning customer id (inherited by new documents).
	 * @param int $veh_id  Job vehicle id (inherited by new documents).
	 * @return void
	 */
	private function render_documents_manager( $job_id, $cust_id, $veh_id ) {
		$estimates = AMAT_Estimate_Model::all( array( 'job_id' => (int) $job_id ), array( 'orderby' => 'id', 'order' => 'ASC' ) );
		$invoices  = AMAT_Invoice_Model::all( array( 'job_id' => (int) $job_id ), array( 'orderby' => 'id', 'order' => 'ASC' ) );
		?>
		<div class="amat-doc-manager">
			<h2><?php esc_html_e( 'Estimates', 'auto-mation' ); ?></h2>
			<?php if ( empty( $estimates ) ) : ?>
				<p class="description"><?php esc_html_e( 'No estimates on this job yet.', 'auto-mation' ); ?></p>
			<?php else : ?>
				<?php foreach ( $estimates as $est ) : ?>
					<?php $this->render_doc_subform( 'estimate', $est, (int) $job_id ); ?>
				<?php endforeach; ?>
			<?php endif; ?>
			<form method="post" class="amat-doc-add">
				<?php wp_nonce_field( self::DOC_NONCE ); ?>
				<input type="hidden" name="job_id" value="<?php echo esc_attr( (int) $job_id ); ?>" />
				<button type="submit" name="amat_action" value="job_estimate_add" class="button amat-btn-primary"><?php esc_html_e( '+ Add estimate', 'auto-mation' ); ?></button>
			</form>

			<h2><?php esc_html_e( 'Invoices', 'auto-mation' ); ?></h2>
			<?php if ( empty( $invoices ) ) : ?>
				<p class="description"><?php esc_html_e( 'No invoices on this job yet. Convert an approved estimate, or add one.', 'auto-mation' ); ?></p>
			<?php else : ?>
				<?php foreach ( $invoices as $inv ) : ?>
					<?php $this->render_doc_subform( 'invoice', $inv, (int) $job_id ); ?>
				<?php endforeach; ?>
			<?php endif; ?>
			<form method="post" class="amat-doc-add">
				<?php wp_nonce_field( self::DOC_NONCE ); ?>
				<input type="hidden" name="job_id" value="<?php echo esc_attr( (int) $job_id ); ?>" />
				<button type="submit" name="amat_action" value="job_invoice_add" class="button"><?php esc_html_e( '+ Add invoice', 'auto-mation' ); ?></button>
			</form>
		</div>
		<?php
	}

	/**
	 * One estimate/invoice sub-form within the job manager: header (number/status/
	 * total), an editable status + notes, the line-item repeater, and action
	 * buttons. Save / Convert / Delete are distinct submit buttons (only the
	 * clicked one's amat_action is posted).
	 *
	 * @param string              $type 'estimate' or 'invoice'.
	 * @param array<string,mixed> $doc  Estimate/invoice row.
	 * @param int                 $job_id Owning job id.
	 * @return void
	 */
	private function render_doc_subform( $type, array $doc, $job_id ) {
		$is_estimate = ( 'estimate' === $type );
		$id          = (int) $doc['id'];
		$items       = $is_estimate ? AMAT_Estimate_Item_Model::for_parent( $id ) : AMAT_Invoice_Item_Model::for_parent( $id );
		$total       = $is_estimate ? AMAT_Estimate_Model::total( $id ) : AMAT_Invoice_Model::total( $id );
		$label       = $is_estimate ? AMAT_Estimates_Page::label( $doc ) : AMAT_Invoices_Page::label( $doc );
		$statuses    = $is_estimate ? AMAT_Estimate_Model::statuses_labeled() : AMAT_Invoice_Model::statuses_labeled();
		$status      = (string) $doc['status'];
		$converted   = $is_estimate && AMAT_Invoice_Model::for_estimate( $id );
		$is_void     = ( 'void' === $status );
		$view_url    = add_query_arg(
			array( 'page' => ( $is_estimate ? AMAT_Estimates_Page::PAGE_SLUG : AMAT_Invoices_Page::PAGE_SLUG ), 'action' => 'view', 'id' => $id ),
			admin_url( 'admin.php' )
		);
		?>
		<div class="amat-doc-card<?php echo $is_void ? ' amat-doc-void' : ''; ?>">
			<form method="post" class="amat-doc-form">
				<?php wp_nonce_field( self::DOC_NONCE ); ?>
				<input type="hidden" name="job_id" value="<?php echo esc_attr( (int) $job_id ); ?>" />
				<input type="hidden" name="doc_id" value="<?php echo esc_attr( $id ); ?>" />

				<div class="amat-doc-card-head">
					<strong><a href="<?php echo esc_url( $view_url ); ?>"><?php echo esc_html( $label ); ?></a></strong>
					<span class="amat-status amat-status-<?php echo esc_attr( $status ); ?>"><?php echo esc_html( $statuses[ $status ] ?? $status ); ?></span>
					<span class="amat-doc-total"><?php echo esc_html( AMAT_Money::format_amount( $total ) ); ?></span>
					<?php if ( $converted ) : ?><span class="description"><?php esc_html_e( '(converted)', 'auto-mation' ); ?></span><?php endif; ?>
				</div>

				<label class="amat-doc-status">
					<?php esc_html_e( 'Status', 'auto-mation' ); ?>
					<select name="status">
						<?php foreach ( $statuses as $slug => $slabel ) : ?>
							<option value="<?php echo esc_attr( $slug ); ?>" <?php selected( $slug, $status ); ?>><?php echo esc_html( $slabel ); ?></option>
						<?php endforeach; ?>
					</select>
				</label>

				<?php AMAT_Estimates_Page::render_items_field( $items ); ?>

				<label class="amat-doc-notes">
					<?php esc_html_e( 'Notes', 'auto-mation' ); ?>
					<textarea name="notes" class="large-text" rows="2"><?php echo esc_textarea( (string) ( $doc['notes'] ?? '' ) ); ?></textarea>
				</label>

				<p class="amat-doc-actions">
					<button type="submit" name="amat_action" value="<?php echo esc_attr( $is_estimate ? 'job_estimate_save' : 'job_invoice_save' ); ?>" class="button amat-btn-primary"><?php esc_html_e( 'Save', 'auto-mation' ); ?></button>
					<?php if ( $is_estimate && ! $converted ) : ?>
						<button type="submit" name="amat_action" value="job_estimate_convert" class="button"><?php esc_html_e( 'Convert to invoice', 'auto-mation' ); ?></button>
					<?php endif; ?>
					<?php if ( AMAT_Admin::delete_enabled() ) : ?>
						<button type="submit" name="amat_action" value="<?php echo esc_attr( $is_estimate ? 'job_estimate_delete' : 'job_invoice_delete' ); ?>" class="button amat-btn-disable amat-doc-delete"><?php esc_html_e( 'Delete', 'auto-mation' ); ?></button>
					<?php endif; ?>
				</p>
			</form>
		</div>
		<?php
	}

	/**
	 * Active vehicles for a customer as id => label, always including the
	 * currently-selected one (even if disabled) so an existing job still shows it.
	 *
	 * @param int $cust_id  Customer id.
	 * @param int $selected Currently-selected vehicle id (0 = none).
	 * @return array<int,string>
	 */
	private static function vehicle_options( $cust_id, $selected = 0 ) {
		$opts = array();
		foreach ( self::vehicle_choices( $cust_id, $selected ) as $v ) {
			$opts[ $v['id'] ] = $v['label'];
		}
		return $opts;
	}

	/**
	 * The same vehicles as vehicle_options(), as a list carrying each vehicle's VIN
	 * so the job form's picker can show (and live-update) the VIN of whichever
	 * vehicle is selected. Feeds both the server-rendered `data-vehicles` payload
	 * and the AJAX customer-items response.
	 *
	 * @param int $cust_id  Customer id.
	 * @param int $selected Currently-selected vehicle id (0 = none).
	 * @return array<int,array<string,mixed>> List of { id, label, vin }.
	 */
	private static function vehicle_choices( $cust_id, $selected = 0 ) {
		$out = array();
		foreach ( AMAT_Vehicle_Model::for_customer( $cust_id ) as $v ) {
			$vid = (int) $v['id'];
			if ( empty( $v['is_active'] ) && $vid !== (int) $selected ) {
				continue;
			}
			$label = AMAT_Vehicle_Model::label( $v );
			if ( empty( $v['is_active'] ) ) {
				$label .= ' ' . __( '(disabled)', 'auto-mation' );
			}
			$out[] = array(
				'id'    => $vid,
				'label' => $label,
				'vin'   => trim( (string) ( $v['vin'] ?? '' ) ),
			);
		}
		return $out;
	}

	/**
	 * Active locations for a customer as id => label, always including the
	 * currently-selected one (even if disabled).
	 *
	 * @param int $cust_id  Customer id.
	 * @param int $selected Currently-selected location id (0 = none).
	 * @return array<int,string>
	 */
	private static function location_options( $cust_id, $selected = 0 ) {
		$opts = array();
		foreach ( AMAT_Location_Model::for_customer( $cust_id ) as $loc ) {
			$lid = (int) $loc['id'];
			if ( empty( $loc['is_active'] ) && $lid !== (int) $selected ) {
				continue;
			}
			$name         = '' !== $loc['label'] ? $loc['label'] : AMAT_Location_Model::one_line( $loc );
			$opts[ $lid ] = empty( $loc['is_active'] ) ? $name . ' ' . __( '(disabled)', 'auto-mation' ) : $name;
		}
		return $opts;
	}

	/**
	 * The business's own shops as id => label, for the job Location dropdown.
	 * Always includes the currently-selected shop (even if disabled) so an
	 * existing job still shows it. These appear after the customer's locations.
	 *
	 * @param int $selected Currently-selected location id (0 = none).
	 * @return array<int,string>
	 */
	private static function business_location_options( $selected = 0 ) {
		$opts = array();
		foreach ( AMAT_Location_Model::business_locations( true ) as $loc ) {
			$lid = (int) $loc['id'];
			if ( empty( $loc['is_active'] ) && $lid !== (int) $selected ) {
				continue;
			}
			$name         = '' !== $loc['label'] ? $loc['label'] : AMAT_Location_Model::one_line( $loc );
			$opts[ $lid ] = empty( $loc['is_active'] ) ? $name . ' ' . __( '(disabled)', 'auto-mation' ) : $name;
		}
		return $opts;
	}

	/**
	 * Echo a paired native date picker + 15-minute time dropdown for a stored
	 * datetime, posting as `{$base}_date` and `{$base}_time` (recombined on save).
	 * Replaces the bare datetime-local input so the time is chosen, not typed.
	 *
	 * @param string $base    Field base name, e.g. 'scheduled_start'.
	 * @param string $id_base Element id base, e.g. 'amat-job-start'.
	 * @param string $value   Stored datetime to prefill.
	 * @return void
	 */
	private function datetime_fields( $base, $id_base, $value ) {
		$date    = $this->dt_date_part( $value );
		$time    = $this->dt_time_part( $value );
		$options = $this->time_options();

		// Keep an off-grid existing time selectable (e.g. legacy 9:07 data).
		if ( '' !== $time && ! isset( $options[ $time ] ) ) {
			$dt              = date_create( '2000-01-01 ' . $time );
			$options         = array( $time => ( $dt ? $dt->format( 'g:i A' ) : $time ) ) + $options;
		}
		?>
		<span class="amat-dt-fields">
			<input type="date" name="<?php echo esc_attr( $base ); ?>_date" id="<?php echo esc_attr( $id_base ); ?>-date" value="<?php echo esc_attr( $date ); ?>" />
			<label class="screen-reader-text" for="<?php echo esc_attr( $id_base ); ?>-time"><?php esc_html_e( 'Time', 'auto-mation' ); ?></label>
			<select name="<?php echo esc_attr( $base ); ?>_time" id="<?php echo esc_attr( $id_base ); ?>-time">
				<?php foreach ( $options as $val => $label ) : ?>
					<option value="<?php echo esc_attr( $val ); ?>" <?php selected( $val, $time ); ?>><?php echo esc_html( $label ); ?></option>
				<?php endforeach; ?>
			</select>
		</span>
		<?php
	}

	/**
	 * Time-of-day options on a 15-minute grid as 'H:i' => 'g:i A', led by a
	 * blank "— Time —" choice (date-only allowed; defaults to midnight on save).
	 *
	 * @return array<string,string>
	 */
	private function time_options() {
		$opts = array( '' => __( '— Time —', 'auto-mation' ) );
		for ( $m = 0; $m < 24 * 60; $m += 15 ) {
			$hi          = sprintf( '%02d:%02d', intdiv( $m, 60 ), $m % 60 );
			$dt          = date_create( '2000-01-01 ' . $hi );
			$opts[ $hi ] = $dt ? $dt->format( 'g:i A' ) : $hi;
		}
		return $opts;
	}

	/**
	 * Combine a posted date ('Y-m-d') + time ('H:i') into a 'Y-m-d H:i' string
	 * for the model's datetime sanitizer, or '' when no valid date was given.
	 *
	 * @param string $date_raw Raw posted date.
	 * @param string $time_raw Raw posted time.
	 * @return string
	 */
	private function combine_datetime( $date_raw, $time_raw ) {
		$date = sanitize_text_field( wp_unslash( $date_raw ) );
		$time = sanitize_text_field( wp_unslash( $time_raw ) );
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) {
			return '';
		}
		if ( ! preg_match( '/^\d{1,2}:\d{2}$/', $time ) ) {
			$time = '00:00';
		}
		return $date . ' ' . $time;
	}

	/**
	 * Date portion ('Y-m-d') of a stored datetime, or '' when empty/zero.
	 *
	 * @param string $v Stored datetime.
	 * @return string
	 */
	private function dt_date_part( $v ) {
		$v = trim( (string) $v );
		if ( '' === $v || 0 === strpos( $v, '0000' ) ) {
			return '';
		}
		$dt = date_create( str_replace( 'T', ' ', $v ) );
		return $dt ? $dt->format( 'Y-m-d' ) : '';
	}

	/**
	 * Time portion ('H:i') of a stored datetime, or '' when empty/zero.
	 *
	 * @param string $v Stored datetime.
	 * @return string
	 */
	private function dt_time_part( $v ) {
		$v = trim( (string) $v );
		if ( '' === $v || 0 === strpos( $v, '0000' ) ) {
			return '';
		}
		$dt = date_create( str_replace( 'T', ' ', $v ) );
		return $dt ? $dt->format( 'H:i' ) : '';
	}

	/**
	 * Friendly display of a stored datetime, or an em dash when unset.
	 *
	 * @param string $v Stored datetime.
	 * @return string
	 */
	private function dt_display( $v ) {
		$v = trim( (string) $v );
		if ( '' === $v || 0 === strpos( $v, '0000' ) ) {
			return '—';
		}
		$dt = date_create( $v );
		return $dt ? $dt->format( 'M j, Y g:i A' ) : $v;
	}

	/**
	 * Time-of-day portion of a stored datetime (e.g. "9:30 AM"), or '' if unset.
	 *
	 * @param string $v Stored datetime.
	 * @return string
	 */
	private function dt_time( $v ) {
		$v = trim( (string) $v );
		if ( '' === $v || 0 === strpos( $v, '0000' ) ) {
			return '';
		}
		$dt = date_create( $v );
		return $dt ? $dt->format( 'g:i A' ) : '';
	}

	/* --------------------------------------------------------------------- */
	/* AJAX: customer search + dependent vehicle/location options            */
	/* --------------------------------------------------------------------- */

	/**
	 * AJAX: search customers for the job form's customer picker.
	 *
	 * Registered on wp_ajax_amat_job_search_customers. Returns up to 20 matches
	 * as { id, name }.
	 *
	 * @return void
	 */
	public static function ajax_search_customers() {
		check_ajax_referer( self::CUST_NONCE, 'nonce' );
		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			wp_send_json_error( array( 'message' => __( 'Not allowed.', 'auto-mation' ) ), 403 );
		}

		$term = isset( $_POST['term'] ) ? sanitize_text_field( wp_unslash( $_POST['term'] ) ) : '';
		// active_only: a disabled customer must not be pickable for a new job, nor
		// offered as a "referred by" (this endpoint feeds both pickers).
		$rows = AMAT_Customer_Model::search( $term, true );

		$out = array();
		foreach ( array_slice( $rows, 0, 20 ) as $c ) {
			$out[] = array( 'id' => (int) $c['id'], 'name' => AMAT_Customer_Model::display_name( $c ) );
		}
		wp_send_json_success( $out );
	}

	/**
	 * AJAX: a customer's active vehicles + locations for the job form.
	 *
	 * Registered on wp_ajax_amat_job_customer_items. Returns {vehicles, locations,
	 * primary} where vehicles/locations are [{id,label}] and primary is the
	 * customer's primary location id (0 if none).
	 *
	 * @return void
	 */
	public static function ajax_customer_items() {
		check_ajax_referer( self::CUST_NONCE, 'nonce' );
		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			wp_send_json_error( array( 'message' => __( 'Not allowed.', 'auto-mation' ) ), 403 );
		}

		$cust_id = isset( $_POST['customer_id'] ) ? absint( $_POST['customer_id'] ) : 0;

		$vehicles  = self::vehicle_choices( $cust_id );
		$locations = array();
		foreach ( self::location_options( $cust_id ) as $lid => $label ) {
			$locations[] = array( 'id' => $lid, 'label' => $label );
		}
		$shops = array();
		foreach ( self::business_location_options() as $lid => $label ) {
			$shops[] = array( 'id' => $lid, 'label' => $label );
		}
		$primary = $cust_id ? AMAT_Location_Model::primary_for_customer( $cust_id ) : null;

		wp_send_json_success(
			array(
				'vehicles'  => $vehicles,
				'locations' => $locations,
				'shops'     => $shops,
				'primary'   => $primary ? (int) $primary['id'] : 0,
			)
		);
	}

	/**
	 * Create a new customer from a typed name (quick add from the job form). One
	 * word → first name only; two+ words → first word is the first name, the rest
	 * is the last name.
	 *
	 * @param string $name Typed full name.
	 * @return int New customer id, or 0 on failure.
	 */
	private static function create_customer_from_name( $name ) {
		$parts = preg_split( '/\s+/', trim( (string) $name ), -1, PREG_SPLIT_NO_EMPTY );
		if ( empty( $parts ) ) {
			return 0;
		}
		$first = (string) array_shift( $parts );
		$last  = $parts ? implode( ' ', $parts ) : '';

		return (int) AMAT_Customer_Model::create(
			array(
				'first_name' => $first,
				'last_name'  => $last,
				'is_active'  => 1,
			)
		);
	}

	/**
	 * Create a new vehicle for a customer from typed "Year Make Model" text (quick
	 * add from the job form). A leading all-digits token is the year; the next is
	 * the make; the remainder is the model. A non-numeric first token means no year.
	 *
	 * @param int    $customer_id Owning customer id.
	 * @param string $text        Typed "Year Make Model" string.
	 * @return int New vehicle id, or 0 on failure.
	 */
	private static function create_vehicle_from_text( $customer_id, $text ) {
		$parts = preg_split( '/\s+/', trim( (string) $text ), -1, PREG_SPLIT_NO_EMPTY );
		if ( empty( $parts ) ) {
			return 0;
		}
		$year = ctype_digit( $parts[0] ) ? (string) array_shift( $parts ) : '';
		$make = $parts ? (string) array_shift( $parts ) : '';
		$model = $parts ? implode( ' ', $parts ) : '';

		$data = array(
			'customer_id' => (int) $customer_id,
			'make'        => $make,
			'model'       => $model,
			'is_active'   => 1,
		);
		if ( '' !== $year ) {
			$data['year'] = $year;
		}

		return (int) AMAT_Vehicle_Model::create( $data );
	}

	/**
	 * Create a new vehicle for a customer from a VIN (quick-add from the job form).
	 * Decodes the VIN live via vPIC server-side and stores every returned spec plus
	 * the VIN itself. The VIN is stored even if the decode fails (transport/API
	 * error), so a vehicle is still created. Returns 0 only on an empty VIN or a DB
	 * insert failure (the caller then falls back to the typed "Year Make Model").
	 *
	 * @param int    $customer_id Owning customer id.
	 * @param string $vin         Entered VIN.
	 * @param int    $year        Model year for decode accuracy (0 = unknown).
	 * @return int New vehicle id, or 0 on failure.
	 */
	private static function create_vehicle_from_vin( $customer_id, $vin, $year = 0 ) {
		$vin = strtoupper( preg_replace( '/[^A-Za-z0-9]/', '', (string) $vin ) );
		if ( '' === $vin ) {
			return 0;
		}

		$data = array(
			'customer_id' => (int) $customer_id,
			'vin'         => $vin,
			'is_active'   => 1,
		);

		$decoder = new AMAT_Vin_Decoder();
		$decoded = $decoder->decode( $vin, $year ?: null );
		if ( ! is_wp_error( $decoded ) ) {
			foreach ( $decoded as $column => $value ) {
				if ( '' !== $value ) {
					$data[ $column ] = $value;
				}
			}
		}

		return (int) AMAT_Vehicle_Model::create( $data );
	}

	/* --------------------------------------------------------------------- */
	/* Manager POST handlers (estimates/invoices on a job)                   */
	/* --------------------------------------------------------------------- */

	/**
	 * Intercept the job-document manager POSTs before the base PRG dispatch, then
	 * fall through to the normal job save. Each action redirects back to the job
	 * edit page with a flash.
	 *
	 * @return void
	 */
	public function maybe_process() {
		$action = isset( $_POST['amat_action'] ) ? sanitize_key( wp_unslash( $_POST['amat_action'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce verified in each handler.
		switch ( $action ) {
			case 'job_estimate_add':
			case 'job_invoice_add':
				$this->process_doc_add( 'job_estimate_add' === $action ? 'estimate' : 'invoice' );
				return;
			case 'job_estimate_save':
			case 'job_invoice_save':
				$this->process_doc_save( 'job_estimate_save' === $action ? 'estimate' : 'invoice' );
				return;
			case 'job_estimate_convert':
				$this->process_doc_convert();
				return;
			case 'job_estimate_delete':
			case 'job_invoice_delete':
				$this->process_doc_delete( 'job_estimate_delete' === $action ? 'estimate' : 'invoice' );
				return;
		}
		parent::maybe_process();
	}

	/**
	 * Shared preamble for a manager action: verify nonce + capability, load the
	 * job, and return the edit-page redirect URL. wp_die on a bad nonce/cap.
	 *
	 * @return array{0:int,1:array<string,mixed>|null,2:string} [job_id, job, redirect].
	 */
	private function doc_action_context() {
		check_admin_referer( self::DOC_NONCE );
		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'auto-mation' ) );
		}
		$job_id   = isset( $_POST['job_id'] ) ? absint( $_POST['job_id'] ) : 0;
		$job      = $job_id ? AMAT_Job_Model::find( $job_id ) : null;
		$redirect = $this->list_url( array( 'action' => 'edit', 'id' => $job_id ) );
		return array( $job_id, $job, $redirect );
	}

	/**
	 * Create a fresh draft estimate/invoice attached to this job (customer +
	 * vehicle inherited from the job), then land back on the job edit page.
	 *
	 * @param string $type 'estimate' or 'invoice'.
	 * @return void
	 */
	private function process_doc_add( $type ) {
		list( $job_id, $job, $redirect ) = $this->doc_action_context();
		if ( ! $job ) {
			$this->flash_to_destination( array( 'status' => 'error', 'message' => __( 'Job not found.', 'auto-mation' ) ), $redirect );
			wp_safe_redirect( $redirect );
			exit;
		}

		$fields = array(
			'customer_id' => (int) $job['customer_id'],
			'job_id'      => (int) $job_id,
			'vehicle_id'  => (int) $job['vehicle_id'],
			'status'      => 'draft',
			'issue_date'  => gmdate( 'Y-m-d', current_time( 'timestamp' ) ),
		);
		if ( 'estimate' === $type ) {
			$new_id = (int) AMAT_Estimate_Model::create( $fields );
		} else {
			$new_id = (int) AMAT_Invoice_Model::create( $fields );
		}

		if ( $new_id ) {
			$this->fire_doc_saved( $type, $new_id, true );
		}

		$this->flash_to_destination(
			array( 'status' => 'success', 'message' => 'estimate' === $type ? __( 'Estimate added.', 'auto-mation' ) : __( 'Invoice added.', 'auto-mation' ) ),
			$redirect
		);
		wp_safe_redirect( $redirect );
		exit;
	}

	/**
	 * Save one estimate/invoice sub-form: status + notes + line items (customer +
	 * vehicle stay inherited from the job). Catalog "save" flags are resolved first.
	 *
	 * @param string $type 'estimate' or 'invoice'.
	 * @return void
	 */
	private function process_doc_save( $type ) {
		list( $job_id, $job, $redirect ) = $this->doc_action_context();
		$doc_id      = isset( $_POST['doc_id'] ) ? absint( $_POST['doc_id'] ) : 0;
		$is_estimate = ( 'estimate' === $type );
		$model       = $is_estimate ? 'AMAT_Estimate_Model' : 'AMAT_Invoice_Model';
		$item_model  = $is_estimate ? 'AMAT_Estimate_Item_Model' : 'AMAT_Invoice_Item_Model';

		$doc = $doc_id ? $model::find( $doc_id ) : null;
		if ( ! $job || ! $doc || (int) $doc['job_id'] !== $job_id ) {
			$this->flash_to_destination( array( 'status' => 'error', 'message' => __( 'That document is not on this job.', 'auto-mation' ) ), $redirect );
			wp_safe_redirect( $redirect );
			exit;
		}

		$status   = isset( $_POST['status'] ) ? sanitize_key( wp_unslash( $_POST['status'] ) ) : 'draft';
		$statuses = $is_estimate ? AMAT_Estimate_Model::STATUSES : AMAT_Invoice_Model::STATUSES;
		$rows     = AMAT_Estimates_Page::persist_catalog_flags( AMAT_Estimates_Page::collect_item_rows() );

		$model::update(
			$doc_id,
			array(
				'customer_id' => (int) $job['customer_id'],
				'vehicle_id'  => (int) $job['vehicle_id'],
				'status'      => in_array( $status, $statuses, true ) ? $status : (string) $doc['status'],
				'notes'       => sanitize_textarea_field( wp_unslash( $_POST['notes'] ?? '' ) ),
			)
		);
		$item_model::replace_for_parent( $doc_id, $rows );

		// After the line items land, so a listener sees the finished document.
		$this->fire_doc_saved( $type, $doc_id, false );

		$this->flash_to_destination( array( 'status' => 'success', 'message' => __( 'Saved.', 'auto-mation' ) ), $redirect );
		wp_safe_redirect( $redirect );
		exit;
	}

	/**
	 * Fire the lifecycle hook for a saved estimate/invoice.
	 *
	 * Fired from the save paths rather than from the models, deliberately: the
	 * models are also driven by migrations, importers and tests, where an
	 * outbound provider call would be wrong. These hooks mean "the owner saved
	 * this record" — which is what a provider's auto-sync mode is about.
	 *
	 * @param string $type   'estimate' or 'invoice'.
	 * @param int    $id     Document id.
	 * @param bool   $is_new Whether the record was just created.
	 * @return void
	 */
	private function fire_doc_saved( $type, $id, $is_new ) {
		if ( 'estimate' === $type ) {
			/**
			 * Fires after the owner saves an estimate from the job's document manager.
			 *
			 * Core ships no listener; a provider integration uses it for auto-sync.
			 *
			 * @param int  $id     Estimate id.
			 * @param bool $is_new Whether the record was just created.
			 */
			do_action( 'amat_after_estimate_save', (int) $id, (bool) $is_new );
			return;
		}

		/**
		 * Fires after the owner saves an invoice from the job's document manager.
		 *
		 * Core ships no listener; a provider integration uses it for auto-sync.
		 *
		 * @param int  $id     Invoice id.
		 * @param bool $is_new Whether the record was just created.
		 */
		do_action( 'amat_after_invoice_save', (int) $id, (bool) $is_new );
	}

	/**
	 * Convert one of the job's estimates into an invoice on the same job, then land
	 * back on the job edit page. Refuses a second convert.
	 *
	 * @return void
	 */
	private function process_doc_convert() {
		list( $job_id, $job, $redirect ) = $this->doc_action_context();
		$doc_id   = isset( $_POST['doc_id'] ) ? absint( $_POST['doc_id'] ) : 0;
		$estimate = $doc_id ? AMAT_Estimate_Model::find( $doc_id ) : null;

		if ( ! $job || ! $estimate || (int) $estimate['job_id'] !== $job_id ) {
			$this->flash_to_destination( array( 'status' => 'error', 'message' => __( 'That estimate is not on this job.', 'auto-mation' ) ), $redirect );
		} elseif ( AMAT_Invoice_Model::for_estimate( $doc_id ) ) {
			$this->flash_to_destination( array( 'status' => 'error', 'message' => __( 'This estimate was already converted to an invoice.', 'auto-mation' ) ), $redirect );
		} else {
			$new = AMAT_Invoice_Model::create_from_estimate( $estimate );
			if ( $new ) {
				$this->fire_doc_saved( 'invoice', (int) $new, true );
			}
			$this->flash_to_destination(
				$new
					? array( 'status' => 'success', 'message' => __( 'Estimate converted to an invoice.', 'auto-mation' ) )
					: array( 'status' => 'error', 'message' => __( 'Could not convert the estimate.', 'auto-mation' ) ),
				$redirect
			);
		}
		wp_safe_redirect( $redirect );
		exit;
	}

	/**
	 * Permanently delete one of the job's estimates/invoices (and its line items),
	 * then land back on the job edit page.
	 *
	 * A dev/testing escape hatch, not an everyday action: gated on the Dev Tools
	 * "record deletion" switch (server-side, not merely a hidden button) and
	 * confirm-gated in JS. The everyday way to cancel a document is the 'void'
	 * status, which keeps it on file.
	 *
	 * @param string $type 'estimate' or 'invoice'.
	 * @return void
	 */
	private function process_doc_delete( $type ) {
		list( $job_id, $job, $redirect ) = $this->doc_action_context();
		$doc_id      = isset( $_POST['doc_id'] ) ? absint( $_POST['doc_id'] ) : 0;
		$is_estimate = ( 'estimate' === $type );
		$model       = $is_estimate ? 'AMAT_Estimate_Model' : 'AMAT_Invoice_Model';
		$item_model  = $is_estimate ? 'AMAT_Estimate_Item_Model' : 'AMAT_Invoice_Item_Model';

		$doc = $doc_id ? $model::find( $doc_id ) : null;
		if ( ! AMAT_Admin::delete_enabled() ) {
			// Server-side gate, not just a hidden button: a permanent delete is
			// only ever available while the Dev Tools switch is on. Everyday
			// cancellation is the 'void' status, which keeps the record on file.
			$this->flash_to_destination(
				array(
					'status'  => 'error',
					'message' => __( 'Permanent deletion is turned off. Set the status to Void instead, or enable record deletion in Settings → Dev Tools.', 'auto-mation' ),
				),
				$redirect
			);
		} elseif ( ! $job || ! $doc || (int) $doc['job_id'] !== $job_id ) {
			$this->flash_to_destination( array( 'status' => 'error', 'message' => __( 'That document is not on this job.', 'auto-mation' ) ), $redirect );
		} else {
			$item_model::replace_for_parent( $doc_id, array() ); // drop line items first (no orphans)
			$model::delete( $doc_id );
			$this->flash_to_destination( array( 'status' => 'success', 'message' => __( 'Deleted.', 'auto-mation' ) ), $redirect );
		}
		wp_safe_redirect( $redirect );
		exit;
	}

	/* --------------------------------------------------------------------- */
	/* Save                                                                  */
	/* --------------------------------------------------------------------- */

	/**
	 * Validate and persist the submitted job.
	 *
	 * Called from the base class on `admin_init` once it confirms this is the
	 * job save POST; always returns a result array (never null).
	 *
	 * @return array{status:string,message:string,data?:array,editing_id?:int}
	 */
	protected function save() {
		check_admin_referer( self::NONCE_ACTION );
		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			return array( 'status' => 'error', 'message' => __( 'You are not allowed to save jobs.', 'auto-mation' ), 'data' => array(), 'editing_id' => 0 );
		}

		$id              = isset( $_POST['job_id'] ) ? absint( $_POST['job_id'] ) : 0;
		$return_customer = isset( $_POST['return_customer'] ) ? absint( $_POST['return_customer'] ) : 0;
		$status          = isset( $_POST['status'] ) ? sanitize_key( wp_unslash( $_POST['status'] ) ) : 'requested';

		// Resolve the customer: a picked existing one, else create a new customer
		// from a typed name (quick add for follow-up). Same for the vehicle.
		$cust_id = isset( $_POST['customer_id'] ) ? absint( $_POST['customer_id'] ) : 0;
		if ( ! $cust_id ) {
			$typed_name = sanitize_text_field( wp_unslash( $_POST['customer_search'] ?? '' ) );
			if ( '' !== trim( $typed_name ) ) {
				$cust_id = (int) self::create_customer_from_name( $typed_name );
			}
		}

		$veh_id = isset( $_POST['vehicle_id'] ) ? absint( $_POST['vehicle_id'] ) : 0;
		if ( ! $veh_id && $cust_id ) {
			// Quick-add priority: a VIN (live-decoded into a full vehicle) beats a
			// typed "Year Make Model" line.
			$vin = isset( $_POST['new_vehicle_vin'] ) ? sanitize_text_field( wp_unslash( $_POST['new_vehicle_vin'] ) ) : '';
			if ( '' !== trim( $vin ) ) {
				$vin_year = isset( $_POST['new_vehicle_year'] ) ? absint( $_POST['new_vehicle_year'] ) : 0;
				$veh_id   = (int) self::create_vehicle_from_vin( $cust_id, $vin, $vin_year );
			}
			if ( ! $veh_id ) {
				$typed_vehicle = sanitize_text_field( wp_unslash( $_POST['vehicle_search'] ?? '' ) );
				if ( '' !== trim( $typed_vehicle ) ) {
					$veh_id = (int) self::create_vehicle_from_text( $cust_id, $typed_vehicle );
				}
			}
		}

		$data = array(
			'customer_id'     => $cust_id,
			'return_customer' => $return_customer,
			'name'            => sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) ),
			'vehicle_id'      => $veh_id,
			'location_id'     => isset( $_POST['location_id'] ) ? absint( $_POST['location_id'] ) : 0,
			'status'          => in_array( $status, AMAT_Job_Model::STATUSES, true ) ? $status : 'requested',
			'scheduled_start' => $this->combine_datetime( $_POST['scheduled_start_date'] ?? '', $_POST['scheduled_start_time'] ?? '' ),
			'scheduled_end'   => $this->combine_datetime( $_POST['scheduled_end_date'] ?? '', $_POST['scheduled_end_time'] ?? '' ),
			'description'     => sanitize_textarea_field( wp_unslash( $_POST['description'] ?? '' ) ),
			// Blank clears it (odometer is optional); the model's int sanitizer stores NULL.
			'mileage'         => ( isset( $_POST['mileage'] ) && '' !== trim( (string) $_POST['mileage'] ) ) ? absint( wp_unslash( $_POST['mileage'] ) ) : null,
		);

		if ( ! $data['customer_id'] ) {
			return array( 'status' => 'error', 'message' => __( 'Please choose a customer for this job.', 'auto-mation' ), 'data' => $data, 'editing_id' => $id );
		}

		$was_new = ( 0 === $id );
		if ( $id ) {
			AMAT_Job_Model::update( $id, $data );
		} else {
			$id = AMAT_Job_Model::create( $data );
		}

		if ( ! $id ) {
			return array( 'status' => 'error', 'message' => __( 'Could not save the job. Please try again.', 'auto-mation' ), 'data' => $data, 'editing_id' => 0 );
		}

		$success = array( 'status' => 'success', 'message' => __( 'Job saved.', 'auto-mation' ) );
		if ( $return_customer ) {
			$success['redirect'] = add_query_arg(
				array( 'page' => AMAT_Customers_Page::PAGE_SLUG, 'action' => 'view', 'id' => $return_customer ),
				admin_url( 'admin.php' )
			);
		} elseif ( $was_new ) {
			// A brand-new job lands on its edit page so estimates/invoices can be
			// added to it right away (the manager lives there).
			$success['redirect'] = $this->list_url( array( 'action' => 'edit', 'id' => (int) $id ) );
		} else {
			// Land on the read-only job view so the saved job is shown, not the list.
			$success['redirect'] = $this->list_url( array( 'action' => 'view', 'id' => (int) $id ) );
		}
		return $success;
	}
}
