<?php
/**
 * Vehicles admin page: list/search, add, and edit vehicles, with live VIN
 * decode from NHTSA vPIC.
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Renders the Vehicles list (search + clickable rows) and the add/edit form.
 *
 * Spec fields are auto-filled from the VIN via an AJAX call to vPIC (see
 * ajax_decode_vin() and AMAT_Vin_Decoder); plate/color/color_code are manual.
 * Security pattern per §5 (nonce, capability, sanitize in, escape out).
 */
class AMAT_Vehicles_Page extends AMAT_Admin_Page {

	const NONCE_ACTION = 'amat_save_vehicle';
	const PAGE_SLUG    = 'amat-vehicles';
	const POST_ACTION  = 'save_vehicle';
	const VIN_NONCE    = 'amat_decode_vin';

	/**
	 * Vehicles support enable/disable (soft delete) — see CLAUDE.md §11.
	 *
	 * @return string
	 */
	protected static function active_model() {
		return 'AMAT_Vehicle_Model';
	}

	/**
	 * Cascade a vehicle hard-delete to its service records (Dev Tools delete).
	 *
	 * @param int $id Deleted vehicle id.
	 * @return void
	 */
	protected function after_delete( $id ) {
		global $wpdb;
		$wpdb->delete( $wpdb->prefix . 'amat_service_records', array( 'vehicle_id' => (int) $id ) );
	}

	/**
	 * Spec columns auto-filled from the VIN decode, with labels.
	 *
	 * @return array<string,string>
	 */
	private static function spec_fields() {
		return array(
			'year'                => __( 'Year', 'auto-mation' ),
			'make'                => __( 'Make', 'auto-mation' ),
			'model'               => __( 'Model', 'auto-mation' ),
			'trim'                => __( 'Trim', 'auto-mation' ),
			'series'              => __( 'Series', 'auto-mation' ),
			'body_type'           => __( 'Body type', 'auto-mation' ),
			'engine_displacement' => __( 'Engine displacement (L)', 'auto-mation' ),
			'engine_cylinders'    => __( 'Cylinders', 'auto-mation' ),
			'fuel_type_primary'   => __( 'Fuel type (primary)', 'auto-mation' ),
			'fuel_type_secondary' => __( 'Fuel type (secondary)', 'auto-mation' ),
			'drive_type'          => __( 'Drive type', 'auto-mation' ),
			'transmission_type'   => __( 'Transmission', 'auto-mation' ),
			'transmission_speeds' => __( 'Transmission speeds', 'auto-mation' ),
		);
	}

	/**
	 * Manual (non-vPIC) text columns, with labels.
	 *
	 * @return array<string,string>
	 */
	private static function manual_fields() {
		return array(
			'license_plate' => __( 'License plate', 'auto-mation' ),
			'color'         => __( 'Color', 'auto-mation' ),
			'color_code'    => __( 'Color code', 'auto-mation' ),
		);
	}

	/**
	 * Render the page: handle a submit, then route to list or form.
	 *
	 * @return void
	 */
	public function render() {
		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'auto-mation' ) );
		}

		$flash  = $this->take_flash();
		$action = isset( $_GET['action'] ) ? sanitize_key( wp_unslash( $_GET['action'] ) ) : '';

		if ( 'new' === $action || 'edit' === $action ) {
			// A failed save flashes the submitted values — re-render with those.
			if ( $flash && 'error' === $flash['status'] ) {
				$this->render_form( $flash['data'], $flash['editing_id'], $flash['message'] );
				return;
			}
			if ( 'new' === $action ) {
				$this->render_form( array(), 0 );
				return;
			}
			$id      = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0;
			$vehicle = $id ? AMAT_Vehicle_Model::find( $id ) : null;
			if ( ! $vehicle ) {
				$this->render_list( '', __( 'Vehicle not found.', 'auto-mation' ) );
				return;
			}
			$this->render_form( $vehicle, $id );
			return;
		}

		// List view, with any flashed success/error notice.
		$success = ( $flash && 'success' === $flash['status'] ) ? $flash['message'] : '';
		$error   = ( $flash && 'error' === $flash['status'] ) ? $flash['message'] : '';
		$this->render_list( $success, $error );
	}

	/* --------------------------------------------------------------------- */
	/* List                                                                  */
	/* --------------------------------------------------------------------- */

	/**
	 * Render the searchable vehicles list.
	 *
	 * @param string $success Optional success notice.
	 * @param string $error   Optional error notice.
	 * @return void
	 */
	private function render_list( $success = '', $error = '' ) {
		$term          = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
		$f_year        = isset( $_GET['year'] ) ? sanitize_text_field( wp_unslash( $_GET['year'] ) ) : '';
		$f_make        = isset( $_GET['make'] ) ? sanitize_text_field( wp_unslash( $_GET['make'] ) ) : '';
		$f_model       = isset( $_GET['model'] ) ? sanitize_text_field( wp_unslash( $_GET['model'] ) ) : '';
		$show_disabled = $this->read_show_disabled();

		list( $orderby, $order ) = $this->read_sort( array( 'year', 'make', 'model', 'vin', 'plate', 'customer' ), 'make' );

		// Distinct filter options come from the full set (so the dropdowns list
		// every value regardless of the current filter/search).
		$all_vehicles = AMAT_Vehicle_Model::all();
		$year_opts    = $this->distinct_values( $all_vehicles, 'year' );
		$make_opts    = $this->distinct_values( $all_vehicles, 'make' );
		$model_opts   = $this->distinct_values( $all_vehicles, 'model' );

		// Base set: search results, or everything. Then filter and sort in PHP so
		// search + filters + sort always compose (search() carries its own ORDER BY).
		$vehicles = '' !== $term ? AMAT_Vehicle_Model::search( $term ) : $all_vehicles;

		// The toggle is exclusive: active rows, or disabled rows, never both.
		$vehicles = $this->filter_active_rows( $vehicles, $show_disabled );

		$vehicles = array_values(
			array_filter(
				$vehicles,
				static function ( $v ) use ( $f_year, $f_make, $f_model ) {
					if ( '' !== $f_year && (string) $v['year'] !== $f_year ) {
						return false;
					}
					if ( '' !== $f_make && (string) $v['make'] !== $f_make ) {
						return false;
					}
					if ( '' !== $f_model && (string) $v['model'] !== $f_model ) {
						return false;
					}
					return true;
				}
			)
		);

		// Attach a resolved customer name for display and customer-sort.
		foreach ( $vehicles as &$v ) {
			$owner               = AMAT_Customer_Model::find( (int) $v['customer_id'] );
			$v['_customer_name'] = $owner ? AMAT_Customer_Model::display_name( $owner ) : '';
		}
		unset( $v );

		$vehicles = $this->sort_rows(
			$vehicles,
			$order,
			static function ( $v ) use ( $orderby ) {
				switch ( $orderby ) {
					case 'year':
						return (int) $v['year'];
					case 'model':
						return (string) $v['model'];
					case 'vin':
						return (string) $v['vin'];
					case 'plate':
						return (string) $v['license_plate'];
					case 'customer':
						return (string) $v['_customer_name'];
					case 'make':
					default:
						return (string) $v['make'];
				}
			}
		);

		$base_args = array( 's' => $term, 'year' => $f_year, 'make' => $f_make, 'model' => $f_model, 'show_disabled' => $show_disabled ? '1' : '' );
		?>
		<div class="wrap">
			<h1 class="wp-heading-inline"><?php esc_html_e( 'Vehicles', 'auto-mation' ); ?></h1>
			<hr class="wp-header-end" />

			<?php if ( $success ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php echo esc_html( $success ); ?></p></div>
			<?php endif; ?>
			<?php if ( $error ) : ?>
				<div class="notice notice-error is-dismissible"><p><?php echo esc_html( $error ); ?></p></div>
			<?php endif; ?>

			<form method="get" class="amat-list-filters">
				<input type="hidden" name="page" value="<?php echo esc_attr( self::PAGE_SLUG ); ?>" />
				<input type="hidden" name="orderby" value="<?php echo esc_attr( $orderby ); ?>" />
				<input type="hidden" name="order" value="<?php echo esc_attr( strtolower( $order ) ); ?>" />
				<label class="screen-reader-text" for="amat-vehicle-search"><?php esc_html_e( 'Search vehicles', 'auto-mation' ); ?></label>
				<input type="search" id="amat-vehicle-search" name="s" value="<?php echo esc_attr( $term ); ?>" placeholder="<?php esc_attr_e( 'Make, model, VIN, or plate', 'auto-mation' ); ?>" />
				<label class="screen-reader-text" for="amat-vehicle-year"><?php esc_html_e( 'Filter by year', 'auto-mation' ); ?></label>
				<select name="year" id="amat-vehicle-year">
					<option value=""><?php esc_html_e( 'All years', 'auto-mation' ); ?></option>
					<?php foreach ( $year_opts as $opt ) : ?>
						<option value="<?php echo esc_attr( $opt ); ?>" <?php selected( $opt, $f_year ); ?>><?php echo esc_html( $opt ); ?></option>
					<?php endforeach; ?>
				</select>
				<label class="screen-reader-text" for="amat-vehicle-make"><?php esc_html_e( 'Filter by make', 'auto-mation' ); ?></label>
				<select name="make" id="amat-vehicle-make">
					<option value=""><?php esc_html_e( 'All makes', 'auto-mation' ); ?></option>
					<?php foreach ( $make_opts as $opt ) : ?>
						<option value="<?php echo esc_attr( $opt ); ?>" <?php selected( $opt, $f_make ); ?>><?php echo esc_html( $opt ); ?></option>
					<?php endforeach; ?>
				</select>
				<label class="screen-reader-text" for="amat-vehicle-model"><?php esc_html_e( 'Filter by model', 'auto-mation' ); ?></label>
				<select name="model" id="amat-vehicle-model">
					<option value=""><?php esc_html_e( 'All models', 'auto-mation' ); ?></option>
					<?php foreach ( $model_opts as $opt ) : ?>
						<option value="<?php echo esc_attr( $opt ); ?>" <?php selected( $opt, $f_model ); ?>><?php echo esc_html( $opt ); ?></option>
					<?php endforeach; ?>
				</select>
				<label class="amat-show-disabled"><input type="checkbox" name="show_disabled" value="1" <?php checked( $show_disabled ); ?> /> <?php esc_html_e( 'Show disabled only', 'auto-mation' ); ?></label>
				<?php submit_button( __( 'Filter', 'auto-mation' ), '', '', false ); ?>
			</form>

			<table class="wp-list-table widefat fixed striped">
				<thead>
					<tr>
						<?php
						// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- sortable_th() returns escaped HTML.
						echo $this->sortable_th( __( 'Year', 'auto-mation' ), 'year', $orderby, $order, $base_args );
						echo $this->sortable_th( __( 'Make', 'auto-mation' ), 'make', $orderby, $order, $base_args );
						echo $this->sortable_th( __( 'Model', 'auto-mation' ), 'model', $orderby, $order, $base_args );
						echo $this->sortable_th( __( 'VIN', 'auto-mation' ), 'vin', $orderby, $order, $base_args );
						echo $this->sortable_th( __( 'Plate', 'auto-mation' ), 'plate', $orderby, $order, $base_args );
						echo $this->sortable_th( __( 'Customer', 'auto-mation' ), 'customer', $orderby, $order, $base_args );
						// phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
						?>
					</tr>
				</thead>
				<tbody>
					<?php if ( empty( $vehicles ) ) : ?>
						<tr><td colspan="6"><?php
							$filtered = ( '' !== $term || '' !== $f_year || '' !== $f_make || '' !== $f_model );
							if ( $filtered ) {
								echo $show_disabled ? esc_html__( 'No matching disabled vehicles.', 'auto-mation' ) : esc_html__( 'No matching vehicles.', 'auto-mation' );
							} else {
								echo $show_disabled ? esc_html__( 'No disabled vehicles.', 'auto-mation' ) : esc_html__( 'No vehicles yet.', 'auto-mation' );
							}
							?></td></tr>
					<?php else : ?>
						<?php foreach ( $vehicles as $vehicle ) : ?>
							<?php
							$vid      = (int) $vehicle['id'];
							$disabled = empty( $vehicle['is_active'] );
							// Vehicles are customer items — open the owning customer's
							// detail (read-only), scrolled to and expanded on this vehicle.
							$view_url = add_query_arg(
								array( 'page' => AMAT_Customers_Page::PAGE_SLUG, 'action' => 'view', 'id' => (int) $vehicle['customer_id'], 'expand' => $vid ),
								admin_url( 'admin.php' )
							) . '#amat-veh-' . $vid;
							?>
							<tr class="amat-clickable-row <?php echo $disabled ? 'amat-row-disabled' : ''; ?>" data-href="<?php echo esc_url( $view_url ); ?>">
								<td><a href="<?php echo esc_url( $view_url ); ?>"><?php echo esc_html( (string) ( $vehicle['year'] ?? '' ) ); ?></a><?php echo $disabled ? ' <span class="amat-badge amat-badge-off">' . esc_html__( 'disabled', 'auto-mation' ) . '</span>' : ''; ?></td>
								<td><?php echo esc_html( (string) ( $vehicle['make'] ?? '' ) ); ?></td>
								<td><?php echo esc_html( (string) ( $vehicle['model'] ?? '' ) ); ?></td>
								<td><?php echo esc_html( (string) ( $vehicle['vin'] ?? '' ) ); ?></td>
								<td><?php echo esc_html( (string) ( $vehicle['license_plate'] ?? '' ) ); ?></td>
								<td><?php echo esc_html( '' !== $vehicle['_customer_name'] ? $vehicle['_customer_name'] : '—' ); ?></td>
							</tr>
						<?php endforeach; ?>
					<?php endif; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	/**
	 * Distinct, non-empty, sorted values of one column across vehicle rows.
	 *
	 * Drives the year/make/model filter dropdowns.
	 *
	 * @param array<int,array<string,mixed>> $rows   Vehicle rows.
	 * @param string                         $column Column to collect.
	 * @return array<int,string> Sorted distinct values.
	 */
	private function distinct_values( array $rows, $column ) {
		$values = array();
		foreach ( $rows as $row ) {
			$val = trim( (string) ( $row[ $column ] ?? '' ) );
			if ( '' !== $val ) {
				$values[ $val ] = true;
			}
		}
		$values = array_keys( $values );
		if ( 'year' === $column ) {
			rsort( $values, SORT_NUMERIC );
		} else {
			natcasesort( $values );
			$values = array_values( $values );
		}
		return $values;
	}

	/* --------------------------------------------------------------------- */
	/* Add / edit form                                                       */
	/* --------------------------------------------------------------------- */

	/**
	 * Render the add/edit form.
	 *
	 * @param array<string,mixed> $data  Vehicle row or submitted values.
	 * @param int                 $id    Vehicle id (0 = new).
	 * @param string              $error Optional error notice.
	 * @return void
	 */
	private function render_form( array $data, $id, $error = '' ) {
		$id        = absint( $id );
		$is_edit   = $id > 0;
		$cust_id   = (int) ( $data['customer_id'] ?? 0 );
		$vin       = (string) ( $data['vin'] ?? '' );
		// Only active customers can own a new vehicle; but if we're editing one whose
		// owner has since been disabled, keep that owner listed so it isn't lost.
		$customers = AMAT_Customer_Model::active_options();
		if ( $cust_id && ! isset( $customers[ $cust_id ] ) ) {
			$owner = AMAT_Customer_Model::find( $cust_id );
			if ( $owner ) {
				/* translators: %s: customer display name. */
				$customers[ $cust_id ] = sprintf( __( '%s (disabled)', 'auto-mation' ), AMAT_Customer_Model::display_name( $owner ) );
			}
		}

		// Customer context: when reached from a customer's detail, the owner is
		// fixed — lock the picker and return there on save/cancel.
		$return_customer = isset( $data['return_customer'] )
			? absint( $data['return_customer'] )
			: ( isset( $_GET['return_customer'] ) ? absint( $_GET['return_customer'] ) : 0 ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only nav context; the save itself is nonce-checked.
		$locked = $return_customer > 0;
		if ( $locked && ! $cust_id ) {
			$cust_id = $return_customer;
		}
		$cancel_url = $locked
			? add_query_arg( array( 'page' => AMAT_Customers_Page::PAGE_SLUG, 'action' => 'view', 'id' => $return_customer ), admin_url( 'admin.php' ) )
			: add_query_arg( array( 'page' => self::PAGE_SLUG ), admin_url( 'admin.php' ) );
		?>
		<div class="wrap">
			<h1><?php echo $is_edit ? esc_html__( 'Edit vehicle', 'auto-mation' ) : esc_html__( 'Add vehicle', 'auto-mation' ); ?></h1>

			<?php if ( $error ) : ?>
				<div class="notice notice-error"><p><?php echo esc_html( $error ); ?></p></div>
			<?php endif; ?>

			<?php if ( empty( $customers ) ) : ?>
				<div class="notice notice-warning"><p><?php esc_html_e( 'Add a customer first — every vehicle belongs to a customer.', 'auto-mation' ); ?></p></div>
			<?php endif; ?>

			<form method="post" id="amat-vehicle-form">
				<?php wp_nonce_field( self::NONCE_ACTION ); ?>
				<input type="hidden" name="amat_action" value="save_vehicle" />
				<input type="hidden" name="vehicle_id" value="<?php echo esc_attr( $id ); ?>" />
				<?php if ( $locked ) : ?>
					<input type="hidden" name="return_customer" value="<?php echo esc_attr( $return_customer ); ?>" />
				<?php endif; ?>

				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="amat-veh-customer"><?php esc_html_e( 'Customer', 'auto-mation' ); ?></label></th>
						<td>
							<?php if ( $locked ) : ?>
								<?php $owner = AMAT_Customer_Model::find( $cust_id ); ?>
								<strong><?php echo esc_html( $owner ? AMAT_Customer_Model::display_name( $owner ) : __( '(unknown customer)', 'auto-mation' ) ); ?></strong>
								<input type="hidden" name="customer_id" value="<?php echo esc_attr( $cust_id ); ?>" />
							<?php else : ?>
								<select name="customer_id" id="amat-veh-customer" required>
									<option value=""><?php esc_html_e( '— Select —', 'auto-mation' ); ?></option>
									<?php foreach ( $customers as $opt_id => $opt_name ) : ?>
										<option value="<?php echo esc_attr( $opt_id ); ?>" <?php selected( $opt_id, $cust_id ); ?>><?php echo esc_html( $opt_name ); ?></option>
									<?php endforeach; ?>
								</select>
							<?php endif; ?>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="amat-veh-vin"><?php esc_html_e( 'VIN', 'auto-mation' ); ?></label></th>
						<td>
							<input name="vin" id="amat-veh-vin" type="text" class="regular-text" maxlength="17" autocomplete="off" value="<?php echo esc_attr( $vin ); ?>" />
							<button type="button" class="button" id="amat-vin-decode"><?php esc_html_e( 'Decode VIN', 'auto-mation' ); ?></button>
							<div id="amat-vin-status" class="amat-vin-status"></div>
							<p class="description"><?php esc_html_e( 'Enter the VIN (and Year below for accuracy), then Decode to auto-fill the specs. All fields stay editable.', 'auto-mation' ); ?></p>
						</td>
					</tr>

					<?php foreach ( self::spec_fields() as $field => $label ) : ?>
						<tr>
							<th scope="row"><label for="amat-veh-<?php echo esc_attr( $field ); ?>"><?php echo esc_html( $label ); ?></label></th>
							<td><input name="<?php echo esc_attr( $field ); ?>" id="amat-veh-<?php echo esc_attr( $field ); ?>" type="text" class="regular-text" value="<?php echo esc_attr( (string) ( $data[ $field ] ?? '' ) ); ?>" /></td>
						</tr>
					<?php endforeach; ?>

					<?php foreach ( self::manual_fields() as $field => $label ) : ?>
						<tr>
							<th scope="row"><label for="amat-veh-<?php echo esc_attr( $field ); ?>"><?php echo esc_html( $label ); ?></label></th>
							<td><input name="<?php echo esc_attr( $field ); ?>" id="amat-veh-<?php echo esc_attr( $field ); ?>" type="text" class="regular-text" value="<?php echo esc_attr( (string) ( $data[ $field ] ?? '' ) ); ?>" /></td>
						</tr>
					<?php endforeach; ?>

					<tr>
						<th scope="row"><label for="amat-veh-warnings"><?php esc_html_e( 'Warnings', 'auto-mation' ); ?></label></th>
						<td><textarea name="warnings" id="amat-veh-warnings" class="large-text" rows="2"><?php echo esc_textarea( (string) ( $data['warnings'] ?? '' ) ); ?></textarea></td>
					</tr>
					<tr>
						<th scope="row"><label for="amat-veh-notes"><?php esc_html_e( 'Notes', 'auto-mation' ); ?></label></th>
						<td><textarea name="notes" id="amat-veh-notes" class="large-text" rows="3"><?php echo esc_textarea( (string) ( $data['notes'] ?? '' ) ); ?></textarea></td>
					</tr>
				</table>

				<?php submit_button( $is_edit ? __( 'Save changes', 'auto-mation' ) : __( 'Add vehicle', 'auto-mation' ) ); ?>
				<a href="<?php echo esc_url( $cancel_url ); ?>" class="button amat-btn-secondary"><?php esc_html_e( 'Cancel', 'auto-mation' ); ?></a>
			</form>
		</div>
		<?php
	}

	/* --------------------------------------------------------------------- */
	/* Save                                                                  */
	/* --------------------------------------------------------------------- */

	/**
	 * Validate and persist the submitted vehicle.
	 *
	 * Called from the base class on `admin_init` once it confirms this is the
	 * vehicle save POST; always returns a result array (never null).
	 *
	 * @return array{status:string,message:string,data?:array,editing_id?:int}
	 */
	protected function save() {
		check_admin_referer( self::NONCE_ACTION );
		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			return array( 'status' => 'error', 'message' => __( 'You are not allowed to save vehicles.', 'auto-mation' ), 'data' => array(), 'editing_id' => 0 );
		}

		$id   = isset( $_POST['vehicle_id'] ) ? absint( $_POST['vehicle_id'] ) : 0;
		// Customer context to return to (kept in $data so a re-rendered form on
		// error preserves it; the model drops it as a non-schema key on save).
		$return_customer = isset( $_POST['return_customer'] ) ? absint( $_POST['return_customer'] ) : 0;
		$data = array(
			'customer_id'     => isset( $_POST['customer_id'] ) ? absint( $_POST['customer_id'] ) : 0,
			'return_customer' => $return_customer,
		);

		foreach ( array_keys( self::spec_fields() ) as $field ) {
			$data[ $field ] = sanitize_text_field( wp_unslash( $_POST[ $field ] ?? '' ) );
		}
		foreach ( array_keys( self::manual_fields() ) as $field ) {
			$data[ $field ] = sanitize_text_field( wp_unslash( $_POST[ $field ] ?? '' ) );
		}
		$data['vin']      = strtoupper( preg_replace( '/[^A-Za-z0-9]/', '', sanitize_text_field( wp_unslash( $_POST['vin'] ?? '' ) ) ) );
		$data['warnings'] = sanitize_textarea_field( wp_unslash( $_POST['warnings'] ?? '' ) );
		$data['notes']    = sanitize_textarea_field( wp_unslash( $_POST['notes'] ?? '' ) );

		if ( ! $data['customer_id'] ) {
			return array( 'status' => 'error', 'message' => __( 'Please choose a customer for this vehicle.', 'auto-mation' ), 'data' => $data, 'editing_id' => $id );
		}

		if ( $id ) {
			AMAT_Vehicle_Model::update( $id, $data );
		} else {
			$id = AMAT_Vehicle_Model::create( $data );
		}

		if ( ! $id ) {
			return array( 'status' => 'error', 'message' => __( 'Could not save the vehicle. Please try again.', 'auto-mation' ), 'data' => $data, 'editing_id' => 0 );
		}

		$success = array( 'status' => 'success', 'message' => __( 'Vehicle saved.', 'auto-mation' ) );
		if ( $return_customer ) {
			// Return to the customer detail this vehicle was managed from.
			$success['redirect'] = add_query_arg(
				array( 'page' => AMAT_Customers_Page::PAGE_SLUG, 'action' => 'view', 'id' => $return_customer ),
				admin_url( 'admin.php' )
			);
		}
		return $success;
	}

	/* --------------------------------------------------------------------- */
	/* AJAX: VIN decode                                                      */
	/* --------------------------------------------------------------------- */

	/**
	 * AJAX handler: decode a VIN via vPIC and return mapped vehicle fields.
	 *
	 * Registered on wp_ajax_amat_decode_vin. Returns JSON success (the decode
	 * result: fields + how well it went — see AMAT_Vin_Decoder::decode_full())
	 * or error (a displayable message, e.g. an unusable VIN).
	 *
	 * @return void
	 */
	public static function ajax_decode_vin() {
		check_ajax_referer( self::VIN_NONCE, 'nonce' );

		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			wp_send_json_error( array( 'message' => __( 'Not allowed.', 'auto-mation' ) ), 403 );
		}

		$vin  = isset( $_POST['vin'] ) ? sanitize_text_field( wp_unslash( $_POST['vin'] ) ) : '';
		$year = isset( $_POST['year'] ) ? absint( $_POST['year'] ) : 0;

		$decoder = new AMAT_Vin_Decoder();
		$result  = $decoder->decode_full( $vin, $year ?: null );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		// { fields, vin, level, message, notes, suggested_vin } — the caller shows
		// the message/notes and only fills fields when something was identified.
		wp_send_json_success( $result );
	}
}
