<?php
/**
 * Locations admin page: list/search, add, and edit customer locations.
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Renders the Locations list and add/edit form.
 *
 * A location belongs to one customer. At most one of a customer's locations
 * may be flagged primary (default service address) and one billing (sent to
 * Wave); saving with a flag set clears it on the customer's other locations.
 * Security pattern per §5 (nonce, capability, sanitize in, escape out).
 */
class AMAT_Locations_Page extends AMAT_Admin_Page {

	const NONCE_ACTION = 'amat_save_location';
	const PAGE_SLUG    = 'amat-locations';
	const POST_ACTION  = 'save_location';

	/**
	 * Locations support enable/disable (soft delete) — see CLAUDE.md §11.
	 *
	 * @return string
	 */
	protected static function active_model() {
		return 'AMAT_Location_Model';
	}

	/**
	 * Render the page: handle a submit, then route to list or form.
	 *
	 * @return void
	 */
	public function render() {
		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'auto-mation' ) );
		}

		$flash  = $this->take_flash();
		$action = isset( $_GET['action'] ) ? sanitize_key( wp_unslash( $_GET['action'] ) ) : '';

		if ( 'new' === $action || 'edit' === $action ) {
			// A failed save flashes the submitted values — re-render with those.
			if ( $flash && 'error' === $flash['status'] ) {
				$this->render_form( $flash['data'], $flash['editing_id'], $flash['message'] );
				return;
			}
			if ( 'new' === $action ) {
				$this->render_form( array(), 0 );
				return;
			}
			$id       = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0;
			$location = $id ? AMAT_Location_Model::find( $id ) : null;
			if ( ! $location ) {
				$this->render_list( '', __( 'Location not found.', 'auto-mation' ) );
				return;
			}
			$this->render_form( $location, $id );
			return;
		}

		// List view, with any flashed success/error notice.
		$success = ( $flash && 'success' === $flash['status'] ) ? $flash['message'] : '';
		$error   = ( $flash && 'error' === $flash['status'] ) ? $flash['message'] : '';
		$this->render_list( $success, $error );
	}

	/* --------------------------------------------------------------------- */
	/* List                                                                  */
	/* --------------------------------------------------------------------- */

	/**
	 * Render the locations list.
	 *
	 * @param string $success Optional success notice.
	 * @param string $error   Optional error notice.
	 * @return void
	 */
	private function render_list( $success = '', $error = '' ) {
		$cust_id       = isset( $_GET['customer'] ) ? absint( $_GET['customer'] ) : 0;
		$show_disabled = $this->read_show_disabled();
		$customers     = AMAT_Customer_Model::options();

		list( $orderby, $order ) = $this->read_sort( array( 'customer', 'label', 'address', 'primary', 'billing' ), 'customer' );

		$locations = $cust_id
			? AMAT_Location_Model::all( array( 'customer_id' => $cust_id ) )
			: AMAT_Location_Model::all();

		// This grid is customer locations only — exclude the business's own shops
		// (customer_id 0), which are managed under Settings → My Business.
		$locations = array_values(
			array_filter(
				$locations,
				static fn( $loc ) => (int) $loc['customer_id'] !== AMAT_Location_Model::BUSINESS_OWNER_ID
			)
		);

		// The toggle is exclusive: active rows, or disabled rows, never both.
		$locations = $this->filter_active_rows( $locations, $show_disabled );

		// Attach a resolved customer name for display and customer-sort.
		foreach ( $locations as &$loc ) {
			$owner                 = AMAT_Customer_Model::find( (int) $loc['customer_id'] );
			$loc['_customer_name'] = $owner ? AMAT_Customer_Model::display_name( $owner ) : '';
		}
		unset( $loc );

		$locations = $this->sort_rows(
			$locations,
			$order,
			static function ( $loc ) use ( $orderby ) {
				switch ( $orderby ) {
					case 'label':
						return (string) $loc['label'];
					case 'address':
						return AMAT_Location_Model::one_line( $loc );
					case 'primary':
						return (int) $loc['is_primary'];
					case 'billing':
						return (int) $loc['is_billing'];
					case 'customer':
					default:
						return (string) $loc['_customer_name'];
				}
			}
		);

		$base_args = array( 'customer' => $cust_id, 'show_disabled' => $show_disabled ? '1' : '' );
		?>
		<div class="wrap">
			<h1 class="wp-heading-inline"><?php esc_html_e( 'Locations', 'auto-mation' ); ?></h1>
			<hr class="wp-header-end" />

			<?php if ( $success ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php echo esc_html( $success ); ?></p></div>
			<?php endif; ?>
			<?php if ( $error ) : ?>
				<div class="notice notice-error is-dismissible"><p><?php echo esc_html( $error ); ?></p></div>
			<?php endif; ?>

			<form method="get" class="amat-list-filters">
				<input type="hidden" name="page" value="<?php echo esc_attr( self::PAGE_SLUG ); ?>" />
				<input type="hidden" name="orderby" value="<?php echo esc_attr( $orderby ); ?>" />
				<input type="hidden" name="order" value="<?php echo esc_attr( strtolower( $order ) ); ?>" />
				<label class="screen-reader-text" for="amat-location-customer"><?php esc_html_e( 'Filter by customer', 'auto-mation' ); ?></label>
				<select name="customer" id="amat-location-customer">
					<option value="0"><?php esc_html_e( 'All customers', 'auto-mation' ); ?></option>
					<?php foreach ( $customers as $opt_id => $opt_name ) : ?>
						<option value="<?php echo esc_attr( $opt_id ); ?>" <?php selected( $opt_id, $cust_id ); ?>><?php echo esc_html( $opt_name ); ?></option>
					<?php endforeach; ?>
				</select>
				<label class="amat-show-disabled"><input type="checkbox" name="show_disabled" value="1" <?php checked( $show_disabled ); ?> /> <?php esc_html_e( 'Show disabled only', 'auto-mation' ); ?></label>
				<?php submit_button( __( 'Filter', 'auto-mation' ), '', '', false ); ?>
			</form>

			<table class="wp-list-table widefat fixed striped">
				<thead>
					<tr>
						<?php
						// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- sortable_th() returns escaped HTML.
						echo $this->sortable_th( __( 'Customer', 'auto-mation' ), 'customer', $orderby, $order, $base_args );
						echo $this->sortable_th( __( 'Label', 'auto-mation' ), 'label', $orderby, $order, $base_args );
						echo $this->sortable_th( __( 'Address', 'auto-mation' ), 'address', $orderby, $order, $base_args );
						echo $this->sortable_th( __( 'Primary', 'auto-mation' ), 'primary', $orderby, $order, $base_args );
						echo $this->sortable_th( __( 'Billing', 'auto-mation' ), 'billing', $orderby, $order, $base_args );
						// phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
						?>
					</tr>
				</thead>
				<tbody>
					<?php if ( empty( $locations ) ) : ?>
						<tr><td colspan="5"><?php
							if ( $cust_id ) {
								echo $show_disabled ? esc_html__( 'No matching disabled locations.', 'auto-mation' ) : esc_html__( 'No matching locations.', 'auto-mation' );
							} else {
								echo $show_disabled ? esc_html__( 'No disabled locations.', 'auto-mation' ) : esc_html__( 'No locations yet.', 'auto-mation' );
							}
							?></td></tr>
					<?php else : ?>
						<?php foreach ( $locations as $location ) : ?>
							<?php
							$disabled = empty( $location['is_active'] );
							// Locations are customer items — open the owning customer's
							// detail (read-only) rather than a bare edit form.
							$view_url = add_query_arg(
								array( 'page' => AMAT_Customers_Page::PAGE_SLUG, 'action' => 'view', 'id' => (int) $location['customer_id'] ),
								admin_url( 'admin.php' )
							);
							?>
							<tr class="amat-clickable-row <?php echo $disabled ? 'amat-row-disabled' : ''; ?>" data-href="<?php echo esc_url( $view_url ); ?>">
								<td><a href="<?php echo esc_url( $view_url ); ?>"><?php echo esc_html( '' !== $location['_customer_name'] ? $location['_customer_name'] : '—' ); ?></a><?php echo $disabled ? ' <span class="amat-badge amat-badge-off">' . esc_html__( 'disabled', 'auto-mation' ) . '</span>' : ''; ?></td>
								<td><?php echo esc_html( '' !== $location['label'] ? $location['label'] : __( '(no label)', 'auto-mation' ) ); ?></td>
								<td><?php echo esc_html( AMAT_Location_Model::one_line( $location ) ); ?></td>
								<td><?php echo $location['is_primary'] ? '✓' : ''; ?></td>
								<td><?php echo $location['is_billing'] ? '✓' : ''; ?></td>
							</tr>
						<?php endforeach; ?>
					<?php endif; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	/* --------------------------------------------------------------------- */
	/* Add / edit form                                                       */
	/* --------------------------------------------------------------------- */

	/**
	 * Render the add/edit form.
	 *
	 * @param array<string,mixed> $data  Location row or submitted values.
	 * @param int                 $id    Location id (0 = new).
	 * @param string              $error Optional error notice.
	 * @return void
	 */
	private function render_form( array $data, $id, $error = '' ) {
		$id        = absint( $id );
		$is_edit   = $id > 0;
		$cust_id   = (int) ( $data['customer_id'] ?? 0 );
		// Only active customers can own a new location; keep an already-selected
		// (now-disabled) owner listed when editing so it isn't silently lost.
		$customers = AMAT_Customer_Model::active_options();
		if ( $cust_id && ! isset( $customers[ $cust_id ] ) ) {
			$owner = AMAT_Customer_Model::find( $cust_id );
			if ( $owner ) {
				/* translators: %s: customer display name. */
				$customers[ $cust_id ] = sprintf( __( '%s (disabled)', 'auto-mation' ), AMAT_Customer_Model::display_name( $owner ) );
			}
		}

		// Customer context: when reached from a customer's detail, the owner is
		// fixed — lock the picker and return there on save/cancel.
		$return_customer = isset( $data['return_customer'] )
			? absint( $data['return_customer'] )
			: ( isset( $_GET['return_customer'] ) ? absint( $_GET['return_customer'] ) : 0 ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only nav context; the save itself is nonce-checked.
		$locked = $return_customer > 0;
		if ( $locked && ! $cust_id ) {
			$cust_id = $return_customer;
		}
		$cancel_url = $locked
			? add_query_arg( array( 'page' => AMAT_Customers_Page::PAGE_SLUG, 'action' => 'view', 'id' => $return_customer ), admin_url( 'admin.php' ) )
			: add_query_arg( array( 'page' => self::PAGE_SLUG ), admin_url( 'admin.php' ) );

		$text = static function ( $key ) use ( $data ) {
			return esc_attr( (string) ( $data[ $key ] ?? '' ) );
		};

		// The first location for a customer defaults Primary + Billing checked so
		// both always exist for Wave/payment (the owner can still uncheck). Only
		// applies to a fresh add (not an error re-render, which carries the keys).
		$first_location  = ! $is_edit && $cust_id && empty( AMAT_Location_Model::for_customer( $cust_id ) );
		$primary_checked = array_key_exists( 'is_primary', $data ) ? ! empty( $data['is_primary'] ) : $first_location;
		$billing_checked = array_key_exists( 'is_billing', $data ) ? ! empty( $data['is_billing'] ) : $first_location;
		?>
		<div class="wrap">
			<h1><?php echo $is_edit ? esc_html__( 'Edit location', 'auto-mation' ) : esc_html__( 'Add location', 'auto-mation' ); ?></h1>

			<?php if ( $error ) : ?>
				<div class="notice notice-error"><p><?php echo esc_html( $error ); ?></p></div>
			<?php endif; ?>

			<?php if ( empty( $customers ) ) : ?>
				<div class="notice notice-warning"><p><?php esc_html_e( 'Add a customer first — every location belongs to a customer.', 'auto-mation' ); ?></p></div>
			<?php endif; ?>

			<form method="post">
				<?php wp_nonce_field( self::NONCE_ACTION ); ?>
				<input type="hidden" name="amat_action" value="save_location" />
				<input type="hidden" name="location_id" value="<?php echo esc_attr( $id ); ?>" />
				<?php if ( $locked ) : ?>
					<input type="hidden" name="return_customer" value="<?php echo esc_attr( $return_customer ); ?>" />
				<?php endif; ?>

				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="amat-loc-customer"><?php esc_html_e( 'Customer', 'auto-mation' ); ?></label></th>
						<td>
							<?php if ( $locked ) : ?>
								<?php $owner = AMAT_Customer_Model::find( $cust_id ); ?>
								<strong><?php echo esc_html( $owner ? AMAT_Customer_Model::display_name( $owner ) : __( '(unknown customer)', 'auto-mation' ) ); ?></strong>
								<input type="hidden" name="customer_id" value="<?php echo esc_attr( $cust_id ); ?>" />
							<?php else : ?>
								<select name="customer_id" id="amat-loc-customer" required>
									<option value=""><?php esc_html_e( '— Select —', 'auto-mation' ); ?></option>
									<?php foreach ( $customers as $opt_id => $opt_name ) : ?>
										<option value="<?php echo esc_attr( $opt_id ); ?>" <?php selected( $opt_id, $cust_id ); ?>><?php echo esc_html( $opt_name ); ?></option>
									<?php endforeach; ?>
								</select>
							<?php endif; ?>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="amat-loc-label"><?php esc_html_e( 'Label', 'auto-mation' ); ?></label></th>
						<td><input name="label" id="amat-loc-label" type="text" class="regular-text" maxlength="100" value="<?php echo $text( 'label' ); ?>" placeholder="<?php esc_attr_e( 'Home, Shop, …', 'auto-mation' ); ?>" /></td>
					</tr>
					<tr>
						<th scope="row"><label for="amat-loc-street1"><?php esc_html_e( 'Street address', 'auto-mation' ); ?></label></th>
						<td>
							<input name="street_1" id="amat-loc-street1" type="text" class="regular-text" maxlength="191" value="<?php echo $text( 'street_1' ); ?>" /><br />
							<input name="street_2" id="amat-loc-street2" type="text" class="regular-text" maxlength="191" value="<?php echo $text( 'street_2' ); ?>" placeholder="<?php esc_attr_e( 'Apt, suite, etc. (optional)', 'auto-mation' ); ?>" style="margin-top:4px;" />
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="amat-loc-city"><?php esc_html_e( 'City', 'auto-mation' ); ?></label></th>
						<td><input name="city" id="amat-loc-city" type="text" class="regular-text" maxlength="100" value="<?php echo $text( 'city' ); ?>" /></td>
					</tr>
					<tr>
						<th scope="row"><label for="amat-loc-state"><?php esc_html_e( 'State', 'auto-mation' ); ?></label></th>
						<td>
							<input name="state" id="amat-loc-state" type="text" class="amat-state-input" list="amat-state-list" maxlength="2" autocapitalize="characters" autocomplete="off" inputmode="text" pattern="[A-Za-z]{2}" value="<?php echo $text( 'state' ); ?>" placeholder="<?php esc_attr_e( 'e.g. CA', 'auto-mation' ); ?>" />
							<datalist id="amat-state-list">
								<?php foreach ( AMAT_Location_Model::state_codes() as $code ) : ?>
									<option value="<?php echo esc_attr( $code ); ?>"></option>
								<?php endforeach; ?>
							</datalist>
							<p class="description"><?php esc_html_e( 'Two-letter US state code (e.g. CA, TX, NY).', 'auto-mation' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="amat-loc-zip"><?php esc_html_e( 'Zipcode', 'auto-mation' ); ?></label></th>
						<td><input name="zipcode" id="amat-loc-zip" type="text" class="regular-text" maxlength="20" value="<?php echo $text( 'zipcode' ); ?>" /></td>
					</tr>
					<tr>
						<th scope="row"><label for="amat-loc-code"><?php esc_html_e( 'Code', 'auto-mation' ); ?></label></th>
						<td>
							<input name="code" id="amat-loc-code" type="text" class="regular-text" maxlength="100" value="<?php echo $text( 'code' ); ?>" />
							<p class="description"><?php esc_html_e( 'Gate/entry code or similar access info.', 'auto-mation' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="amat-loc-notes"><?php esc_html_e( 'Notes', 'auto-mation' ); ?></label></th>
						<td>
							<textarea name="notes" id="amat-loc-notes" class="large-text" rows="3"><?php echo esc_textarea( (string) ( $data['notes'] ?? '' ) ); ?></textarea>
							<p class="description"><?php esc_html_e( 'Additional info about this location (for you or the customer).', 'auto-mation' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Flags', 'auto-mation' ); ?></th>
						<td>
							<label><input name="is_primary" type="checkbox" value="1" <?php checked( $primary_checked ); ?> /> <?php esc_html_e( 'Primary (default service address)', 'auto-mation' ); ?></label><br />
							<label><input name="is_billing" type="checkbox" value="1" <?php checked( $billing_checked ); ?> /> <?php esc_html_e( 'Billing (address sent to Wave)', 'auto-mation' ); ?></label>
							<p class="description"><?php esc_html_e( 'Setting one of these clears it on the customer’s other locations. The customer must always have a primary and a billing location, so you can’t uncheck the last one — assign the flag to another location instead.', 'auto-mation' ); ?></p>
						</td>
					</tr>
				</table>

				<?php submit_button( $is_edit ? __( 'Save changes', 'auto-mation' ) : __( 'Add location', 'auto-mation' ) ); ?>
				<a href="<?php echo esc_url( $cancel_url ); ?>" class="button amat-btn-secondary"><?php esc_html_e( 'Cancel', 'auto-mation' ); ?></a>
			</form>
		</div>
		<?php
	}

	/* --------------------------------------------------------------------- */
	/* Save                                                                  */
	/* --------------------------------------------------------------------- */

	/**
	 * Validate and persist the submitted location.
	 *
	 * Called from the base class on `admin_init` once it confirms this is the
	 * location save POST; always returns a result array (never null).
	 *
	 * @return array{status:string,message:string,data?:array,editing_id?:int}
	 */
	protected function save() {
		check_admin_referer( self::NONCE_ACTION );
		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			return array( 'status' => 'error', 'message' => __( 'You are not allowed to save locations.', 'auto-mation' ), 'data' => array(), 'editing_id' => 0 );
		}

		$id              = isset( $_POST['location_id'] ) ? absint( $_POST['location_id'] ) : 0;
		// Customer context to return to (kept in $data so a re-rendered form on
		// error preserves it; the model drops it as a non-schema key on save).
		$return_customer = isset( $_POST['return_customer'] ) ? absint( $_POST['return_customer'] ) : 0;
		$data = array(
			'customer_id'     => isset( $_POST['customer_id'] ) ? absint( $_POST['customer_id'] ) : 0,
			'return_customer' => $return_customer,
			'label'       => sanitize_text_field( wp_unslash( $_POST['label'] ?? '' ) ),
			'street_1'    => sanitize_text_field( wp_unslash( $_POST['street_1'] ?? '' ) ),
			'street_2'    => sanitize_text_field( wp_unslash( $_POST['street_2'] ?? '' ) ),
			'city'        => sanitize_text_field( wp_unslash( $_POST['city'] ?? '' ) ),
			'state'       => strtoupper( sanitize_text_field( wp_unslash( $_POST['state'] ?? '' ) ) ),
			'zipcode'     => sanitize_text_field( wp_unslash( $_POST['zipcode'] ?? '' ) ),
			'code'        => sanitize_text_field( wp_unslash( $_POST['code'] ?? '' ) ),
			'notes'       => sanitize_textarea_field( wp_unslash( $_POST['notes'] ?? '' ) ),
			'is_primary'  => isset( $_POST['is_primary'] ) ? 1 : 0,
			'is_billing'  => isset( $_POST['is_billing'] ) ? 1 : 0,
		);

		if ( ! $data['customer_id'] ) {
			return array( 'status' => 'error', 'message' => __( 'Please choose a customer for this location.', 'auto-mation' ), 'data' => $data, 'editing_id' => $id );
		}

		// State is optional, but if given must be a valid US 2-letter code.
		if ( '' !== $data['state'] && ! AMAT_Location_Model::is_valid_state( $data['state'] ) ) {
			return array( 'status' => 'error', 'message' => __( 'Please enter a valid two-letter US state code (e.g. CA).', 'auto-mation' ), 'data' => $data, 'editing_id' => $id );
		}

		// A customer must always have a primary and a billing location (Wave needs
		// both). A flag may only *move* to a replacement, never be left unset — so
		// reject the save if unchecking one would leave no active location with it.
		$others = array_filter(
			AMAT_Location_Model::for_customer( $data['customer_id'] ),
			static fn( $loc ) => (int) $loc['id'] !== $id && ! empty( $loc['is_active'] )
		);
		$other_has_primary = (bool) array_filter( $others, static fn( $loc ) => ! empty( $loc['is_primary'] ) );
		$other_has_billing = (bool) array_filter( $others, static fn( $loc ) => ! empty( $loc['is_billing'] ) );
		if ( ! $data['is_primary'] && ! $other_has_primary ) {
			return array( 'status' => 'error', 'message' => __( 'This is the customer’s only primary location — set another location as primary before removing it here.', 'auto-mation' ), 'data' => $data, 'editing_id' => $id );
		}
		if ( ! $data['is_billing'] && ! $other_has_billing ) {
			return array( 'status' => 'error', 'message' => __( 'This is the customer’s only billing location — set another location as billing before removing it here.', 'auto-mation' ), 'data' => $data, 'editing_id' => $id );
		}

		if ( $id ) {
			AMAT_Location_Model::update( $id, $data );
		} else {
			$id = AMAT_Location_Model::create( $data );
		}

		if ( ! $id ) {
			return array( 'status' => 'error', 'message' => __( 'Could not save the location. Please try again.', 'auto-mation' ), 'data' => $data, 'editing_id' => 0 );
		}

		// Keep primary/billing unique per customer.
		if ( $data['is_primary'] ) {
			AMAT_Location_Model::make_sole_flag( $data['customer_id'], $id, 'is_primary' );
		}
		if ( $data['is_billing'] ) {
			AMAT_Location_Model::make_sole_flag( $data['customer_id'], $id, 'is_billing' );
		}

		$success = array( 'status' => 'success', 'message' => __( 'Location saved.', 'auto-mation' ) );
		if ( $return_customer ) {
			// Return to the customer detail this location was managed from.
			$success['redirect'] = add_query_arg(
				array( 'page' => AMAT_Customers_Page::PAGE_SLUG, 'action' => 'view', 'id' => $return_customer ),
				admin_url( 'admin.php' )
			);
		}
		return $success;
	}
}
