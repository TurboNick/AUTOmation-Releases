<?php
/**
 * Shared base for the plugin's admin CRUD pages.
 *
 * Provides the post/redirect/get (PRG) plumbing so a saved form ends on a
 * clean GET of the list (or back on the form when validation fails) instead
 * of rendering in the same request as the POST — which left the URL on
 * `action=edit` and re-submitted the form on a browser refresh.
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Base class for admin list/add/edit pages.
 *
 * Subclasses define three constants — PAGE_SLUG, NONCE_ACTION, and POST_ACTION
 * (the hidden `amat_action` value) — and implement save(), which validates and
 * persists the POST and returns a result array:
 *
 *   - On success: array{status:'success', message:string}
 *   - On failure: array{status:'error', message:string, data:array,
 *                       editing_id:int, ...extra preserved input}
 *
 * The save runs on `admin_init` (before any output) via maybe_process(); the
 * result is flashed into a short-lived transient and the request redirects.
 * The page's render() then calls take_flash() to show the notice and, on a
 * validation error, repopulate the form with what the user typed.
 */
abstract class AMAT_Admin_Page {

	/**
	 * Validate and persist the submitted POST.
	 *
	 * Implementations must verify the nonce (check_admin_referer) and the
	 * user capability before writing. Reads from $_POST directly.
	 *
	 * @return array{status:string,message:string,data?:array,editing_id?:int}
	 */
	abstract protected function save();

	/**
	 * PRG entry point, hooked on `admin_init`.
	 *
	 * Ignores every request except this page's own form POST, then runs the
	 * save, flashes the result, and redirects — list on success, back to the
	 * form (preserving input) on error. Always exits when it handles a POST.
	 *
	 * @return void
	 */
	public function maybe_process() {
		// A row enable/disable toggle (soft delete) is its own POST action so it
		// can ride the same admin_init hook without going through save().
		if ( isset( $_POST['amat_action'] ) && ( static::POST_ACTION . '_active' ) === $_POST['amat_action'] ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce is checked in process_active_toggle() before any write.
			$this->process_active_toggle();
			return;
		}

		// A per-record hard delete (Dev Tools gated; any record of a deletable model).
		if ( isset( $_POST['amat_action'] ) && ( static::POST_ACTION . '_delete' ) === $_POST['amat_action'] ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce is checked in process_delete() before any write.
			$this->process_delete();
			return;
		}

		if ( ! isset( $_POST['amat_action'] ) || static::POST_ACTION !== $_POST['amat_action'] ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce is checked in save() before any write.
			return;
		}

		$result = $this->save();

		if ( 'success' === $result['status'] ) {
			// A page may steer the post-save redirect (e.g. back to a customer
			// detail) by returning a 'redirect' URL; otherwise land on the list.
			$target = isset( $result['redirect'] ) ? $result['redirect'] : $this->list_url();
			// Flash onto the destination page (often a different page than the one
			// that handled the save — e.g. saving a job returns to the customer).
			$this->flash_to_destination( array( 'status' => 'success', 'message' => $result['message'] ), $target );
			wp_safe_redirect( $target );
			exit;
		}

		// Error: carry the message + the user's input back to the form.
		$this->set_flash( $result );
		$id       = isset( $result['editing_id'] ) ? (int) $result['editing_id'] : 0;
		$redirect = $id > 0
			? $this->list_url( array( 'action' => 'edit', 'id' => $id ) )
			: $this->list_url( array( 'action' => 'new' ) );
		wp_safe_redirect( $redirect );
		exit;
	}

	/* --------------------------------------------------------------------- */
	/* Enable / disable (soft delete) toggle                                 */
	/* --------------------------------------------------------------------- */

	/**
	 * Model class whose rows this page can enable/disable, or '' to opt out.
	 *
	 * Pages that support soft-delete (Vehicles, Locations) override this to
	 * return their model class name; the rest inherit the no-op default.
	 *
	 * @return string Fully-qualified model class name, or '' if unsupported.
	 */
	protected static function active_model() {
		return '';
	}

	/**
	 * Handle a row enable/disable POST: flip is_active, flash, and redirect
	 * back to where the action was triggered.
	 *
	 * Records are disabled rather than deleted so jobs/service history can keep
	 * referencing them and they still appear in reporting (see CLAUDE.md §11).
	 *
	 * @return void
	 */
	private function process_active_toggle() {
		$model = static::active_model();
		if ( '' === $model ) {
			return;
		}

		check_admin_referer( static::NONCE_ACTION . '_active' );
		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'auto-mation' ) );
		}

		$id     = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		$active = ( isset( $_POST['active'] ) && '1' === (string) $_POST['active'] ) ? 1 : 0;
		if ( $id ) {
			$model::update( $id, array( 'is_active' => $active ) );
			$this->after_active_toggle( $id, $active );
		}

		// Return to the originating screen (a customer detail, or the grid with
		// its filters). wp_safe_redirect confines this to the local admin.
		$redirect = isset( $_POST['redirect'] ) ? esc_url_raw( wp_unslash( $_POST['redirect'] ) ) : $this->list_url();
		$redirect = $redirect ?: $this->list_url();

		$this->flash_to_destination(
			array(
				'status'  => 'success',
				'message' => $active ? __( 'Record enabled.', 'auto-mation' ) : __( 'Record disabled.', 'auto-mation' ),
			),
			$redirect
		);

		wp_safe_redirect( $redirect );
		exit;
	}

	/**
	 * Hook called after a row's is_active is flipped, for cascade side effects.
	 *
	 * Default no-op; the Customers page overrides it to cascade-disable a
	 * customer's vehicles and locations (re-enabling does not cascade back).
	 *
	 * @param int $id     Row id that was toggled.
	 * @param int $active New active state (1 = enabled, 0 = disabled).
	 * @return void
	 */
	protected function after_active_toggle( $id, $active ) {}

	/**
	 * Build the inline enable/disable button form for one row.
	 *
	 * A tiny POST form (nonced) so the toggle is a state change, not a GET link.
	 * Disabled rows show an "Enable" button; active rows a "Disable" button.
	 *
	 * The action/nonce are passed in (not read from static::) because the form
	 * is often rendered on a different page than the one that handles it — e.g.
	 * the customer detail renders a *vehicle* toggle, which the Vehicles page's
	 * maybe_process() handles. Pass that page's base POST_ACTION + NONCE_ACTION;
	 * this method appends the "_active" suffix the handler expects.
	 *
	 * @param string $post_action  Owning page's POST_ACTION (e.g. 'save_vehicle').
	 * @param string $nonce_action Owning page's NONCE_ACTION (e.g. 'amat_save_vehicle').
	 * @param int    $id           Row id.
	 * @param bool   $is_active    Current state.
	 * @param string $redirect     URL to return to after the toggle.
	 * @return string Escaped HTML form.
	 */
	protected function active_toggle_button( $post_action, $nonce_action, $id, $is_active, $redirect ) {
		$next  = $is_active ? '0' : '1';
		$label = $is_active ? __( 'Disable', 'auto-mation' ) : __( 'Enable', 'auto-mation' );
		$class = $is_active ? 'button amat-btn-disable' : 'button amat-btn-primary';

		ob_start();
		?>
		<form method="post" class="amat-inline-form">
			<?php wp_nonce_field( $nonce_action . '_active' ); ?>
			<input type="hidden" name="amat_action" value="<?php echo esc_attr( $post_action . '_active' ); ?>" />
			<input type="hidden" name="id" value="<?php echo esc_attr( (int) $id ); ?>" />
			<input type="hidden" name="active" value="<?php echo esc_attr( $next ); ?>" />
			<input type="hidden" name="redirect" value="<?php echo esc_attr( $redirect ); ?>" />
			<button type="submit" class="<?php echo esc_attr( $class ); ?>"><?php echo esc_html( $label ); ?></button>
		</form>
		<?php
		return ob_get_clean();
	}

	/* --------------------------------------------------------------------- */
	/* Per-record hard delete (Dev Tools gated)                              */
	/* --------------------------------------------------------------------- */

	/**
	 * Model class whose rows this page can hard-delete, or '' to opt out.
	 *
	 * Defaults to the soft-delete model (so Customers/Vehicles/Locations/Services/
	 * Parts get delete for free); pages with no soft-delete (Jobs, Estimates,
	 * Invoices) override this to return their model and become deletable too.
	 *
	 * @return string Fully-qualified model class name, or '' if unsupported.
	 */
	protected static function deletable_model() {
		return static::active_model();
	}

	/**
	 * Handle a per-record hard-delete POST: permanently remove one record.
	 *
	 * A development convenience for clearing errant test records, so it is gated:
	 * it only runs when the Dev Tools "allow delete" option is on, only for a page
	 * that opts in via `deletable_model()`, and only after a nonce + capability
	 * check (the button also shows a JS confirm). Cascade cleanup of owned rows is
	 * left to the page via `after_delete()`.
	 *
	 * @return void
	 */
	private function process_delete() {
		$model = static::deletable_model();
		if ( '' === $model || ! AMAT_Admin::delete_enabled() ) {
			return;
		}

		check_admin_referer( static::NONCE_ACTION . '_delete' );
		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'auto-mation' ) );
		}

		$id     = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		$record = $id ? $model::find( $id ) : null;

		$redirect = isset( $_POST['redirect'] ) ? esc_url_raw( wp_unslash( $_POST['redirect'] ) ) : $this->list_url();
		$redirect = $redirect ?: $this->list_url();

		if ( ! $record ) {
			$this->flash_to_destination(
				array( 'status' => 'error', 'message' => __( 'That record could not be found.', 'auto-mation' ) ),
				$redirect
			);
			wp_safe_redirect( $redirect );
			exit;
		}

		$model::delete( $id );
		$this->after_delete( $id );

		$this->flash_to_destination(
			array( 'status' => 'success', 'message' => __( 'Record permanently deleted.', 'auto-mation' ) ),
			$redirect
		);
		wp_safe_redirect( $redirect );
		exit;
	}

	/**
	 * Hook called after a record is hard-deleted, for cascade cleanup of owned
	 * rows. Default no-op; the Customers page overrides it to remove the deleted
	 * customer's contact methods, locations, vehicles, jobs, and estimates/invoices.
	 *
	 * @param int $id Row id that was deleted.
	 * @return void
	 */
	protected function after_delete( $id ) {}

	/**
	 * Build the inline hard-delete button form for one record, or '' when the Dev
	 * Tools delete option is off. Mirrors active_toggle_button(); the owning page's
	 * POST_ACTION/NONCE_ACTION are passed in because the form is often rendered on
	 * a different page than the one that handles it.
	 *
	 * @param string $post_action  Owning page's POST_ACTION (e.g. 'save_vehicle').
	 * @param string $nonce_action Owning page's NONCE_ACTION (e.g. 'amat_save_vehicle').
	 * @param int    $id           Row id.
	 * @param string $redirect     URL to return to after the delete.
	 * @return string Escaped HTML form, or '' when disabled.
	 */
	protected function delete_button( $post_action, $nonce_action, $id, $redirect ) {
		if ( ! AMAT_Admin::delete_enabled() ) {
			return '';
		}

		$confirm = esc_js( __( 'Permanently delete this record? This cannot be undone.', 'auto-mation' ) );

		ob_start();
		?>
		<form method="post" class="amat-inline-form" onsubmit="return confirm('<?php echo $confirm; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- esc_js() above. ?>');">
			<?php wp_nonce_field( $nonce_action . '_delete' ); ?>
			<input type="hidden" name="amat_action" value="<?php echo esc_attr( $post_action . '_delete' ); ?>" />
			<input type="hidden" name="id" value="<?php echo esc_attr( (int) $id ); ?>" />
			<input type="hidden" name="redirect" value="<?php echo esc_attr( $redirect ); ?>" />
			<button type="submit" class="button amat-btn-delete"><?php esc_html_e( 'Delete', 'auto-mation' ); ?></button>
		</form>
		<?php
		return ob_get_clean();
	}

	/* --------------------------------------------------------------------- */
	/* Flash (one-shot per-user notice + preserved input)                    */
	/* --------------------------------------------------------------------- */

	/**
	 * Transient key for this page's flash, scoped to the current user so two
	 * admins don't read each other's notices.
	 *
	 * @return string
	 */
	private function flash_key() {
		return 'amat_flash_' . static::PAGE_SLUG . '_' . get_current_user_id();
	}

	/**
	 * Stash a flash payload for the next request.
	 *
	 * @param array<string,mixed> $payload Notice (and, on error, input) to carry.
	 * @return void
	 */
	protected function set_flash( array $payload ) {
		set_transient( $this->flash_key(), $payload, MINUTE_IN_SECONDS );
	}

	/**
	 * Flash a payload onto the page named in a redirect URL's `page` arg.
	 *
	 * Cross-page redirects (e.g. saving a customer-owned job returns to the
	 * customer detail) need the notice on the *destination* page, not the
	 * handler's own page. Falls back to this page's slug if none is found.
	 *
	 * @param array<string,mixed> $payload  Flash payload.
	 * @param string              $redirect Destination URL.
	 * @return void
	 */
	protected function flash_to_destination( array $payload, $redirect ) {
		$slug  = static::PAGE_SLUG;
		$query = wp_parse_url( $redirect, PHP_URL_QUERY );
		if ( $query ) {
			parse_str( $query, $parts );
			if ( ! empty( $parts['page'] ) ) {
				$slug = sanitize_key( $parts['page'] );
			}
		}
		set_transient( 'amat_flash_' . $slug . '_' . get_current_user_id(), $payload, MINUTE_IN_SECONDS );
	}

	/**
	 * Read and clear this page's flash payload, if any.
	 *
	 * @return array<string,mixed>|null The payload, or null when none is set.
	 */
	protected function take_flash() {
		$key     = $this->flash_key();
		$payload = get_transient( $key );
		if ( false === $payload ) {
			return null;
		}
		delete_transient( $key );
		return is_array( $payload ) ? $payload : null;
	}

	/* --------------------------------------------------------------------- */
	/* URL helpers                                                           */
	/* --------------------------------------------------------------------- */

	/**
	 * Build a URL to this page, optionally with extra query args.
	 *
	 * @param array<string,mixed> $extra Additional query args (e.g. action/id).
	 * @return string
	 */
	protected function list_url( array $extra = array() ) {
		return add_query_arg(
			array_merge( array( 'page' => static::PAGE_SLUG ), $extra ),
			admin_url( 'admin.php' )
		);
	}

	/* --------------------------------------------------------------------- */
	/* Active/disabled list filtering                                        */
	/* --------------------------------------------------------------------- */

	/**
	 * Read the list's "Show disabled only" toggle from the request.
	 *
	 * @return bool
	 */
	protected function read_show_disabled() {
		return ! empty( $_GET['show_disabled'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only list toggle, no state change.
	}

	/**
	 * Narrow a set of rows to either the active or the disabled ones.
	 *
	 * The toggle is exclusive, not additive: off shows only active rows, on
	 * shows only disabled rows. A search therefore searches within whichever
	 * set the toggle selected.
	 *
	 * @param array<int,array<string,mixed>> $rows          Rows carrying `is_active`.
	 * @param bool                           $show_disabled Toggle state.
	 * @return array<int,array<string,mixed>> Filtered, re-indexed rows.
	 */
	protected function filter_active_rows( array $rows, $show_disabled ) {
		return array_values(
			array_filter(
				$rows,
				static function ( $row ) use ( $show_disabled ) {
					$disabled = empty( $row['is_active'] );
					return $show_disabled ? $disabled : ! $disabled;
				}
			)
		);
	}

	/* --------------------------------------------------------------------- */
	/* Sortable list helpers                                                 */
	/* --------------------------------------------------------------------- */

	/**
	 * Read the active sort from the request, whitelisted against allowed keys.
	 *
	 * @param string[] $allowed     Sort keys the page accepts.
	 * @param string   $default_key Key to use when none/invalid is requested.
	 * @return array{0:string,1:string} [orderby key, 'ASC'|'DESC'].
	 */
	protected function read_sort( array $allowed, $default_key ) {
		$orderby = isset( $_GET['orderby'] ) ? sanitize_key( wp_unslash( $_GET['orderby'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only list sort, no state change.
		if ( ! in_array( $orderby, $allowed, true ) ) {
			$orderby = $default_key;
		}
		$order = ( isset( $_GET['order'] ) && 'desc' === strtolower( (string) wp_unslash( $_GET['order'] ) ) ) ? 'DESC' : 'ASC'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only list sort.
		return array( $orderby, $order );
	}

	/**
	 * Render one sortable column header (`<th>`), linking to this page with the
	 * sort toggled and the surrounding filter args preserved.
	 *
	 * @param string              $label     Column heading text.
	 * @param string              $key       This column's sort key.
	 * @param string              $orderby   Currently active sort key.
	 * @param string              $order     Currently active direction.
	 * @param array<string,mixed> $base_args Filter args to keep in the link (e.g. s, customer).
	 * @return string Escaped `<th>` HTML.
	 */
	protected function sortable_th( $label, $key, $orderby, $order, array $base_args = array() ) {
		$is_active  = ( $key === $orderby );
		$next_order = ( $is_active && 'ASC' === $order ) ? 'desc' : 'asc';
		$url        = $this->list_url( array_merge( $base_args, array( 'orderby' => $key, 'order' => $next_order ) ) );
		$arrow      = $is_active ? ( 'ASC' === $order ? ' ↑' : ' ↓' ) : '';

		return '<th><a href="' . esc_url( $url ) . '">' . esc_html( $label ) . esc_html( $arrow ) . '</a></th>';
	}

	/**
	 * Stable-sort rows by a per-row sort value, honoring direction.
	 *
	 * @param array<int,array<string,mixed>> $rows   Rows to sort.
	 * @param string                         $order  'ASC' or 'DESC'.
	 * @param callable                       $key_fn fn(array $row): string|int sort value.
	 * @return array<int,array<string,mixed>> Sorted rows.
	 */
	protected function sort_rows( array $rows, $order, callable $key_fn ) {
		$dir = ( 'DESC' === $order ) ? -1 : 1;
		usort(
			$rows,
			static function ( $a, $b ) use ( $key_fn, $dir ) {
				$va = $key_fn( $a );
				$vb = $key_fn( $b );
				if ( is_numeric( $va ) && is_numeric( $vb ) ) {
					$cmp = ( $va <=> $vb );
				} else {
					$cmp = strcasecmp( (string) $va, (string) $vb );
				}
				return $dir * $cmp;
			}
		);
		return $rows;
	}
}
