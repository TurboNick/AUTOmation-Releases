<?php
/**
 * Estimates admin page: native customer-owned estimate documents.
 *
 * A submenu under Customers. Read-only detail + add/edit on the AMAT_Admin_Page
 * PRG base (mirrors the Jobs page: customer lock, vehicle dropdown, return_customer
 * context). Line items are an editable repeater seeded from the Services/Parts
 * catalogs. Sending/approval are delegated to a provider integration via the
 * external_refs link (rendered through the `amat_estimate_detail_actions` hook).
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Renders the Estimates list, read-only detail, and add/edit form.
 */
class AMAT_Estimates_Page extends AMAT_Admin_Page {

	const NONCE_ACTION  = 'amat_save_estimate';
	const PAGE_SLUG     = 'amat-estimates';
	const POST_ACTION   = 'save_estimate';
	const CATALOG_NONCE = 'amat_catalog_search';

	/**
	 * Estimates opt into the Dev Tools per-record delete. They have no soft-delete
	 * (no is_active): a cancelled estimate carries the 'void' *status* instead, so
	 * the cancellation reads on the record (DB v16) — hence this overrides
	 * deletable_model() directly rather than inheriting it from active_model().
	 *
	 * @return string
	 */
	protected static function deletable_model() {
		return 'AMAT_Estimate_Model';
	}

	/**
	 * Cascade an estimate hard-delete to its line items (Dev Tools delete).
	 *
	 * @param int $id Deleted estimate id.
	 * @return void
	 */
	protected function after_delete( $id ) {
		global $wpdb;
		$wpdb->delete( $wpdb->prefix . 'amat_estimate_items', array( 'estimate_id' => (int) $id ) );
	}

	/**
	 * Render the page: route to list / detail / form.
	 *
	 * @return void
	 */
	public function render() {
		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'auto-mation' ) );
		}

		$flash  = $this->take_flash();
		$action = isset( $_GET['action'] ) ? sanitize_key( wp_unslash( $_GET['action'] ) ) : '';

		// Estimates are created and edited on their parent job now (§ job-owned
		// documents). 'view' stays read-only; 'edit'/'new' collapse to it/the list.
		if ( 'view' === $action || 'edit' === $action ) {
			$id       = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0;
			$estimate = $id ? AMAT_Estimate_Model::find( $id ) : null;
			if ( ! $estimate ) {
				$this->render_list( '', __( 'Estimate not found.', 'auto-mation' ) );
				return;
			}
			$success = ( $flash && 'success' === $flash['status'] ) ? $flash['message'] : '';
			$error   = ( $flash && 'error' === $flash['status'] ) ? $flash['message'] : '';
			$this->render_view( $estimate, $success, $error );
			return;
		}

		$success = ( $flash && 'success' === $flash['status'] ) ? $flash['message'] : '';
		$error   = ( $flash && 'error' === $flash['status'] ) ? $flash['message'] : '';
		$this->render_list( $success, $error );
	}

	/* --------------------------------------------------------------------- */
	/* List                                                                  */
	/* --------------------------------------------------------------------- */

	/**
	 * Render the estimates list (all estimates, newest first).
	 *
	 * @param string $success Optional success notice.
	 * @param string $error   Optional error notice.
	 * @return void
	 */
	private function render_list( $success = '', $error = '' ) {
		$estimates = AMAT_Estimate_Model::all( array(), array( 'orderby' => 'id', 'order' => 'DESC' ) );
		?>
		<div class="wrap">
			<h1 class="wp-heading-inline"><?php esc_html_e( 'Estimates', 'auto-mation' ); ?></h1>
			<hr class="wp-header-end" />

			<?php if ( $success ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php echo esc_html( $success ); ?></p></div>
			<?php endif; ?>
			<?php if ( $error ) : ?>
				<div class="notice notice-error is-dismissible"><p><?php echo esc_html( $error ); ?></p></div>
			<?php endif; ?>

			<p class="description"><?php esc_html_e( 'A read-only list of every estimate. Open one to view it; estimates are created and edited on their job.', 'auto-mation' ); ?></p>

			<table class="wp-list-table widefat fixed striped">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Estimate', 'auto-mation' ); ?></th>
						<th><?php esc_html_e( 'Customer', 'auto-mation' ); ?></th>
						<th><?php esc_html_e( 'Status', 'auto-mation' ); ?></th>
						<th><?php esc_html_e( 'Total', 'auto-mation' ); ?></th>
						<th><?php esc_html_e( 'Issued', 'auto-mation' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php if ( empty( $estimates ) ) : ?>
						<tr><td colspan="5"><?php esc_html_e( 'No estimates yet.', 'auto-mation' ); ?></td></tr>
					<?php else : ?>
						<?php foreach ( $estimates as $estimate ) : ?>
							<?php
							$view_url = $this->list_url( array( 'action' => 'view', 'id' => (int) $estimate['id'] ) );
							$owner    = $estimate['customer_id'] ? AMAT_Customer_Model::find( (int) $estimate['customer_id'] ) : null;
							?>
							<tr class="amat-clickable-row" data-href="<?php echo esc_url( $view_url ); ?>">
								<td><a href="<?php echo esc_url( $view_url ); ?>"><?php echo esc_html( self::label( $estimate ) ); ?></a></td>
								<td><?php echo esc_html( $owner ? AMAT_Customer_Model::display_name( $owner ) : '—' ); ?></td>
								<td><span class="amat-status amat-status-<?php echo esc_attr( $estimate['status'] ); ?>"><?php echo esc_html( AMAT_Estimate_Model::status_label( $estimate['status'] ) ); ?></span></td>
								<td><?php echo esc_html( AMAT_Money::format_amount( AMAT_Estimate_Model::total( (int) $estimate['id'] ) ) ); ?></td>
								<td><?php echo esc_html( self::date_display( $estimate['issue_date'] ?? '' ) ); ?></td>
							</tr>
						<?php endforeach; ?>
					<?php endif; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	/* --------------------------------------------------------------------- */
	/* Read-only detail view                                                 */
	/* --------------------------------------------------------------------- */

	/**
	 * Render the read-only estimate detail.
	 *
	 * @param array<string,mixed> $estimate Estimate row.
	 * @param string              $success  Optional success notice.
	 * @param string              $error    Optional error notice.
	 * @return void
	 */
	private function render_view( array $estimate, $success = '', $error = '' ) {
		$id              = (int) $estimate['id'];
		$return_customer = isset( $_GET['return_customer'] ) ? absint( $_GET['return_customer'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only nav context.
		$owner           = $estimate['customer_id'] ? AMAT_Customer_Model::find( (int) $estimate['customer_id'] ) : null;
		$vehicle         = $estimate['vehicle_id'] ? AMAT_Vehicle_Model::find( (int) $estimate['vehicle_id'] ) : null;
		$items           = AMAT_Estimate_Item_Model::for_parent( $id );
		$notes           = trim( (string) ( $estimate['notes'] ?? '' ) );

		$job_id   = (int) ( $estimate['job_id'] ?? 0 );
		$job_edit = $job_id
			? add_query_arg( array( 'page' => AMAT_Jobs_Page::PAGE_SLUG, 'action' => 'edit', 'id' => $job_id ), admin_url( 'admin.php' ) )
			: '';
		$back_url   = $return_customer
			? add_query_arg( array( 'page' => AMAT_Customers_Page::PAGE_SLUG, 'action' => 'view', 'id' => $return_customer ), admin_url( 'admin.php' ) )
			: $this->list_url();
		$back_label = $return_customer ? __( 'Back to customer', 'auto-mation' ) : __( 'Back to estimates', 'auto-mation' );
		?>
		<div class="wrap amat-detail">
			<h1><?php echo esc_html( self::label( $estimate ) ); ?></h1>
			<div class="amat-detail-actions">
				<?php if ( $job_edit ) : ?>
					<a href="<?php echo esc_url( $job_edit ); ?>" class="button amat-btn-primary"><?php esc_html_e( 'Edit on job', 'auto-mation' ); ?></a>
				<?php endif; ?>
				<a href="<?php echo esc_url( $back_url ); ?>" class="button amat-btn-secondary"><?php echo esc_html( $back_label ); ?></a>
			</div>
			<hr class="wp-header-end" />

			<?php if ( $success ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php echo esc_html( $success ); ?></p></div>
			<?php endif; ?>
			<?php if ( $error ) : ?>
				<div class="notice notice-error is-dismissible"><p><?php echo esc_html( $error ); ?></p></div>
			<?php endif; ?>

			<table class="amat-detail-table">
				<tbody>
					<tr><th><?php esc_html_e( 'Customer', 'auto-mation' ); ?></th><td><?php echo esc_html( $owner ? AMAT_Customer_Model::display_name( $owner ) : '—' ); ?></td></tr>
					<tr><th><?php esc_html_e( 'Status', 'auto-mation' ); ?></th><td><span class="amat-status amat-status-<?php echo esc_attr( $estimate['status'] ); ?>"><?php echo esc_html( AMAT_Estimate_Model::status_label( $estimate['status'] ) ); ?></span></td></tr>
					<tr><th><?php esc_html_e( 'Vehicle', 'auto-mation' ); ?></th><td><?php echo esc_html( $vehicle ? AMAT_Vehicle_Model::label( $vehicle ) : '—' ); ?></td></tr>
					<tr><th><?php esc_html_e( 'Issue date', 'auto-mation' ); ?></th><td><?php echo esc_html( self::date_display( $estimate['issue_date'] ?? '' ) ?: '—' ); ?></td></tr>
					<tr><th><?php esc_html_e( 'Valid until', 'auto-mation' ); ?></th><td><?php echo esc_html( self::date_display( $estimate['valid_until'] ?? '' ) ?: '—' ); ?></td></tr>
				</tbody>
			</table>

			<h2><?php esc_html_e( 'Line items', 'auto-mation' ); ?></h2>
			<?php $this->render_items_table( $items ); ?>

			<h2><?php esc_html_e( 'Notes', 'auto-mation' ); ?></h2>
			<p><?php echo '' !== $notes ? nl2br( esc_html( $notes ) ) : '<span class="description">' . esc_html__( 'No notes.', 'auto-mation' ) . '</span>'; ?></p>

			<h2><?php esc_html_e( 'Invoice', 'auto-mation' ); ?></h2>
			<?php $linked_invoice = AMAT_Invoice_Model::for_estimate( $id ); ?>
			<?php if ( $linked_invoice ) : ?>
				<?php
				$inv_url = add_query_arg(
					array( 'page' => AMAT_Invoices_Page::PAGE_SLUG, 'action' => 'view', 'id' => (int) $linked_invoice['id'] ),
					admin_url( 'admin.php' )
				);
				?>
				<p>
					<?php esc_html_e( 'Converted to', 'auto-mation' ); ?>
					<a href="<?php echo esc_url( $inv_url ); ?>"><?php echo esc_html( AMAT_Invoices_Page::label( $linked_invoice ) ); ?></a>.
				</p>
			<?php elseif ( $job_edit ) : ?>
				<p class="description"><?php esc_html_e( 'Not converted yet. Open the job to convert this estimate to an invoice.', 'auto-mation' ); ?></p>
			<?php else : ?>
				<p class="description"><?php esc_html_e( 'Not converted yet.', 'auto-mation' ); ?></p>
			<?php endif; ?>

			<?php
			/**
			 * Let a provider integration (e.g. Wave) add actions to the estimate
			 * detail — "Push to Wave", sync status, etc. Core ships no default.
			 *
			 * @param array<string,mixed> $estimate Estimate row.
			 */
			do_action( 'amat_estimate_detail_actions', $estimate );
			?>
		</div>
		<?php
	}

	/**
	 * Render a read-only line-items table with computed amounts + total.
	 *
	 * @param array<int,array<string,mixed>> $items Line item rows.
	 * @return void
	 */
	private function render_items_table( array $items ) {
		if ( empty( $items ) ) {
			echo '<p class="description">' . esc_html__( 'No line items.', 'auto-mation' ) . '</p>';
			return;
		}
		$total = 0.0;
		?>
		<table class="wp-list-table widefat fixed striped amat-items-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Description', 'auto-mation' ); ?></th>
					<th class="amat-col-num"><?php esc_html_e( 'Qty', 'auto-mation' ); ?></th>
					<th class="amat-col-num"><?php esc_html_e( 'Unit price', 'auto-mation' ); ?></th>
					<th class="amat-col-num"><?php esc_html_e( 'Amount', 'auto-mation' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $items as $item ) : ?>
					<?php
					$amount = AMAT_Estimate_Item_Model::line_amount( $item );
					$total += $amount;
					?>
					<tr>
						<td><?php echo esc_html( $item['description'] ); ?></td>
						<td class="amat-col-num"><?php echo esc_html( rtrim( rtrim( number_format( (float) $item['quantity'], 2 ), '0' ), '.' ) ); ?></td>
						<td class="amat-col-num"><?php echo esc_html( AMAT_Money::format( $item['unit_price'] ?? null ) ?: '—' ); ?></td>
						<td class="amat-col-num"><?php echo esc_html( AMAT_Money::format_amount( $amount ) ); ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
			<tfoot>
				<tr>
					<th colspan="3" class="amat-col-num"><?php esc_html_e( 'Total', 'auto-mation' ); ?></th>
					<th class="amat-col-num"><?php echo esc_html( AMAT_Money::format_amount( $total ) ); ?></th>
				</tr>
			</tfoot>
		</table>
		<?php
	}

	/**
	 * Echo the line-items repeater (rows of description/qty/price + a catalog
	 * search that appends pre-filled rows). Uses classes (not ids) so several
	 * instances can coexist on one page — e.g. one per estimate/invoice in the
	 * job edit page's manager. Driven by initLineItems() in admin.js, which wires
	 * each `.amat-line-items` container independently.
	 *
	 * @param array<int,array<string,mixed>> $items Existing line rows.
	 * @return void
	 */
	public static function render_items_field( array $items ) {
		?>
		<div class="amat-line-items">
			<div class="amat-li-head">
				<span class="amat-li-h-type"><?php esc_html_e( 'Type', 'auto-mation' ); ?></span>
				<span class="amat-li-h-desc"><?php esc_html_e( 'Description', 'auto-mation' ); ?></span>
				<span class="amat-li-h-qty"><?php esc_html_e( 'Qty', 'auto-mation' ); ?></span>
				<span class="amat-li-h-price"><?php esc_html_e( 'Price', 'auto-mation' ); ?></span>
				<span class="amat-li-h-actions"></span>
			</div>
			<div class="amat-li-rows">
				<?php
				if ( empty( $items ) ) :
					// Start with one blank line (§ line-item redesign).
					echo self::item_row_html( array() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped internally.
				else :
					foreach ( $items as $item ) :
						echo self::item_row_html( $item ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped internally.
					endforeach;
				endif;
				?>
			</div>
			<?php echo self::item_row_html( array(), true ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped internally. ?>
			<p><button type="button" class="button amat-li-add"><?php esc_html_e( 'Add line', 'auto-mation' ); ?></button></p>
		</div>
		<?php
	}

	/**
	 * The line-item source types (a line is always one of these; a not-in-catalog
	 * line is simply one with source_id 0). Retired the old free-text 'custom'.
	 *
	 * @return array<string,string> slug => label.
	 */
	public static function line_types() {
		return array(
			'service' => __( 'Service', 'auto-mation' ),
			'part'    => __( 'Part', 'auto-mation' ),
		);
	}

	/**
	 * One line-item row. Each row is self-contained: a Service/Part type selector,
	 * a description that doubles as the catalog type-ahead (search both catalogs;
	 * picking a result links it and sets the type), qty, price, a save-to-catalog
	 * star (deferred — persisted on form save), and remove. Hidden template inputs
	 * are disabled so they never submit; the six item_* arrays stay index-aligned.
	 *
	 * @param array<string,mixed> $item        Row values.
	 * @param bool                $is_template Whether this is the JS clone template.
	 * @return string Escaped HTML.
	 */
	private static function item_row_html( array $item = array(), $is_template = false ) {
		$desc  = (string) ( $item['description'] ?? '' );
		$qty   = isset( $item['quantity'] ) ? rtrim( rtrim( number_format( (float) $item['quantity'], 2 ), '0' ), '.' ) : '1';
		$price = ( null === ( $item['unit_price'] ?? null ) || '' === ( $item['unit_price'] ?? '' ) ) ? '' : (string) $item['unit_price'];
		$stype = (string) ( $item['source_type'] ?? 'service' );
		if ( ! isset( self::line_types()[ $stype ] ) ) {
			$stype = 'service';
		}
		$sid   = (int) ( $item['source_id'] ?? 0 );
		$save  = ! empty( $item['save_catalog'] );
		$d     = $is_template ? ' disabled' : '';
		$cls   = $is_template ? 'amat-li-row amat-li-template' : 'amat-li-row';
		$style = $is_template ? ' style="display:none;"' : '';

		ob_start();
		?>
		<div class="<?php echo esc_attr( $cls ); ?>"<?php echo $style; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static. ?>>
			<select class="amat-li-type" name="item_source_type[]"<?php echo $d; // phpcs:ignore ?>>
				<?php foreach ( self::line_types() as $slug => $label ) : ?>
					<option value="<?php echo esc_attr( $slug ); ?>" <?php selected( $slug, $stype ); ?>><?php echo esc_html( $label ); ?></option>
				<?php endforeach; ?>
			</select>
			<input type="hidden" name="item_source_id[]" value="<?php echo esc_attr( $sid ); ?>"<?php echo $d; // phpcs:ignore ?> />
			<div class="amat-li-desc-wrap">
				<input type="text" class="amat-li-desc" name="item_desc[]" autocomplete="off" value="<?php echo esc_attr( $desc ); ?>" placeholder="<?php esc_attr_e( 'Type to search or enter a description…', 'auto-mation' ); ?>"<?php echo $d; // phpcs:ignore ?> />
				<div class="amat-li-results amat-search-results"></div>
			</div>
			<input type="number" class="amat-li-qty" name="item_qty[]" step="0.01" min="0" value="<?php echo esc_attr( $qty ); ?>"<?php echo $d; // phpcs:ignore ?> />
			<input type="number" class="amat-li-price" name="item_price[]" step="0.01" min="0" value="<?php echo esc_attr( $price ); ?>" placeholder="0.00"<?php echo $d; // phpcs:ignore ?> />
			<input type="hidden" class="amat-li-save-flag" name="item_save_catalog[]" value="<?php echo $save ? '1' : '0'; ?>"<?php echo $d; // phpcs:ignore ?> />
			<button type="button" class="button-link amat-li-save <?php echo $save ? 'is-on' : ''; ?>" aria-pressed="<?php echo $save ? 'true' : 'false'; ?>" title="<?php esc_attr_e( 'Save to catalog for reuse', 'auto-mation' ); ?>" aria-label="<?php esc_attr_e( 'Save to catalog for reuse', 'auto-mation' ); ?>"><span class="dashicons <?php echo $save ? 'dashicons-star-filled' : 'dashicons-star-empty'; ?>"></span></button>
			<button type="button" class="button-link amat-li-remove" aria-label="<?php esc_attr_e( 'Remove', 'auto-mation' ); ?>">&times;</button>
		</div>
		<?php
		return ob_get_clean();
	}

	/* --------------------------------------------------------------------- */
	/* Save                                                                  */
	/* --------------------------------------------------------------------- */

	/**
	 * Validate and persist the submitted estimate.
	 *
	 * @return array{status:string,message:string,data?:array,editing_id?:int}
	 */
	protected function save() {
		check_admin_referer( self::NONCE_ACTION );
		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			return array( 'status' => 'error', 'message' => __( 'You are not allowed to save estimates.', 'auto-mation' ), 'data' => array(), 'editing_id' => 0 );
		}

		$id              = isset( $_POST['estimate_id'] ) ? absint( $_POST['estimate_id'] ) : 0;
		$return_customer = isset( $_POST['return_customer'] ) ? absint( $_POST['return_customer'] ) : 0;
		$status          = isset( $_POST['status'] ) ? sanitize_key( wp_unslash( $_POST['status'] ) ) : 'draft';
		$rows            = self::collect_item_rows();

		$data = array(
			'customer_id'     => isset( $_POST['customer_id'] ) ? absint( $_POST['customer_id'] ) : 0,
			'return_customer' => $return_customer,
			'vehicle_id'      => isset( $_POST['vehicle_id'] ) ? absint( $_POST['vehicle_id'] ) : 0,
			'status'          => in_array( $status, AMAT_Estimate_Model::STATUSES, true ) ? $status : 'draft',
			'number'          => sanitize_text_field( wp_unslash( $_POST['number'] ?? '' ) ),
			'issue_date'      => sanitize_text_field( wp_unslash( $_POST['issue_date'] ?? '' ) ),
			'valid_until'     => sanitize_text_field( wp_unslash( $_POST['valid_until'] ?? '' ) ),
			'notes'           => sanitize_textarea_field( wp_unslash( $_POST['notes'] ?? '' ) ),
			'_items'          => $rows,
		);

		if ( ! $data['customer_id'] ) {
			return array( 'status' => 'error', 'message' => __( 'Please choose a customer for this estimate.', 'auto-mation' ), 'data' => $data, 'editing_id' => $id );
		}

		if ( $id ) {
			AMAT_Estimate_Model::update( $id, $data );
		} else {
			$id = AMAT_Estimate_Model::create( $data );
		}
		if ( ! $id ) {
			return array( 'status' => 'error', 'message' => __( 'Could not save the estimate. Please try again.', 'auto-mation' ), 'data' => $data, 'editing_id' => 0 );
		}

		AMAT_Estimate_Item_Model::replace_for_parent( $id, self::persist_catalog_flags( $rows ) );

		$success = array( 'status' => 'success', 'message' => __( 'Estimate saved.', 'auto-mation' ) );
		if ( $return_customer ) {
			$success['redirect'] = add_query_arg( array( 'page' => AMAT_Customers_Page::PAGE_SLUG, 'action' => 'view', 'id' => $return_customer ), admin_url( 'admin.php' ) );
		} else {
			$success['redirect'] = $this->list_url( array( 'action' => 'view', 'id' => (int) $id ) );
		}
		return $success;
	}

	/**
	 * Zip the parallel item_* POST arrays into row arrays (blank rows dropped by
	 * the item model on replace). Shared by the Invoices page too.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public static function collect_item_rows() {
		$descs  = isset( $_POST['item_desc'] ) ? (array) wp_unslash( $_POST['item_desc'] ) : array(); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce checked by caller's save().
		$qtys   = isset( $_POST['item_qty'] ) ? (array) wp_unslash( $_POST['item_qty'] ) : array(); // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$prices = isset( $_POST['item_price'] ) ? (array) wp_unslash( $_POST['item_price'] ) : array(); // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$stypes = isset( $_POST['item_source_type'] ) ? (array) wp_unslash( $_POST['item_source_type'] ) : array(); // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$sids   = isset( $_POST['item_source_id'] ) ? (array) wp_unslash( $_POST['item_source_id'] ) : array(); // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$saves  = isset( $_POST['item_save_catalog'] ) ? (array) wp_unslash( $_POST['item_save_catalog'] ) : array(); // phpcs:ignore WordPress.Security.NonceVerification.Missing

		$rows = array();
		foreach ( $descs as $i => $desc ) {
			$stype = isset( $stypes[ $i ] ) ? sanitize_key( (string) $stypes[ $i ] ) : 'service';
			$rows[] = array(
				'description'  => sanitize_text_field( (string) $desc ),
				'quantity'     => isset( $qtys[ $i ] ) ? (float) $qtys[ $i ] : 1,
				'unit_price'   => ( isset( $prices[ $i ] ) && '' !== trim( (string) $prices[ $i ] ) ) ? (string) $prices[ $i ] : null,
				'source_type'  => isset( self::line_types()[ $stype ] ) ? $stype : 'service',
				'source_id'    => isset( $sids[ $i ] ) ? absint( $sids[ $i ] ) : 0,
				'save_catalog' => ! empty( $saves[ $i ] ) && '0' !== (string) $saves[ $i ],
			);
		}
		return $rows;
	}

	/**
	 * Persist any lines flagged "save to catalog" into the services/parts tables
	 * (deferred — run once on form save, by every page that saves line items).
	 *
	 * For each flagged line with no catalog link (source_id 0) and a non-empty
	 * name: adopt an existing active catalog item of the same name (case-
	 * insensitive) rather than duplicate it, else create a new one; either way the
	 * line's source_id is set so it's linked going forward. The transient
	 * `save_catalog` key is stripped from every row so the line-item model only
	 * ever sees storable columns.
	 *
	 * @param array<int,array<string,mixed>> $rows Rows from collect_item_rows().
	 * @return array<int,array<string,mixed>> Rows with source_id resolved, save flag removed.
	 */
	public static function persist_catalog_flags( array $rows ) {
		foreach ( $rows as &$row ) {
			$flagged = ! empty( $row['save_catalog'] );
			unset( $row['save_catalog'] );

			$name = trim( (string) ( $row['description'] ?? '' ) );
			if ( ! $flagged || (int) ( $row['source_id'] ?? 0 ) > 0 || '' === $name ) {
				continue;
			}

			$model = ( 'part' === ( $row['source_type'] ?? 'service' ) ) ? 'AMAT_Part_Model' : 'AMAT_Service_Model';

			$existing = 0;
			foreach ( $model::active() as $cat ) {
				if ( 0 === strcasecmp( trim( (string) $cat['name'] ), $name ) ) {
					$existing = (int) $cat['id'];
					break;
				}
			}

			if ( $existing ) {
				$row['source_id'] = $existing;
				continue;
			}

			$new_id = $model::create(
				array(
					'name'             => $name,
					'default_price'    => $row['unit_price'] ?? null,
					'default_quantity' => $row['quantity'] ?? null,
					'is_active'        => 1,
					'sort_order'       => 0,
				)
			);
			if ( $new_id ) {
				$row['source_id'] = (int) $new_id;
			}
		}
		unset( $row );

		return $rows;
	}

	/* --------------------------------------------------------------------- */
	/* Shared helpers + AJAX                                                  */
	/* --------------------------------------------------------------------- */

	/**
	 * Display label for an estimate: its number, else "#ID".
	 *
	 * @param array<string,mixed> $estimate Estimate row.
	 * @return string
	 */
	public static function label( array $estimate ) {
		$number = trim( (string) ( $estimate['number'] ?? '' ) );
		/* translators: %d: estimate id. */
		return '' !== $number ? $number : sprintf( __( 'Estimate #%d', 'auto-mation' ), (int) $estimate['id'] );
	}

	/**
	 * Format a stored date ('Y-m-d') for display, or '' when empty/zero.
	 *
	 * @param string $value Stored date.
	 * @return string
	 */
	public static function date_display( $value ) {
		$value = trim( (string) $value );
		if ( '' === $value || 0 === strpos( $value, '0000' ) ) {
			return '';
		}
		$d = date_create( $value );
		return $d ? $d->format( 'M j, Y' ) : '';
	}

	/**
	 * AJAX: search the Services + Parts catalogs for the line-item picker.
	 *
	 * Registered on wp_ajax_amat_search_catalog. Returns up to 20 matches as
	 * { label, description, price, source_type, source_id }.
	 *
	 * @return void
	 */
	public static function ajax_search_catalog() {
		check_ajax_referer( self::CATALOG_NONCE, 'nonce' );
		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			wp_send_json_error( array( 'message' => __( 'Not allowed.', 'auto-mation' ) ), 403 );
		}

		$term = isset( $_POST['term'] ) ? sanitize_text_field( wp_unslash( $_POST['term'] ) ) : '';
		$out  = array();

		foreach ( AMAT_Service_Model::active() as $s ) {
			if ( '' !== $term && false === stripos( (string) $s['name'], $term ) ) {
				continue;
			}
			$out[] = self::catalog_row( 'service', $s );
		}
		foreach ( AMAT_Part_Model::active() as $p ) {
			if ( '' !== $term && false === stripos( (string) $p['name'], $term ) ) {
				continue;
			}
			$out[] = self::catalog_row( 'part', $p );
		}

		wp_send_json_success( array_slice( $out, 0, 20 ) );
	}

	/**
	 * Shape one catalog row (service/part) for the AJAX picker.
	 *
	 * @param string              $type Source type ('service'|'part').
	 * @param array<string,mixed> $row  Catalog row.
	 * @return array<string,mixed>
	 */
	private static function catalog_row( $type, array $row ) {
		$price = ( null === ( $row['default_price'] ?? null ) || '' === ( $row['default_price'] ?? '' ) ) ? '' : (string) $row['default_price'];
		$qty   = AMAT_Money::quantity( $row['default_quantity'] ?? null );
		$label = (string) $row['name'] . ( '' !== $price ? ' (' . AMAT_Money::format( $price ) . ')' : '' );
		return array(
			'label'       => $label,
			'description' => (string) $row['name'],
			'price'       => $price,
			'quantity'    => '' !== $qty ? $qty : '1',
			'source_type' => $type,
			'source_id'   => (int) $row['id'],
		);
	}
}
