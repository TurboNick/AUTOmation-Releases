<?php
/**
 * Customers admin page: list/search, add, and edit customers and their
 * ordered contact methods.
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Renders the Customers list (with search + clickable rows) and the
 * add/edit form (identity, notes, and a drag-orderable contact-methods
 * repeater).
 *
 * Security pattern (§5): nonce on the form, capability check before any
 * write, sanitize on input (models + the contact-type registry), escape on
 * output here.
 */
class AMAT_Customers_Page extends AMAT_Admin_Page {

	/**
	 * Nonce action name for the save form.
	 *
	 * @var string
	 */
	const NONCE_ACTION = 'amat_save_customer';

	/**
	 * Admin page slug.
	 *
	 * @var string
	 */
	const PAGE_SLUG = 'amat-customers';

	/**
	 * Hidden `amat_action` value identifying this page's save POST.
	 *
	 * @var string
	 */
	const POST_ACTION = 'save_customer';

	/**
	 * Customers support enable/disable (soft delete). Unlike vehicles/locations
	 * (toggled only from the customer edit view), the customer toggle lives on
	 * the grid itself — a customer is the top-level entity, not a sub-item.
	 *
	 * @return string
	 */
	protected static function active_model() {
		return 'AMAT_Customer_Model';
	}

	/**
	 * Cascade a customer disable down to their vehicles and locations.
	 *
	 * Disabling a customer disables all of their currently-active vehicles and
	 * locations too. Re-enabling the customer does NOT cascade back on — those
	 * sub-items stay disabled and are re-enabled individually (per Nick's call).
	 *
	 * @param int $id     Customer id that was toggled.
	 * @param int $active New active state (1 = enabled, 0 = disabled).
	 * @return void
	 */
	protected function after_active_toggle( $id, $active ) {
		if ( 0 !== (int) $active ) {
			return;
		}
		foreach ( AMAT_Vehicle_Model::for_customer( $id ) as $vehicle ) {
			if ( ! empty( $vehicle['is_active'] ) ) {
				AMAT_Vehicle_Model::update( (int) $vehicle['id'], array( 'is_active' => 0 ) );
			}
		}
		foreach ( AMAT_Location_Model::for_customer( $id ) as $location ) {
			if ( ! empty( $location['is_active'] ) ) {
				AMAT_Location_Model::update( (int) $location['id'], array( 'is_active' => 0 ) );
			}
		}
	}

	/**
	 * Cascade a customer hard-delete to everything they own, so the Dev Tools
	 * per-record delete leaves no orphans: line items → estimates/invoices, jobs'
	 * parts orders + service records, vehicles' service records, then the customer's
	 * contact methods/locations/vehicles/jobs/estimates/invoices. (The customer row
	 * itself was already deleted by the base handler before this runs.)
	 *
	 * @param int $id Deleted customer id.
	 * @return void
	 */
	protected function after_delete( $id ) {
		global $wpdb;
		$p  = $wpdb->prefix . 'amat_';
		$id = (int) $id;

		$est_ids = $wpdb->get_col( $wpdb->prepare( "SELECT id FROM {$p}estimates WHERE customer_id = %d", $id ) ); // phpcs:ignore WordPress.DB
		foreach ( $est_ids as $eid ) {
			$wpdb->delete( $p . 'estimate_items', array( 'estimate_id' => (int) $eid ) );
		}
		$inv_ids = $wpdb->get_col( $wpdb->prepare( "SELECT id FROM {$p}invoices WHERE customer_id = %d", $id ) ); // phpcs:ignore WordPress.DB
		foreach ( $inv_ids as $iid ) {
			$wpdb->delete( $p . 'invoice_items', array( 'invoice_id' => (int) $iid ) );
		}

		$job_ids = $wpdb->get_col( $wpdb->prepare( "SELECT id FROM {$p}jobs WHERE customer_id = %d", $id ) ); // phpcs:ignore WordPress.DB
		foreach ( $job_ids as $jid ) {
			$wpdb->delete( $p . 'parts_orders', array( 'job_id' => (int) $jid ) );
			$wpdb->delete( $p . 'service_records', array( 'job_id' => (int) $jid ) );
		}

		$veh_ids = $wpdb->get_col( $wpdb->prepare( "SELECT id FROM {$p}vehicles WHERE customer_id = %d", $id ) ); // phpcs:ignore WordPress.DB
		foreach ( $veh_ids as $vid ) {
			$wpdb->delete( $p . 'service_records', array( 'vehicle_id' => (int) $vid ) );
		}

		foreach ( array( 'contact_methods', 'locations', 'vehicles', 'jobs', 'estimates', 'invoices' ) as $table ) {
			$wpdb->delete( $p . $table, array( 'customer_id' => $id ) );
		}
	}

	/**
	 * Render the page: show any flashed notice, then route to list or form.
	 *
	 * The save itself runs earlier on `admin_init` (see save() via the base
	 * class) and redirects here, so this method only ever handles a GET.
	 *
	 * @return void
	 */
	public function render() {
		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'auto-mation' ) );
		}

		$flash  = $this->take_flash();
		$action = isset( $_GET['action'] ) ? sanitize_key( wp_unslash( $_GET['action'] ) ) : '';

		if ( 'view' === $action ) {
			$this->render_detail_route( $flash );
			return;
		}

		if ( 'new' === $action || 'edit' === $action ) {
			$this->render_form_route( $action, $flash );
			return;
		}

		// List view, with any flashed success/error notice.
		$success = ( $flash && 'success' === $flash['status'] ) ? $flash['message'] : '';
		$error   = ( $flash && 'error' === $flash['status'] ) ? $flash['message'] : '';
		$this->render_list( $success, $error );
	}

	/**
	 * Route a read-only detail request, showing any flashed notice (e.g. after
	 * a vehicle/location was saved from within this customer).
	 *
	 * @param array<string,mixed>|null $flash Flash payload from a prior save.
	 * @return void
	 */
	private function render_detail_route( $flash ) {
		$id       = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0;
		$customer = $id ? AMAT_Customer_Model::find( $id ) : null;
		if ( ! $customer ) {
			$this->render_list( '', __( 'Customer not found.', 'auto-mation' ) );
			return;
		}
		$success = ( $flash && 'success' === $flash['status'] ) ? $flash['message'] : '';
		$error   = ( $flash && 'error' === $flash['status'] ) ? $flash['message'] : '';
		$this->render_detail( $customer, $success, $error );
	}

	/**
	 * Route an add/edit request to the form, preferring flashed input from a
	 * failed save over the stored record.
	 *
	 * @param string                   $action 'new' or 'edit'.
	 * @param array<string,mixed>|null $flash  Flash payload from a prior save.
	 * @return void
	 */
	private function render_form_route( $action, $flash ) {
		// A failed save flashes the submitted values — re-render with those.
		if ( $flash && 'error' === $flash['status'] ) {
			$this->render_form( $flash['data'], $flash['methods'], $flash['editing_id'], $flash['message'] );
			return;
		}

		if ( 'new' === $action ) {
			$this->render_form( array(), array(), 0 );
			return;
		}

		$id       = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0;
		$customer = $id ? AMAT_Customer_Model::find( $id ) : null;
		if ( ! $customer ) {
			$this->render_list( '', __( 'Customer not found.', 'auto-mation' ) );
			return;
		}
		$methods = AMAT_Contact_Method_Model::for_customer( $id );
		// A success flash (e.g. after disabling a vehicle/location from this form)
		// is shown atop the still-unlocked edit screen.
		$success = ( $flash && 'success' === $flash['status'] ) ? $flash['message'] : '';
		$this->render_form( $customer, $methods, $id, '', $success );
	}

	/* --------------------------------------------------------------------- */
	/* List view                                                             */
	/* --------------------------------------------------------------------- */

	/**
	 * Render the searchable customers list.
	 *
	 * @param string $success Optional success notice.
	 * @param string $error   Optional error notice.
	 * @return void
	 */
	private function render_list( $success = '', $error = '' ) {
		$term          = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
		$show_disabled = $this->read_show_disabled();
		$customers     = '' !== $term
			? AMAT_Customer_Model::search( $term )
			: AMAT_Customer_Model::all( array(), array( 'orderby' => 'last_name', 'order' => 'ASC' ) );

		// The toggle is exclusive: active rows, or disabled rows, never both.
		$customers = $this->filter_active_rows( $customers, $show_disabled );

		// Where the per-row toggle returns to: this list, keeping search + toggle.
		$return_url = $this->list_url( array_filter( array( 's' => $term, 'show_disabled' => $show_disabled ? '1' : '' ) ) );

		$new_url = add_query_arg(
			array( 'page' => self::PAGE_SLUG, 'action' => 'new' ),
			admin_url( 'admin.php' )
		);
		?>
		<div class="wrap">
			<h1 class="wp-heading-inline"><?php esc_html_e( 'Customers', 'auto-mation' ); ?></h1>
			<hr class="wp-header-end" />

			<?php if ( $success ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php echo esc_html( $success ); ?></p></div>
			<?php endif; ?>
			<?php if ( $error ) : ?>
				<div class="notice notice-error is-dismissible"><p><?php echo esc_html( $error ); ?></p></div>
			<?php endif; ?>

			<div class="amat-list-bar">
				<a href="<?php echo esc_url( $new_url ); ?>" class="button amat-btn-primary amat-add-inline"><?php esc_html_e( 'Add customer', 'auto-mation' ); ?></a>
				<form method="get" class="amat-search-form">
					<input type="hidden" name="page" value="<?php echo esc_attr( self::PAGE_SLUG ); ?>" />
					<label class="screen-reader-text" for="amat-customer-search"><?php esc_html_e( 'Search customers', 'auto-mation' ); ?></label>
					<input type="search" id="amat-customer-search" name="s" value="<?php echo esc_attr( $term ); ?>" placeholder="<?php esc_attr_e( 'Name, phone, or email', 'auto-mation' ); ?>" />
					<label class="amat-show-disabled"><input type="checkbox" name="show_disabled" value="1" <?php checked( $show_disabled ); ?> /> <?php esc_html_e( 'Show disabled only', 'auto-mation' ); ?></label>
					<?php submit_button( __( 'Search', 'auto-mation' ), '', '', false ); ?>
				</form>
			</div>

			<table class="wp-list-table widefat fixed striped">
				<thead>
					<tr>
						<th><?php esc_html_e( 'First', 'auto-mation' ); ?></th>
						<th><?php esc_html_e( 'Last', 'auto-mation' ); ?></th>
						<th><?php esc_html_e( 'Display name', 'auto-mation' ); ?></th>
						<th><?php esc_html_e( 'Primary contact', 'auto-mation' ); ?></th>
						<th class="amat-col-actions"></th>
					</tr>
				</thead>
				<tbody>
					<?php if ( empty( $customers ) ) : ?>
						<tr><td colspan="5"><?php
							if ( '' !== $term ) {
								echo $show_disabled ? esc_html__( 'No matching disabled customers.', 'auto-mation' ) : esc_html__( 'No matching customers.', 'auto-mation' );
							} else {
								echo $show_disabled ? esc_html__( 'No disabled customers.', 'auto-mation' ) : esc_html__( 'No customers yet.', 'auto-mation' );
							}
							?></td></tr>
					<?php else : ?>
						<?php foreach ( $customers as $customer ) : ?>
							<?php
							$view_url = add_query_arg(
								array( 'page' => self::PAGE_SLUG, 'action' => 'view', 'id' => (int) $customer['id'] ),
								admin_url( 'admin.php' )
							);
							$primary = AMAT_Contact_Method_Model::primary_for_customer( (int) $customer['id'] );
							if ( $primary ) {
								$p_type  = (string) $primary['type'];
								$p_label = AMAT_Contact_Method_Types::label( $p_type );
								$p_show  = AMAT_Contact_Method_Types::format( $p_type, $primary['value'] );
								$p_href  = AMAT_Contact_Method_Types::href( $p_type, $primary['value'] );
								$contact = $p_href
									? esc_html( $p_label ) . ': <a href="' . esc_url( $p_href ) . '" target="_blank" rel="noopener noreferrer">' . esc_html( $p_show ) . '</a>'
									: esc_html( $p_label . ': ' . $p_show );
							} else {
								$contact = '&mdash;';
							}
								$disabled = empty( $customer['is_active'] );
								$edit_url = add_query_arg(
									array( 'page' => self::PAGE_SLUG, 'action' => 'edit', 'id' => (int) $customer['id'] ),
									admin_url( 'admin.php' )
								);
								?>
							<tr class="amat-clickable-row <?php echo $disabled ? 'amat-row-disabled' : ''; ?>" data-href="<?php echo esc_url( $view_url ); ?>">
								<td><?php echo esc_html( $customer['first_name'] ); ?></td>
								<td><?php echo esc_html( $customer['last_name'] ); ?></td>
								<td>
									<a href="<?php echo esc_url( $view_url ); ?>"><?php echo $this->display_name_markup( $customer ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped internally. ?></a>
									<?php if ( $disabled ) : ?><span class="amat-badge amat-badge-off"><?php esc_html_e( 'disabled', 'auto-mation' ); ?></span><?php endif; ?>
								</td>
								<td><?php echo $contact; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- assembled from esc_html()/esc_url() parts above. ?></td>
								<td class="amat-col-actions">
									<div class="amat-row-actions">
										<a href="<?php echo esc_url( $edit_url ); ?>" class="button"><?php esc_html_e( 'Edit', 'auto-mation' ); ?></a>
										<?php
										echo $this->active_toggle_button( self::POST_ACTION, self::NONCE_ACTION, (int) $customer['id'], ! $disabled, $return_url ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built with esc_* internally.
										echo $this->delete_button( self::POST_ACTION, self::NONCE_ACTION, (int) $customer['id'], $return_url ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built with esc_* internally.
										?>
									</div>
								</td>
							</tr>
						<?php endforeach; ?>
					<?php endif; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	/**
	 * Render a customer's display name, flagging an auto-generated one.
	 *
	 * When the name is the computed "First Last" (no custom display_name stored),
	 * it's shown grey + italic with an "(Auto)" suffix so it's clear at a glance
	 * the name isn't a customized one; a custom name renders plainly. Returns
	 * escaped HTML.
	 *
	 * @param array<string,mixed> $customer Customer row.
	 * @return string Escaped HTML.
	 */
	private function display_name_markup( array $customer ) {
		$name = AMAT_Customer_Model::display_name( $customer );
		if ( ! AMAT_Customer_Model::is_display_name_auto( $customer ) ) {
			return esc_html( $name );
		}
		return '<span class="amat-name-auto">' . esc_html( $name ) . ' '
			. esc_html__( '(Auto)', 'auto-mation' ) . '</span>';
	}

	/* --------------------------------------------------------------------- */
	/* Read-only detail view                                                 */
	/* --------------------------------------------------------------------- */

	/**
	 * Render the read-only customer detail: identity, contact methods, notes,
	 * and the customer's locations and vehicles. Has no form inputs — the only
	 * control is an Edit button — so it can't be edited or pop a keyboard by
	 * accident while scrolling on a phone (the requested "locked" view).
	 *
	 * @param array<string,mixed> $customer Customer row.
	 * @param string              $success  Optional success notice.
	 * @param string              $error    Optional error notice.
	 * @return void
	 */
	private function render_detail( array $customer, $success = '', $error = '' ) {
		$id        = (int) $customer['id'];
		$name      = AMAT_Customer_Model::display_name( $customer );
		$notes     = trim( (string) ( $customer['notes'] ?? '' ) );
		$methods   = AMAT_Contact_Method_Model::for_customer( $id );
		$locations = AMAT_Location_Model::for_customer( $id );
		$vehicles  = AMAT_Vehicle_Model::for_customer( $id );
		$edit_url    = $this->list_url( array( 'action' => 'edit', 'id' => $id ) );
		$list_url    = $this->list_url();
		$add_job_url = add_query_arg(
			array( 'page' => AMAT_Jobs_Page::PAGE_SLUG, 'action' => 'new', 'return_customer' => $id ),
			admin_url( 'admin.php' )
		);
		?>
		<div class="wrap amat-detail">
			<h1><?php echo esc_html( $name ); ?></h1>
			<p class="amat-detail-actions">
				<a href="<?php echo esc_url( $add_job_url ); ?>" class="button amat-btn-primary"><?php esc_html_e( 'Add job', 'auto-mation' ); ?></a>
				<a href="<?php echo esc_url( $edit_url ); ?>" class="button amat-btn-primary"><?php esc_html_e( 'Edit', 'auto-mation' ); ?></a>
				<a href="<?php echo esc_url( $list_url ); ?>" class="button amat-btn-secondary"><?php esc_html_e( 'Back to customers', 'auto-mation' ); ?></a>
			</p>
			<hr class="wp-header-end" />

			<?php if ( $success ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php echo esc_html( $success ); ?></p></div>
			<?php endif; ?>
			<?php if ( $error ) : ?>
				<div class="notice notice-error is-dismissible"><p><?php echo esc_html( $error ); ?></p></div>
			<?php endif; ?>

			<p class="description"><?php esc_html_e( 'Read-only. Tap Edit to change details or to add and manage vehicles and locations.', 'auto-mation' ); ?></p>

			<h2><?php esc_html_e( 'Contact', 'auto-mation' ); ?></h2>
			<table class="amat-detail-table">
				<tbody>
					<tr>
						<th><?php esc_html_e( 'Name', 'auto-mation' ); ?></th>
						<td><?php echo esc_html( trim( (string) $customer['first_name'] . ' ' . (string) $customer['last_name'] ) ); ?></td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Display name', 'auto-mation' ); ?></th>
						<td><?php echo $this->display_name_markup( $customer ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped internally. ?></td>
					</tr>
					<?php $referred_by = AMAT_Customer_Model::referred_by_label( $customer ); ?>
					<?php if ( '' !== $referred_by ) : ?>
						<tr>
							<th><?php esc_html_e( 'Referred by', 'auto-mation' ); ?></th>
							<td>
								<?php
								$ref_cid = (int) ( $customer['referred_by_customer_id'] ?? 0 );
								if ( $ref_cid ) :
									$ref_url = $this->list_url( array( 'action' => 'view', 'id' => $ref_cid ) );
									?>
									<a href="<?php echo esc_url( $ref_url ); ?>"><?php echo esc_html( $referred_by ); ?></a>
								<?php else : ?>
									<?php echo esc_html( $referred_by ); ?>
								<?php endif; ?>
							</td>
						</tr>
					<?php endif; ?>
					<?php if ( empty( $methods ) ) : ?>
						<tr>
							<th><?php esc_html_e( 'Contact methods', 'auto-mation' ); ?></th>
							<td><span class="description"><?php esc_html_e( 'None on file.', 'auto-mation' ); ?></span></td>
						</tr>
					<?php else : ?>
						<?php foreach ( $methods as $i => $m ) : ?>
							<?php
							$type  = (string) ( $m['type'] ?? '' );
							$label = AMAT_Contact_Method_Types::label( $type );
							$show  = AMAT_Contact_Method_Types::format( $type, (string) ( $m['value'] ?? '' ) );
							$href  = AMAT_Contact_Method_Types::href( $type, (string) ( $m['value'] ?? '' ) );
							?>
							<tr>
								<th>
									<?php echo esc_html( $label ); ?>
									<?php if ( 0 === (int) $i ) : ?><span class="amat-badge"><?php esc_html_e( 'preferred', 'auto-mation' ); ?></span><?php endif; ?>
								</th>
								<td>
									<?php if ( $href ) : ?>
										<a href="<?php echo esc_url( $href ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $show ); ?></a>
									<?php else : ?>
										<?php echo esc_html( $show ); ?>
									<?php endif; ?>
								</td>
							</tr>
						<?php endforeach; ?>
					<?php endif; ?>
				</tbody>
			</table>

			<h2><?php esc_html_e( 'Notes (Internal)', 'auto-mation' ); ?></h2>
			<p><?php echo '' !== $notes ? nl2br( esc_html( $notes ) ) : '<span class="description">' . esc_html__( 'No notes.', 'auto-mation' ) . '</span>'; ?></p>

			<?php
			$this->locations_block( $locations, $id, false );
			$this->vehicles_block( $vehicles, $id, false );
			$this->jobs_block( AMAT_Job_Model::for_customer( $id ), $id, false );
			$this->estimates_block( $id );
			$this->invoices_block( $id );

			/**
			 * Let a provider integration (e.g. Wave) render actions on the customer
			 * detail — sync buttons, link status, etc. Core ships no default.
			 *
			 * @param array<string,mixed> $customer Customer row.
			 */
			do_action( 'amat_customer_detail_actions', $customer );
			?>
		</div>
		<?php
	}

	/**
	 * Echo the Locations section for a customer.
	 *
	 * Read-only in the detail view; in the edit ("unlocked") form, $manageable
	 * adds per-row Edit links and an Add button that open the Locations form
	 * scoped to this customer and return here on save.
	 *
	 * @param array<int,array<string,mixed>> $locations  Location rows.
	 * @param int                            $customer_id Owning customer id.
	 * @param bool                           $manageable  Whether to show manage controls.
	 * @return void
	 */
	private function locations_block( array $locations, $customer_id, $manageable ) {
		$add_url = add_query_arg(
			array( 'page' => AMAT_Locations_Page::PAGE_SLUG, 'action' => 'new', 'return_customer' => (int) $customer_id ),
			admin_url( 'admin.php' )
		);
		?>
		<h2 class="amat-section-head">
			<?php esc_html_e( 'Locations', 'auto-mation' ); ?>
			<?php if ( $manageable ) : ?>
				<a href="<?php echo esc_url( $add_url ); ?>" class="button amat-btn-primary"><?php esc_html_e( 'Add location', 'auto-mation' ); ?></a>
			<?php endif; ?>
		</h2>
		<?php if ( empty( $locations ) ) : ?>
			<p class="description"><?php esc_html_e( 'No locations yet.', 'auto-mation' ); ?></p>
		<?php else : ?>
			<?php $return_url = $this->list_url( array( 'action' => 'edit', 'id' => (int) $customer_id ) ); ?>
			<table class="wp-list-table widefat fixed striped amat-grid-locations">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Label', 'auto-mation' ); ?></th>
						<th><?php esc_html_e( 'Address', 'auto-mation' ); ?></th>
						<th><?php esc_html_e( 'Code', 'auto-mation' ); ?></th>
						<th><?php esc_html_e( 'Notes', 'auto-mation' ); ?></th>
						<th class="amat-col-flag"><?php esc_html_e( 'Primary', 'auto-mation' ); ?></th>
						<th class="amat-col-flag"><?php esc_html_e( 'Billing', 'auto-mation' ); ?></th>
						<?php if ( $manageable ) : ?><th class="amat-col-actions"></th><?php endif; ?>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $locations as $location ) : ?>
						<?php $disabled = empty( $location['is_active'] ); ?>
						<tr class="<?php echo $disabled ? 'amat-row-disabled' : ''; ?>">
							<td>
								<?php echo esc_html( '' !== $location['label'] ? $location['label'] : __( '(no label)', 'auto-mation' ) ); ?>
								<?php if ( $disabled ) : ?><span class="amat-badge amat-badge-off"><?php esc_html_e( 'disabled', 'auto-mation' ); ?></span><?php endif; ?>
							</td>
							<td>
								<?php
								$loc_oneline = AMAT_Location_Model::one_line( $location );
								$loc_map     = AMAT_Location_Model::map_url( $location );
								if ( '' === $loc_oneline ) {
									echo '<span class="description">' . esc_html__( 'No address', 'auto-mation' ) . '</span>';
								} elseif ( $loc_map ) {
									echo '<a href="' . esc_url( $loc_map ) . '" target="_blank" rel="noopener noreferrer">' . esc_html( $loc_oneline ) . '</a>';
								} else {
									echo esc_html( $loc_oneline );
								}
								?>
							</td>
							<td><?php echo esc_html( (string) ( $location['code'] ?? '' ) ); ?></td>
							<td><?php echo esc_html( (string) ( $location['notes'] ?? '' ) ); ?></td>
							<td class="amat-col-flag"><?php echo $location['is_primary'] ? '✓' : ''; ?></td>
							<td class="amat-col-flag"><?php echo $location['is_billing'] ? '✓' : ''; ?></td>
							<?php if ( $manageable ) : ?>
								<td class="amat-col-actions">
									<?php
									$edit_loc = add_query_arg(
										array( 'page' => AMAT_Locations_Page::PAGE_SLUG, 'action' => 'edit', 'id' => (int) $location['id'], 'return_customer' => (int) $customer_id ),
										admin_url( 'admin.php' )
									);
									?>
									<div class="amat-row-actions">
										<a href="<?php echo esc_url( $edit_loc ); ?>" class="button"><?php esc_html_e( 'Edit', 'auto-mation' ); ?></a>
										<?php
										echo $this->active_toggle_button( AMAT_Locations_Page::POST_ACTION, AMAT_Locations_Page::NONCE_ACTION, (int) $location['id'], ! $disabled, $return_url ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built with esc_* internally.
										echo $this->delete_button( AMAT_Locations_Page::POST_ACTION, AMAT_Locations_Page::NONCE_ACTION, (int) $location['id'], $return_url ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built with esc_* internally.
										?>
									</div>
								</td>
							<?php endif; ?>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>
		<?php
	}

	/**
	 * Echo the Vehicles section for a customer (read-only or manageable).
	 *
	 * @param array<int,array<string,mixed>> $vehicles    Vehicle rows.
	 * @param int                            $customer_id Owning customer id.
	 * @param bool                           $manageable  Whether to show manage controls.
	 * @return void
	 */
	private function vehicles_block( array $vehicles, $customer_id, $manageable ) {
		$add_url = add_query_arg(
			array( 'page' => AMAT_Vehicles_Page::PAGE_SLUG, 'action' => 'new', 'return_customer' => (int) $customer_id ),
			admin_url( 'admin.php' )
		);
		?>
		<h2 class="amat-section-head">
			<?php esc_html_e( 'Vehicles', 'auto-mation' ); ?>
			<?php if ( $manageable ) : ?>
				<a href="<?php echo esc_url( $add_url ); ?>" class="button amat-btn-primary"><?php esc_html_e( 'Add vehicle', 'auto-mation' ); ?></a>
			<?php endif; ?>
		</h2>
		<?php if ( empty( $vehicles ) ) : ?>
			<p class="description"><?php esc_html_e( 'No vehicles yet.', 'auto-mation' ); ?></p>
		<?php else : ?>
			<?php
			// Deep-link target: the Vehicles grid opens this view with ?expand=<id>
			// to auto-open one vehicle's detail and scroll to it.
			$expand_id  = isset( $_GET['expand'] ) ? absint( $_GET['expand'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only nav context.
			$return_url = $this->list_url( array( 'action' => 'edit', 'id' => (int) $customer_id ) );
			$colspan    = 5 + ( $manageable ? 1 : 0 );
			?>
			<table class="wp-list-table widefat striped amat-grid-vehicles">
				<thead>
					<tr>
						<th class="amat-col-expand"></th>
						<th><?php esc_html_e( 'Vehicle', 'auto-mation' ); ?></th>
						<th><?php esc_html_e( 'Color', 'auto-mation' ); ?></th>
						<th><?php esc_html_e( 'Plate', 'auto-mation' ); ?></th>
						<th><?php esc_html_e( 'VIN', 'auto-mation' ); ?></th>
						<?php if ( $manageable ) : ?><th class="amat-col-actions"></th><?php endif; ?>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $vehicles as $vehicle ) : ?>
						<?php
						$vid      = (int) $vehicle['id'];
						$disabled = empty( $vehicle['is_active'] );
						$is_open  = ( $vid === $expand_id );
						?>
						<tr id="amat-veh-<?php echo esc_attr( $vid ); ?>" class="amat-veh-summary <?php echo $disabled ? 'amat-row-disabled' : ''; ?>">
							<td class="amat-col-expand">
								<button type="button" class="button-link amat-veh-toggle" aria-expanded="<?php echo $is_open ? 'true' : 'false'; ?>" aria-controls="amat-veh-detail-<?php echo esc_attr( $vid ); ?>">
									<span class="dashicons dashicons-arrow-right amat-veh-caret" aria-hidden="true"></span>
									<span class="screen-reader-text"><?php esc_html_e( 'Show vehicle details', 'auto-mation' ); ?></span>
								</button>
							</td>
							<td>
								<?php echo esc_html( AMAT_Vehicle_Model::label( $vehicle ) ); ?>
								<?php if ( $disabled ) : ?><span class="amat-badge amat-badge-off"><?php esc_html_e( 'disabled', 'auto-mation' ); ?></span><?php endif; ?>
							</td>
							<td><?php echo esc_html( (string) ( $vehicle['color'] ?? '' ) ); ?></td>
							<td><?php echo esc_html( (string) ( $vehicle['license_plate'] ?? '' ) ); ?></td>
							<td><?php echo esc_html( (string) ( $vehicle['vin'] ?? '' ) ); ?></td>
							<?php if ( $manageable ) : ?>
								<td class="amat-col-actions">
									<?php
									$edit_veh = add_query_arg(
										array( 'page' => AMAT_Vehicles_Page::PAGE_SLUG, 'action' => 'edit', 'id' => $vid, 'return_customer' => (int) $customer_id ),
										admin_url( 'admin.php' )
									);
									?>
									<div class="amat-row-actions">
										<a href="<?php echo esc_url( $edit_veh ); ?>" class="button"><?php esc_html_e( 'Edit', 'auto-mation' ); ?></a>
										<?php
										echo $this->active_toggle_button( AMAT_Vehicles_Page::POST_ACTION, AMAT_Vehicles_Page::NONCE_ACTION, $vid, ! $disabled, $return_url ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built with esc_* internally.
										echo $this->delete_button( AMAT_Vehicles_Page::POST_ACTION, AMAT_Vehicles_Page::NONCE_ACTION, $vid, $return_url ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built with esc_* internally.
										?>
									</div>
								</td>
							<?php endif; ?>
						</tr>
						<tr id="amat-veh-detail-<?php echo esc_attr( $vid ); ?>" class="amat-veh-detail <?php echo $is_open ? '' : 'amat-hidden'; ?>">
							<td colspan="<?php echo esc_attr( $colspan ); ?>">
								<?php $this->vehicle_detail( $vehicle ); ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>
		<?php
	}

	/**
	 * Echo a vehicle's expanded detail: only the fields that have a value, no
	 * empty placeholders (per the Testing Feedback). Mobile-friendly key/value
	 * list. Used inside the customer view's expandable vehicle rows.
	 *
	 * @param array<string,mixed> $vehicle Vehicle row.
	 * @return void
	 */
	private function vehicle_detail( array $vehicle ) {
		// Year/Make/Model/Color/Plate/VIN are already shown in the summary row,
		// so the expanded panel covers only the remaining spec/manual fields.
		$labels = array(
			'trim'                => __( 'Trim', 'auto-mation' ),
			'series'              => __( 'Series', 'auto-mation' ),
			'body_type'           => __( 'Body type', 'auto-mation' ),
			'engine_displacement' => __( 'Engine displacement (L)', 'auto-mation' ),
			'engine_cylinders'    => __( 'Cylinders', 'auto-mation' ),
			'fuel_type_primary'   => __( 'Fuel type (primary)', 'auto-mation' ),
			'fuel_type_secondary' => __( 'Fuel type (secondary)', 'auto-mation' ),
			'drive_type'          => __( 'Drive type', 'auto-mation' ),
			'transmission_type'   => __( 'Transmission', 'auto-mation' ),
			'transmission_speeds' => __( 'Transmission speeds', 'auto-mation' ),
			'color_code'          => __( 'Color code', 'auto-mation' ),
			'warnings'            => __( 'Warnings', 'auto-mation' ),
			'notes'               => __( 'Notes', 'auto-mation' ),
		);

		$rows = array();
		foreach ( $labels as $field => $label ) {
			$value = trim( (string) ( $vehicle[ $field ] ?? '' ) );
			if ( '' !== $value ) {
				$rows[ $label ] = $value;
			}
		}
		?>
		<?php if ( empty( $rows ) ) : ?>
			<p class="description"><?php esc_html_e( 'No additional details on file. Tap Edit to add them.', 'auto-mation' ); ?></p>
		<?php else : ?>
			<dl class="amat-veh-specs">
				<?php foreach ( $rows as $label => $value ) : ?>
					<div class="amat-veh-spec">
						<dt><?php echo esc_html( $label ); ?></dt>
						<dd><?php echo nl2br( esc_html( $value ) ); ?></dd>
					</div>
				<?php endforeach; ?>
			</dl>
		<?php endif; ?>
		<?php
	}

	/**
	 * Echo the Jobs section for a customer (read-only or manageable).
	 *
	 * @param array<int,array<string,mixed>> $jobs        Job rows.
	 * @param int                            $customer_id Owning customer id.
	 * @param bool                           $manageable  Whether to show manage controls.
	 * @return void
	 */
	private function jobs_block( array $jobs, $customer_id, $manageable ) {
		// Add job lives on the read-only detail header (not here), so the owner can
		// start a job without unlocking the edit form.
		?>
		<h2 class="amat-section-head"><?php esc_html_e( 'Jobs', 'auto-mation' ); ?></h2>
		<?php if ( empty( $jobs ) ) : ?>
			<p class="description"><?php esc_html_e( 'No jobs yet.', 'auto-mation' ); ?></p>
		<?php else : ?>
			<table class="wp-list-table widefat fixed striped">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Name', 'auto-mation' ); ?></th>
						<th><?php esc_html_e( 'Scheduled', 'auto-mation' ); ?></th>
						<th><?php esc_html_e( 'Vehicle', 'auto-mation' ); ?></th>
						<th><?php esc_html_e( 'Status', 'auto-mation' ); ?></th>
						<?php if ( $manageable ) : ?><th class="amat-col-actions"></th><?php endif; ?>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $jobs as $job ) : ?>
						<?php
						$start   = trim( (string) ( $job['scheduled_start'] ?? '' ) );
						$when    = ( '' === $start || 0 === strpos( $start, '0000' ) ) ? '—' : ( date_create( $start ) ? date_create( $start )->format( 'M j, Y g:i A' ) : $start );
						$vehicle = $job['vehicle_id'] ? AMAT_Vehicle_Model::find( (int) $job['vehicle_id'] ) : null;
						$view_job = add_query_arg(
							array( 'page' => AMAT_Jobs_Page::PAGE_SLUG, 'action' => 'view', 'id' => (int) $job['id'], 'return_customer' => (int) $customer_id ),
							admin_url( 'admin.php' )
						);
						$edit_job = add_query_arg(
							array( 'page' => AMAT_Jobs_Page::PAGE_SLUG, 'action' => 'edit', 'id' => (int) $job['id'], 'return_customer' => (int) $customer_id ),
							admin_url( 'admin.php' )
						);
						?>
						<tr>
							<td><a href="<?php echo esc_url( $view_job ); ?>"><?php echo esc_html( '' !== trim( (string) ( $job['name'] ?? '' ) ) ? $job['name'] : '—' ); ?></a></td>
							<td><?php echo esc_html( $when ); ?></td>
							<td><?php echo esc_html( $vehicle ? AMAT_Vehicle_Model::label( $vehicle ) : '—' ); ?></td>
							<td><span class="amat-status amat-status-<?php echo esc_attr( $job['status'] ); ?>"><?php echo esc_html( AMAT_Job_Model::status_label( $job['status'] ) ); ?></span></td>
							<?php if ( $manageable ) : ?>
								<td class="amat-col-actions">
									<div class="amat-row-actions">
										<a href="<?php echo esc_url( $edit_job ); ?>" class="button"><?php esc_html_e( 'Edit', 'auto-mation' ); ?></a>
									</div>
								</td>
							<?php endif; ?>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>
		<?php
	}

	/**
	 * Echo the read-only Estimates section for a customer (view links only —
	 * estimates are created/edited on their job). Shown on the detail + edit views.
	 *
	 * @param int $customer_id Owning customer id.
	 * @return void
	 */
	private function estimates_block( $customer_id ) {
		$estimates = AMAT_Estimate_Model::for_customer( $customer_id );
		?>
		<h2 class="amat-section-head"><?php esc_html_e( 'Estimates', 'auto-mation' ); ?></h2>
		<?php if ( empty( $estimates ) ) : ?>
			<p class="description"><?php esc_html_e( 'No estimates yet.', 'auto-mation' ); ?></p>
		<?php else : ?>
			<table class="wp-list-table widefat fixed striped">
				<thead><tr>
					<th><?php esc_html_e( 'Estimate', 'auto-mation' ); ?></th>
					<th><?php esc_html_e( 'Status', 'auto-mation' ); ?></th>
					<th><?php esc_html_e( 'Total', 'auto-mation' ); ?></th>
				</tr></thead>
				<tbody>
					<?php foreach ( $estimates as $estimate ) : ?>
						<?php
						$view = add_query_arg(
							array( 'page' => AMAT_Estimates_Page::PAGE_SLUG, 'action' => 'view', 'id' => (int) $estimate['id'], 'return_customer' => (int) $customer_id ),
							admin_url( 'admin.php' )
						);
						?>
						<tr>
							<td><a href="<?php echo esc_url( $view ); ?>"><?php echo esc_html( AMAT_Estimates_Page::label( $estimate ) ); ?></a></td>
							<td><span class="amat-status amat-status-<?php echo esc_attr( $estimate['status'] ); ?>"><?php echo esc_html( AMAT_Estimate_Model::status_label( $estimate['status'] ) ); ?></span></td>
							<td><?php echo esc_html( AMAT_Money::format_amount( AMAT_Estimate_Model::total( (int) $estimate['id'] ) ) ); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>
		<?php
	}

	/**
	 * Echo the read-only Invoices section for a customer (view links only —
	 * invoices are created/edited on their job). Shown on the detail + edit views.
	 *
	 * @param int $customer_id Owning customer id.
	 * @return void
	 */
	private function invoices_block( $customer_id ) {
		$invoices = AMAT_Invoice_Model::for_customer( $customer_id );
		?>
		<h2 class="amat-section-head"><?php esc_html_e( 'Invoices', 'auto-mation' ); ?></h2>
		<?php if ( empty( $invoices ) ) : ?>
			<p class="description"><?php esc_html_e( 'No invoices yet.', 'auto-mation' ); ?></p>
		<?php else : ?>
			<table class="wp-list-table widefat fixed striped">
				<thead><tr>
					<th><?php esc_html_e( 'Invoice', 'auto-mation' ); ?></th>
					<th><?php esc_html_e( 'Status', 'auto-mation' ); ?></th>
					<th><?php esc_html_e( 'Total', 'auto-mation' ); ?></th>
				</tr></thead>
				<tbody>
					<?php foreach ( $invoices as $invoice ) : ?>
						<?php
						$view = add_query_arg(
							array( 'page' => AMAT_Invoices_Page::PAGE_SLUG, 'action' => 'view', 'id' => (int) $invoice['id'], 'return_customer' => (int) $customer_id ),
							admin_url( 'admin.php' )
						);
						?>
						<tr>
							<td><a href="<?php echo esc_url( $view ); ?>"><?php echo esc_html( AMAT_Invoices_Page::label( $invoice ) ); ?></a></td>
							<td><span class="amat-status amat-status-<?php echo esc_attr( $invoice['status'] ); ?>"><?php echo esc_html( AMAT_Invoice_Model::status_label( $invoice['status'] ) ); ?></span></td>
							<td><?php echo esc_html( AMAT_Money::format_amount( AMAT_Invoice_Model::total( (int) $invoice['id'] ) ) ); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>
		<?php
	}

	/* --------------------------------------------------------------------- */
	/* Add / edit form                                                       */
	/* --------------------------------------------------------------------- */

	/**
	 * Render the add/edit form.
	 *
	 * @param array<string,mixed>                        $data    Customer row or submitted values.
	 * @param array<int,array<string,mixed>>             $methods Contact methods (DB rows or submitted pairs).
	 * @param int                                        $id      Customer id (0 = new).
	 * @param string                                     $error   Optional error notice.
	 * @return void
	 */
	private function render_form( array $data, array $methods, $id, $error = '', $success = '' ) {
		$id         = absint( $id );
		$is_edit    = $id > 0;
		$first      = (string) ( $data['first_name'] ?? '' );
		$last       = (string) ( $data['last_name'] ?? '' );
		$display    = (string) ( $data['display_name'] ?? '' );
		$notes      = (string) ( $data['notes'] ?? '' );
		$has_custom = '' !== trim( $display );

		// "Referred by": one picker whose value is 'cust:<id>' or 'src:<slug>'.
		$ref_cust     = (int) ( $data['referred_by_customer_id'] ?? 0 );
		$ref_src      = (string) ( $data['referred_by_source'] ?? '' );
		$ref_selected = $ref_cust ? 'cust:' . $ref_cust : ( '' !== $ref_src ? 'src:' . $ref_src : '' );

		// Cancel returns to the read-only detail when editing, else to the list.
		$cancel_url = $is_edit
			? $this->list_url( array( 'action' => 'view', 'id' => $id ) )
			: $this->list_url();
		?>
		<div class="wrap">
			<h1><?php echo $is_edit ? esc_html__( 'Edit customer', 'auto-mation' ) : esc_html__( 'Add customer', 'auto-mation' ); ?></h1>

			<?php if ( $success ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php echo esc_html( $success ); ?></p></div>
			<?php endif; ?>
			<?php if ( $error ) : ?>
				<div class="notice notice-error"><p><?php echo esc_html( $error ); ?></p></div>
			<?php endif; ?>

			<form method="post" id="amat-customer-form">
				<?php wp_nonce_field( self::NONCE_ACTION ); ?>
				<input type="hidden" name="amat_action" value="save_customer" />
				<input type="hidden" name="customer_id" value="<?php echo esc_attr( $id ); ?>" />

				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="amat-first"><?php esc_html_e( 'First name', 'auto-mation' ); ?></label></th>
						<td><input name="first_name" id="amat-first" type="text" class="regular-text" maxlength="100" value="<?php echo esc_attr( $first ); ?>" required /></td>
					</tr>
					<tr>
						<th scope="row"><label for="amat-last"><?php esc_html_e( 'Last name', 'auto-mation' ); ?></label></th>
						<td><input name="last_name" id="amat-last" type="text" class="regular-text" maxlength="100" value="<?php echo esc_attr( $last ); ?>" /></td>
					</tr>
					<tr>
						<th scope="row"><label for="amat-display"><?php esc_html_e( 'Display name', 'auto-mation' ); ?></label></th>
						<td>
							<input name="display_name" id="amat-display" type="text" class="regular-text<?php echo $has_custom ? '' : ' amat-input-auto'; ?>" maxlength="191" value="<?php echo esc_attr( $display ); ?>" data-custom="<?php echo $has_custom ? '1' : '0'; ?>" />
							<span id="amat-display-auto" class="amat-auto-tag"<?php echo $has_custom ? ' style="display:none;"' : ''; ?>><?php esc_html_e( '(Auto)', 'auto-mation' ); ?></span>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Contact methods', 'auto-mation' ); ?></th>
						<td>
							<div id="amat-cm-rows">
								<?php
								if ( empty( $methods ) ) {
									// Start a new customer with one empty row.
									echo $this->cm_row_html( '', '' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built with esc_* internally.
								} else {
									foreach ( $methods as $m ) {
										$type  = (string) ( $m['type'] ?? '' );
										$value = (string) ( $m['value'] ?? '' );
										// Show phone values formatted; validation re-normalizes on save.
										$shown = AMAT_Contact_Method_Types::is_valid_type( $type )
											? AMAT_Contact_Method_Types::format( $type, $value )
											: $value;
										echo $this->cm_row_html( $type, $shown ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built with esc_* internally.
									}
								}
								?>
							</div>
							<?php echo $this->cm_row_html( '', '', true ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built with esc_* internally. ?>
							<p><button type="button" class="button" id="amat-cm-add"><?php esc_html_e( 'Add contact method', 'auto-mation' ); ?></button></p>
							<p class="description"><?php esc_html_e( 'Drag to reorder — the top method is the preferred way to reach the customer.', 'auto-mation' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="amat-notes"><?php esc_html_e( 'Notes (Internal)', 'auto-mation' ); ?></label></th>
						<td>
							<textarea name="notes" id="amat-notes" class="large-text" rows="3"><?php echo esc_textarea( $notes ); ?></textarea>
							<p class="description"><?php esc_html_e( 'Internal use only — not shown to the customer.', 'auto-mation' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="amat-refby-search"><?php esc_html_e( 'Referred by', 'auto-mation' ); ?></label></th>
						<td>
							<?php
							// Fixed (non-customer) sources offered alongside the customer search.
							$ref_sources = array();
							foreach ( AMAT_Customer_Model::referral_sources() as $slug => $label ) {
								$ref_sources[] = array( 'v' => 'src:' . $slug, 'label' => $label );
							}
							$ref_label = AMAT_Customer_Model::referred_by_label( $data );
							?>
							<div class="amat-search-wrap" id="amat-refby-wrap" data-self="<?php echo esc_attr( $id ); ?>" data-sources="<?php echo esc_attr( (string) wp_json_encode( $ref_sources ) ); ?>">
								<input type="search" id="amat-refby-search" class="regular-text" autocomplete="off" placeholder="<?php esc_attr_e( 'Search a customer, or pick a source…', 'auto-mation' ); ?>" value="<?php echo esc_attr( $ref_label ); ?>" />
								<div id="amat-refby-results" class="amat-search-results"></div>
							</div>
							<input type="hidden" name="referred_by" id="amat-refby-id" value="<?php echo esc_attr( $ref_selected ); ?>" />
							<p class="description">
								<?php esc_html_e( 'Who referred this customer — another customer, or how they found you.', 'auto-mation' ); ?>
								<button type="button" class="button-link" id="amat-refby-clear"><?php esc_html_e( 'Clear', 'auto-mation' ); ?></button>
							</p>
						</td>
					</tr>
				</table>

				<?php submit_button( $is_edit ? __( 'Save changes', 'auto-mation' ) : __( 'Add customer', 'auto-mation' ) ); ?>
				<a href="<?php echo esc_url( $cancel_url ); ?>" class="button amat-btn-secondary"><?php esc_html_e( 'Cancel', 'auto-mation' ); ?></a>
			</form>

			<?php if ( $is_edit ) : ?>
				<div class="amat-subitems">
				<?php
				// Manage the customer's locations and vehicles. Shown only once
				// the customer exists (an unsaved new customer has no id to own
				// them yet). These links open the respective form scoped to this
				// customer and return to the detail view on save.
				$this->locations_block( AMAT_Location_Model::for_customer( $id ), $id, true );
				$this->vehicles_block( AMAT_Vehicle_Model::for_customer( $id ), $id, true );
				$this->jobs_block( AMAT_Job_Model::for_customer( $id ), $id, true );
				$this->estimates_block( $id );
				$this->invoices_block( $id );
				?>
				</div>
			<?php else : ?>
				<p class="description"><?php esc_html_e( 'Save the customer first, then you can add vehicles and locations.', 'auto-mation' ); ?></p>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Build one contact-method repeater row.
	 *
	 * @param string $type     Selected type slug.
	 * @param string $value    Displayed value.
	 * @param bool   $template Whether this is the hidden clone template (its
	 *                         inputs are disabled so they never submit).
	 * @return string Escaped HTML row.
	 */
	private function cm_row_html( $type, $value, $template = false ) {
		$disabled = $template ? ' disabled' : '';

		$options = '';
		foreach ( AMAT_Contact_Method_Types::definitions() as $slug => $def ) {
			$options .= sprintf(
				'<option value="%s"%s>%s</option>',
				esc_attr( $slug ),
				selected( $slug, $type, false ),
				esc_html( $def['label'] )
			);
		}

		$row  = '<div class="amat-cm-row' . ( $template ? ' amat-cm-template' : '' ) . '"' . ( $template ? ' style="display:none"' : '' ) . '>';
		$row .= '<span class="amat-cm-handle dashicons dashicons-menu" aria-hidden="true"></span>';
		$row .= '<select name="cm_type[]"' . $disabled . '>' . $options . '</select>';
		$row .= '<input type="text" name="cm_value[]" class="regular-text" value="' . esc_attr( $value ) . '" maxlength="191"' . $disabled . ' />';
		$row .= '<button type="button" class="button-link amat-cm-remove" aria-label="' . esc_attr__( 'Remove', 'auto-mation' ) . '">&times;</button>';
		$row .= '</div>';

		return $row;
	}

	/* --------------------------------------------------------------------- */
	/* Save                                                                  */
	/* --------------------------------------------------------------------- */

	/**
	 * Validate and persist the submitted customer + contact methods.
	 *
	 * Called from the base class on `admin_init` once it confirms this is the
	 * customer save POST; always returns a result array (never null).
	 *
	 * @return array{status:string,message:string,data?:array,methods?:array,editing_id?:int}
	 */
	protected function save() {
		check_admin_referer( self::NONCE_ACTION );
		if ( ! current_user_can( AMAT_Admin::CAPABILITY ) ) {
			return array(
				'status'  => 'error',
				'message' => __( 'You are not allowed to save customers.', 'auto-mation' ),
				'data'    => array(),
				'methods' => array(),
				'editing_id' => 0,
			);
		}

		$id = isset( $_POST['customer_id'] ) ? absint( $_POST['customer_id'] ) : 0;

		// Display name is stored only when customized; an untouched field is
		// cleared by JS, so a non-empty value here means the user set it.
		$data = array(
			'first_name'   => sanitize_text_field( wp_unslash( $_POST['first_name'] ?? '' ) ),
			'last_name'    => sanitize_text_field( wp_unslash( $_POST['last_name'] ?? '' ) ),
			'display_name' => sanitize_text_field( wp_unslash( $_POST['display_name'] ?? '' ) ),
			'notes'        => sanitize_textarea_field( wp_unslash( $_POST['notes'] ?? '' ) ),
		);

		// "Referred by": the single picker posts 'cust:<id>' or 'src:<slug>'.
		$ref      = sanitize_text_field( wp_unslash( $_POST['referred_by'] ?? '' ) );
		$ref_cust = 0;
		$ref_src  = '';
		if ( 0 === strpos( $ref, 'cust:' ) ) {
			$ref_cust = absint( substr( $ref, 5 ) );
			if ( $ref_cust === $id ) {
				$ref_cust = 0; // a customer can't refer themselves
			}
		} elseif ( 0 === strpos( $ref, 'src:' ) ) {
			$slug = sanitize_key( substr( $ref, 4 ) );
			if ( isset( AMAT_Customer_Model::referral_sources()[ $slug ] ) ) {
				$ref_src = $slug;
			}
		}
		$data['referred_by_customer_id'] = $ref_cust;
		$data['referred_by_source']      = $ref_src;

		// Parse and validate the contact-method repeater.
		$raw_types  = isset( $_POST['cm_type'] ) ? (array) wp_unslash( $_POST['cm_type'] ) : array();
		$raw_values = isset( $_POST['cm_value'] ) ? (array) wp_unslash( $_POST['cm_value'] ) : array();

		$methods = array();
		$errors  = array();
		foreach ( $raw_types as $i => $type ) {
			$type  = sanitize_key( $type );
			$value = isset( $raw_values[ $i ] ) ? trim( (string) $raw_values[ $i ] ) : '';

			if ( '' === $value ) {
				continue; // Skip empty rows.
			}

			$normalized = AMAT_Contact_Method_Types::validate( $type, $value );
			if ( is_wp_error( $normalized ) ) {
				$errors[] = AMAT_Contact_Method_Types::label( $type ) . ': ' . $normalized->get_error_message();
				continue;
			}
			$methods[] = array( 'type' => $type, 'value' => $normalized );
		}

		// Re-render the form on any validation problem, preserving input.
		$fail = function ( $message ) use ( $data, $raw_types, $raw_values, $id ) {
			// Rebuild method pairs from raw input so the user keeps what they typed.
			$submitted = array();
			foreach ( $raw_types as $i => $t ) {
				$submitted[] = array(
					'type'  => sanitize_key( $t ),
					'value' => isset( $raw_values[ $i ] ) ? sanitize_text_field( $raw_values[ $i ] ) : '',
				);
			}
			return array(
				'status'     => 'error',
				'message'    => $message,
				'data'       => $data,
				'methods'    => $submitted,
				'editing_id' => $id,
			);
		};

		if ( '' === $data['first_name'] ) {
			return $fail( __( 'A first name is required.', 'auto-mation' ) );
		}
		if ( $errors ) {
			return $fail( implode( ' ', $errors ) );
		}

		// Persist the customer, then replace its contact methods in order.
		$is_new = ! $id;
		if ( $id ) {
			AMAT_Customer_Model::update( $id, $data );
		} else {
			$id = AMAT_Customer_Model::create( $data );
		}

		if ( ! $id ) {
			return $fail( __( 'Could not save the customer. Please try again.', 'auto-mation' ) );
		}

		AMAT_Contact_Method_Model::replace_for_customer( $id, $methods );

		/**
		 * Fires after the owner saves a customer from the admin.
		 *
		 * Core ships no listener; a provider integration uses this for its
		 * auto-sync mode. Fired here (the save path) and NOT from the model on
		 * purpose: the models are also driven by migrations, importers and tests,
		 * where an outbound API call would be wrong. This hook means "the owner
		 * saved this record", which is what auto-sync is about.
		 *
		 * Fires after the contact methods are written, so a listener reading the
		 * customer sees the complete record.
		 *
		 * @param int  $id     Customer id.
		 * @param bool $is_new Whether the record was just created.
		 */
		do_action( 'amat_after_customer_save', (int) $id, $is_new );

		// Land on the read-only detail so the owner sees the saved record.
		return array(
			'status'   => 'success',
			'message'  => __( 'Customer saved.', 'auto-mation' ),
			'redirect' => $this->list_url( array( 'action' => 'view', 'id' => (int) $id ) ),
		);
	}
}
