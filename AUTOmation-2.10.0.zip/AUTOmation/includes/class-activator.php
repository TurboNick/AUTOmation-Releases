<?php
/**
 * Plugin activation: creates and upgrades custom database tables.
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handles schema creation/upgrade via dbDelta().
 *
 * Per §4 of CLAUDE.md the relational core lives in custom tables, not CPTs.
 * Run on activation and whenever AMAT_DB_VERSION is ahead of the stored option.
 */
class AMAT_Activator {

	/**
	 * Create or upgrade the plugin's tables, then record the schema version.
	 *
	 * dbDelta() is idempotent: it diffs the existing schema against the
	 * definitions below and applies only the needed changes, so this is safe
	 * to call repeatedly for upgrades.
	 *
	 * @return void
	 */
	public static function activate() {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		// The schema version we are upgrading *from*, read before it is bumped
		// below. 0 = fresh install (no option yet), so there is nothing to
		// migrate. Version-gated migrations below need this: not every migration
		// is safely re-runnable (see migrate_document_statuses()).
		$from = (int) get_option( AMAT_DB_VERSION_OPTION, 0 );

		$charset_collate = $wpdb->get_charset_collate();
		$prefix          = $wpdb->prefix . 'amat_';

		$queries = array();

		// customers
		// Contact details (email/phones/preferred method) moved to the
		// contact_methods table as of DB v2 — see §4 of CLAUDE.md.
		$queries[] = "CREATE TABLE {$prefix}customers (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			wp_user_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			is_active TINYINT(1) NOT NULL DEFAULT 1,
			first_name VARCHAR(100) NOT NULL DEFAULT '',
			last_name VARCHAR(100) NOT NULL DEFAULT '',
			display_name VARCHAR(191) NOT NULL DEFAULT '',
			notes TEXT NULL,
			referred_by_customer_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			referred_by_source VARCHAR(50) NOT NULL DEFAULT '',
			wave_customer_id VARCHAR(191) NOT NULL DEFAULT '',
			created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			updated_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			KEY wp_user_id (wp_user_id),
			KEY referred_by_customer_id (referred_by_customer_id),
			KEY wave_customer_id (wave_customer_id)
		) {$charset_collate};";

		// contact_methods — one row per customer contact channel, ordered.
		// type is a registry slug (email/call/text/...); value is the stored
		// (normalized) value; sort_order is priority (lower = higher priority),
		// replacing the old preferred_contact_method column. See §4.
		$queries[] = "CREATE TABLE {$prefix}contact_methods (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			customer_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			type VARCHAR(30) NOT NULL DEFAULT '',
			value VARCHAR(191) NOT NULL DEFAULT '',
			sort_order INT(10) UNSIGNED NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			updated_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			KEY customer_id (customer_id)
		) {$charset_collate};";

		// locations
		$queries[] = "CREATE TABLE {$prefix}locations (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			customer_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			label VARCHAR(100) NOT NULL DEFAULT '',
			is_primary TINYINT(1) NOT NULL DEFAULT 0,
			is_billing TINYINT(1) NOT NULL DEFAULT 0,
			is_active TINYINT(1) NOT NULL DEFAULT 1,
			street_1 VARCHAR(191) NOT NULL DEFAULT '',
			street_2 VARCHAR(191) NOT NULL DEFAULT '',
			city VARCHAR(100) NOT NULL DEFAULT '',
			state VARCHAR(50) NOT NULL DEFAULT '',
			zipcode VARCHAR(20) NOT NULL DEFAULT '',
			code VARCHAR(100) NOT NULL DEFAULT '',
			notes TEXT NULL,
			created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			updated_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			KEY customer_id (customer_id)
		) {$charset_collate};";

		// vehicles
		$queries[] = "CREATE TABLE {$prefix}vehicles (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			customer_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			is_active TINYINT(1) NOT NULL DEFAULT 1,
			vin VARCHAR(17) NOT NULL DEFAULT '',
			year SMALLINT(5) UNSIGNED NULL,
			make VARCHAR(100) NOT NULL DEFAULT '',
			model VARCHAR(100) NOT NULL DEFAULT '',
			trim VARCHAR(100) NOT NULL DEFAULT '',
			series VARCHAR(100) NOT NULL DEFAULT '',
			body_type VARCHAR(100) NOT NULL DEFAULT '',
			engine_displacement VARCHAR(20) NOT NULL DEFAULT '',
			engine_cylinders VARCHAR(10) NOT NULL DEFAULT '',
			fuel_type_primary VARCHAR(50) NOT NULL DEFAULT '',
			fuel_type_secondary VARCHAR(50) NOT NULL DEFAULT '',
			drive_type VARCHAR(50) NOT NULL DEFAULT '',
			transmission_type VARCHAR(50) NOT NULL DEFAULT '',
			transmission_speeds VARCHAR(20) NOT NULL DEFAULT '',
			license_plate VARCHAR(20) NOT NULL DEFAULT '',
			color VARCHAR(50) NOT NULL DEFAULT '',
			color_code VARCHAR(50) NOT NULL DEFAULT '',
			warnings TEXT NULL,
			notes TEXT NULL,
			created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			updated_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			KEY customer_id (customer_id),
			KEY vin (vin)
		) {$charset_collate};";

		// jobs
		$queries[] = "CREATE TABLE {$prefix}jobs (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			customer_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			vehicle_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			location_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			name VARCHAR(255) NOT NULL DEFAULT '',
			scheduled_start DATETIME NULL,
			scheduled_end DATETIME NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'requested',
			description TEXT NULL,
			mileage BIGINT(20) UNSIGNED NULL,
			wave_estimate_id VARCHAR(191) NOT NULL DEFAULT '',
			wave_invoice_id VARCHAR(191) NOT NULL DEFAULT '',
			created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			updated_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			KEY customer_id (customer_id),
			KEY vehicle_id (vehicle_id),
			KEY location_id (location_id),
			KEY status (status),
			KEY scheduled_start (scheduled_start)
		) {$charset_collate};";

		// parts_orders
		$queries[] = "CREATE TABLE {$prefix}parts_orders (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			job_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			description VARCHAR(255) NOT NULL DEFAULT '',
			part_number VARCHAR(100) NOT NULL DEFAULT '',
			supplier VARCHAR(191) NOT NULL DEFAULT '',
			quantity INT(10) UNSIGNED NOT NULL DEFAULT 1,
			unit_cost DECIMAL(10,2) NOT NULL DEFAULT 0.00,
			status VARCHAR(20) NOT NULL DEFAULT 'needed',
			created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			updated_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			KEY job_id (job_id),
			KEY status (status)
		) {$charset_collate};";

		// services — the master list of pre-set services a job can include
		// (DB v4). name is the only required field; default_price/default_quantity
		// prefill a line item (DB v11) and are optional (NULL = unset). is_active
		// soft-deletes a service from the picker. (The old default_duration (DB v4)
		// and wave_product_id (DB v5) columns are no longer used — line items carry
		// quantity and reference a Settings-chosen parent product; dbDelta leaves
		// the dead columns on existing installs.)
		$queries[] = "CREATE TABLE {$prefix}services (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			name VARCHAR(191) NOT NULL DEFAULT '',
			description TEXT NULL,
			default_price DECIMAL(10,2) NULL,
			default_quantity DECIMAL(10,2) NULL,
			is_active TINYINT(1) NOT NULL DEFAULT 1,
			sort_order INT(10) UNSIGNED NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			updated_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			KEY is_active (is_active)
		) {$charset_collate};";

		// parts — the master list of pre-set parts a job can include (DB v6),
		// mirroring services. name is the only required field; default_price/
		// default_quantity (DB v11) prefill a line item and are optional
		// (NULL = unset). is_active soft-deletes a part from the picker.
		$queries[] = "CREATE TABLE {$prefix}parts (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			name VARCHAR(191) NOT NULL DEFAULT '',
			description TEXT NULL,
			default_price DECIMAL(10,2) NULL,
			default_quantity DECIMAL(10,2) NULL,
			is_active TINYINT(1) NOT NULL DEFAULT 1,
			sort_order INT(10) UNSIGNED NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			updated_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			KEY is_active (is_active)
		) {$charset_collate};";

		// service_records
		$queries[] = "CREATE TABLE {$prefix}service_records (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			vehicle_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			job_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			description TEXT NULL,
			date_completed DATE NULL,
			mileage_at_service INT(10) UNSIGNED NULL,
			created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			updated_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			KEY vehicle_id (vehicle_id),
			KEY job_id (job_id)
		) {$charset_collate};";

		// estimates — native job-owned estimate documents (DB v7). Totals are
		// computed from estimate_items. Cancelling is the 'void' STATUS (DB v16),
		// not a soft-delete flag: unlike a vehicle or a location, a document is a
		// point-in-time record whose cancellation is part of its story, so it is
		// said out loud on the record rather than hidden behind is_active.
		$queries[] = "CREATE TABLE {$prefix}estimates (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			customer_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			job_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			vehicle_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			number VARCHAR(50) NOT NULL DEFAULT '',
			status VARCHAR(20) NOT NULL DEFAULT 'draft',
			issue_date DATE NULL,
			valid_until DATE NULL,
			notes TEXT NULL,
			created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			updated_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			KEY customer_id (customer_id),
			KEY job_id (job_id),
			KEY status (status)
		) {$charset_collate};";

		// estimate_items — line items on an estimate (DB v7). source_type/source_id
		// record where a line was seeded from (a service/part catalog row) but the
		// description/quantity/unit_price are an editable point-in-time snapshot.
		$queries[] = "CREATE TABLE {$prefix}estimate_items (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			estimate_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			source_type VARCHAR(20) NOT NULL DEFAULT 'service',
			source_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			description VARCHAR(255) NOT NULL DEFAULT '',
			quantity DECIMAL(10,2) NOT NULL DEFAULT 1.00,
			unit_price DECIMAL(10,2) NULL,
			sort_order INT(10) UNSIGNED NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			updated_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			KEY estimate_id (estimate_id)
		) {$charset_collate};";

		// invoices — native job-owned invoice documents (DB v7). Optionally
		// converted from an estimate. Payment fields (amount_paid/paid_date/status)
		// are updated by a provider sync — the provider owns the money, we mirror
		// it. Cancelling is the 'void' STATUS (DB v16), as on estimates.
		$queries[] = "CREATE TABLE {$prefix}invoices (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			customer_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			estimate_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			job_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			vehicle_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			number VARCHAR(50) NOT NULL DEFAULT '',
			status VARCHAR(20) NOT NULL DEFAULT 'draft',
			issue_date DATE NULL,
			due_date DATE NULL,
			amount_paid DECIMAL(10,2) NULL,
			paid_date DATE NULL,
			notes TEXT NULL,
			created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			updated_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			KEY customer_id (customer_id),
			KEY estimate_id (estimate_id),
			KEY job_id (job_id),
			KEY status (status)
		) {$charset_collate};";

		// invoice_items — line items on an invoice (DB v7); same shape as estimate_items.
		$queries[] = "CREATE TABLE {$prefix}invoice_items (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			invoice_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			source_type VARCHAR(20) NOT NULL DEFAULT 'service',
			source_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			description VARCHAR(255) NOT NULL DEFAULT '',
			quantity DECIMAL(10,2) NOT NULL DEFAULT 1.00,
			unit_price DECIMAL(10,2) NULL,
			sort_order INT(10) UNSIGNED NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			updated_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			KEY invoice_id (invoice_id)
		) {$charset_collate};";

		// external_refs — generic, provider-agnostic store linking a local entity to
		// its ID in an external system (DB v7). The single mechanism a companion
		// integration plugin (e.g. Wave) uses to remember what it synced; core never
		// hard-codes a provider. One row per (provider, entity_type, entity_id).
		$queries[] = "CREATE TABLE {$prefix}external_refs (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			provider VARCHAR(32) NOT NULL DEFAULT '',
			entity_type VARCHAR(32) NOT NULL DEFAULT '',
			entity_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			external_id VARCHAR(191) NOT NULL DEFAULT '',
			status VARCHAR(32) NULL,
			synced_at DATETIME NULL,
			created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			updated_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			UNIQUE KEY provider_entity (provider, entity_type, entity_id),
			KEY provider (provider)
		) {$charset_collate};";

		// logs — a generic, append-only event log (DB v17). Provider-agnostic: the
		// Wave companion writes to it via AMAT_Log and core never learns what
		// 'wave' means. entity_type/entity_id are nullable-by-convention (0/'')
		// so an entry can be about a record or about nothing in particular.
		// Pruned on a daily cron to the configured retention window.
		$queries[] = "CREATE TABLE {$prefix}logs (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			level VARCHAR(20) NOT NULL DEFAULT 'info',
			channel VARCHAR(32) NOT NULL DEFAULT '',
			entity_type VARCHAR(32) NOT NULL DEFAULT '',
			entity_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			message TEXT NULL,
			context LONGTEXT NULL,
			user_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			updated_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			KEY created_at (created_at),
			KEY level (level),
			KEY channel (channel),
			KEY entity (entity_type, entity_id)
		) {$charset_collate};";

		foreach ( $queries as $query ) {
			dbDelta( $query );
		}

		// dbDelta never drops columns, so remove the contact columns that
		// moved to contact_methods in DB v2 when upgrading an older install.
		self::drop_obsolete_customer_columns( $prefix . 'customers' );

		// Migrate any legacy customers.wave_customer_id values into the generic
		// external_refs store (DB v8). Idempotent: set() upserts, so re-running is
		// safe; the vestigial column is left in place (dbDelta never drops it).
		self::migrate_wave_customer_links( $prefix );

		// Migrate legacy contact-method type slugs to the new set (DB v9):
		// call → call_only, text → text_call. Idempotent.
		self::migrate_contact_method_types( $prefix );

		// Migrate legacy 'custom' line items to 'service' (DB v12): line items are
		// now always typed service/part (a not-in-catalog line is just source_id 0),
		// so the old 'custom' source_type is retired and folds into service. Idempotent.
		self::migrate_custom_line_types( $prefix );

		// Attach any job-less estimates/invoices to a parent job (DB v14): estimates
		// and invoices are now job-owned. Orphans (created the old customer-first way)
		// get grouped onto one auto-created container job per customer. Idempotent.
		self::migrate_documents_to_jobs( $prefix );

		// Move estimates/invoices onto the richer status vocabulary (DB v15).
		// VERSION-GATED — unlike the migrations above, this one is NOT safe to
		// re-run; see the method docblock.
		if ( $from > 0 && $from < 15 ) {
			self::migrate_document_statuses( $prefix );
		}

		// Retire the short-lived document is_active flag in favour of a 'void'
		// status (DB v16). Guarded by a column-existence check, so idempotent.
		self::migrate_document_void_status( $prefix );

		// Ensure the front-end customer role exists (§4 portal auth).
		AMAT_Portal::add_role();

		// Keep the event log pruned to its retention window (DB v17).
		AMAT_Log::schedule_prune();

		update_option( AMAT_DB_VERSION_OPTION, AMAT_DB_VERSION );
	}

	/**
	 * Copy legacy customers.wave_customer_id values into external_refs (provider
	 * 'wave', entity_type 'customer'). No-op when the column is gone or empty.
	 *
	 * @param string $prefix The `{$wpdb->prefix}amat_` table prefix.
	 * @return void
	 */
	private static function migrate_wave_customer_links( $prefix ) {
		global $wpdb;

		$table  = $prefix . 'customers';
		$exists = $wpdb->get_var( $wpdb->prepare( "SHOW COLUMNS FROM {$table} LIKE %s", 'wave_customer_id' ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		if ( ! $exists ) {
			return;
		}

		// Trusted internal identifiers; no user input in the query.
		$rows = $wpdb->get_results( "SELECT id, wave_customer_id FROM {$table} WHERE wave_customer_id IS NOT NULL AND wave_customer_id <> ''", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery
		foreach ( (array) $rows as $row ) {
			if ( '' === AMAT_External_Ref_Model::external_id( 'wave', 'customer', (int) $row['id'] ) ) {
				AMAT_External_Ref_Model::set( 'wave', 'customer', (int) $row['id'], (string) $row['wave_customer_id'] );
			}
		}
	}

	/**
	 * Attach job-less estimates/invoices to a parent job (DB v14).
	 *
	 * Estimates and invoices are now job-owned. Any row with job_id = 0 (created
	 * the old customer-first way) is grouped onto a single auto-created container
	 * job per customer (status 'completed', name 'Imported records'), so the
	 * "every estimate/invoice has a parent job" rule holds with no exceptions. An
	 * invoice converted from an estimate inherits that estimate's job. Rows with no
	 * customer are left as-is (nothing sensible to attach them to). Idempotent:
	 * after migration no job_id = 0 rows remain, so a re-run is a no-op.
	 *
	 * @param string $prefix The `{$wpdb->prefix}amat_` table prefix.
	 * @return void
	 */
	private static function migrate_documents_to_jobs( $prefix ) {
		global $wpdb;

		$containers = array(); // customer_id => container job id (created on demand).

		$container_for = static function ( $customer_id ) use ( &$containers ) {
			$customer_id = (int) $customer_id;
			if ( $customer_id <= 0 ) {
				return 0;
			}
			if ( isset( $containers[ $customer_id ] ) ) {
				return $containers[ $customer_id ];
			}
			$job_id = (int) AMAT_Job_Model::create(
				array(
					'customer_id' => $customer_id,
					'name'        => __( 'Imported records', 'auto-mation' ),
					'status'      => 'completed',
				)
			);
			$containers[ $customer_id ] = $job_id;
			return $job_id;
		};

		// Estimates first, so a converted invoice can inherit its estimate's job.
		$est_table = $prefix . 'estimates';
		$estimates = $wpdb->get_results( "SELECT id, customer_id FROM {$est_table} WHERE job_id = 0 OR job_id IS NULL", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		foreach ( (array) $estimates as $row ) {
			$job_id = $container_for( (int) $row['customer_id'] );
			if ( $job_id ) {
				AMAT_Estimate_Model::update( (int) $row['id'], array( 'job_id' => $job_id ) );
			}
		}

		// Invoices: a converted invoice (estimate_id set) inherits that estimate's
		// (now-populated) job; otherwise it groups by its own customer.
		$inv_table = $prefix . 'invoices';
		$invoices  = $wpdb->get_results( "SELECT id, customer_id, estimate_id FROM {$inv_table} WHERE job_id = 0 OR job_id IS NULL", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		foreach ( (array) $invoices as $row ) {
			$job_id = 0;
			if ( ! empty( $row['estimate_id'] ) ) {
				$parent = AMAT_Estimate_Model::find( (int) $row['estimate_id'] );
				$job_id = $parent ? (int) $parent['job_id'] : 0;
			}
			if ( ! $job_id ) {
				$job_id = $container_for( (int) $row['customer_id'] );
			}
			if ( $job_id ) {
				AMAT_Invoice_Model::update( (int) $row['id'], array( 'job_id' => $job_id ) );
			}
		}
	}

	/**
	 * Move estimates onto the DB v15 status vocabulary: **'approved' → 'accepted'**.
	 *
	 * Before v15, `approved` meant *the customer approved it*. From v15 the two are
	 * distinguished — `accepted` is the customer's decision, `approved` is the owner
	 * finalizing his own draft — so existing rows carry the customer meaning and
	 * move to `accepted`.
	 *
	 * (v15 also briefly turned the invoice `void` status into a disabled record;
	 * v16 reversed that — `void` is a status again on both types — so nothing to do
	 * here for invoices. A v14 install upgrading straight to v16 keeps its void
	 * invoices as-is, since the value is valid again.)
	 *
	 * **This is NOT idempotent, which is why the caller version-gates it.**
	 * `approved` becomes a *valid* value again after v15 (with the new
	 * owner-finalized meaning), so re-running this over a v15+ database would
	 * silently rewrite genuine owner-approvals into customer-acceptances. The
	 * activator runs on every activation — not only on upgrades — so the guard is
	 * load-bearing, not decoration.
	 *
	 * @param string $prefix The `{$wpdb->prefix}amat_` table prefix.
	 * @return void
	 */
	private static function migrate_document_statuses( $prefix ) {
		global $wpdb;

		$estimates = $prefix . 'estimates';
		// %s value placeholders; the table name is a trusted constant.
		$wpdb->query( $wpdb->prepare( "UPDATE {$estimates} SET status = %s WHERE status = %s", 'accepted', 'approved' ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
	}

	/**
	 * Retire the document `is_active` flag in favour of a 'void' status (DB v16).
	 *
	 * v15 briefly modelled a cancelled estimate/invoice as a *disabled record*,
	 * mirroring vehicles/locations. That was wrong for documents: an estimate or
	 * invoice is a point-in-time record, and its cancellation is part of the story
	 * you want to read *on* it — not a flag that quietly filters it out of view.
	 * So `void` is a status on both types, and the column goes.
	 *
	 * Any row that was disabled is voided first, so the intent survives the
	 * column being dropped. dbDelta never drops columns, hence the explicit
	 * ALTER (same pattern as drop_obsolete_customer_columns()).
	 *
	 * Idempotent: guarded on the column still existing, so a re-run is a no-op.
	 *
	 * @param string $prefix The `{$wpdb->prefix}amat_` table prefix.
	 * @return void
	 */
	private static function migrate_document_void_status( $prefix ) {
		global $wpdb;

		foreach ( array( 'estimates', 'invoices' ) as $slug ) {
			$table = $prefix . $slug;

			// SHOW COLUMNS LIKE takes the column name as a value placeholder.
			$exists = $wpdb->get_var( $wpdb->prepare( "SHOW COLUMNS FROM {$table} LIKE %s", 'is_active' ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
			if ( ! $exists ) {
				continue;
			}

			// Preserve the intent before the flag disappears.
			$wpdb->query( $wpdb->prepare( "UPDATE {$table} SET status = %s WHERE is_active = 0", 'void' ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery

			// Trusted internal identifiers; no user input.
			$wpdb->query( "ALTER TABLE {$table} DROP COLUMN is_active" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery
		}
	}

	/**
	 * Migrate legacy 'custom' line items to 'service' (DB v12) on both the
	 * estimate_items and invoice_items tables. Line items are now always typed
	 * service/part; a typed-but-not-in-catalog line is simply source_id 0, so the
	 * old free-text 'custom' type folds into service (labor being the common case).
	 * Idempotent (after migration no 'custom' rows remain).
	 *
	 * @param string $prefix The `{$wpdb->prefix}amat_` table prefix.
	 * @return void
	 */
	private static function migrate_custom_line_types( $prefix ) {
		global $wpdb;

		foreach ( array( 'estimate_items', 'invoice_items' ) as $slug ) {
			$table = $prefix . $slug;
			// %s value placeholders; the table name is a trusted constant.
			$wpdb->query( $wpdb->prepare( "UPDATE {$table} SET source_type = %s WHERE source_type = %s", 'service', 'custom' ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		}
	}

	/**
	 * Migrate legacy contact-method type slugs to the new set (DB v9): the old
	 * single channels 'call'/'text' become 'call_only'/'text_call'. Idempotent
	 * (after migration no 'call'/'text' rows remain). 'email' is unchanged.
	 *
	 * @param string $prefix The `{$wpdb->prefix}amat_` table prefix.
	 * @return void
	 */
	private static function migrate_contact_method_types( $prefix ) {
		global $wpdb;

		$table = $prefix . 'contact_methods';
		// %s value placeholders; the table name is a trusted constant.
		$wpdb->query( $wpdb->prepare( "UPDATE {$table} SET type = %s WHERE type = %s", 'call_only', 'call' ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$wpdb->query( $wpdb->prepare( "UPDATE {$table} SET type = %s WHERE type = %s", 'text_call', 'text' ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
	}

	/**
	 * Drop the customer contact columns superseded by contact_methods (v2).
	 *
	 * Guarded by an existence check so it is a no-op on fresh installs and
	 * safe to re-run. Column/table names are trusted internal identifiers.
	 *
	 * @param string $table Fully-qualified customers table name.
	 * @return void
	 */
	private static function drop_obsolete_customer_columns( $table ) {
		global $wpdb;

		$obsolete = array(
			'email',
			'phone_primary',
			'phone_primary_accepts_text',
			'phone_secondary',
			'phone_secondary_accepts_text',
			'preferred_contact_method',
		);

		foreach ( $obsolete as $column ) {
			// SHOW COLUMNS LIKE accepts a value placeholder for the column name.
			$exists = $wpdb->get_var(
				$wpdb->prepare( "SHOW COLUMNS FROM {$table} LIKE %s", $column )
			);
			if ( $exists ) {
				$wpdb->query( "ALTER TABLE {$table} DROP COLUMN {$column}" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			}
		}
	}
}
