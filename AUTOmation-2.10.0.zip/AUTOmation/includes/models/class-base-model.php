<?php
/**
 * Base data-access model: shared CRUD over a custom table.
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Abstract base for the plugin's table-backed models.
 *
 * Subclasses declare a table name (without prefix) and the writable columns.
 * All queries go through $wpdb->prepare()/insert()/update() so input is never
 * interpolated into SQL (see §5 of CLAUDE.md). Timestamps are managed here.
 */
abstract class AMAT_Base_Model {

	/**
	 * Table name without the WordPress + plugin prefix, e.g. 'customers'.
	 *
	 * @return string
	 */
	abstract protected static function table_slug();

	/**
	 * Columns that callers are allowed to write, with a sanitizer each.
	 *
	 * Map of column => one of: 'text', 'textarea', 'email', 'int', 'bool',
	 * 'decimal', 'datetime'. Any field not listed is ignored on insert/update.
	 *
	 * @return array<string,string>
	 */
	abstract protected static function schema();

	/**
	 * Fully-qualified table name including prefixes.
	 *
	 * @return string
	 */
	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'amat_' . static::table_slug();
	}

	/**
	 * Fetch a single row by primary key.
	 *
	 * @param int $id Row id.
	 * @return array<string,mixed>|null Associative row, or null if not found.
	 */
	public static function find( $id ) {
		global $wpdb;
		$table = static::table();
		$row   = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", absint( $id ) ),
			ARRAY_A
		);
		return $row ?: null;
	}

	/**
	 * Fetch rows, optionally filtered by exact-match column values.
	 *
	 * @param array<string,mixed> $where Column => value equality filters.
	 * @param array{orderby?:string,order?:string,limit?:int,offset?:int} $args Query options.
	 * @return array<int,array<string,mixed>>
	 */
	public static function all( array $where = array(), array $args = array() ) {
		global $wpdb;
		$table = static::table();

		$sql    = "SELECT * FROM {$table}";
		$params = array();

		$clauses = array();
		foreach ( $where as $column => $value ) {
			if ( ! self::is_known_column( $column ) ) {
				continue;
			}
			$clauses[] = is_int( $value ) ? "{$column} = %d" : "{$column} = %s";
			$params[]  = $value;
		}
		if ( $clauses ) {
			$sql .= ' WHERE ' . implode( ' AND ', $clauses );
		}

		// orderby is whitelisted against known columns; order is constrained.
		$orderby = isset( $args['orderby'] ) && self::is_known_column( $args['orderby'] )
			? $args['orderby']
			: 'id';
		$order   = isset( $args['order'] ) && 'ASC' === strtoupper( $args['order'] )
			? 'ASC'
			: 'DESC';
		$sql    .= " ORDER BY {$orderby} {$order}";

		if ( isset( $args['limit'] ) ) {
			$sql     .= ' LIMIT %d';
			$params[] = absint( $args['limit'] );
			if ( isset( $args['offset'] ) ) {
				$sql     .= ' OFFSET %d';
				$params[] = absint( $args['offset'] );
			}
		}

		if ( $params ) {
			$sql = $wpdb->prepare( $sql, $params );
		}

		return $wpdb->get_results( $sql, ARRAY_A ) ?: array();
	}

	/**
	 * Insert a new row from raw input. Unknown keys are dropped.
	 *
	 * @param array<string,mixed> $data Raw input keyed by column.
	 * @return int|false New row id, or false on failure.
	 */
	public static function create( array $data ) {
		global $wpdb;

		$clean               = static::sanitize( $data );
		$now                 = current_time( 'mysql' );
		$clean['created_at'] = $now;
		$clean['updated_at'] = $now;

		$result = $wpdb->insert( static::table(), $clean );
		return $result ? (int) $wpdb->insert_id : false;
	}

	/**
	 * Update an existing row. Unknown keys are dropped.
	 *
	 * @param int                 $id   Row id.
	 * @param array<string,mixed> $data Raw input keyed by column.
	 * @return bool True on success (including a no-op match), false on error.
	 */
	public static function update( $id, array $data ) {
		global $wpdb;

		$clean = static::sanitize( $data );
		if ( ! $clean ) {
			return false;
		}
		$clean['updated_at'] = current_time( 'mysql' );

		$result = $wpdb->update( static::table(), $clean, array( 'id' => absint( $id ) ) );
		return false !== $result;
	}

	/**
	 * Delete a row by primary key.
	 *
	 * @param int $id Row id.
	 * @return bool
	 */
	public static function delete( $id ) {
		global $wpdb;
		return (bool) $wpdb->delete( static::table(), array( 'id' => absint( $id ) ) );
	}

	/**
	 * Sanitize raw input against the subclass schema.
	 *
	 * @param array<string,mixed> $data Raw input.
	 * @return array<string,mixed> Clean column => value pairs.
	 */
	protected static function sanitize( array $data ) {
		$clean  = array();
		$schema = static::schema();

		foreach ( $schema as $column => $type ) {
			if ( ! array_key_exists( $column, $data ) ) {
				continue;
			}
			$value = $data[ $column ];

			switch ( $type ) {
				case 'int':
					$clean[ $column ] = ( null === $value || '' === $value ) ? null : absint( $value );
					break;
				case 'bool':
					$clean[ $column ] = ( $value && '0' !== $value ) ? 1 : 0;
					break;
				case 'decimal':
					$clean[ $column ] = number_format( (float) $value, 2, '.', '' );
					break;
				case 'datetime':
					// Accept an HTML datetime-local value (Y-m-dTH:i) or a MySQL
					// datetime; store normalized wall-clock 'Y-m-d H:i:s', or NULL
					// when empty/unparseable (the column is DATETIME NULL).
					$raw = str_replace( 'T', ' ', trim( (string) $value ) );
					if ( '' === $raw ) {
						$clean[ $column ] = null;
						break;
					}
					$dt               = date_create( $raw );
					$clean[ $column ] = $dt ? $dt->format( 'Y-m-d H:i:s' ) : null;
					break;
				case 'date':
					// Accept an HTML date input (Y-m-d) or any parseable date; store
					// 'Y-m-d', or NULL when empty/unparseable (the column is DATE NULL).
					$raw = trim( (string) $value );
					if ( '' === $raw ) {
						$clean[ $column ] = null;
						break;
					}
					$d                = date_create( $raw );
					$clean[ $column ] = $d ? $d->format( 'Y-m-d' ) : null;
					break;
				case 'email':
					$clean[ $column ] = sanitize_email( $value );
					break;
				case 'textarea':
					$clean[ $column ] = sanitize_textarea_field( $value );
					break;
				case 'text':
				default:
					$clean[ $column ] = sanitize_text_field( $value );
					break;
			}
		}

		return $clean;
	}

	/**
	 * Whether a column is part of the writable schema or a managed field.
	 *
	 * @param string $column Column name.
	 * @return bool
	 */
	protected static function is_known_column( $column ) {
		$known = array_merge(
			array( 'id', 'created_at', 'updated_at' ),
			array_keys( static::schema() )
		);
		return in_array( $column, $known, true );
	}
}
