<?php
/**
 * Shared base for estimate/invoice line items.
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Common data access for a document's line items (estimate_items, invoice_items).
 * Each line carries an editable point-in-time snapshot (description, quantity,
 * unit_price) plus an optional source (a services/parts catalog row it was seeded
 * from). Subclasses only specify their table and the parent foreign-key column.
 */
abstract class AMAT_Line_Item_Model extends AMAT_Base_Model {

	/**
	 * The foreign-key column pointing at the owning document, e.g. 'estimate_id'.
	 *
	 * @return string
	 */
	abstract protected static function parent_column();

	/**
	 * {@inheritDoc}
	 *
	 * quantity/unit_price are handled in sanitize() (not listed) so quantity
	 * defaults to 1 and unit_price stores NULL when blank rather than 0.00.
	 */
	protected static function schema() {
		return array(
			static::parent_column() => 'int',
			'source_type'           => 'text',
			'source_id'             => 'int',
			'description'           => 'text',
			'sort_order'            => 'int',
		);
	}

	/**
	 * Sanitize, normalizing quantity (blank/zero → 1) and unit_price (blank → NULL).
	 *
	 * @param array<string,mixed> $data Raw input.
	 * @return array<string,mixed>
	 */
	protected static function sanitize( array $data ) {
		$clean = parent::sanitize( $data );

		if ( array_key_exists( 'quantity', $data ) ) {
			$qty               = (float) $data['quantity'];
			$clean['quantity'] = number_format( $qty > 0 ? $qty : 1, 2, '.', '' );
		}
		if ( array_key_exists( 'unit_price', $data ) ) {
			$clean['unit_price'] = AMAT_Money::sanitize( $data['unit_price'] );
		}

		return $clean;
	}

	/**
	 * Line items for a document, in order.
	 *
	 * @param int $parent_id Owning document id.
	 * @return array<int,array<string,mixed>>
	 */
	public static function for_parent( $parent_id ) {
		return self::all(
			array( static::parent_column() => absint( $parent_id ) ),
			array( 'orderby' => 'sort_order', 'order' => 'ASC' )
		);
	}

	/**
	 * Replace a document's line items with the submitted ordered set.
	 *
	 * Delete the document's existing items, then re-insert the submitted set.
	 * Each $row is a raw array with description/quantity/unit_price/source_type/
	 * source_id; rows with a blank description are skipped.
	 *
	 * @param int                            $parent_id Owning document id.
	 * @param array<int,array<string,mixed>> $rows      Ordered line rows.
	 * @return void
	 */
	public static function replace_for_parent( $parent_id, array $rows ) {
		global $wpdb;

		$parent_id = absint( $parent_id );
		$column    = static::parent_column();
		$wpdb->delete( static::table(), array( $column => $parent_id ) );

		$order = 0;
		foreach ( $rows as $row ) {
			$description = sanitize_text_field( (string) ( $row['description'] ?? '' ) );
			if ( '' === trim( $description ) ) {
				continue;
			}
			self::create(
				array(
					$column        => $parent_id,
					'source_type'  => (string) ( $row['source_type'] ?? 'service' ),
					'source_id'    => (int) ( $row['source_id'] ?? 0 ),
					'description'  => $description,
					'quantity'     => $row['quantity'] ?? 1,
					'unit_price'   => $row['unit_price'] ?? null,
					'sort_order'   => $order++,
				)
			);
		}
	}

	/**
	 * Extended amount for one line (quantity × unit_price), 0 when no price.
	 *
	 * @param array<string,mixed> $row Line row.
	 * @return float
	 */
	public static function line_amount( array $row ) {
		$qty   = (float) ( $row['quantity'] ?? 0 );
		$price = ( null === ( $row['unit_price'] ?? null ) || '' === ( $row['unit_price'] ?? '' ) )
			? 0.0
			: (float) $row['unit_price'];
		return $qty * $price;
	}

	/**
	 * Total of all line amounts for a document.
	 *
	 * @param int $parent_id Owning document id.
	 * @return float
	 */
	public static function total_for_parent( $parent_id ) {
		$total = 0.0;
		foreach ( self::for_parent( $parent_id ) as $row ) {
			$total += self::line_amount( $row );
		}
		return $total;
	}
}
