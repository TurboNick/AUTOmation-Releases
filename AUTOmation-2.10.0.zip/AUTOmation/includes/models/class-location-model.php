<?php
/**
 * Location model.
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Data access for the locations table.
 *
 * A location belongs to one customer. At most one per customer is is_primary
 * (default service address) and at most one is_billing (address sent to Wave).
 * See §4 of CLAUDE.md.
 */
class AMAT_Location_Model extends AMAT_Base_Model {

	/**
	 * {@inheritDoc}
	 */
	protected static function table_slug() {
		return 'locations';
	}

	/**
	 * {@inheritDoc}
	 */
	protected static function schema() {
		return array(
			'customer_id' => 'int',
			'label'       => 'text',
			'is_primary'  => 'bool',
			'is_billing'  => 'bool',
			'is_active'   => 'bool',
			'street_1'    => 'text',
			'street_2'    => 'text',
			'city'        => 'text',
			'state'       => 'text',
			'zipcode'     => 'text',
			'code'        => 'text',
			'notes'       => 'textarea',
		);
	}

	/**
	 * Sentinel customer_id marking a location as the business's own (a shop),
	 * not a customer's. Business locations live in this same table so a job's
	 * location_id can reference them with no schema change (see CLAUDE.md §4).
	 *
	 * @var int
	 */
	const BUSINESS_OWNER_ID = 0;

	/**
	 * All locations for a customer.
	 *
	 * @param int $customer_id Customer id.
	 * @return array<int,array<string,mixed>>
	 */
	public static function for_customer( $customer_id ) {
		return self::all(
			array( 'customer_id' => absint( $customer_id ) ),
			array( 'orderby' => 'is_primary', 'order' => 'DESC' )
		);
	}

	/**
	 * The business's own locations (shops), ordered by label.
	 *
	 * @param bool $include_inactive Whether to include disabled shops.
	 * @return array<int,array<string,mixed>>
	 */
	public static function business_locations( $include_inactive = false ) {
		$rows = self::all( array( 'customer_id' => self::BUSINESS_OWNER_ID ), array( 'orderby' => 'label', 'order' => 'ASC' ) );
		if ( ! $include_inactive ) {
			$rows = array_values(
				array_filter(
					$rows,
					static function ( $r ) {
						return ! empty( $r['is_active'] );
					}
				)
			);
		}
		// all() orders by id (label isn't a guaranteed sort there); enforce label order.
		usort(
			$rows,
			static function ( $a, $b ) {
				return strcasecmp( (string) $a['label'], (string) $b['label'] );
			}
		);
		return $rows;
	}

	/**
	 * The customer's primary (default service) location, or null.
	 *
	 * @param int $customer_id Customer id.
	 * @return array<string,mixed>|null
	 */
	public static function primary_for_customer( $customer_id ) {
		$rows = self::all(
			array( 'customer_id' => absint( $customer_id ), 'is_primary' => 1 ),
			array( 'limit' => 1 )
		);
		return $rows[0] ?? null;
	}

	/**
	 * The customer's billing location (for Wave), or null.
	 *
	 * @param int $customer_id Customer id.
	 * @return array<string,mixed>|null
	 */
	public static function billing_for_customer( $customer_id ) {
		$rows = self::all(
			array( 'customer_id' => absint( $customer_id ), 'is_billing' => 1 ),
			array( 'limit' => 1 )
		);
		return $rows[0] ?? null;
	}

	/**
	 * Ensure only one of the customer's locations carries the given flag.
	 *
	 * Clears the flag on every other location for the customer, leaving it set
	 * only on $keep_id. Use after saving a location flagged primary/billing.
	 *
	 * @param int    $customer_id Customer id.
	 * @param int    $keep_id     Location id that keeps the flag.
	 * @param string $flag        'is_primary' or 'is_billing'.
	 * @return void
	 */
	public static function make_sole_flag( $customer_id, $keep_id, $flag ) {
		global $wpdb;

		// Whitelist the column name — it is interpolated, never user input.
		if ( ! in_array( $flag, array( 'is_primary', 'is_billing' ), true ) ) {
			return;
		}

		$table = static::table();
		$wpdb->query(
			$wpdb->prepare(
				"UPDATE {$table} SET {$flag} = 0 WHERE customer_id = %d AND id <> %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $flag is whitelisted above.
				absint( $customer_id ),
				absint( $keep_id )
			)
		);
	}

	/**
	 * Valid US state/territory two-letter codes (uppercase).
	 *
	 * Used to validate the State field (which takes a 2-letter code, not a
	 * dropdown — see the Testing Feedback in CLAUDE.md) and to drive the
	 * mobile-friendly autocomplete datalist on the form.
	 *
	 * @return string[]
	 */
	public static function state_codes() {
		return array(
			'AL', 'AK', 'AZ', 'AR', 'CA', 'CO', 'CT', 'DE', 'FL', 'GA',
			'HI', 'ID', 'IL', 'IN', 'IA', 'KS', 'KY', 'LA', 'ME', 'MD',
			'MA', 'MI', 'MN', 'MS', 'MO', 'MT', 'NE', 'NV', 'NH', 'NJ',
			'NM', 'NY', 'NC', 'ND', 'OH', 'OK', 'OR', 'PA', 'RI', 'SC',
			'SD', 'TN', 'TX', 'UT', 'VT', 'VA', 'WA', 'WV', 'WI', 'WY',
			'DC', 'AS', 'GU', 'MP', 'PR', 'VI',
		);
	}

	/**
	 * Whether a value is a valid US state/territory code (case-insensitive).
	 *
	 * @param string $code Candidate code.
	 * @return bool
	 */
	public static function is_valid_state( $code ) {
		return in_array( strtoupper( trim( (string) $code ) ), self::state_codes(), true );
	}

	/**
	 * One-line address for a location row.
	 *
	 * @param array<string,mixed> $loc Location row.
	 * @return string
	 */
	public static function one_line( array $loc ) {
		$street = trim( ( $loc['street_1'] ?? '' ) . ' ' . ( $loc['street_2'] ?? '' ) );
		$tail   = trim( ( $loc['city'] ?? '' ) . ' ' . ( $loc['state'] ?? '' ) . ' ' . ( $loc['zipcode'] ?? '' ) );
		$parts  = array_filter( array( $street, $tail ), static fn( $p ) => '' !== trim( $p ) );
		return implode( ', ', $parts );
	}

	/**
	 * A maps URL for a location's address, for tap-to-navigate in the field, or
	 * '' when the location has no address. Uses the cross-platform Google Maps
	 * search URL (opens the device's default map app where one is installed).
	 *
	 * @param array<string,mixed> $loc Location row.
	 * @return string
	 */
	public static function map_url( array $loc ) {
		$address = self::one_line( $loc );
		if ( '' === trim( $address ) ) {
			return '';
		}
		return 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( $address );
	}
}
