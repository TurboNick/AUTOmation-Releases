<?php
/**
 * Estimate model.
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A native, customer-owned estimate document (DB v7). Optionally linked to a job
 * and vehicle. Line items live in estimate_items; the total is computed from them
 * (AMAT_Estimate_Item_Model::total_for_parent), not stored. Sending/PDF/approval
 * are delegated to a provider integration (e.g. Wave) via the external_refs link.
 */
class AMAT_Estimate_Model extends AMAT_Base_Model {

	/**
	 * Allowed estimate statuses, in lifecycle order (DB v15).
	 *
	 * Rich enough to record everything a provider or the future portal can tell
	 * us, so nothing is lost in translation. The lifecycle is:
	 *
	 *     draft → sent → (viewed) → accepted | approved → [convert to invoice]
	 *                             ↘ declined | expired
	 *
	 * Three states worth explaining:
	 *
	 * - `accepted` vs `approved` — **both mean "this estimate has the go-ahead",
	 *   and both come AFTER it is sent.** The difference is *who* gave it:
	 *   `accepted` is the customer saying yes; `approved` is the owner recording
	 *   the go-ahead himself (the customer agreed by phone, say). Either one is
	 *   what makes the estimate convertible to an invoice. They are **not** a
	 *   draft-finalizing step — the owner does not approve his own drafts.
	 *   (Before v15 `approved` carried the customer's meaning; those rows migrated
	 *   to `accepted`.)
	 * - `viewed` — the customer opened it but has not decided. Only observable via
	 *   a provider today; the portal will report it natively later.
	 * - `void` — cancelled (DB v16). A document is a point-in-time record, so its
	 *   cancellation belongs *on* it where you can read it, not behind a
	 *   soft-delete flag that quietly filters it out of view. (This is why
	 *   estimates/invoices have no `is_active`, unlike vehicles/locations.) Note
	 *   `void` has no counterpart in Wave's vocabulary — it is a core state.
	 *
	 * Deliberately absent: **converted** — the estimate→invoice *link* is the
	 * source of truth for "converted" (§4), so a converted estimate keeps its
	 * accepted/approved status on record instead of having it overwritten.
	 *
	 * @var string[]
	 */
	const STATUSES = array( 'draft', 'sent', 'viewed', 'accepted', 'approved', 'declined', 'expired', 'void' );

	/**
	 * {@inheritDoc}
	 */
	protected static function table_slug() {
		return 'estimates';
	}

	/**
	 * {@inheritDoc}
	 */
	protected static function schema() {
		return array(
			'customer_id' => 'int',
			'job_id'      => 'int',
			'vehicle_id'  => 'int',
			'number'      => 'text',
			'status'      => 'text',
			'issue_date'  => 'date',
			'valid_until' => 'date',
			'notes'       => 'textarea',
		);
	}

	/**
	 * Validate status against the allowed set (default 'draft').
	 *
	 * @param array<string,mixed> $data Raw input.
	 * @return array<string,mixed>
	 */
	protected static function sanitize( array $data ) {
		$clean = parent::sanitize( $data );
		if ( isset( $clean['status'] ) && ! in_array( $clean['status'], self::STATUSES, true ) ) {
			$clean['status'] = 'draft';
		}
		return $clean;
	}

	/**
	 * Statuses as slug => human label.
	 *
	 * @return array<string,string>
	 */
	public static function statuses_labeled() {
		return array(
			'draft'    => __( 'Draft', 'auto-mation' ),
			'sent'     => __( 'Sent', 'auto-mation' ),
			'viewed'   => __( 'Viewed by customer', 'auto-mation' ),
			'accepted' => __( 'Accepted by customer', 'auto-mation' ),
			'approved' => __( 'Approved by me', 'auto-mation' ),
			'declined' => __( 'Declined by customer', 'auto-mation' ),
			'expired'  => __( 'Expired', 'auto-mation' ),
			'void'     => __( 'Void', 'auto-mation' ),
		);
	}

	/**
	 * Whether an estimate has the go-ahead to become an invoice.
	 *
	 * Either the customer accepted it, or the owner approved it on their behalf —
	 * both are a green light, and both only happen after it is sent.
	 *
	 * @param array<string,mixed>|string $estimate Estimate row, or a status slug.
	 * @return bool
	 */
	public static function is_go_ahead( $estimate ) {
		$status = is_array( $estimate ) ? (string) ( $estimate['status'] ?? '' ) : (string) $estimate;
		return in_array( $status, array( 'accepted', 'approved' ), true );
	}

	/**
	 * Human label for a status slug.
	 *
	 * @param string $status Status slug.
	 * @return string
	 */
	public static function status_label( $status ) {
		$labels = self::statuses_labeled();
		return $labels[ $status ] ?? (string) $status;
	}

	/**
	 * Estimates for a customer, newest first.
	 *
	 * @param int $customer_id Customer id.
	 * @return array<int,array<string,mixed>>
	 */
	public static function for_customer( $customer_id ) {
		return self::all(
			array( 'customer_id' => absint( $customer_id ) ),
			array( 'orderby' => 'id', 'order' => 'DESC' )
		);
	}

	/**
	 * Computed total of an estimate's line items.
	 *
	 * @param int $estimate_id Estimate id.
	 * @return float
	 */
	public static function total( $estimate_id ) {
		return AMAT_Estimate_Item_Model::total_for_parent( $estimate_id );
	}
}
