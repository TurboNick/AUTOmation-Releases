<?php
/**
 * Service model.
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Data access for the services table — the master list of pre-set services used
 * as a default lookup when adding estimate/invoice/job line items. Only the name
 * is required; default_price/default_quantity are optional defaults (NULL when
 * unset) that prefill a line item. Soft-deleted via is_active (§11 of CLAUDE.md).
 */
class AMAT_Service_Model extends AMAT_Base_Model {

	/**
	 * {@inheritDoc}
	 */
	protected static function table_slug() {
		return 'services';
	}

	/**
	 * {@inheritDoc}
	 *
	 * default_price/default_quantity are handled in sanitize() (not listed
	 * here) so an empty input stores NULL rather than a coerced 0.00.
	 */
	protected static function schema() {
		return array(
			'name'        => 'text',
			'description' => 'textarea',
			'is_active'   => 'bool',
			'sort_order'  => 'int',
		);
	}

	/**
	 * Sanitize, treating an empty price/quantity as NULL (unset) rather than a
	 * coerced zero, so "no price" is distinct from "$0.00".
	 *
	 * @param array<string,mixed> $data Raw input.
	 * @return array<string,mixed>
	 */
	protected static function sanitize( array $data ) {
		$clean = parent::sanitize( $data );

		if ( array_key_exists( 'default_price', $data ) ) {
			$clean['default_price'] = AMAT_Money::sanitize( $data['default_price'] );
		}
		if ( array_key_exists( 'default_quantity', $data ) ) {
			$clean['default_quantity'] = AMAT_Money::sanitize( $data['default_quantity'] );
		}

		return $clean;
	}

	/**
	 * Active services, ordered for the picker (sort_order, then name).
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public static function active() {
		$rows = self::all( array( 'is_active' => 1 ), array( 'orderby' => 'sort_order', 'order' => 'ASC' ) );
		usort(
			$rows,
			static function ( $a, $b ) {
				$cmp = ( (int) $a['sort_order'] <=> (int) $b['sort_order'] );
				return 0 !== $cmp ? $cmp : strcasecmp( (string) $a['name'], (string) $b['name'] );
			}
		);
		return $rows;
	}

	/**
	 * All services, name-ordered, for the management list.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public static function all_by_name() {
		$rows = self::all();
		usort(
			$rows,
			static function ( $a, $b ) {
				return strcasecmp( (string) $a['name'], (string) $b['name'] );
			}
		);
		return $rows;
	}

	/**
	 * Format a stored price for display (e.g. "$45.00"), or '' when unset.
	 *
	 * @param mixed $price Stored price (null when unset).
	 * @return string
	 */
	public static function format_price( $price ) {
		if ( null === $price || '' === $price ) {
			return '';
		}
		return '$' . number_format( (float) $price, 2 );
	}

}
