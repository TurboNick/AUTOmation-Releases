<?php
/**
 * Part model.
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Data access for the parts table — the master list of pre-set parts a job can
 * include, mirroring services (the job keeps a notes field alongside). Only the
 * name is required; price is optional and stored as NULL when unset.
 * Soft-deleted via is_active (§11 of CLAUDE.md).
 *
 * Unlike services, parts have no duration and are NOT mirrored to per-part Wave
 * products — when parts feed Wave estimates/invoices they roll into a single
 * generic "Parts" product with the detail in the line description (§11), so
 * there is intentionally no wave_product_id here.
 */
class AMAT_Part_Model extends AMAT_Base_Model {

	/**
	 * {@inheritDoc}
	 */
	protected static function table_slug() {
		return 'parts';
	}

	/**
	 * {@inheritDoc}
	 *
	 * default_price is handled in sanitize() (not listed here) so an empty
	 * input stores NULL rather than a coerced 0.00.
	 */
	protected static function schema() {
		return array(
			'name'        => 'text',
			'description' => 'textarea',
			'is_active'   => 'bool',
			'sort_order'  => 'int',
		);
	}

	/**
	 * Sanitize, treating an empty price as NULL (unset) rather than a coerced
	 * zero, so "no price" is distinct from "$0.00".
	 *
	 * @param array<string,mixed> $data Raw input.
	 * @return array<string,mixed>
	 */
	protected static function sanitize( array $data ) {
		$clean = parent::sanitize( $data );

		if ( array_key_exists( 'default_price', $data ) ) {
			$clean['default_price'] = AMAT_Money::sanitize( $data['default_price'] );
		}
		if ( array_key_exists( 'default_quantity', $data ) ) {
			$clean['default_quantity'] = AMAT_Money::sanitize( $data['default_quantity'] );
		}

		return $clean;
	}

	/**
	 * Active parts, ordered for the picker (sort_order, then name).
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public static function active() {
		$rows = self::all( array( 'is_active' => 1 ), array( 'orderby' => 'sort_order', 'order' => 'ASC' ) );
		usort(
			$rows,
			static function ( $a, $b ) {
				$cmp = ( (int) $a['sort_order'] <=> (int) $b['sort_order'] );
				return 0 !== $cmp ? $cmp : strcasecmp( (string) $a['name'], (string) $b['name'] );
			}
		);
		return $rows;
	}

	/**
	 * All parts, name-ordered, for the management list.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public static function all_by_name() {
		$rows = self::all();
		usort(
			$rows,
			static function ( $a, $b ) {
				return strcasecmp( (string) $a['name'], (string) $b['name'] );
			}
		);
		return $rows;
	}

	/**
	 * Format a stored price for display (e.g. "$45.00"), or '' when unset.
	 *
	 * @param mixed $price Stored price (null when unset).
	 * @return string
	 */
	public static function format_price( $price ) {
		if ( null === $price || '' === $price ) {
			return '';
		}
		return '$' . number_format( (float) $price, 2 );
	}
}
