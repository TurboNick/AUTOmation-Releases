<?php
/**
 * Vehicle model.
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Data access for the vehicles table.
 *
 * A vehicle belongs to one customer and has many jobs and service records.
 * Most spec fields are auto-populated from the NHTSA vPIC VIN decode
 * (see AMAT_Vin_Decoder and §7 of CLAUDE.md); license_plate/color/color_code
 * are entered manually.
 */
class AMAT_Vehicle_Model extends AMAT_Base_Model {

	/**
	 * {@inheritDoc}
	 */
	protected static function table_slug() {
		return 'vehicles';
	}

	/**
	 * {@inheritDoc}
	 */
	protected static function schema() {
		return array(
			'customer_id'         => 'int',
			'is_active'           => 'bool',
			'vin'                 => 'text',
			'year'                => 'int',
			'make'                => 'text',
			'model'               => 'text',
			'trim'                => 'text',
			'series'              => 'text',
			'body_type'           => 'text',
			'engine_displacement' => 'text',
			'engine_cylinders'    => 'text',
			'fuel_type_primary'   => 'text',
			'fuel_type_secondary' => 'text',
			'drive_type'          => 'text',
			'transmission_type'   => 'text',
			'transmission_speeds' => 'text',
			'license_plate'       => 'text',
			'color'               => 'text',
			'color_code'          => 'text',
			'warnings'            => 'textarea',
			'notes'               => 'textarea',
		);
	}

	/**
	 * All vehicles belonging to a customer.
	 *
	 * @param int $customer_id Customer id.
	 * @return array<int,array<string,mixed>>
	 */
	public static function for_customer( $customer_id ) {
		return self::all(
			array( 'customer_id' => absint( $customer_id ) ),
			array( 'orderby' => 'make', 'order' => 'ASC' )
		);
	}

	/**
	 * Search vehicles by make, model, VIN, plate, or year.
	 *
	 * @param string $term Raw search term.
	 * @return array<int,array<string,mixed>>
	 */
	public static function search( $term ) {
		global $wpdb;

		$term = trim( (string) $term );
		if ( '' === $term ) {
			return self::all( array(), array( 'orderby' => 'make', 'order' => 'ASC' ) );
		}

		$table = static::table();
		$like  = '%' . $wpdb->esc_like( $term ) . '%';
		$sql   = $wpdb->prepare(
			"SELECT * FROM {$table}
			 WHERE make LIKE %s OR model LIKE %s OR vin LIKE %s OR license_plate LIKE %s OR year LIKE %s
			 ORDER BY make ASC, model ASC",
			$like,
			$like,
			$like,
			$like,
			$like
		);

		return $wpdb->get_results( $sql, ARRAY_A ) ?: array();
	}

	/**
	 * A short label for a vehicle row, e.g. "2019 Toyota Camry".
	 *
	 * @param array<string,mixed> $vehicle Vehicle row.
	 * @return string
	 */
	public static function label( array $vehicle ) {
		$parts = array_filter(
			array(
				(string) ( $vehicle['year'] ?? '' ),
				(string) ( $vehicle['make'] ?? '' ),
				(string) ( $vehicle['model'] ?? '' ),
			),
			static fn( $p ) => '' !== trim( $p )
		);
		$label = trim( implode( ' ', $parts ) );
		return '' !== $label ? $label : __( '(unspecified vehicle)', 'auto-mation' );
	}
}
