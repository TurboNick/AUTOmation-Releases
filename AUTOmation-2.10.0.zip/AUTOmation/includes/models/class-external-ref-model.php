<?php
/**
 * External reference model.
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Generic, provider-agnostic link between a local AUTOmation entity and its ID
 * in an external system (e.g. a Wave customer/estimate/invoice). This is the one
 * mechanism a companion integration plugin uses to remember what it has synced —
 * core never hard-codes a provider or stores provider IDs on entity tables.
 *
 * One row per (provider, entity_type, entity_id). entity_type is a free string
 * the provider chooses (e.g. 'customer', 'estimate', 'invoice', 'product').
 */
class AMAT_External_Ref_Model extends AMAT_Base_Model {

	/**
	 * {@inheritDoc}
	 */
	protected static function table_slug() {
		return 'external_refs';
	}

	/**
	 * {@inheritDoc}
	 */
	protected static function schema() {
		return array(
			'provider'    => 'text',
			'entity_type' => 'text',
			'entity_id'   => 'int',
			'external_id' => 'text',
			'status'      => 'text',
			'synced_at'   => 'datetime',
		);
	}

	/**
	 * The stored row linking one entity to one provider, or null when none.
	 *
	 * @param string $provider    Provider slug (e.g. 'wave').
	 * @param string $entity_type Entity type (e.g. 'customer').
	 * @param int    $entity_id   Local entity id.
	 * @return array<string,mixed>|null
	 */
	public static function get( $provider, $entity_type, $entity_id ) {
		$rows = self::all(
			array(
				'provider'    => sanitize_text_field( $provider ),
				'entity_type' => sanitize_text_field( $entity_type ),
				'entity_id'   => absint( $entity_id ),
			),
			array( 'limit' => 1 )
		);
		return $rows ? $rows[0] : null;
	}

	/**
	 * The external ID for an entity/provider, or '' when not linked.
	 *
	 * @param string $provider    Provider slug.
	 * @param string $entity_type Entity type.
	 * @param int    $entity_id   Local entity id.
	 * @return string
	 */
	public static function external_id( $provider, $entity_type, $entity_id ) {
		$row = self::get( $provider, $entity_type, $entity_id );
		return $row ? (string) $row['external_id'] : '';
	}

	/**
	 * Create or update the link for an entity/provider (upsert).
	 *
	 * @param string               $provider    Provider slug.
	 * @param string               $entity_type Entity type.
	 * @param int                  $entity_id   Local entity id.
	 * @param string               $external_id External system's ID.
	 * @param array<string,mixed>  $extra       Optional 'status' / 'synced_at'.
	 * @return int|false Row id on success, false on failure.
	 */
	public static function set( $provider, $entity_type, $entity_id, $external_id, array $extra = array() ) {
		$data = array(
			'provider'    => sanitize_text_field( $provider ),
			'entity_type' => sanitize_text_field( $entity_type ),
			'entity_id'   => absint( $entity_id ),
			'external_id' => sanitize_text_field( $external_id ),
		);
		if ( array_key_exists( 'status', $extra ) ) {
			$data['status'] = $extra['status'];
		}
		if ( array_key_exists( 'synced_at', $extra ) ) {
			$data['synced_at'] = $extra['synced_at'];
		}

		$existing = self::get( $provider, $entity_type, $entity_id );
		if ( $existing ) {
			return self::update( (int) $existing['id'], $data ) ? (int) $existing['id'] : false;
		}
		return self::create( $data );
	}

	/**
	 * Remove the link for one entity/provider.
	 *
	 * @param string $provider    Provider slug.
	 * @param string $entity_type Entity type.
	 * @param int    $entity_id   Local entity id.
	 * @return bool
	 */
	public static function forget( $provider, $entity_type, $entity_id ) {
		$row = self::get( $provider, $entity_type, $entity_id );
		return $row ? self::delete( (int) $row['id'] ) : false;
	}

	/**
	 * All links for a provider, optionally filtered to one entity type.
	 *
	 * @param string $provider    Provider slug.
	 * @param string $entity_type Optional entity type filter.
	 * @return array<int,array<string,mixed>>
	 */
	public static function all_for( $provider, $entity_type = '' ) {
		$where = array( 'provider' => sanitize_text_field( $provider ) );
		if ( '' !== $entity_type ) {
			$where['entity_type'] = sanitize_text_field( $entity_type );
		}
		return self::all( $where );
	}

	/**
	 * Count links for a provider, optionally by entity type.
	 *
	 * @param string $provider    Provider slug.
	 * @param string $entity_type Optional entity type filter.
	 * @return int
	 */
	public static function count_for( $provider, $entity_type = '' ) {
		return count( self::all_for( $provider, $entity_type ) );
	}

	/**
	 * Delete every link for a provider (the generic "unlink from <provider>").
	 *
	 * @param string $provider Provider slug.
	 * @return int Number of links cleared.
	 */
	public static function clear_for_provider( $provider ) {
		global $wpdb;
		return (int) $wpdb->delete( static::table(), array( 'provider' => sanitize_text_field( $provider ) ) );
	}
}
