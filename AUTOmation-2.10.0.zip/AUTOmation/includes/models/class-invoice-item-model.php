<?php
/**
 * Invoice line-item model.
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Line items belonging to an invoice. See AMAT_Line_Item_Model for the shared
 * behaviour; this class only binds the table and parent foreign key.
 */
class AMAT_Invoice_Item_Model extends AMAT_Line_Item_Model {

	/**
	 * {@inheritDoc}
	 */
	protected static function table_slug() {
		return 'invoice_items';
	}

	/**
	 * {@inheritDoc}
	 */
	protected static function parent_column() {
		return 'invoice_id';
	}
}
