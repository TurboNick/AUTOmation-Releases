<?php
/**
 * Invoice model.
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A native, customer-owned invoice document (DB v7). Optionally converted from an
 * estimate and/or linked to a job and vehicle. Line items live in invoice_items;
 * the total is computed from them. Payment fields (status/amount_paid/paid_date)
 * are updated by a provider integration (e.g. Wave) reading payment status back.
 */
class AMAT_Invoice_Model extends AMAT_Base_Model {

	/**
	 * Allowed invoice statuses, in lifecycle order (DB v15).
	 *
	 * Rich enough to hold everything a payment provider can report, so a sync
	 * loses nothing: `approved` (the owner finalized his draft) and `viewed` (the
	 * customer opened it) join the payment states, and `unpaid`/`overpaid` are
	 * distinct from `paid`/`partial` rather than being flattened into them.
	 *
	 * `void` is cancellation (DB v16): a document is a point-in-time record, so
	 * its cancellation is said out loud on the record rather than hidden behind a
	 * soft-delete flag — which is why invoices/estimates carry no `is_active`,
	 * unlike vehicles/locations. Voiding locally must never delete the provider's
	 * copy: over there it is an accounting record. Note `void` has no counterpart
	 * in Wave's vocabulary — it is a core state.
	 *
	 * @var string[]
	 */
	const STATUSES = array( 'draft', 'approved', 'sent', 'viewed', 'unpaid', 'partial', 'paid', 'overpaid', 'overdue', 'void' );

	/**
	 * {@inheritDoc}
	 */
	protected static function table_slug() {
		return 'invoices';
	}

	/**
	 * {@inheritDoc}
	 *
	 * amount_paid is handled in sanitize() (NULL when blank, not 0.00).
	 */
	protected static function schema() {
		return array(
			'customer_id' => 'int',
			'estimate_id' => 'int',
			'job_id'      => 'int',
			'vehicle_id'  => 'int',
			'number'      => 'text',
			'status'      => 'text',
			'issue_date'  => 'date',
			'due_date'    => 'date',
			'paid_date'   => 'date',
			'notes'       => 'textarea',
		);
	}

	/**
	 * Validate status (default 'draft') and normalize amount_paid (blank → NULL).
	 *
	 * @param array<string,mixed> $data Raw input.
	 * @return array<string,mixed>
	 */
	protected static function sanitize( array $data ) {
		$clean = parent::sanitize( $data );
		if ( isset( $clean['status'] ) && ! in_array( $clean['status'], self::STATUSES, true ) ) {
			$clean['status'] = 'draft';
		}
		if ( array_key_exists( 'amount_paid', $data ) ) {
			$clean['amount_paid'] = AMAT_Money::sanitize( $data['amount_paid'] );
		}
		return $clean;
	}

	/**
	 * Statuses as slug => human label.
	 *
	 * @return array<string,string>
	 */
	public static function statuses_labeled() {
		return array(
			'draft'    => __( 'Draft', 'auto-mation' ),
			'approved' => __( 'Approved by me', 'auto-mation' ),
			'sent'     => __( 'Sent', 'auto-mation' ),
			'viewed'   => __( 'Viewed by customer', 'auto-mation' ),
			'unpaid'   => __( 'Unpaid', 'auto-mation' ),
			'partial'  => __( 'Partially paid', 'auto-mation' ),
			'paid'     => __( 'Paid', 'auto-mation' ),
			'overpaid' => __( 'Overpaid', 'auto-mation' ),
			'overdue'  => __( 'Overdue', 'auto-mation' ),
			'void'     => __( 'Void', 'auto-mation' ),
		);
	}

	/**
	 * Human label for a status slug.
	 *
	 * @param string $status Status slug.
	 * @return string
	 */
	public static function status_label( $status ) {
		$labels = self::statuses_labeled();
		return $labels[ $status ] ?? (string) $status;
	}

	/**
	 * Invoices for a customer, newest first.
	 *
	 * @param int $customer_id Customer id.
	 * @return array<int,array<string,mixed>>
	 */
	public static function for_customer( $customer_id ) {
		return self::all(
			array( 'customer_id' => absint( $customer_id ) ),
			array( 'orderby' => 'id', 'order' => 'DESC' )
		);
	}

	/**
	 * Computed total of an invoice's line items.
	 *
	 * @param int $invoice_id Invoice id.
	 * @return float
	 */
	public static function total( $invoice_id ) {
		return AMAT_Invoice_Item_Model::total_for_parent( $invoice_id );
	}

	/**
	 * The invoice converted from a given estimate, or null when none exists yet.
	 * The estimate→invoice link is the source of truth for "converted".
	 *
	 * @param int $estimate_id Estimate id.
	 * @return array<string,mixed>|null
	 */
	public static function for_estimate( $estimate_id ) {
		$rows = self::all( array( 'estimate_id' => absint( $estimate_id ) ), array( 'limit' => 1 ) );
		return $rows ? $rows[0] : null;
	}

	/**
	 * Create a draft invoice from an approved estimate: copy customer/vehicle/job,
	 * link the estimate, and copy its line items. The estimate stays on record
	 * (its status/approval is unchanged). Returns the new invoice id.
	 *
	 * @param array<string,mixed> $estimate Estimate row.
	 * @return int|false New invoice id, or false on failure.
	 */
	public static function create_from_estimate( array $estimate ) {
		$eid = (int) ( $estimate['id'] ?? 0 );
		$id  = self::create(
			array(
				'customer_id' => (int) ( $estimate['customer_id'] ?? 0 ),
				'estimate_id' => $eid,
				'job_id'      => (int) ( $estimate['job_id'] ?? 0 ),
				'vehicle_id'  => (int) ( $estimate['vehicle_id'] ?? 0 ),
				'status'      => 'draft',
				'issue_date'  => gmdate( 'Y-m-d', current_time( 'timestamp' ) ),
				'notes'       => (string) ( $estimate['notes'] ?? '' ),
			)
		);
		if ( ! $id ) {
			return false;
		}

		$rows = array();
		foreach ( AMAT_Estimate_Item_Model::for_parent( $eid ) as $item ) {
			$rows[] = array(
				'source_type' => (string) ( $item['source_type'] ?? 'service' ),
				'source_id'   => (int) ( $item['source_id'] ?? 0 ),
				'description' => (string) $item['description'],
				'quantity'    => $item['quantity'] ?? 1,
				'unit_price'  => $item['unit_price'] ?? null,
			);
		}
		AMAT_Invoice_Item_Model::replace_for_parent( $id, $rows );

		return $id;
	}
}
