<?php
/**
 * Service record model.
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Data access for the service_records table.
 *
 * A completed job produces one service record tied to the vehicle. The link
 * to the job invoice is via job_id -> jobs.wave_invoice_id (§4 of CLAUDE.md).
 */
class AMAT_Service_Record_Model extends AMAT_Base_Model {

	/**
	 * {@inheritDoc}
	 */
	protected static function table_slug() {
		return 'service_records';
	}

	/**
	 * {@inheritDoc}
	 */
	protected static function schema() {
		return array(
			'vehicle_id'         => 'int',
			'job_id'             => 'int',
			'description'        => 'textarea',
			'date_completed'     => 'text',
			'mileage_at_service' => 'int',
		);
	}

	/**
	 * Service history for a vehicle, most recent first.
	 *
	 * @param int $vehicle_id Vehicle id.
	 * @return array<int,array<string,mixed>>
	 */
	public static function for_vehicle( $vehicle_id ) {
		return self::all( array( 'vehicle_id' => absint( $vehicle_id ) ), array( 'orderby' => 'date_completed' ) );
	}
}
