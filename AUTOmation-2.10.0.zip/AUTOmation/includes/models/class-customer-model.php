<?php
/**
 * Customer model.
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Data access for the customers table.
 *
 * A customer has many locations, vehicles, and jobs, and is linked to one
 * WordPress user account for front-end portal access (§4 of CLAUDE.md).
 */
class AMAT_Customer_Model extends AMAT_Base_Model {

	/**
	 * {@inheritDoc}
	 */
	protected static function table_slug() {
		return 'customers';
	}

	/**
	 * {@inheritDoc}
	 *
	 * Contact details live in the contact_methods table (DB v2); only the
	 * customer's identity/notes are stored here.
	 */
	protected static function schema() {
		return array(
			'wp_user_id'              => 'int',
			'is_active'               => 'bool',
			'first_name'              => 'text',
			'last_name'               => 'text',
			'display_name'            => 'text',
			'notes'                   => 'textarea',
			'referred_by_customer_id' => 'int',
			'referred_by_source'      => 'text',
		);
		// Note: the Wave link moved to the generic external_refs store; the legacy
		// customers.wave_customer_id column is vestigial (migrated on upgrade).
	}

	/**
	 * Non-customer referral sources ("Referred by"), keyed by slug. Hard-coded for
	 * now; a Settings-driven editable list is a Future Feature (§11). This is the
	 * single swap point — labels and validity both flow from here.
	 *
	 * @return array<string,string>
	 */
	public static function referral_sources() {
		return array(
			'facebook'      => __( 'Facebook', 'auto-mation' ),
			'website'       => __( 'Website', 'auto-mation' ),
			'business_card' => __( 'Business Card', 'auto-mation' ),
		);
	}

	/**
	 * Human "Referred by" label for a customer: the referring customer's name (when
	 * referred_by_customer_id is set), else the source label, else '' for none.
	 *
	 * @param array<string,mixed> $customer Customer row.
	 * @return string
	 */
	public static function referred_by_label( array $customer ) {
		$cid = (int) ( $customer['referred_by_customer_id'] ?? 0 );
		if ( $cid ) {
			$ref = self::find( $cid );
			return $ref ? self::display_name( $ref ) : '';
		}
		$src = (string) ( $customer['referred_by_source'] ?? '' );
		$sources = self::referral_sources();
		return $sources[ $src ] ?? '';
	}

	/**
	 * The name to show for a customer.
	 *
	 * display_name is stored only when the user customized it; otherwise it is
	 * blank and we fall back to "First Last" at display time (§1/§4). This is
	 * the single helper the admin/portal should use for a customer's name.
	 *
	 * @param array<string,mixed> $customer Customer row.
	 * @return string
	 */
	public static function display_name( array $customer ) {
		$display = trim( (string) ( $customer['display_name'] ?? '' ) );
		if ( '' !== $display ) {
			return $display;
		}
		return trim( ( $customer['first_name'] ?? '' ) . ' ' . ( $customer['last_name'] ?? '' ) );
	}

	/**
	 * Whether the display name is auto-generated (computed "First Last") rather
	 * than a custom value the user stored. True when the display_name column is
	 * blank — the admin uses this to flag auto names (grey/italic "(Auto)").
	 *
	 * @param array<string,mixed> $customer Customer row.
	 * @return bool
	 */
	public static function is_display_name_auto( array $customer ) {
		return '' === trim( (string) ( $customer['display_name'] ?? '' ) );
	}

	/**
	 * Search customers by name or any contact-method value.
	 *
	 * Matches first/last/display name and the value of any linked contact
	 * method (so searching a phone number or email finds the customer).
	 *
	 * @param string $term        Raw search term.
	 * @param bool   $active_only  Exclude disabled customers (default false).
	 *                             The Customers grid searches ALL rows (its own
	 *                             toggle decides which to show); selection pickers
	 *                             pass true so a disabled customer can't be chosen.
	 * @return array<int,array<string,mixed>>
	 */
	public static function search( $term, $active_only = false ) {
		global $wpdb;

		$term = trim( (string) $term );
		if ( '' === $term ) {
			$where = $active_only ? array( 'is_active' => 1 ) : array();
			return self::all( $where, array( 'orderby' => 'last_name', 'order' => 'ASC' ) );
		}

		$table = static::table();
		$cm     = AMAT_Contact_Method_Model::table();
		$like   = '%' . $wpdb->esc_like( $term ) . '%';
		// A contact value search matches on digits too (stored normalized).
		$digits = preg_replace( '/\D+/', '', $term );
		$like_d = '' !== $digits ? '%' . $wpdb->esc_like( $digits ) . '%' : $like;

		// The OR group must be parenthesized before ANDing the active filter, or
		// AND (higher precedence) would bind to only the last OR term. The suffix
		// is a constant literal — no user input — so it is safe to interpolate.
		$active_sql = $active_only ? ' AND c.is_active = 1' : '';

		$sql = $wpdb->prepare(
			"SELECT DISTINCT c.* FROM {$table} c
			 LEFT JOIN {$cm} m ON m.customer_id = c.id
			 WHERE (c.first_name LIKE %s
			    OR c.last_name LIKE %s
			    OR c.display_name LIKE %s
			    OR CONCAT_WS(' ', c.first_name, c.last_name) LIKE %s
			    OR CONCAT_WS(' ', c.last_name, c.first_name) LIKE %s
			    OR m.value LIKE %s){$active_sql}
			 ORDER BY c.last_name ASC, c.first_name ASC", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $active_sql is a constant literal.
			$like,
			$like,
			$like,
			$like,
			$like,
			$like_d
		);

		return $wpdb->get_results( $sql, ARRAY_A ) ?: array();
	}

	/**
	 * Customers as id => display name, for select dropdowns.
	 *
	 * Includes disabled customers — used by the grid's customer FILTER (where you
	 * may legitimately want to view a disabled customer's records) and the Wave
	 * importer's dedup. For an owner PICKER use active_options() instead.
	 *
	 * @return array<int,string>
	 */
	public static function options() {
		$out = array();
		foreach ( self::all( array(), array( 'orderby' => 'last_name', 'order' => 'ASC' ) ) as $c ) {
			$out[ (int) $c['id'] ] = self::display_name( $c );
		}
		return $out;
	}

	/**
	 * Active customers as id => display name, for owner-selection dropdowns.
	 *
	 * A disabled customer must not be assignable as the owner of a new vehicle /
	 * location / job. When editing a record whose owner has since been disabled,
	 * the caller should still add that one owner back so it stays selectable.
	 *
	 * @return array<int,string>
	 */
	public static function active_options() {
		$out = array();
		foreach ( self::all( array( 'is_active' => 1 ), array( 'orderby' => 'last_name', 'order' => 'ASC' ) ) as $c ) {
			$out[ (int) $c['id'] ] = self::display_name( $c );
		}
		return $out;
	}
}
