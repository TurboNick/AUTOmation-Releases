<?php
/**
 * Estimate line-item model.
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Line items belonging to an estimate. See AMAT_Line_Item_Model for the shared
 * behaviour; this class only binds the table and parent foreign key.
 */
class AMAT_Estimate_Item_Model extends AMAT_Line_Item_Model {

	/**
	 * {@inheritDoc}
	 */
	protected static function table_slug() {
		return 'estimate_items';
	}

	/**
	 * {@inheritDoc}
	 */
	protected static function parent_column() {
		return 'estimate_id';
	}
}
