<?php
/**
 * Parts order model.
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Data access for the parts_orders table.
 *
 * A parts order belongs to one job. Ordering is manual until the O'Reilly API
 * is available (§9 of CLAUDE.md).
 */
class AMAT_Parts_Order_Model extends AMAT_Base_Model {

	/**
	 * Allowed parts-order statuses (§4 status vocabulary).
	 *
	 * @var string[]
	 */
	const STATUSES = array( 'needed', 'ordered', 'received', 'installed' );

	/**
	 * {@inheritDoc}
	 */
	protected static function table_slug() {
		return 'parts_orders';
	}

	/**
	 * {@inheritDoc}
	 */
	protected static function schema() {
		return array(
			'job_id'      => 'int',
			'description' => 'text',
			'part_number' => 'text',
			'supplier'    => 'text',
			'quantity'    => 'int',
			'unit_cost'   => 'decimal',
			'status'      => 'text',
		);
	}

	/**
	 * Sanitize, forcing status to the allowed vocabulary.
	 *
	 * @param array<string,mixed> $data Raw input.
	 * @return array<string,mixed>
	 */
	protected static function sanitize( array $data ) {
		$clean = parent::sanitize( $data );
		if ( isset( $clean['status'] ) && ! in_array( $clean['status'], self::STATUSES, true ) ) {
			$clean['status'] = 'needed';
		}
		return $clean;
	}

	/**
	 * All parts for a job.
	 *
	 * @param int $job_id Job id.
	 * @return array<int,array<string,mixed>>
	 */
	public static function for_job( $job_id ) {
		return self::all( array( 'job_id' => absint( $job_id ) ), array( 'orderby' => 'id', 'order' => 'ASC' ) );
	}
}
