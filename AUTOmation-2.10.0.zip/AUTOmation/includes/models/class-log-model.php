<?php
/**
 * Log model — data access for the append-only event log.
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * One row of the plugin's event log (DB v17).
 *
 * Append-only by convention: rows are written and read, never updated. Writing
 * goes through AMAT_Log, which owns the ergonomic API, secret redaction and
 * size caps — call that, not this. This class is the storage/query half.
 *
 * `context` deliberately bypasses the base sanitizers: it holds a JSON blob and
 * sanitize_textarea_field() would mangle it. AMAT_Log encodes it, so what lands
 * here is already machine-generated.
 */
class AMAT_Log_Model extends AMAT_Base_Model {

	/**
	 * Severity levels, least to most severe.
	 *
	 * @var string[]
	 */
	const LEVELS = array( 'debug', 'info', 'warning', 'error' );

	/**
	 * {@inheritDoc}
	 */
	protected static function table_slug() {
		return 'logs';
	}

	/**
	 * {@inheritDoc}
	 */
	protected static function schema() {
		return array(
			'level'       => 'text',
			'channel'     => 'text',
			'entity_type' => 'text',
			'entity_id'   => 'int',
			'message'     => 'textarea',
			'user_id'     => 'int',
		);
	}

	/**
	 * Validate the level (default 'info') and pass `context` through untouched.
	 *
	 * @param array<string,mixed> $data Raw input.
	 * @return array<string,mixed>
	 */
	protected static function sanitize( array $data ) {
		$clean = parent::sanitize( $data );

		if ( isset( $clean['level'] ) && ! in_array( $clean['level'], self::LEVELS, true ) ) {
			$clean['level'] = 'info';
		}

		// A JSON string, already built + redacted by AMAT_Log. Not run through
		// the text sanitizers, which would corrupt the encoding.
		if ( array_key_exists( 'context', $data ) ) {
			$clean['context'] = is_string( $data['context'] ) ? $data['context'] : null;
		}

		return $clean;
	}

	/**
	 * Log rows for one entity, newest first.
	 *
	 * @param string $entity_type Entity type slug (e.g. 'estimate').
	 * @param int    $entity_id   Entity id.
	 * @param int    $limit       Max rows.
	 * @return array<int,array<string,mixed>>
	 */
	public static function for_entity( $entity_type, $entity_id, $limit = 50 ) {
		return self::all(
			array(
				'entity_type' => (string) $entity_type,
				'entity_id'   => absint( $entity_id ),
			),
			array( 'orderby' => 'id', 'order' => 'DESC', 'limit' => absint( $limit ) )
		);
	}

	/**
	 * The distinct channels present in the log, for the viewer's filter.
	 *
	 * @return string[]
	 */
	public static function channels() {
		global $wpdb;
		$table = self::table();
		// No user input; trusted identifier.
		$rows = $wpdb->get_col( "SELECT DISTINCT channel FROM {$table} ORDER BY channel ASC" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery
		return array_values( array_filter( (array) $rows ) );
	}

	/**
	 * Count rows matching optional level/channel filters.
	 *
	 * @param string $level   Level slug, or '' for any.
	 * @param string $channel Channel slug, or '' for any.
	 * @return int
	 */
	public static function count_filtered( $level = '', $channel = '' ) {
		global $wpdb;
		$table = self::table();

		$sql    = "SELECT COUNT(*) FROM {$table}";
		$where  = array();
		$params = array();
		if ( '' !== $level ) {
			$where[]  = 'level = %s';
			$params[] = $level;
		}
		if ( '' !== $channel ) {
			$where[]  = 'channel = %s';
			$params[] = $channel;
		}
		if ( $where ) {
			$sql .= ' WHERE ' . implode( ' AND ', $where );
			$sql  = $wpdb->prepare( $sql, $params ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		}

		return (int) $wpdb->get_var( $sql ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery
	}

	/**
	 * Delete every log row. Returns the number removed.
	 *
	 * @return int
	 */
	public static function purge_all() {
		global $wpdb;
		$table = self::table();
		$count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery
		$wpdb->query( "DELETE FROM {$table}" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery
		return $count;
	}

	/**
	 * Delete rows older than N days.
	 *
	 * @param int $days Age in days; must be > 0.
	 * @return int Rows removed.
	 */
	public static function prune_older_than( $days ) {
		global $wpdb;

		$days = absint( $days );
		if ( $days < 1 ) {
			return 0;
		}

		$table  = self::table();
		$cutoff = gmdate( 'Y-m-d H:i:s', strtotime( "-{$days} days", (int) current_time( 'timestamp' ) ) );

		// %s value placeholder; the table name is a trusted constant.
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE created_at < %s", $cutoff ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery

		return (int) $wpdb->rows_affected;
	}
}
