<?php
/**
 * Self-hosted plugin updates, so a release can be installed from wp-admin.
 *
 * These three plugins are not on wordpress.org, so WordPress has nowhere to look
 * for updates and every deploy is a manual zip upload. That is a poor fit for the
 * one place updates actually get applied — a phone, in a driveway, away from the
 * machine that builds them. This class teaches WordPress where to look: it points
 * the update system at a JSON manifest, and from then on a new release shows up on
 * Dashboard → Updates with a one-tap **Update** button, exactly like any other
 * plugin.
 *
 * Shared by all three plugins (the companions already hard-require core, so there
 * is no independence to protect by copying it three times). Each passes its own
 * main file and manifest URL:
 *
 *     ( new AMAT_Updater( AMAT_PLUGIN_FILE, AMAT_Updater::manifest_url( 'automation' ) ) )->register();
 *
 * Two rules this follows, both learned the hard way elsewhere:
 *
 * - **Never break the updates screen.** Every failure path — no network, bad JSON,
 *   a 404 manifest — returns the transient untouched. A plugin that throws here
 *   takes down updates for the whole site, including security ones.
 * - **Never let wordpress.org answer for us.** Each plugin header carries an
 *   `Update URI:`, which tells WordPress to ignore the .org API for that plugin.
 *   Without it, a .org plugin whose slug happens to match could be served over the
 *   top of ours — WordPress matches on directory name, and "AUTOmation" is not a
 *   name we own over there.
 *
 * @package AUTOmation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Checks a JSON manifest for a newer release and feeds it to WordPress.
 */
class AMAT_Updater {

	/**
	 * Where the release manifests live: a small public repo holding only built
	 * zips and their manifests. Public because a raw.githubusercontent.com URL
	 * needs no token, which keeps credentials off the production server entirely.
	 * The zips carry no secrets — package.ps1 excludes every .env.
	 *
	 * @var string
	 */
	const MANIFEST_BASE = 'https://raw.githubusercontent.com/TurboNick/AUTOmation-Releases/main/';

	/**
	 * How long a fetched manifest is cached. Long enough not to hit GitHub on
	 * every admin page load, short enough that a release published from the
	 * workshop shows up on the phone within the hour.
	 *
	 * @var int
	 */
	const CACHE_HOURS = 1;

	/**
	 * Absolute path to the plugin's main file.
	 *
	 * @var string
	 */
	private $file;

	/**
	 * Plugin basename, e.g. `AUTOmation/automation.php` — WordPress's identity for
	 * the plugin, and the key the update transient is written under.
	 *
	 * @var string
	 */
	private $basename;

	/**
	 * Directory name, e.g. `AUTOmation`. Used as the "slug" WordPress shows.
	 *
	 * @var string
	 */
	private $slug;

	/**
	 * Currently installed version, read from the plugin header.
	 *
	 * @var string
	 */
	private $version;

	/**
	 * Manifest URL for this plugin.
	 *
	 * @var string
	 */
	private $manifest_url;

	/**
	 * @param string $file         Absolute path to the plugin's main file.
	 * @param string $manifest_url URL of this plugin's release manifest.
	 * @param string $version      Installed version. Read from the header when omitted.
	 */
	public function __construct( $file, $manifest_url, $version = '' ) {
		$this->file         = (string) $file;
		$this->manifest_url = (string) $manifest_url;
		$this->basename     = plugin_basename( $this->file );
		$this->slug         = dirname( $this->basename );
		$this->version      = (string) $version;
	}

	/**
	 * The conventional manifest URL for a plugin slug.
	 *
	 * @param string $slug Manifest name without extension (e.g. 'automation').
	 * @return string
	 */
	public static function manifest_url( $slug ) {
		return self::MANIFEST_BASE . sanitize_file_name( $slug ) . '.json';
	}

	/**
	 * Hook into WordPress's update machinery.
	 *
	 * @return void
	 */
	public function register() {
		add_filter( 'update_plugins_raw.githubusercontent.com', array( $this, 'update_uri_check' ), 10, 3 );
		add_filter( 'site_transient_update_plugins', array( $this, 'check_for_update' ) );
		add_filter( 'plugins_api', array( $this, 'plugin_info' ), 10, 3 );

		// After any plugin update, drop the cached manifest so the "up to date"
		// state is read fresh rather than from a manifest fetched pre-update.
		add_action( 'upgrader_process_complete', array( $this, 'clear_cache' ), 10, 0 );
	}

	/**
	 * Installed version, from the plugin header unless one was supplied.
	 *
	 * @return string
	 */
	private function installed_version() {
		if ( '' !== $this->version ) {
			return $this->version;
		}

		if ( ! function_exists( 'get_plugin_data' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$data          = get_plugin_data( $this->file, false, false );
		$this->version = (string) ( $data['Version'] ?? '0.0.0' );

		return $this->version;
	}

	/**
	 * Fetch (and cache) this plugin's manifest.
	 *
	 * @param bool $force Skip the cache.
	 * @return array<string,mixed>|null Manifest, or null when unavailable.
	 */
	private function manifest( $force = false ) {
		$key = 'amat_update_' . md5( $this->manifest_url );

		if ( ! $force ) {
			$cached = get_transient( $key );
			if ( is_array( $cached ) ) {
				// Validate on the way OUT of the cache as well as into it. The empty
				// array is the deliberate "fetch failed" marker, but anything else
				// malformed (a corrupted transient, a future caller priming this key)
				// would otherwise reach version_compare() and emit a PHP warning on
				// every admin page load.
				return $this->is_valid( $cached ) ? $cached : null;
			}
		}

		$response = wp_remote_get(
			$this->manifest_url,
			array(
				'timeout' => 10,
				'headers' => array( 'Accept' => 'application/json' ),
			)
		);

		if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
			// Cache the miss briefly too: an unreachable manifest must not mean a
			// fetch on every single admin page load.
			set_transient( $key, array(), 15 * MINUTE_IN_SECONDS );
			return null;
		}

		$manifest = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( ! $this->is_valid( $manifest ) ) {
			set_transient( $key, array(), 15 * MINUTE_IN_SECONDS );
			return null;
		}

		set_transient( $key, $manifest, self::CACHE_HOURS * HOUR_IN_SECONDS );
		return $manifest;
	}

	/**
	 * The minimum a manifest must carry to be worth acting on.
	 *
	 * @param mixed $manifest Decoded manifest.
	 * @return bool
	 */
	private function is_valid( $manifest ) {
		return is_array( $manifest ) && ! empty( $manifest['version'] );
	}

	/**
	 * Whether the manifest describes something newer than what is installed.
	 *
	 * @param array<string,mixed> $manifest Manifest.
	 * @return bool
	 */
	private function is_newer( array $manifest ) {
		return version_compare( (string) $manifest['version'], $this->installed_version(), '>' );
	}

	/**
	 * Shape the manifest into the object WordPress's update system expects.
	 *
	 * @param array<string,mixed> $manifest Manifest.
	 * @return object
	 */
	private function response_object( array $manifest ) {
		return (object) array(
			'id'            => $this->basename,
			'slug'          => $this->slug,
			'plugin'        => $this->basename,
			'new_version'   => (string) $manifest['version'],
			'url'           => (string) ( $manifest['homepage'] ?? '' ),
			'package'       => (string) ( $manifest['download_url'] ?? '' ),
			'icons'         => array(),
			'banners'       => array(),
			'banners_rtl'   => array(),
			'tested'        => (string) ( $manifest['tested'] ?? '' ),
			'requires_php'  => (string) ( $manifest['requires_php'] ?? '' ),
			'compatibility' => new stdClass(),
		);
	}

	/**
	 * Answer the `Update URI:` check for manifests hosted on raw.githubusercontent.com.
	 *
	 * WordPress 5.8+ routes a plugin whose header carries an `Update URI` to a
	 * hostname-specific filter instead of the .org API. This is the modern, narrow
	 * path; check_for_update() below is the belt-and-braces one for anything that
	 * bypasses it.
	 *
	 * @param array|false         $update      Update data, or false.
	 * @param array<string,mixed> $plugin_data Plugin headers.
	 * @param string              $plugin_file Plugin basename.
	 * @return array|false
	 */
	public function update_uri_check( $update, $plugin_data, $plugin_file ) {
		if ( $plugin_file !== $this->basename ) {
			return $update;
		}

		$manifest = $this->manifest();
		if ( ! $manifest || ! $this->is_newer( $manifest ) ) {
			return $update;
		}

		return array(
			'id'          => $this->basename,
			'slug'        => $this->slug,
			'version'     => (string) $manifest['version'],
			'url'         => (string) ( $manifest['homepage'] ?? '' ),
			'package'     => (string) ( $manifest['download_url'] ?? '' ),
			'tested'      => (string) ( $manifest['tested'] ?? '' ),
			'requires_php' => (string) ( $manifest['requires_php'] ?? '' ),
		);
	}

	/**
	 * Add this plugin to the update transient when a newer release exists.
	 *
	 * @param mixed $transient Update transient (object, or something else early on).
	 * @return mixed
	 */
	public function check_for_update( $transient ) {
		// Called before the transient is built on some requests; hand it straight
		// back rather than inventing structure.
		if ( ! is_object( $transient ) ) {
			return $transient;
		}

		$manifest = $this->manifest();
		if ( ! $manifest ) {
			return $transient;
		}

		if ( $this->is_newer( $manifest ) ) {
			$transient->response[ $this->basename ] = $this->response_object( $manifest );
		} else {
			// Listing it as "no update" is what makes wp-admin show a version and
			// "up to date" rather than nothing at all for an off-.org plugin.
			$transient->no_update[ $this->basename ] = $this->response_object( $manifest );
		}

		return $transient;
	}

	/**
	 * Serve the "View details" modal from the manifest.
	 *
	 * @param mixed  $result Default result.
	 * @param string $action API action.
	 * @param object $args   Request args.
	 * @return mixed
	 */
	public function plugin_info( $result, $action, $args ) {
		if ( 'plugin_information' !== $action || empty( $args->slug ) || $args->slug !== $this->slug ) {
			return $result;
		}

		$manifest = $this->manifest();
		if ( ! $manifest ) {
			return $result;
		}

		return (object) array(
			'name'          => (string) ( $manifest['name'] ?? $this->slug ),
			'slug'          => $this->slug,
			'version'       => (string) $manifest['version'],
			'author'        => (string) ( $manifest['author'] ?? '' ),
			'homepage'      => (string) ( $manifest['homepage'] ?? '' ),
			'requires'      => (string) ( $manifest['requires'] ?? '' ),
			'requires_php'  => (string) ( $manifest['requires_php'] ?? '' ),
			'tested'        => (string) ( $manifest['tested'] ?? '' ),
			'last_updated'  => (string) ( $manifest['last_updated'] ?? '' ),
			'download_link' => (string) ( $manifest['download_url'] ?? '' ),
			'sections'      => array(
				'description' => (string) ( $manifest['description'] ?? '' ),
				'changelog'   => (string) ( $manifest['changelog'] ?? '' ),
			),
		);
	}

	/**
	 * Drop this plugin's cached manifest.
	 *
	 * @return void
	 */
	public function clear_cache() {
		delete_transient( 'amat_update_' . md5( $this->manifest_url ) );
	}

	/**
	 * Drop every cached manifest (all three plugins), for a "check now" control.
	 *
	 * @return void
	 */
	public static function clear_all_caches() {
		global $wpdb;

		// Find the transients by name prefix (the key itself is a hash), then delete
		// each through delete_transient().
		//
		// NOT a bulk DELETE against wp_options, which is the obvious implementation
		// and is wrong: transients with an expiry are ordinary options, so they sit
		// in the in-memory options cache. Deleting the rows underneath that cache
		// leaves get_transient() still returning the old value for the rest of the
		// request — and worse, a later delete_option() finds no row and returns
		// early WITHOUT clearing the cache, so the stale value survives. Caught by
		// tests/test-updater.php.
		$prefix = '_transient_amat_update_';
		$names  = $wpdb->get_col( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s",
				$wpdb->esc_like( $prefix ) . '%'
			)
		);

		foreach ( (array) $names as $name ) {
			// '_transient_amat_update_abc123' -> 'amat_update_abc123'
			delete_transient( substr( (string) $name, strlen( '_transient_' ) ) );
		}
	}
}
