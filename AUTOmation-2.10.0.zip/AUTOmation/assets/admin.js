/**
 * AUTOmation admin scripts.
 *
 * - Live "First Last" preview for the display name (stored only if customized).
 * - Contact-method repeater: add/remove rows, drag to reorder (priority).
 * - Clickable customer rows.
 *
 * @package AUTOmation
 */
( function ( $ ) {
	'use strict';

	$( function () {
		initDisplayName();
		initContactRepeater();
		initPhoneMask();
		initVinDecode();
		initClickableRows();
		initVehicleExpand();
		initStateInput();
		initJobCustomerSearch();
		initJobVehicleSearch();
		initJobVinDecode();
		initLineItems();
		initReferredBy();
		initDevToolsClear();
		initDevToolsRestore();
		initPurgeLogs();
		initDocManager();
		initCopyButtons();
	} );

	/**
	 * Copy-to-clipboard buttons (e.g. the job VIN): copy the button's data-copy
	 * value and briefly show a check. Uses the async Clipboard API on a secure
	 * context, else a hidden-textarea + execCommand fallback (works on plain http
	 * local sites like automation.local).
	 */
	function initCopyButtons() {
		function copyText( text ) {
			if ( navigator.clipboard && window.isSecureContext ) {
				navigator.clipboard.writeText( text ).catch( function () {} );
				return;
			}
			var ta = document.createElement( 'textarea' );
			ta.value = text;
			ta.setAttribute( 'readonly', '' );
			ta.style.position = 'fixed';
			ta.style.opacity = '0';
			document.body.appendChild( ta );
			ta.select();
			try { document.execCommand( 'copy' ); } catch ( e ) {}
			document.body.removeChild( ta );
		}

		$( document ).on( 'click', '.amat-copy-btn', function () {
			var $btn = $( this );
			var text = $btn.attr( 'data-copy' ) || '';
			if ( ! text ) {
				return;
			}
			copyText( text );
			var $icon = $btn.find( '.dashicons' );
			$btn.addClass( 'is-copied' );
			$icon.removeClass( 'dashicons-clipboard' ).addClass( 'dashicons-yes' );
			clearTimeout( $btn.data( 'copyTimer' ) );
			$btn.data( 'copyTimer', setTimeout( function () {
				$btn.removeClass( 'is-copied' );
				$icon.removeClass( 'dashicons-yes' ).addClass( 'dashicons-clipboard' );
			}, 1200 ) );
		} );
	}

	/**
	 * Job edit page estimates/invoices manager: confirm before a Delete submit.
	 */
	function initDocManager() {
		$( document ).on( 'click', '.amat-doc-delete', function ( e ) {
			if ( ! window.confirm( 'Delete this permanently? This cannot be undone.' ) ) {
				e.preventDefault();
			}
		} );
	}

	/**
	 * Dev Tools data-clear: require a confirmation dialog before submitting the
	 * (irreversible, hard-delete) form. The server re-validates the confirm box.
	 */
	function initDevToolsClear() {
		var $form = $( '#amat-clear-data-form' );
		if ( ! $form.length ) {
			return;
		}

		var $all      = $( '#amat-clear-all' );
		var $entities = $form.find( '.amat-clear-entity' );

		// "All" subsumes the individual entities: check + lock them for clarity.
		$all.on( 'change', function () {
			var on = $all.prop( 'checked' );
			$entities.prop( 'checked', on ).prop( 'disabled', on );
		} );

		$form.on( 'submit', function ( e ) {
			var msg;
			if ( $all.prop( 'checked' ) ) {
				msg = 'This PERMANENTLY deletes ALL plugin data and resets to a '
					+ 'just-installed state. This cannot be undone.\n\nContinue?';
			} else {
				var picked = $entities.filter( ':checked' ).map( function () {
					return $.trim( $( this ).closest( 'label' ).text() );
				} ).get();
				if ( ! picked.length ) {
					return; // nothing selected — let the server return its notice
				}
				msg = 'This PERMANENTLY deletes the following and cannot be undone:\n\n'
					+ picked.join( '\n' ) + '\n\nContinue?';
			}
			if ( ! window.confirm( msg ) ) {
				e.preventDefault();
			}
		} );
	}

	/**
	 * Dev Tools restore: confirm before replacing all data from a backup file.
	 * The server re-validates the confirm box, the file format and the schema
	 * version — this is only the first line of defence.
	 */
	function initDevToolsRestore() {
		var $form = $( '#amat-restore-form' );
		if ( ! $form.length ) {
			return;
		}

		$form.on( 'submit', function ( e ) {
			var msg = 'This REPLACES all current AUTOmation data with the contents '
				+ 'of the uploaded file. Anything not in the backup is lost.\n\nContinue?';
			if ( ! window.confirm( msg ) ) {
				e.preventDefault();
			}
		} );
	}

	/**
	 * Logs page: confirm before deleting every log entry.
	 */
	function initPurgeLogs() {
		var $form = $( '#amat-purge-logs-form' );
		if ( ! $form.length ) {
			return;
		}

		$form.on( 'submit', function ( e ) {
			if ( ! window.confirm( 'Delete every log entry? This cannot be undone.' ) ) {
				e.preventDefault();
			}
		} );
	}

	/**
	 * Job form customer picker: AJAX-search customers, and on selection load that
	 * customer's vehicles/locations into the dependent selects. Only runs on the
	 * job add form (where the customer isn't locked).
	 */
	function initJobCustomerSearch() {
		var $search = $( '#amat-job-customer-search' );
		if ( ! $search.length || 'undefined' === typeof window.amatData ) {
			return;
		}

		var $results = $( '#amat-job-customer-results' );
		var $hidden  = $( '#amat-job-customer-id' );
		var $new     = $( '#amat-job-customer-new' );
		var $vehWrap = $( '#amat-job-vehicle-wrap' );
		var $loc     = $( '#amat-job-location' );
		var timer;

		// Show "(NEW)" when there's typed text but no existing customer selected
		// (display only — the typed name itself is what's saved).
		function refreshNew() {
			$new.toggle( '' === $hidden.val() && '' !== $.trim( $search.val() ) );
		}

		$search.on( 'input', function () {
			var term = $.trim( $search.val() );
			$hidden.val( '' ); // typing invalidates a prior pick until re-selected
			$vehWrap.trigger( 'amat:setvehicles', [ [] ] ); // a different customer → drop their vehicles
			refreshNew();
			clearTimeout( timer );
			timer = setTimeout( function () {
				search( term );
			}, 250 );
		} );

		function search( term ) {
			$.post( amatData.ajaxUrl, {
				action: 'amat_job_search_customers',
				nonce: amatData.custNonce,
				term: term
			} ).done( function ( resp ) {
				$results.empty();
				if ( resp && resp.success && resp.data && resp.data.length ) {
					$.each( resp.data, function ( i, c ) {
						$( '<button type="button" class="amat-search-result"></button>' )
							.text( c.name )
							.attr( 'data-id', c.id )
							.appendTo( $results );
					} );
					$results.show();
				} else {
					$results.hide();
				}
			} );
		}

		$results.on( 'click', '.amat-search-result', function () {
			var id = $( this ).attr( 'data-id' );
			$hidden.val( id );
			$search.val( $( this ).text() );
			$results.empty().hide();
			refreshNew();
			loadItems( id );
		} );

		refreshNew(); // initial state

		function loadItems( id ) {
			$.post( amatData.ajaxUrl, {
				action: 'amat_job_customer_items',
				nonce: amatData.custNonce,
				customer_id: id
			} ).done( function ( resp ) {
				if ( ! resp || ! resp.success || ! resp.data ) {
					return;
				}
				$vehWrap.trigger( 'amat:setvehicles', [ resp.data.vehicles || [] ] );
				fillLocations( $loc, resp.data.locations, resp.data.shops, resp.data.primary );
			} );
		}

		// Rebuild the Location select: customer locations first, then a "Your
		// shops" optgroup of the business's own locations.
		function fillLocations( $sel, locations, shops, primary ) {
			if ( ! $sel.length ) {
				return;
			}
			$sel.empty();
			$( '<option></option>' ).val( '0' ).text( amatData.i18n.none ).appendTo( $sel );

			appendOptions( $sel, locations, primary, amatData.i18n.customerLocations );
			appendOptions( $sel, shops, primary, amatData.i18n.yourShops );
		}

		// Append items to $sel, wrapped in an <optgroup> when a label is given.
		function appendOptions( $sel, items, selectId, groupLabel ) {
			if ( ! items || ! items.length ) {
				return;
			}
			var $target = groupLabel
				? $( '<optgroup></optgroup>' ).attr( 'label', groupLabel ).appendTo( $sel )
				: $sel;
			$.each( items, function ( i, it ) {
				var $o = $( '<option></option>' ).val( it.id ).text( it.label );
				if ( selectId && String( selectId ) === String( it.id ) ) {
					$o.prop( 'selected', true );
				}
				$o.appendTo( $target );
			} );
		}

		// Close the results when clicking outside the picker.
		$( document ).on( 'click', function ( e ) {
			if ( ! $( e.target ).closest( '#amat-job-customer-search, #amat-job-customer-results' ).length ) {
				$results.hide();
			}
		} );
	}

	/**
	 * Job form vehicle picker: a type-to-search field over the selected customer's
	 * vehicles (no AJAX — filtered client-side from a list kept in sync with the
	 * customer pick) that also accepts free text. Typing "Year Make Model" with no
	 * pick creates a new vehicle on save. Listens for 'amat:setvehicles' (fired by
	 * the customer picker) to swap the list when the customer changes.
	 */
	function initJobVehicleSearch() {
		var $wrap = $( '#amat-job-vehicle-wrap' );
		if ( ! $wrap.length ) {
			return;
		}

		var $search  = $( '#amat-job-vehicle-search' );
		var $results = $( '#amat-job-vehicle-results' );
		var $hidden  = $( '#amat-job-vehicle-id' );
		var $new     = $( '#amat-job-vehicle-new' );
		var vehicles = $wrap.data( 'vehicles' ) || [];

		function vinFor( id ) {
			var vin = '';
			$.each( vehicles, function ( i, v ) {
				if ( String( v.id ) === String( id ) ) {
					vin = v.vin || '';
					return false;
				}
			} );
			return vin;
		}

		// Show "(NEW)" when text is typed but no existing vehicle is selected.
		function refreshNew() {
			$new.toggle( '' === $hidden.val() && '' !== $.trim( $search.val() ) );
		}

		function render( term ) {
			$results.empty();
			var lower = term.toLowerCase();
			var shown = 0;
			$.each( vehicles, function ( i, v ) {
				if ( '' !== term && -1 === String( v.label ).toLowerCase().indexOf( lower ) ) {
					return;
				}
				$( '<button type="button" class="amat-search-result"></button>' )
					.text( v.label )
					.attr( 'data-id', v.id )
					.appendTo( $results );
				shown++;
			} );
			$results.toggle( shown > 0 );
		}

		$search.on( 'focus', function () {
			render( $.trim( $search.val() ) );
		} );

		$search.on( 'input', function () {
			$hidden.val( '' ); // typing invalidates a prior pick (→ new vehicle on save)
			setJobVin( '' );
			render( $.trim( $search.val() ) );
			refreshNew();
		} );

		$results.on( 'click', '.amat-search-result', function () {
			var id = $( this ).attr( 'data-id' );
			$hidden.val( id );
			$search.val( $( this ).text() );
			$results.empty().hide();
			setJobVin( vinFor( id ) );
			refreshNew();
		} );

		// The customer picker swaps the vehicle list (and clears any selection).
		$wrap.on( 'amat:setvehicles', function ( e, list ) {
			vehicles = list || [];
			$hidden.val( '' );
			$search.val( '' );
			$results.empty().hide();
			setJobVin( '' );
			refreshNew();
		} );

		refreshNew(); // initial state

		$( document ).on( 'click', function ( e ) {
			if ( ! $( e.target ).closest( '#amat-job-vehicle-wrap' ).length ) {
				$results.hide();
			}
		} );
	}

	/* --------------------------------------------------------------------- */
	/* VIN entry: live validation + decode status                            */
	/* --------------------------------------------------------------------- */

	var VIN_LENGTH = 17;

	/**
	 * Uppercase a VIN and drop separators. Mirrors AMAT_Vin_Decoder::normalize().
	 *
	 * @param {string} raw VIN as typed.
	 * @return {string} Normalized VIN.
	 */
	function vinNormalize( raw ) {
		return String( raw || '' ).toUpperCase().replace( /[^A-Z0-9]/g, '' );
	}

	/**
	 * Verify a full VIN's check digit (9th character) per ISO 3779. Mirrors
	 * AMAT_Vin_Decoder::check_digit_ok() — a mistyped character almost always
	 * breaks it. Anything shorter than 17 characters gets the benefit of the doubt.
	 *
	 * @param {string} vin Normalized VIN.
	 * @return {boolean} True when the check digit matches.
	 */
	function vinCheckDigitOk( vin ) {
		if ( VIN_LENGTH !== vin.length ) {
			return true;
		}
		var values  = { A:1, B:2, C:3, D:4, E:5, F:6, G:7, H:8, J:1, K:2, L:3, M:4, N:5, P:7, R:9, S:2, T:3, U:4, V:5, W:6, X:7, Y:8, Z:9 };
		var weights = [ 8, 7, 6, 5, 4, 3, 2, 10, 0, 9, 8, 7, 6, 5, 4, 3, 2 ];
		var sum = 0;
		for ( var i = 0; i < VIN_LENGTH; i++ ) {
			var c = vin.charAt( i );
			var v = /[0-9]/.test( c ) ? parseInt( c, 10 ) : values[ c ];
			if ( 'undefined' === typeof v ) {
				return false; // An illegal letter (I/O/Q) can never check out.
			}
			sum += v * weights[ i ];
		}
		var remainder = sum % 11;
		return vin.charAt( 8 ) === ( 10 === remainder ? 'X' : String( remainder ) );
	}

	/**
	 * Sanity-check a VIN as it's typed, so an obvious typo is caught before we
	 * spend a round trip on vPIC. Mirrors AMAT_Vin_Decoder::validate() (the
	 * server re-validates regardless — this is only for instant feedback).
	 *
	 * @param {string} raw VIN as typed.
	 * @return {{vin:string, level:string, message:string, blocking:boolean}}
	 */
	function vinCheck( raw ) {
		var vin  = vinNormalize( raw );
		var i18n = ( 'undefined' !== typeof window.amatData ) ? amatData.i18n : {};

		if ( '' === vin ) {
			return { vin: vin, level: 'ok', message: '', blocking: true };
		}

		var bad = vin.match( /[IOQ]/g );
		if ( bad ) {
			return {
				vin: vin,
				level: 'error',
				message: ( i18n.vinIllegal || 'A VIN never contains I, O or Q (found: %s).' ).replace( '%s', bad.join( ', ' ) ),
				blocking: true
			};
		}

		if ( vin.length < VIN_LENGTH ) {
			return {
				vin: vin,
				level: 'warning',
				message: ( i18n.vinPartial || 'Partial VIN — %1$d of %2$d characters.' ).replace( '%1$d', vin.length ).replace( '%2$d', VIN_LENGTH ),
				blocking: false
			};
		}

		if ( ! vinCheckDigitOk( vin ) ) {
			return { vin: vin, level: 'warning', message: i18n.vinCheckDigit || 'The check digit (9th character) does not calculate — the VIN may be mistyped.', blocking: false };
		}

		return { vin: vin, level: 'ok', message: i18n.vinValid || 'VIN looks valid.', blocking: false };
	}

	/**
	 * Render a VIN status: a headline styled by level (ok/warning/error) plus any
	 * specifics (ours, or vPIC's own wording passed back by the decode).
	 *
	 * @param {jQuery}        $status Status container.
	 * @param {string}        level   'ok' | 'warning' | 'error'.
	 * @param {string}        message Headline.
	 * @param {Array<string>} notes   Optional detail lines.
	 */
	function setVinStatus( $status, level, message, notes ) {
		$status.removeClass( 'is-ok is-warning is-error' ).empty();
		if ( ! message && ( ! notes || ! notes.length ) ) {
			return;
		}
		$status.addClass( 'is-' + ( level || 'ok' ) );
		if ( message ) {
			$status.append( $( '<p class="amat-vin-status-msg"></p>' ).text( message ) );
		}
		if ( notes && notes.length ) {
			var $ul = $( '<ul class="amat-vin-notes"></ul>' );
			$.each( notes, function ( i, note ) {
				$( '<li></li>' ).text( note ).appendTo( $ul );
			} );
			$status.append( $ul );
		}
	}

	/**
	 * Wire a VIN input to live validation: normalize what's typed (uppercase, no
	 * separators) and report on it. Returns nothing; the decode buttons call
	 * vinCheck() themselves to decide whether it's worth calling vPIC.
	 *
	 * @param {jQuery} $input  The VIN field.
	 * @param {jQuery} $status Its status container.
	 */
	function initVinField( $input, $status ) {
		if ( ! $input.length ) {
			return;
		}
		$input.on( 'input', function () {
			var check = vinCheck( $input.val() );
			if ( check.vin !== $input.val() ) {
				$input.val( check.vin ); // normalize in place, as the phone mask does
			}
			setVinStatus( $status, check.level, check.message, [] );
		} );
	}

	/**
	 * Job form: show (or clear, when passed '') the VIN of the currently-picked
	 * vehicle, with a copy button. Mirrors AMAT_Jobs_Page::render_vin_copy()'s
	 * markup — the container is server-rendered (populated for the job's saved
	 * vehicle) and this keeps it in step as the picker changes.
	 */
	function setJobVin( vin ) {
		var $box = $( '#amat-job-vin-display' );
		if ( ! $box.length ) {
			return;
		}
		$box.empty();
		vin = $.trim( vin || '' );
		if ( '' === vin ) {
			return;
		}
		var label = ( 'undefined' !== typeof window.amatData && amatData.i18n.copyVin ) ? amatData.i18n.copyVin : 'Copy VIN';
		$box.append(
			$( '<span class="amat-vin-display"></span>' )
				.append( $( '<code class="amat-vin-value"></code>' ).text( vin ) )
				.append(
					$( '<button type="button" class="button-link amat-copy-btn"></button>' )
						.attr( { 'data-copy': vin, title: label, 'aria-label': label } )
						.append( $( '<span class="dashicons dashicons-clipboard"></span>' ) )
				)
		);
	}

	/**
	 * Job form: live-decode a VIN (server hits NHTSA vPIC) to quick-add a vehicle.
	 * On success it previews "Year Make Model" in the vehicle search box and marks
	 * it NEW; the full spec is (re-)decoded and stored server-side on job save (the
	 * VIN submits as new_vehicle_vin). Reuses the vehicle-form decode endpoint.
	 */
	function initJobVinDecode() {
		var $btn = $( '#amat-job-vin-decode' );
		if ( ! $btn.length || 'undefined' === typeof window.amatData ) {
			return;
		}

		var $vin    = $( '#amat-job-vin' );
		var $year   = $( '#amat-job-vin-year' );
		var $status = $( '#amat-job-vin-status' );
		var $search = $( '#amat-job-vehicle-search' );
		var $vehId  = $( '#amat-job-vehicle-id' );
		var $new    = $( '#amat-job-vehicle-new' );

		initVinField( $vin, $status );

		$btn.on( 'click', function () {
			var check = vinCheck( $vin.val() );
			if ( check.blocking ) {
				setVinStatus( $status, 'error', check.message || amatData.i18n.vinRequired, [] );
				return;
			}
			setVinStatus( $status, 'ok', amatData.i18n.decoding, [] );
			$btn.prop( 'disabled', true );

			$.post( amatData.ajaxUrl, {
				action: 'amat_decode_vin',
				nonce: amatData.vinNonce,
				vin: check.vin,
				year: $.trim( $year.val() )
			} ).done( function ( resp ) {
				if ( ! resp || ! resp.success || ! resp.data ) {
					setVinStatus( $status, 'error', ( resp && resp.data && resp.data.message ) ? resp.data.message : amatData.i18n.failed, [] );
					return;
				}
				var d = resp.data;
				setVinStatus( $status, d.level, d.message, d.notes );

				if ( 'error' === d.level ) {
					setJobVin( '' ); // nothing identified — don't imply we have a vehicle
					return;
				}
				var f     = d.fields || {};
				var label = $.trim( [ f.year, f.make, f.model ].filter( Boolean ).join( ' ' ) );
				if ( label ) {
					$search.val( label ); // preview; VIN path wins on save regardless
					$vehId.val( '' );      // ensure a NEW vehicle is created on save
					$new.show();
				}
				setJobVin( d.vin ); // the decoded VIN is what gets stored on save
			} ).fail( function () {
				setVinStatus( $status, 'error', amatData.i18n.failed, [] );
			} ).always( function () {
				$btn.prop( 'disabled', false );
			} );
		} );
	}

	/**
	 * Expand/collapse a vehicle's detail panel in the customer view, and, when
	 * the page was deep-linked with ?expand=<id> (open on load), scroll the
	 * opened vehicle into view.
	 */
	function initVehicleExpand() {
		var $toggles = $( '.amat-veh-toggle' );
		if ( ! $toggles.length ) {
			return;
		}

		$toggles.on( 'click', function () {
			var $btn    = $( this );
			var $detail = $( '#' + $btn.attr( 'aria-controls' ) );
			var open    = 'true' === $btn.attr( 'aria-expanded' );
			$btn.attr( 'aria-expanded', open ? 'false' : 'true' );
			$detail.toggleClass( 'amat-hidden', open );
		} );

		// Scroll a pre-opened (deep-linked) vehicle into view.
		var $open = $( '.amat-veh-summary' ).filter( function () {
			return 'true' === $( this ).find( '.amat-veh-toggle' ).attr( 'aria-expanded' );
		} ).first();
		if ( $open.length && $open[ 0 ].scrollIntoView ) {
			$open[ 0 ].scrollIntoView( { block: 'center' } );
		}
	}

	/**
	 * Force the State field to uppercase as the user types (it stores a 2-letter
	 * US code; the server re-validates and re-uppercases on save).
	 */
	function initStateInput() {
		$( '.amat-state-input' ).on( 'input', function () {
			this.value = this.value.toUpperCase();
		} );
	}

	/**
	 * Decode the entered VIN via AJAX (server hits NHTSA vPIC) and fill the
	 * vehicle spec fields. Each decoded key maps to an input id of the form
	 * #amat-veh-<key>. Fields remain editable afterward.
	 */
	function initVinDecode() {
		var $btn = $( '#amat-vin-decode' );
		if ( ! $btn.length || 'undefined' === typeof window.amatData ) {
			return;
		}

		var $status = $( '#amat-vin-status' );
		var $vin    = $( '#amat-veh-vin' );

		initVinField( $vin, $status );

		$btn.on( 'click', function () {
			var check = vinCheck( $vin.val() );
			if ( check.blocking ) {
				setVinStatus( $status, 'error', check.message || amatData.i18n.vinRequired, [] );
				return;
			}

			$btn.prop( 'disabled', true );
			setVinStatus( $status, 'ok', amatData.i18n.decoding, [] );

			$.post( amatData.ajaxUrl, {
				action: 'amat_decode_vin',
				nonce: amatData.vinNonce,
				vin: check.vin,
				year: $( '#amat-veh-year' ).val()
			} ).done( function ( resp ) {
				if ( ! resp || ! resp.success || ! resp.data ) {
					setVinStatus( $status, 'error', ( resp && resp.data && resp.data.message ) ? resp.data.message : amatData.i18n.failed, [] );
					return;
				}
				var d = resp.data;
				setVinStatus( $status, d.level, d.message, d.notes );

				if ( 'error' === d.level ) {
					return; // nothing identified — leave the spec fields alone
				}
				$.each( d.fields || {}, function ( key, value ) {
					var $field = $( '#amat-veh-' + key );
					if ( $field.length ) {
						$field.val( value );
					}
				} );
			} ).fail( function () {
				setVinStatus( $status, 'error', amatData.i18n.failed, [] );
			} ).always( function () {
				$btn.prop( 'disabled', false );
			} );
		} );
	}

	/**
	 * Group raw input into a US phone display string (555-444-3333) as the
	 * user types. Mirrors the server-side normalization in
	 * AMAT_Contact_Method_Types (which still re-validates on save).
	 *
	 * @param {string} raw Raw field value.
	 * @return {string} Formatted partial/complete number.
	 */
	function formatPhone( raw ) {
		var d = ( raw || '' ).replace( /\D/g, '' );
		if ( 11 === d.length && '1' === d.charAt( 0 ) ) {
			d = d.slice( 1 );
		}
		d = d.slice( 0, 10 );

		if ( d.length > 6 ) {
			return d.slice( 0, 3 ) + '-' + d.slice( 3, 6 ) + '-' + d.slice( 6 );
		}
		if ( d.length > 3 ) {
			return d.slice( 0, 3 ) + '-' + d.slice( 3 );
		}
		return d;
	}

	/**
	 * Live-format contact values as phone numbers while a Call/Text row is
	 * being filled in or edited; re-format when the type changes.
	 */
	function initPhoneMask() {
		var $rows = $( '#amat-cm-rows' );
		if ( ! $rows.length ) {
			return;
		}

		// Every type but Email holds a phone number, so mask all non-email types.
		$rows.on( 'input', 'input[name="cm_value[]"]', function () {
			var type = $( this ).closest( '.amat-cm-row' ).find( 'select' ).val();
			if ( 'email' !== type ) {
				this.value = formatPhone( this.value );
			}
		} );

		$rows.on( 'change', 'select[name="cm_type[]"]', function () {
			var $value = $( this ).closest( '.amat-cm-row' ).find( 'input[name="cm_value[]"]' );
			if ( 'email' !== this.value ) {
				$value.val( formatPhone( $value.val() ) );
			}
		} );
	}

	/**
	 * Keep the display-name field previewing "First Last" until the user
	 * customizes it. If left uncustomized, clear it on submit so the server
	 * stores blank and falls back to "First Last" at display time.
	 */
	function initDisplayName() {
		var $display = $( '#amat-display' );
		if ( ! $display.length ) {
			return;
		}

		var $first  = $( '#amat-first' );
		var $last   = $( '#amat-last' );
		var $auto   = $( '#amat-display-auto' );
		var custom  = '1' === $display.attr( 'data-custom' );

		// Grey/italic field + visible "(Auto)" tag while the name is auto-generated;
		// both clear the moment a custom name is entered.
		function reflectAuto() {
			$display.toggleClass( 'amat-input-auto', ! custom );
			$auto.toggle( ! custom );
		}

		function preview() {
			if ( ! custom ) {
				$display.val( $.trim( $first.val() + ' ' + $last.val() ) );
			}
		}

		// Mark customized once the user edits the field directly.
		$display.on( 'input', function () {
			custom = true;
			reflectAuto();
		} );

		$first.on( 'input', preview );
		$last.on( 'input', preview );

		// Populate the initial visual for new/uncustomized records.
		preview();
		reflectAuto();

		// Don't persist an auto-generated display name.
		$display.closest( 'form' ).on( 'submit', function () {
			if ( ! custom ) {
				$display.val( '' );
			}
		} );
	}

	/**
	 * Contact-method repeater: clone the hidden template to add rows, remove
	 * rows, and enable drag-ordering (DOM order is the submitted order).
	 */
	function initContactRepeater() {
		var $rows = $( '#amat-cm-rows' );
		if ( ! $rows.length ) {
			return;
		}

		var $template = $( '.amat-cm-template' );

		$( '#amat-cm-add' ).on( 'click', function () {
			var $row = $template.clone()
				.removeClass( 'amat-cm-template' )
				.removeAttr( 'style' );
			// Template inputs are disabled so they never submit; re-enable.
			$row.find( 'select, input' ).prop( 'disabled', false );
			$rows.append( $row );
			$row.find( 'input[type="text"]' ).trigger( 'focus' );
		} );

		$rows.on( 'click', '.amat-cm-remove', function () {
			$( this ).closest( '.amat-cm-row' ).remove();
		} );

		if ( $.fn.sortable ) {
			$rows.sortable( {
				handle: '.amat-cm-handle',
				axis: 'y',
				items: '.amat-cm-row'
			} );
		}
	}

	/**
	 * Estimate/Invoice line-item repeater: a catalog search (services + parts)
	 * that appends pre-filled rows, an "Add blank line" button, and per-row remove.
	 * Each row is editable (description / qty / unit price).
	 */
	function initLineItems() {
		if ( 'undefined' === typeof window.amatData ) {
			return;
		}
		// Wire each repeater independently so many can coexist on one page (the
		// job edit page renders one per estimate/invoice sub-form).
		$( '.amat-line-items' ).each( function () {
			var $wrap = $( this );
			if ( $wrap.data( 'amatLiReady' ) ) {
				return;
			}
			$wrap.data( 'amatLiReady', true );
			initOneLineItems( $wrap );
		} );
	}

	function initOneLineItems( $wrap ) {
		var $rows     = $wrap.find( '.amat-li-rows' ).first();
		var $template = $wrap.find( '.amat-li-template' ).first();

		// Append a blank line, or one prefilled from a catalog pick.
		function addRow( values ) {
			var $row = $template.clone()
				.removeClass( 'amat-li-template' )
				.removeAttr( 'style' );
			$row.find( 'input, select' ).prop( 'disabled', false );
			if ( values ) {
				fillRow( $row, values );
			}
			$rows.append( $row );
			return $row;
		}

		// Populate a row from a catalog result and link it (programmatic .val()
		// does not fire 'input', so the link we set below is not cleared).
		function fillRow( $row, r ) {
			$row.find( '.amat-li-type' ).val( r.source_type || 'service' );
			$row.find( '.amat-li-desc' ).val( r.description || '' );
			$row.find( '.amat-li-qty' ).val( r.quantity || '1' );
			$row.find( '.amat-li-price' ).val( ( '' !== r.price && null != r.price ) ? r.price : '' );
			$row.find( '.amat-li-source-id, input[name="item_source_id[]"]' ).val( r.source_id || '0' );
		}

		function closeResults( $except ) {
			$rows.find( '.amat-li-results' ).each( function () {
				if ( ! $except || this !== $except[ 0 ] ) {
					$( this ).empty().hide();
				}
			} );
		}

		$wrap.find( '.amat-li-add' ).first().on( 'click', function () {
			addRow( null ).find( '.amat-li-desc' ).trigger( 'focus' );
		} );

		$rows.on( 'click', '.amat-li-remove', function () {
			$( this ).closest( '.amat-li-row' ).remove();
		} );

		// Star toggle: flip the hidden save-to-catalog flag + icon.
		$rows.on( 'click', '.amat-li-save', function () {
			var $btn  = $( this );
			var $flag = $btn.closest( '.amat-li-row' ).find( '.amat-li-save-flag' );
			var on    = '1' !== $flag.val();
			$flag.val( on ? '1' : '0' );
			$btn.toggleClass( 'is-on', on ).attr( 'aria-pressed', on ? 'true' : 'false' )
				.find( '.dashicons' ).toggleClass( 'dashicons-star-filled', on ).toggleClass( 'dashicons-star-empty', ! on );
		} );

		// Changing the type unlinks any catalog item (it no longer matches).
		$rows.on( 'change', '.amat-li-type', function () {
			$( this ).closest( '.amat-li-row' ).find( 'input[name="item_source_id[]"]' ).val( '0' );
		} );

		// Description doubles as the catalog type-ahead. Typing unlinks (the text no
		// longer necessarily equals the picked item) and searches both catalogs.
		$rows.on( 'input', '.amat-li-desc', function () {
			var $desc    = $( this );
			var $row     = $desc.closest( '.amat-li-row' );
			var $results = $row.find( '.amat-li-results' );
			$row.find( 'input[name="item_source_id[]"]' ).val( '0' );

			var term = $.trim( $desc.val() );
			clearTimeout( $desc.data( 'timer' ) );
			$desc.data( 'timer', setTimeout( function () {
				$.post( amatData.ajaxUrl, {
					action: 'amat_search_catalog',
					nonce: amatData.catalogNonce,
					term: term
				} ).done( function ( resp ) {
					$results.empty();
					var list = ( resp && resp.success && resp.data ) ? resp.data : [];
					$.each( list, function ( i, r ) {
						var kind = ( 'part' === r.source_type ) ? amatData.i18n.part : amatData.i18n.service;
						$( '<button type="button" class="amat-search-result"></button>' )
							.text( kind + ' · ' + r.label )
							.data( 'row', r )
							.appendTo( $results );
					} );
					$results.toggle( list.length > 0 );
				} );
			}, 250 ) );
		} );

		$rows.on( 'click', '.amat-li-results .amat-search-result', function () {
			var $btn = $( this );
			fillRow( $btn.closest( '.amat-li-row' ), $btn.data( 'row' ) );
			closeResults();
		} );

		$( document ).on( 'click', function ( e ) {
			if ( ! $( e.target ).closest( '.amat-li-desc-wrap' ).length ) {
				closeResults();
			}
		} );
	}

	/**
	 * Customer "Referred by" picker: one mobile-friendly type-to-search field that
	 * returns matching customers (AJAX, reusing the job customer-search endpoint)
	 * plus the fixed sources (Facebook/Website/Business Card). The chosen value is
	 * stored in a hidden field as 'cust:<id>' or 'src:<slug>'.
	 */
	function initReferredBy() {
		var $wrap = $( '#amat-refby-wrap' );
		if ( ! $wrap.length || 'undefined' === typeof window.amatData ) {
			return;
		}

		var $search  = $( '#amat-refby-search' );
		var $results = $( '#amat-refby-results' );
		var $hidden  = $( '#amat-refby-id' );
		var self     = String( $wrap.data( 'self' ) || '0' );
		var sources  = $wrap.data( 'sources' ) || [];
		var timer;

		function render( term, customers ) {
			$results.empty();
			var lower = term.toLowerCase();
			var shown = 0;

			// Fixed sources (filtered client-side by the typed term).
			$.each( sources, function ( i, s ) {
				if ( '' !== term && -1 === s.label.toLowerCase().indexOf( lower ) ) {
					return;
				}
				addResult( s.v, s.label );
				shown++;
			} );

			// Matching customers (skip self — can't refer themselves).
			$.each( customers || [], function ( i, c ) {
				if ( String( c.id ) === self ) {
					return;
				}
				addResult( 'cust:' + c.id, c.name );
				shown++;
			} );

			$results.toggle( shown > 0 );
		}

		function addResult( value, label ) {
			$( '<button type="button" class="amat-search-result"></button>' )
				.text( label )
				.attr( 'data-value', value )
				.appendTo( $results );
		}

		function search( term ) {
			if ( '' === term ) {
				render( '', [] ); // sources only, no customer fetch
				return;
			}
			$.post( amatData.ajaxUrl, {
				action: 'amat_job_search_customers',
				nonce: amatData.custNonce,
				term: term
			} ).done( function ( resp ) {
				render( term, ( resp && resp.success && resp.data ) ? resp.data : [] );
			} );
		}

		$search.on( 'focus', function () {
			search( $.trim( $search.val() ) );
		} );

		$search.on( 'input', function () {
			$hidden.val( '' ); // typing invalidates a prior pick until re-selected
			var term = $.trim( $search.val() );
			clearTimeout( timer );
			timer = setTimeout( function () {
				search( term );
			}, 250 );
		} );

		$results.on( 'click', '.amat-search-result', function () {
			$hidden.val( $( this ).attr( 'data-value' ) );
			$search.val( $( this ).text() );
			$results.empty().hide();
		} );

		$( '#amat-refby-clear' ).on( 'click', function () {
			$hidden.val( '' );
			$search.val( '' );
			$results.empty().hide();
		} );

		$( document ).on( 'click', function ( e ) {
			if ( ! $( e.target ).closest( '#amat-refby-wrap' ).length ) {
				$results.hide();
			}
		} );
	}

	/**
	 * Make customer table rows navigate to their edit screen on click,
	 * ignoring clicks on links so the keyboard/anchor path still works.
	 */
	function initClickableRows() {
		$( '.amat-clickable-row' ).on( 'click', function ( e ) {
			if ( $( e.target ).closest( 'a, button' ).length ) {
				return;
			}
			var href = $( this ).data( 'href' );
			if ( href ) {
				window.location = href;
			}
		} );
	}
} )( jQuery );
