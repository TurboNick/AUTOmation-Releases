<?php
/**
 * Plugin Name:       AUTOmation
 * Plugin URI:        https://mrgind.com/
 * Update URI:        https://raw.githubusercontent.com/TurboNick/AUTOmation-Releases/main/automation.json
 * Description:       Operational hub for an auto mechanic business: customers, locations, vehicles, jobs, scheduling, parts, and service history, with estimates/invoices synced to Wave (waveapps) and VINs decoded via NHTSA vPIC.
 * Version:           2.10.0
 * Requires at least: 7.0
 * Requires PHP:      8.2
 * Author:            Nick G
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       auto-mation
 * Domain Path:       /languages
 *
 * @package AUTOmation
 */

// Abort if this file is called directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Plugin version. Bump on every release.
 */
define( 'AMAT_VERSION', '2.10.0' );

/**
 * Database schema version. Bump whenever the table schema in the activator
 * changes so the upgrade routine runs on the next load. See §8 of CLAUDE.md.
 */
define( 'AMAT_DB_VERSION', '18' );

/**
 * Absolute path to the plugin directory, with trailing slash.
 */
define( 'AMAT_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

/**
 * URL to the plugin directory, with trailing slash.
 */
define( 'AMAT_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

/**
 * Main plugin file path, used for (de)activation hooks.
 */
define( 'AMAT_PLUGIN_FILE', __FILE__ );

/**
 * Option key that stores the installed DB schema version.
 */
define( 'AMAT_DB_VERSION_OPTION', 'amat_db_version' );

/**
 * Minimal autoloader for the AMAT_ class prefix.
 *
 * Maps class names like `AMAT_Customer_Model` to files using the WordPress
 * naming convention (class-customer-model.php) within /includes and its
 * sub-directories, so models/admin/public/integrations files are found
 * without a hardcoded map.
 *
 * @param string $class Fully qualified class name.
 * @return void
 */
function amat_autoload( $class ) {
	if ( 0 !== strpos( $class, 'AMAT_' ) ) {
		return;
	}

	// AMAT_Customer_Model -> customer-model
	$slug = strtolower( str_replace( '_', '-', substr( $class, strlen( 'AMAT_' ) ) ) );
	$file = 'class-' . $slug . '.php';

	$candidates = array(
		AMAT_PLUGIN_DIR . 'includes/' . $file,
		AMAT_PLUGIN_DIR . 'includes/models/' . $file,
		AMAT_PLUGIN_DIR . 'includes/admin/' . $file,
		AMAT_PLUGIN_DIR . 'includes/public/' . $file,
		AMAT_PLUGIN_DIR . 'includes/integrations/' . $file,
	);

	foreach ( $candidates as $candidate ) {
		if ( is_readable( $candidate ) ) {
			require_once $candidate;
			return;
		}
	}
}
spl_autoload_register( 'amat_autoload' );

// Activation / deactivation hooks. These classes are loaded via the autoloader.
register_activation_hook( __FILE__, array( 'AMAT_Activator', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'AMAT_Deactivator', 'deactivate' ) );

/**
 * Run the DB upgrade routine when the stored schema version is behind code.
 *
 * Lets schema changes apply on a normal page load (e.g. after `git pull`)
 * without forcing a manual deactivate/reactivate. See §8 of CLAUDE.md.
 *
 * @return void
 */
function amat_maybe_upgrade() {
	if ( get_option( AMAT_DB_VERSION_OPTION ) !== AMAT_DB_VERSION ) {
		AMAT_Activator::activate();
	}
}
add_action( 'plugins_loaded', 'amat_maybe_upgrade' );

// Daily prune of the event log to its retention window (§4 logs / AMAT_Log).
// Registered unconditionally — cron fires with no admin context.
add_action( AMAT_Log::PRUNE_HOOK, array( 'AMAT_Log', 'prune' ) );

/**
 * Load the plugin text domain for translations.
 *
 * @return void
 */
function amat_load_textdomain() {
	load_plugin_textdomain(
		'auto-mation',
		false,
		dirname( plugin_basename( __FILE__ ) ) . '/languages'
	);
}
add_action( 'init', 'amat_load_textdomain' );

/**
 * Boot the plugin once all plugins are loaded.
 *
 * Wires up the admin layer (menus, pages) and the front-end customer portal.
 *
 * @return void
 */
function amat_init() {
	if ( is_admin() ) {
		// Self-hosted updates. Admin-only: the update transient is only built and
		// read there, so a front-end request should never spend a network call on it.
		( new AMAT_Updater( AMAT_PLUGIN_FILE, AMAT_Updater::manifest_url( 'automation' ), AMAT_VERSION ) )->register();
		( new AMAT_Admin() )->register();
	} else {
		( new AMAT_Portal() )->register();
	}
}
add_action( 'plugins_loaded', 'amat_init' );
